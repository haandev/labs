var __create = Object.create;
var __getProtoOf = Object.getPrototypeOf;
var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
function __accessProp(key) {
  return this[key];
}
var __toESMCache_node;
var __toESMCache_esm;
var __toESM = (mod, isNodeMode, target) => {
  var canCache = mod != null && typeof mod === "object";
  if (canCache) {
    var cache = isNodeMode ? __toESMCache_node ??= new WeakMap : __toESMCache_esm ??= new WeakMap;
    var cached = cache.get(mod);
    if (cached)
      return cached;
  }
  target = mod != null ? __create(__getProtoOf(mod)) : {};
  const to = isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target;
  if (mod && typeof mod === "object" || typeof mod === "function") {
    for (let key of __getOwnPropNames(mod))
      if (!__hasOwnProp.call(to, key))
        __defProp(to, key, {
          get: __accessProp.bind(mod, key),
          enumerable: true
        });
  }
  if (canCache)
    cache.set(mod, to);
  return to;
};
var __commonJS = (cb, mod) => () => (mod || cb((mod = { exports: {} }).exports, mod), mod.exports);

// generated/formatter/formatter.js
var require_formatter = __commonJS(function(exports, module) {
  var ATOMIC_TOKENS = [{ name: "BEGIN", source: "(?:[bB])(?:[eE])(?:[gG])(?:[iI])(?:[nN])" }, { name: "COMMIT", source: "(?:[cC])(?:[oO])(?:[mM])(?:[mM])(?:[iI])(?:[tT])" }, { name: "ROLLBACK", source: "(?:[rR])(?:[oO])(?:[lL])(?:[lL])(?:[bB])(?:[aA])(?:[cC])(?:[kK])" }, { name: "ON", source: "(?:[oO])(?:[nN])" }, { name: "ERROR", source: "(?:[eE])(?:[rR])(?:[rR])(?:[oO])(?:[rR])" }, { name: "INSERT", source: "(?:[iI])(?:[nN])(?:[sS])(?:[eE])(?:[rR])(?:[tT])" }, { name: "UPDATE", source: "(?:[uU])(?:[pP])(?:[dD])(?:[aA])(?:[tT])(?:[eE])" }, { name: "UPSERT", source: "(?:[uU])(?:[pP])(?:[sS])(?:[eE])(?:[rR])(?:[tT])" }, { name: "DELETE", source: "(?:[dD])(?:[eE])(?:[lL])(?:[eE])(?:[tT])(?:[eE])" }, { name: "EACH", source: "(?:[eE])(?:[aA])(?:[cC])(?:[hH])" }, { name: "SOFT", source: "(?:[sS])(?:[oO])(?:[fF])(?:[tT])" }, { name: "HARD", source: "(?:[hH])(?:[aA])(?:[rR])(?:[dD])" }, { name: "SELECT", source: "(?:[sS])(?:[eE])(?:[lL])(?:[eE])(?:[cC])(?:[tT])" }, { name: "SUMMARIZE", source: "(?:[sS])(?:[uU])(?:[mM])(?:[mM])(?:[aA])(?:[rR])(?:[iI])(?:[zZ])(?:[eE])" }, { name: "FILTER", source: "(?:[fF])(?:[iI])(?:[lL])(?:[tT])(?:[eE])(?:[rR])" }, { name: "ORDER", source: "(?:[oO])(?:[rR])(?:[dD])(?:[eE])(?:[rR])" }, { name: "BY", source: "(?:[bB])(?:[yY])" }, { name: "TAKE", source: "(?:[tT])(?:[aA])(?:[kK])(?:[eE])" }, { name: "DISTINCT", source: "(?:[dD])(?:[iI])(?:[sS])(?:[tT])(?:[iI])(?:[nN])(?:[cC])(?:[tT])" }, { name: "EXPAND", source: "(?:[eE])(?:[xX])(?:[pP])(?:[aA])(?:[nN])(?:[dD])" }, { name: "FIRST", source: "(?:[fF])(?:[iI])(?:[rR])(?:[sS])(?:[tT])" }, { name: "UNION", source: "(?:[uU])(?:[nN])(?:[iI])(?:[oO])(?:[nN])" }, { name: "INTERSECT", source: "(?:[iI])(?:[nN])(?:[tT])(?:[eE])(?:[rR])(?:[sS])(?:[eE])(?:[cC])(?:[tT])" }, { name: "EXCEPT", source: "(?:[eE])(?:[xX])(?:[cC])(?:[eE])(?:[pP])(?:[tT])" }, { name: "ALL", source: "(?:[aA])(?:[lL])(?:[lL])" }, { name: "AS", source: "(?:[aA])(?:[sS])" }, { name: "OVER", source: "(?:[oO])(?:[vV])(?:[eE])(?:[rR])" }, { name: "WINDOW", source: "(?:[wW])(?:[iI])(?:[nN])(?:[dD])(?:[oO])(?:[wW])" }, { name: "LOOP", source: "(?:[lL])(?:[oO])(?:[oO])(?:[pP])" }, { name: "USING", source: "(?:[uU])(?:[sS])(?:[iI])(?:[nN])(?:[gG])" }, { name: "CASE", source: "(?:[cC])(?:[aA])(?:[sS])(?:[eE])" }, { name: "CAST", source: "(?:[cC])(?:[aA])(?:[sS])(?:[tT])" }, { name: "AND", source: "(?:[aA])(?:[nN])(?:[dD])" }, { name: "OR", source: "(?:[oO])(?:[rR])" }, { name: "NOT", source: "(?:[nN])(?:[oO])(?:[tT])" }, { name: "IF", source: "(?:[iI])(?:[fF])" }, { name: "IN", source: "(?:[iI])(?:[nN])" }, { name: "BETWEEN", source: "(?:[bB])(?:[eE])(?:[tT])(?:[wW])(?:[eE])(?:[eE])(?:[nN])" }, { name: "LIKE", source: "(?:[lL])(?:[iI])(?:[kK])(?:[eE])" }, { name: "IS", source: "(?:[iI])(?:[sS])" }, { name: "NULL_LITERAL", source: "(?:[nN])(?:[uU])(?:[lL])(?:[lL])" }, { name: "TRUE", source: "(?:[tT])(?:[rR])(?:[uU])(?:[eE])" }, { name: "FALSE", source: "(?:[fF])(?:[aA])(?:[lL])(?:[sS])(?:[eE])" }, { name: "ASC", source: "(?:[aA])(?:[sS])(?:[cC])" }, { name: "DESC", source: "(?:[dD])(?:[eE])(?:[sS])(?:[cC])" }, { name: "ROWS", source: "(?:[rR])(?:[oO])(?:[wW])(?:[sS])" }, { name: "RANGE", source: "(?:[rR])(?:[aA])(?:[nN])(?:[gG])(?:[eE])" }, { name: "PARTITION", source: "(?:[pP])(?:[aA])(?:[rR])(?:[tT])(?:[iI])(?:[tT])(?:[iI])(?:[oO])(?:[nN])" }, { name: "SORT", source: "(?:[sS])(?:[oO])(?:[rR])(?:[tT])" }, { name: "SEARCH", source: "(?:[sS])(?:[eE])(?:[aA])(?:[rR])(?:[cC])(?:[hH])" }, { name: "DERIVE", source: "(?:[dD])(?:[eE])(?:[rR])(?:[iI])(?:[vV])(?:[eE])" }, { name: "REST", source: "(?:[rR])(?:[eE])(?:[sS])(?:[tT])" }, { name: "ARRAY", source: "(?:[aA])(?:[rR])(?:[rR])(?:[aA])(?:[yY])" }, { name: "SKIPLOCK", source: "(?:[sS])(?:[kK])(?:[iI])(?:[pP])(?:[lL])(?:[oO])(?:[cC])(?:[kK])" }, { name: "NOWAIT", source: "(?:[nN])(?:[oO])(?:[wW])(?:[aA])(?:[iI])(?:[tT])" }, { name: "LINK", source: "(?:[lL])(?:[iI])(?:[nN])(?:[kK])" }, { name: "SOURCE", source: "(?:[sS])(?:[oO])(?:[uU])(?:[rR])(?:[cC])(?:[eE])" }, { name: "TARGET", source: "(?:[tT])(?:[aA])(?:[rR])(?:[gG])(?:[eE])(?:[tT])" }, { name: "MULTI", source: "(?:[mM])(?:[uU])(?:[lL])(?:[tT])(?:[iI])" }, { name: "CONFLICT", source: "(?:[cC])(?:[oO])(?:[nN])(?:[fF])(?:[lL])(?:[iI])(?:[cC])(?:[tT])" }, { name: "DO", source: "(?:[dD])(?:[oO])" }, { name: "NOTHING", source: "(?:[nN])(?:[oO])(?:[tT])(?:[hH])(?:[iI])(?:[nN])(?:[gG])" }, { name: "HAS", source: "(?:[hH])(?:[aA])(?:[sS])" }, { name: "OF", source: "(?:[oO])(?:[fF])" }, { name: "CURRENT_DATE", source: "(?:[cC])(?:[uU])(?:[rR])(?:[rR])(?:[eE])(?:[nN])(?:[tT])_(?:[dD])(?:[aA])(?:[tT])(?:[eE])" }, { name: "CURRENT_TIME", source: "(?:[cC])(?:[uU])(?:[rR])(?:[rR])(?:[eE])(?:[nN])(?:[tT])_(?:[tT])(?:[iI])(?:[mM])(?:[eE])" }, { name: "CURRENT_TIMESTAMP", source: "(?:[cC])(?:[uU])(?:[rR])(?:[rR])(?:[eE])(?:[nN])(?:[tT])_(?:[tT])(?:[iI])(?:[mM])(?:[eE])(?:[sS])(?:[tT])(?:[aA])(?:[mM])(?:[pP])" }, { name: "LOCALTIME", source: "(?:[lL])(?:[oO])(?:[cC])(?:[aA])(?:[lL])(?:[tT])(?:[iI])(?:[mM])(?:[eE])" }, { name: "LOCALTIMESTAMP", source: "(?:[lL])(?:[oO])(?:[cC])(?:[aA])(?:[lL])(?:[tT])(?:[iI])(?:[mM])(?:[eE])(?:[sS])(?:[tT])(?:[aA])(?:[mM])(?:[pP])" }, { name: "DEFAULT", source: "(?:[dD])(?:[eE])(?:[fF])(?:[aA])(?:[uU])(?:[lL])(?:[tT])" }, { name: "REQUIRED", source: "(?:[rR])(?:[eE])(?:[qQ])(?:[uU])(?:[iI])(?:[rR])(?:[eE])(?:[dD])" }, { name: "DEFINE", source: "(?:[dD])(?:[eE])(?:[fF])(?:[iI])(?:[nN])(?:[eE])" }, { name: "IMPORT", source: "(?:[iI])(?:[mM])(?:[pP])(?:[oO])(?:[rR])(?:[tT])" }, { name: "EXPOSE", source: "(?:[eE])(?:[xX])(?:[pP])(?:[oO])(?:[sS])(?:[eE])" }, { name: "DROP", source: "(?:[dD])(?:[rR])(?:[oO])(?:[pP])" }, { name: "REPLACE", source: "(?:[rR])(?:[eE])(?:[pP])(?:[lL])(?:[aA])(?:[cC])(?:[eE])" }, { name: "END", source: "(?:[eE])(?:[nN])(?:[dD])" }, { name: "POLICY", source: "(?:[pP])(?:[oO])(?:[lL])(?:[iI])(?:[cC])(?:[yY])" }, { name: "CAN", source: "(?:[cC])(?:[aA])(?:[nN])" }, { name: "GRANT", source: "(?:[gG])(?:[rR])(?:[aA])(?:[nN])(?:[tT])" }, { name: "PREVENT", source: "(?:[pP])(?:[rR])(?:[eE])(?:[vV])(?:[eE])(?:[nN])(?:[tT])" }, { name: "ALTER", source: "(?:[aA])(?:[lL])(?:[tT])(?:[eE])(?:[rR])" }, { name: "DELEGATE", source: "(?:[dD])(?:[eE])(?:[lL])(?:[eE])(?:[gG])(?:[aA])(?:[tT])(?:[eE])" }, { name: "DELEGATION", source: "(?:[dD])(?:[eE])(?:[lL])(?:[eE])(?:[gG])(?:[aA])(?:[tT])(?:[iI])(?:[oO])(?:[nN])" }, { name: "REVOKE", source: "(?:[rR])(?:[eE])(?:[vV])(?:[oO])(?:[kK])(?:[eE])" }, { name: "TO", source: "(?:[tT])(?:[oO])" }, { name: "STARTS", source: "(?:[sS])(?:[tT])(?:[aA])(?:[rR])(?:[tT])(?:[sS])" }, { name: "UNTIL", source: "(?:[uU])(?:[nN])(?:[tT])(?:[iI])(?:[lL])" }, { name: "SERVICE", source: "(?:[sS])(?:[eE])(?:[rR])(?:[vV])(?:[iI])(?:[cC])(?:[eE])" }, { name: "TRUSTED", source: "(?:[tT])(?:[rR])(?:[uU])(?:[sS])(?:[tT])(?:[eE])(?:[dD])" }, { name: "PUBLIC", source: "(?:[pP])(?:[uU])(?:[bB])(?:[lL])(?:[iI])(?:[cC])" }, { name: "ELEVATED", source: "(?:[eE])(?:[lL])(?:[eE])(?:[vV])(?:[aA])(?:[tT])(?:[eE])(?:[dD])" }, { name: "ROW_NUMBER", source: "(?:[rR])(?:[oO])(?:[wW])_(?:[nN])(?:[uU])(?:[mM])(?:[bB])(?:[eE])(?:[rR])" }, { name: "RANK", source: "(?:[rR])(?:[aA])(?:[nN])(?:[kK])" }, { name: "DENSE_RANK", source: "(?:[dD])(?:[eE])(?:[nN])(?:[sS])(?:[eE])_(?:[rR])(?:[aA])(?:[nN])(?:[kK])" }, { name: "PERCENT_RANK", source: "(?:[pP])(?:[eE])(?:[rR])(?:[cC])(?:[eE])(?:[nN])(?:[tT])_(?:[rR])(?:[aA])(?:[nN])(?:[kK])" }, { name: "CUME_DIST", source: "(?:[cC])(?:[uU])(?:[mM])(?:[eE])_(?:[dD])(?:[iI])(?:[sS])(?:[tT])" }, { name: "NTILE", source: "(?:[nN])(?:[tT])(?:[iI])(?:[lL])(?:[eE])" }, { name: "LAG", source: "(?:[lL])(?:[aA])(?:[gG])" }, { name: "LEAD", source: "(?:[lL])(?:[eE])(?:[aA])(?:[dD])" }, { name: "FIRST_VALUE", source: "(?:[fF])(?:[iI])(?:[rR])(?:[sS])(?:[tT])_(?:[vV])(?:[aA])(?:[lL])(?:[uU])(?:[eE])" }, { name: "LAST_VALUE", source: "(?:[lL])(?:[aA])(?:[sS])(?:[tT])_(?:[vV])(?:[aA])(?:[lL])(?:[uU])(?:[eE])" }, { name: "NTH_VALUE", source: "(?:[nN])(?:[tT])(?:[hH])_(?:[vV])(?:[aA])(?:[lL])(?:[uU])(?:[eE])" }, { name: "ASSIGN", source: ":=" }, { name: "CONDITIONAL_ASSIGN", source: "\\?=" }, { name: "ARROW", source: "->" }, { name: "SPREAD", source: "\\.\\.\\." }, { name: "EQ", source: "==" }, { name: "EQUALS", source: "=" }, { name: "NEQ", source: "!=" }, { name: "BANG", source: "!" }, { name: "LT", source: "<" }, { name: "GT", source: ">" }, { name: "LTE", source: "<=" }, { name: "GTE", source: ">=" }, { name: "PLUS", source: "\\+" }, { name: "MINUS", source: "-" }, { name: "STAR", source: "\\*" }, { name: "SLASH", source: "/" }, { name: "PERCENT", source: "%" }, { name: "DOT", source: "\\." }, { name: "HASH", source: "#" }, { name: "RANGE_OP", source: "\\.\\." }, { name: "CAST_OP", source: "::" }, { name: "PIPE", source: "\\|" }, { name: "COLON", source: ":" }, { name: "COMMA", source: "," }, { name: "SEMICOLON", source: ";" }, { name: "LPAREN", source: "\\(" }, { name: "RPAREN", source: "\\)" }, { name: "LBRACKET", source: "\\[" }, { name: "RBRACKET", source: "\\]" }, { name: "LBRACE", source: "\\{" }, { name: "RBRACE", source: "\\}" }, { name: "FULLTEXT_MATCH", source: "@@" }, { name: "REGEX_MATCH", source: "~" }, { name: "REGEX_MATCH_CI", source: "~\\*" }, { name: "NOT_REGEX_MATCH", source: "!~" }, { name: "NOT_REGEX_MATCH_CI", source: "!~\\*" }, { name: "RANGE_CONTAINS", source: "@>|(?:[cC])(?:[oO])(?:[nN])(?:[tT])(?:[aA])(?:[iI])(?:[nN])(?:[sS])" }, { name: "RANGE_CONTAINED_BY", source: "<@|(?:[cC])(?:[oO])(?:[nN])(?:[tT])(?:[aA])(?:[iI])(?:[nN])(?:[eE])(?:[dD])[ \\t\\r\\n]+(?:[bB])(?:[yY])" }, { name: "RANGE_OVERLAPS", source: "&&|(?:[oO])(?:[vV])(?:[eE])(?:[rR])(?:[lL])(?:[aA])(?:[pP])(?:[sS])" }, { name: "RANGE_ADJACENT", source: "-\\|-|(?:[aA])(?:[dD])(?:[jJ])(?:[aA])(?:[cC])(?:[eE])(?:[nN])(?:[tT])" }, { name: "RANGE_STRICTLY_LEFT", source: "<<|(?:[sS])(?:[tT])(?:[rR])(?:[iI])(?:[cC])(?:[tT])(?:[lL])(?:[yY])[ \\t\\r\\n]+(?:[lL])(?:[eE])(?:[fF])(?:[tT])" }, { name: "RANGE_STRICTLY_RIGHT", source: ">>|(?:[sS])(?:[tT])(?:[rR])(?:[iI])(?:[cC])(?:[tT])(?:[lL])(?:[yY])[ \\t\\r\\n]+(?:[rR])(?:[iI])(?:[gG])(?:[hH])(?:[tT])" }, { name: "NULLISH_COALESCE", source: "\\?\\?" }, { name: "JSONB_KEY_EXISTS", source: "\\?" }, { name: "JSONB_ALL_KEYS_EXIST", source: "\\?&" }, { name: "JSONB_ANY_KEY_EXISTS", source: "\\?\\|" }, { name: "JSONB_PATH", source: "#>" }, { name: "JSONB_PATH_TEXT", source: "#>>" }, { name: "INLINE_SQL", source: "\\$sql`(?:[^`]|``)*`" }, { name: "BACKTICK", source: "`" }, { name: "LINK_LOOKUP_STRICT", source: "@!" }, { name: "LINK_LOOKUP_NULLABLE", source: "@\\?" }, { name: "LOOKUP_STRICT", source: "(?:[lL])(?:[oO])(?:[oO])(?:[kK])(?:[uU])(?:[pP])" }, { name: "LOOKUP_NULLABLE", source: "(?:[lL])(?:[oO])(?:[oO])(?:[kK])(?:[uU])(?:[pP])\\?" }, { name: "CONST_REF", source: "\\$<[a-zA-Z_][a-zA-Z_0-9]*(?:\\.[a-zA-Z_][a-zA-Z_0-9]*)?>" }, { name: "COLUMN_REF", source: "\\$ref" }, { name: "PARAM_REF", source: "\\$\\{[a-zA-Z_][a-zA-Z0-9_.]*(?:[ \\t]*\\?\\?[ \\t]*[^}]+)?\\}" }, { name: "DYNAMIC_TABLE_REF", source: "\\$\\$[a-zA-Z_][a-zA-Z0-9_]*" }, { name: "CHOICES_REF", source: "\\$choices" }, { name: "CHOICE_REF", source: "\\$choice" }, { name: "CTE_REF", source: "\\$[a-zA-Z_][a-zA-Z0-9_]*" }, { name: "ANNOTATION", source: "@[a-z]+" }, { name: "IDENTIFIER", source: "[a-zA-Z_][a-zA-Z0-9_]*" }, { name: "QUOTED_IDENTIFIER", source: "`(?:[^`]|``)*`" }, { name: "INTEGER", source: "[0-9]+" }, { name: "DECIMAL", source: "[0-9]+\\.[0-9]+" }, { name: "STRING", source: `'(?:[^']|'')*'|"(?:[^"]|"")*"` }, { name: "LINE_COMMENT", source: "//[^\\r\\n]*" }, { name: "BLOCK_COMMENT", source: "/\\*[\\s\\S]*?\\*/" }].map((t) => ({
    name: t.name,
    re: new RegExp(t.source, "y")
  }));
  var TOP_CLAUSE_KEYWORDS = new Set(["SELECT", "SUMMARIZE", "INSERT", "UPDATE", "UPSERT", "DELETE", "FILTER", "SORT", "TAKE", "BY", "DERIVE", "UNION", "INTERSECT", "EXCEPT", "OVER", "PARTITION", "LINK", "LOOP", "USING", "WINDOW", "RANK", "ON", "HAS"]);
  var CLAUSE_PREFIX_KEYWORDS = new Set(["REQUIRED"]);
  var POST_BLOCK_KEYWORDS = new Set(["FILTER", "SORT", "TAKE", "BY", "DERIVE"]);
  var BLOCK_START_KEYWORDS = new Set(["BEGIN", "CASE"]);
  var BLOCK_END_KEYWORDS = new Set(["COMMIT", "ROLLBACK"]);
  var GAP_SENSITIVE_PREFIXES = new Set(["<", ">", "#"]);
  var LINK_OPERAND_START = /^[a-zA-Z_`]/;
  var SPACED_OPERATORS = [":=", "->", "==", "!=", "<=", ">=", "+", "-", "*", "/", "%"];
  var SPACED_WORD_OPERATORS = ["AND", "OR"];

  class Formatter {
    constructor(options = {}) {
      this.indent = options.indent || "  ";
    }
    format(text) {
      const tokens = this.tokenize(text);
      const formatted = this.buildFormattedOutput(tokens);
      return this.finalCleanup(formatted);
    }
    tokenize(text) {
      const tokens = [];
      let i = 0;
      let previousEnd = -1;
      while (i < text.length) {
        if (/\s/.test(text[i])) {
          i++;
          continue;
        }
        let bestLength = 0;
        let bestName = "";
        for (const token of ATOMIC_TOKENS) {
          token.re.lastIndex = i;
          const match = token.re.exec(text);
          if (match && match[0].length > bestLength) {
            bestLength = match[0].length;
            bestName = token.name;
          }
        }
        const length = bestLength === 0 ? 1 : bestLength;
        const matched = text.slice(i, i + length);
        const gluedToPrevious = i === previousEnd;
        previousEnd = i + length;
        i += length;
        const previous = tokens[tokens.length - 1];
        if (gluedToPrevious && previous && GAP_SENSITIVE_PREFIXES.has(previous.text) && LINK_OPERAND_START.test(matched)) {
          previous.text += matched;
          continue;
        }
        tokens.push({ name: bestLength === 0 ? "UNKNOWN" : bestName, text: matched });
      }
      return tokens;
    }
    buildFormattedOutput(tokens) {
      const lines = [];
      let currentLine = [];
      let depth = 0;
      let i = 0;
      const pushLine = () => {
        if (currentLine.length > 0) {
          const lineContent = this.formatLine(currentLine);
          const indentStr = this.indent.repeat(depth);
          lines.push(indentStr + lineContent);
          currentLine = [];
        }
      };
      while (i < tokens.length) {
        const token = tokens[i];
        const nextToken = tokens[i + 1];
        const prevToken = tokens[i - 1];
        if (token.name === "LINE_COMMENT" || token.name === "BLOCK_COMMENT") {
          pushLine();
          lines.push(this.indent.repeat(depth) + token.text);
          i++;
          continue;
        }
        if (token.text === "{") {
          const blockContent = this.getBlockContent(tokens, i + 1);
          if (blockContent.isSingleItem) {
            currentLine.push(token);
            for (const t of blockContent.tokens) {
              currentLine.push(t);
            }
            currentLine.push(tokens[blockContent.endIndex] || { name: "UNKNOWN", text: "}" });
            i = blockContent.endIndex + 1;
            if (tokens[i] && (tokens[i].text === "->" || tokens[i].text === ";")) {
              currentLine.push(tokens[i]);
              i++;
            }
            continue;
          }
          currentLine.push(token);
          pushLine();
          depth++;
          i++;
          continue;
        }
        if (token.text === "}") {
          pushLine();
          depth = Math.max(0, depth - 1);
          currentLine.push(token);
          if (nextToken && (nextToken.text === "->" || nextToken.text === ";")) {
            currentLine.push(nextToken);
            i++;
          }
          pushLine();
          i++;
          continue;
        }
        if (token.text === "[") {
          currentLine.push(token);
          i++;
          continue;
        }
        if (token.text === "]") {
          currentLine.push(token);
          i++;
          continue;
        }
        if (token.text === ";") {
          currentLine.push(token);
          pushLine();
          i++;
          continue;
        }
        if (token.text === ",") {
          currentLine.push(token);
          if (depth > 0) {
            pushLine();
          }
          i++;
          continue;
        }
        if (depth === 0 && TOP_CLAUSE_KEYWORDS.has(token.text.toUpperCase())) {
          const prefixes = [];
          while (currentLine.length > 0 && CLAUSE_PREFIX_KEYWORDS.has(currentLine[currentLine.length - 1].text.toUpperCase())) {
            prefixes.unshift(currentLine.pop());
          }
          if (currentLine.length > 0 || prefixes.length === 0) {
            pushLine();
          }
          currentLine.push(...prefixes, token);
          i++;
          continue;
        }
        if (depth === 0 && POST_BLOCK_KEYWORDS.has(token.text.toUpperCase()) && (prevToken && prevToken.text === "}" || lines.length > 0 && lines[lines.length - 1].trim().endsWith("}"))) {
          pushLine();
          currentLine.push(token);
          i++;
          continue;
        }
        if (BLOCK_END_KEYWORDS.has(token.text.toUpperCase()) && depth > 0) {
          pushLine();
          depth = Math.max(0, depth - 1);
          currentLine.push(token);
          i++;
          continue;
        }
        if (BLOCK_START_KEYWORDS.has(token.text.toUpperCase())) {
          pushLine();
          currentLine.push(token);
          while (tokens[i + 1] && /^[a-zA-Z_]+$/.test(tokens[i + 1].text) && !BLOCK_START_KEYWORDS.has(tokens[i + 1].text.toUpperCase()) && !BLOCK_END_KEYWORDS.has(tokens[i + 1].text.toUpperCase())) {
            currentLine.push(tokens[i + 1]);
            i++;
          }
          if (tokens[i + 1] && tokens[i + 1].text === ";") {
            currentLine.push(tokens[i + 1]);
            i++;
          }
          pushLine();
          depth++;
          i++;
          continue;
        }
        currentLine.push(token);
        i++;
      }
      pushLine();
      return lines.join(`
`);
    }
    formatLine(tokens) {
      if (tokens.length === 0)
        return "";
      let result = "";
      for (let i = 0;i < tokens.length; i++) {
        const token = tokens[i];
        const prevToken = tokens[i - 1];
        const upper = token.text.toUpperCase();
        const prevUpper = prevToken ? prevToken.text.toUpperCase() : "";
        let needsSpaceBefore = i > 0;
        if (prevToken && ["(", "[", "."].includes(prevToken.text)) {
          needsSpaceBefore = false;
        }
        if ([")", "]", ",", ";", ".", "::", ".."].includes(token.text)) {
          needsSpaceBefore = false;
        }
        if (token.text === "(" && prevToken && /^[a-zA-Z_][a-zA-Z0-9_]*$/.test(prevToken.text)) {
          needsSpaceBefore = false;
        }
        if (token.text === "::" || prevToken && prevToken.text === "::") {
          needsSpaceBefore = false;
        }
        if (token.text === ".." || prevToken && prevToken.text === "..") {
          needsSpaceBefore = false;
        }
        if (token.text === "." || prevToken && prevToken.text === ".") {
          needsSpaceBefore = false;
        }
        if (token.text === "{") {
          needsSpaceBefore = true;
        }
        if (SPACED_OPERATORS.includes(token.text) || SPACED_WORD_OPERATORS.includes(upper)) {
          needsSpaceBefore = true;
        }
        if (prevToken && (SPACED_OPERATORS.includes(prevToken.text) || SPACED_WORD_OPERATORS.includes(prevUpper) || prevToken.text === ":")) {
          needsSpaceBefore = true;
        }
        if (token.text === "*" && prevToken && prevToken.text === "(") {
          needsSpaceBefore = false;
        }
        if (token.text === ")" && prevToken && prevToken.text === "*") {
          needsSpaceBefore = false;
        }
        if (prevToken && (prevToken.text === "+" || prevToken.text === "-") && /^[a-zA-Z_`]/.test(token.text)) {
          const sortKeywords = ["SORT", "BY"];
          for (let j = i - 2;j >= 0 && j >= i - 5; j--) {
            if (sortKeywords.includes(tokens[j].text.toUpperCase())) {
              needsSpaceBefore = false;
              break;
            }
            if (tokens[j].text === "," || tokens[j].text === "{" || tokens[j].text === ";") {
              break;
            }
          }
        }
        if (needsSpaceBefore && result.length > 0 && !result.endsWith(" ")) {
          result += " ";
        }
        result += token.text;
      }
      return result;
    }
    getBlockContent(tokens, startIndex) {
      const content = [];
      let depth = 1;
      let hasComma = false;
      let i = startIndex;
      while (i < tokens.length && depth > 0) {
        const token = tokens[i];
        if (token.text === "{") {
          depth++;
          content.push(token);
        } else if (token.text === "}") {
          depth--;
          if (depth === 0) {
            break;
          }
          content.push(token);
        } else if (token.text === "," && depth === 1) {
          hasComma = true;
          content.push(token);
        } else {
          content.push(token);
        }
        i++;
      }
      return {
        endIndex: i,
        isSingleItem: !hasComma && content.length > 0,
        tokens: content
      };
    }
    finalCleanup(text) {
      text = text.replace(/\n{3,}/g, `

`);
      text = text.split(`
`).map((line) => line.trimEnd()).join(`
`);
      text = text.trimEnd() + `
`;
      return text;
    }
  }
  module.exports = { Formatter };
});

// generated/formatter/index.ts
var import_formatter = __toESM(require_formatter(), 1);
var export_Formatter = import_formatter.Formatter;

export {
  export_Formatter as Formatter
};
