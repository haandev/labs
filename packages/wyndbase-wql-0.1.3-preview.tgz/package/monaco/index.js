// generated/monaco/wql.monarch.ts
var monarchLanguage = {
  defaultToken: "",
  tokenPostfix: ".wql",
  ignoreCase: true,
  keywords: [
    "BEGIN",
    "COMMIT",
    "ROLLBACK",
    "INSERT",
    "UPDATE",
    "UPSERT",
    "DELETE",
    "EACH",
    "SOFT",
    "HARD",
    "SUMMARIZE",
    "FILTER",
    "ORDER",
    "BY",
    "TAKE",
    "DISTINCT",
    "EXPAND",
    "FIRST",
    "UNION",
    "INTERSECT",
    "EXCEPT",
    "ALL",
    "AS",
    "OVER",
    "WINDOW",
    "LOOP",
    "USING",
    "CASE",
    "CAST",
    "AND",
    "OR",
    "NOT",
    "IF",
    "IN",
    "BETWEEN",
    "LIKE",
    "IS",
    "ASC",
    "DESC",
    "ROWS",
    "RANGE",
    "PARTITION",
    "SORT",
    "SEARCH",
    "DERIVE",
    "REST",
    "ARRAY",
    "SKIPLOCK",
    "NOWAIT",
    "LINK",
    "SOURCE",
    "TARGET",
    "MULTI",
    "CONFLICT",
    "DO",
    "NOTHING",
    "HAS",
    "OF",
    "LOCALTIME",
    "LOCALTIMESTAMP",
    "DEFAULT",
    "REQUIRED",
    "DEFINE",
    "IMPORT",
    "EXPOSE",
    "DROP",
    "REPLACE",
    "END",
    "POLICY",
    "CAN",
    "GRANT",
    "PREVENT",
    "ALTER",
    "DELEGATE",
    "DELEGATION",
    "REVOKE",
    "TO",
    "STARTS",
    "UNTIL",
    "SERVICE",
    "TRUSTED",
    "PUBLIC",
    "ELEVATED",
    "RANK",
    "NTILE",
    "LAG",
    "LEAD",
    "INLINE_SQL",
    "LOOKUP_STRICT",
    "LOOKUP_NULLABLE",
    "SELECT",
    "ON",
    "TRUE",
    "FALSE",
    "INT",
    "INTEGER",
    "FLOAT",
    "DECIMAL",
    "STRING",
    "TEXT",
    "BOOLEAN",
    "DATE",
    "DATETIME",
    "TIMESTAMP",
    "UUID",
    "JSON",
    "JSONB",
    "ARRAY",
    "BLOB",
    "COUNT",
    "SUM",
    "AVG",
    "MIN",
    "MAX",
    "COALESCE",
    "NULLIF",
    "CAST",
    "EXTRACT",
    "NOW",
    "CURRENT_DATE",
    "CURRENT_TIME",
    "CURRENT_TIMESTAMP",
    "ROW_NUMBER",
    "RANK",
    "DENSE_RANK",
    "PERCENT_RANK",
    "CUME_DIST",
    "NTILE",
    "LAG",
    "LEAD",
    "FIRST_VALUE",
    "LAST_VALUE",
    "NTH_VALUE",
    "STRING_AGG",
    "ARRAY_AGG",
    "JSON_AGG",
    "JSONB_AGG"
  ],
  windowFunctions: [
    "ROW_NUMBER",
    "RANK",
    "DENSE_RANK",
    "PERCENT_RANK",
    "CUME_DIST",
    "NTILE",
    "LAG",
    "LEAD",
    "FIRST_VALUE",
    "LAST_VALUE",
    "NTH_VALUE",
    "COUNT",
    "SUM",
    "AVG",
    "MIN",
    "MAX",
    "COALESCE",
    "NULLIF",
    "CAST",
    "EXTRACT",
    "NOW",
    "CURRENT_DATE",
    "CURRENT_TIME",
    "CURRENT_TIMESTAMP",
    "STRING_AGG",
    "ARRAY_AGG",
    "JSON_AGG",
    "JSONB_AGG"
  ],
  typeKeywords: [
    "INT",
    "INTEGER",
    "BIGINT",
    "SMALLINT",
    "DECIMAL",
    "NUMERIC",
    "REAL",
    "FLOAT",
    "DOUBLE",
    "VARCHAR",
    "CHAR",
    "TEXT",
    "STRING",
    "BOOLEAN",
    "BOOL",
    "DATE",
    "TIME",
    "TIMESTAMP",
    "TIMESTAMPTZ",
    "JSON",
    "JSONB",
    "UUID",
    "BYTEA",
    "ARRAY"
  ],
  operators: [
    ":=",
    "?=",
    "...",
    "==",
    "=",
    "!=",
    "<",
    ">",
    "<=",
    ">=",
    "+",
    "-",
    "*",
    "/",
    "%",
    "..",
    "::",
    "|",
    "@@",
    "~",
    "~*",
    "!~",
    "!~*",
    "??",
    "?",
    "?&",
    "?|",
    "#>",
    "#>>",
    "@!",
    "@?",
    "$<",
    "$ref",
    "$$",
    "$choices",
    "$choice",
    "!",
    ".",
    "#",
    ":",
    ",",
    ";",
    "(",
    ")",
    "[",
    "]",
    "{",
    "}",
    "`"
  ],
  symbols: /[=><!~?:&|+\-*/\^%@#]+/,
  escapes: /\\(?:[abfnrtv\\"']|x[0-9A-Fa-f]{1,4}|u[0-9A-Fa-f]{4}|U[0-9A-Fa-f]{8})/,
  tokenizer: {
    root: [
      { include: "@whitespace" },
      [/\/\/.*$/, "comment"],
      [/\/\*/, "comment", "@comment"],
      [/'/, "string", "@string_0"],
      [/"/, "string", "@string_1"],
      [/[0-9]+\.[0-9]+/, "number.float"],
      [/[0-9]+/, "number"],
      [/\$context(?:\.[a-zA-Z_][a-zA-Z0-9_]*)*/, "variable.predefined"],
      [/\$sql`(?:[^`]|``)*`/, "keyword.special"],
      [/\$[a-zA-Z_][a-zA-Z0-9_]*/, "variable"],
      [/`(?:[^`]|``)*`/, "identifier.quoted"],
      [/@[!?]/, "operator.link"],
      [/[a-zA-Z_][a-zA-Z0-9_]*/, {
        cases: {
          "@keywords": "keyword",
          "@windowFunctions": "function.window",
          "@typeKeywords": "type",
          "true|false": "constant.boolean",
          null: "constant.null",
          "@default": "identifier"
        }
      }],
      [/[{}\[\]()]/, "@brackets"],
      [/@symbols/, {
        cases: {
          "@operators": "operator",
          "@default": ""
        }
      }],
      [/[,;]/, "delimiter"]
    ],
    comment: [
      [/[^/*]+/, "comment"],
      [/\*\//, "comment", "@pop"],
      [/[/*]/, "comment"]
    ],
    string_0: [
      [/[^']+/, "string"],
      [/''/, "string.escape"],
      [/'/, "string", "@pop"]
    ],
    string_1: [
      [/[^"]+/, "string"],
      [/""/, "string.escape"],
      [/"/, "string", "@pop"]
    ],
    whitespace: [
      [/[ \t\r\n]+/, "white"]
    ]
  },
  brackets: [
    { open: "{", close: "}", token: "delimiter.curly" },
    { open: "[", close: "]", token: "delimiter.bracket" },
    { open: "(", close: ")", token: "delimiter.parenthesis" }
  ]
};

// generated/monaco/wql.language.ts
var languageConfiguration = {
  comments: {
    lineComment: "//",
    blockComment: ["/*", "*/"]
  },
  brackets: [
    ["{", "}"],
    ["[", "]"],
    ["(", ")"]
  ],
  autoClosingPairs: [
    { open: "{", close: "}" },
    { open: "[", close: "]" },
    { open: "(", close: ")" },
    { open: "'", close: "'", notIn: ["string", "comment"] },
    { open: '"', close: '"', notIn: ["string", "comment"] },
    { open: "/*", close: " */", notIn: ["string"] }
  ],
  surroundingPairs: [
    { open: "{", close: "}" },
    { open: "[", close: "]" },
    { open: "(", close: ")" },
    { open: "'", close: "'" },
    { open: '"', close: '"' }
  ],
  folding: {
    markers: {
      start: new RegExp("^\\s*\\/\\/\\s*#?region\\b"),
      end: new RegExp("^\\s*\\/\\/\\s*#?endregion\\b")
    }
  },
  indentationRules: {
    increaseIndentPattern: new RegExp("^.*\\{[^}]*$"),
    decreaseIndentPattern: new RegExp("^\\s*\\}")
  }
};

// generated/monaco/wql.completion.ts
var keywords = [
  "BEGIN",
  "COMMIT",
  "ROLLBACK",
  "INSERT",
  "UPDATE",
  "UPSERT",
  "DELETE",
  "EACH",
  "SOFT",
  "HARD",
  "SUMMARIZE",
  "FILTER",
  "ORDER",
  "BY",
  "TAKE",
  "DISTINCT",
  "EXPAND",
  "FIRST",
  "UNION",
  "INTERSECT",
  "EXCEPT",
  "ALL",
  "AS",
  "OVER",
  "WINDOW",
  "LOOP",
  "USING",
  "CASE",
  "CAST",
  "AND",
  "OR",
  "NOT",
  "IF",
  "IN",
  "BETWEEN",
  "LIKE",
  "IS",
  "ASC",
  "DESC",
  "ROWS",
  "RANGE",
  "PARTITION",
  "SORT",
  "SEARCH",
  "DERIVE",
  "REST",
  "ARRAY",
  "SKIPLOCK",
  "NOWAIT",
  "LINK",
  "SOURCE",
  "TARGET",
  "MULTI",
  "CONFLICT",
  "DO",
  "NOTHING",
  "HAS",
  "OF",
  "LOCALTIME",
  "LOCALTIMESTAMP",
  "DEFAULT",
  "REQUIRED",
  "DEFINE",
  "IMPORT",
  "EXPOSE",
  "DROP",
  "REPLACE",
  "END",
  "POLICY",
  "CAN",
  "GRANT",
  "PREVENT",
  "ALTER",
  "DELEGATE",
  "DELEGATION",
  "REVOKE",
  "TO",
  "STARTS",
  "UNTIL",
  "SERVICE",
  "TRUSTED",
  "PUBLIC",
  "ELEVATED",
  "RANK",
  "NTILE",
  "LAG",
  "LEAD",
  "INLINE_SQL",
  "LOOKUP_STRICT",
  "LOOKUP_NULLABLE",
  "SELECT",
  "ON",
  "TRUE",
  "FALSE",
  "INT",
  "INTEGER",
  "FLOAT",
  "DECIMAL",
  "STRING",
  "TEXT",
  "BOOLEAN",
  "DATE",
  "DATETIME",
  "TIMESTAMP",
  "UUID",
  "JSON",
  "JSONB",
  "ARRAY",
  "BLOB",
  "COUNT",
  "SUM",
  "AVG",
  "MIN",
  "MAX",
  "COALESCE",
  "NULLIF",
  "CAST",
  "EXTRACT",
  "NOW",
  "CURRENT_DATE",
  "CURRENT_TIME",
  "CURRENT_TIMESTAMP",
  "ROW_NUMBER",
  "RANK",
  "DENSE_RANK",
  "PERCENT_RANK",
  "CUME_DIST",
  "NTILE",
  "LAG",
  "LEAD",
  "FIRST_VALUE",
  "LAST_VALUE",
  "NTH_VALUE",
  "STRING_AGG",
  "ARRAY_AGG",
  "JSON_AGG",
  "JSONB_AGG"
];
var windowFunctions = [
  "ROW_NUMBER",
  "RANK",
  "DENSE_RANK",
  "PERCENT_RANK",
  "CUME_DIST",
  "NTILE",
  "LAG",
  "LEAD",
  "FIRST_VALUE",
  "LAST_VALUE",
  "NTH_VALUE",
  "COUNT",
  "SUM",
  "AVG",
  "MIN",
  "MAX",
  "COALESCE",
  "NULLIF",
  "CAST",
  "EXTRACT",
  "NOW",
  "CURRENT_DATE",
  "CURRENT_TIME",
  "CURRENT_TIMESTAMP",
  "STRING_AGG",
  "ARRAY_AGG",
  "JSON_AGG",
  "JSONB_AGG"
];
var snippets = [
  {
    label: "select",
    kind: "Snippet",
    insertText: [
      "SELECT ${1:tableName} {",
      "  ${2:column1},",
      "  ${3:column2}",
      "}",
      "FILTER ${4:condition}",
      "SORT ${5:+column}",
      "TAKE ${6:10};"
    ].join(`
`),
    insertTextRules: 4,
    documentation: "Create a SELECT query"
  },
  {
    label: "summarize",
    kind: "Snippet",
    insertText: [
      "SUMMARIZE ${1:tableName} {",
      "  ${2:total} := sum(${3:column}),",
      "  ${4:count} := count(*)",
      "}",
      "BY ${5:groupColumn}",
      "SORT ${6:-total}",
      "TAKE ${7:10};"
    ].join(`
`),
    insertTextRules: 4,
    documentation: "Create a SUMMARIZE (aggregate) query"
  },
  {
    label: "insert",
    kind: "Snippet",
    insertText: [
      "INSERT ${1:tableName} {",
      "  ${2:field}: ${3:value}",
      "} -> ${4:id};"
    ].join(`
`),
    insertTextRules: 4,
    documentation: "Create an INSERT statement"
  },
  {
    label: "update",
    kind: "Snippet",
    insertText: [
      "UPDATE ${1:tableName} [${2:condition}] {",
      "  ${3:field}: ${4:value}",
      "};"
    ].join(`
`),
    insertTextRules: 4,
    documentation: "Create an UPDATE statement"
  },
  {
    label: "delete",
    kind: "Snippet",
    insertText: "DELETE ${1:tableName} [${2:condition}];",
    insertTextRules: 4,
    documentation: "Create a DELETE statement"
  }
];
function createCompletionProvider(monaco) {
  return {
    provideCompletionItems(model, position) {
      const word = model.getWordUntilPosition(position);
      const range = {
        startLineNumber: position.lineNumber,
        endLineNumber: position.lineNumber,
        startColumn: word.startColumn,
        endColumn: word.endColumn
      };
      const suggestions = [];
      for (const kw of keywords) {
        suggestions.push({
          label: kw,
          kind: monaco.languages.CompletionItemKind.Keyword,
          insertText: kw,
          range
        });
      }
      for (const fn of windowFunctions) {
        suggestions.push({
          label: fn,
          kind: monaco.languages.CompletionItemKind.Function,
          insertText: fn + "()",
          insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
          detail: "Window function",
          range
        });
      }
      for (const snippet of snippets) {
        suggestions.push({
          label: snippet.label,
          kind: monaco.languages.CompletionItemKind.Snippet,
          insertText: snippet.insertText,
          insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
          documentation: snippet.documentation,
          range
        });
      }
      return { suggestions };
    }
  };
}

// generated/monaco/wql.theme.ts
var darkThemeRules = [
  { token: "keyword", foreground: "569CD6" },
  { token: "keyword.special", foreground: "C586C0" },
  { token: "function.window", foreground: "DCDCAA" },
  { token: "type", foreground: "4EC9B0" },
  { token: "constant.boolean", foreground: "569CD6" },
  { token: "constant.null", foreground: "569CD6" },
  { token: "number", foreground: "B5CEA8" },
  { token: "number.float", foreground: "B5CEA8" },
  { token: "string", foreground: "CE9178" },
  { token: "string.escape", foreground: "D7BA7D" },
  { token: "comment", foreground: "6A9955" },
  { token: "variable", foreground: "9CDCFE" },
  { token: "variable.predefined", foreground: "4EC9B0" },
  { token: "identifier", foreground: "9CDCFE" },
  { token: "identifier.quoted", foreground: "9CDCFE" },
  { token: "operator", foreground: "D4D4D4" },
  { token: "operator.link", foreground: "C586C0" },
  { token: "delimiter", foreground: "D4D4D4" }
];
var lightThemeRules = [
  { token: "keyword", foreground: "0000FF" },
  { token: "keyword.special", foreground: "AF00DB" },
  { token: "function.window", foreground: "795E26" },
  { token: "type", foreground: "267F99" },
  { token: "constant.boolean", foreground: "0000FF" },
  { token: "constant.null", foreground: "0000FF" },
  { token: "number", foreground: "098658" },
  { token: "number.float", foreground: "098658" },
  { token: "string", foreground: "A31515" },
  { token: "string.escape", foreground: "EE0000" },
  { token: "comment", foreground: "008000" },
  { token: "variable", foreground: "001080" },
  { token: "variable.predefined", foreground: "267F99" },
  { token: "identifier", foreground: "001080" },
  { token: "identifier.quoted", foreground: "001080" },
  { token: "operator", foreground: "000000" },
  { token: "operator.link", foreground: "AF00DB" },
  { token: "delimiter", foreground: "000000" }
];
function createDarkTheme() {
  return {
    base: "vs-dark",
    inherit: true,
    rules: darkThemeRules,
    colors: {}
  };
}
function createLightTheme() {
  return {
    base: "vs",
    inherit: true,
    rules: lightThemeRules,
    colors: {}
  };
}

// generated/monaco/index.ts
var LANGUAGE_ID = "wql";
function registerWQLLanguage(monacoInstance) {
  monacoInstance.languages.register({
    id: LANGUAGE_ID,
    extensions: [".wql"],
    aliases: ["WQL", "WQL Query Language"],
    mimetypes: ["text/x-wql"]
  });
  monacoInstance.languages.setLanguageConfiguration(LANGUAGE_ID, languageConfiguration);
  monacoInstance.languages.setMonarchTokensProvider(LANGUAGE_ID, monarchLanguage);
  monacoInstance.languages.registerCompletionItemProvider(LANGUAGE_ID, createCompletionProvider(monacoInstance));
  monacoInstance.editor.defineTheme("wql-dark", createDarkTheme());
  monacoInstance.editor.defineTheme("wql-light", createLightTheme());
}
export {
  LANGUAGE_ID,
  createCompletionProvider,
  createDarkTheme,
  createLightTheme,
  darkThemeRules,
  languageConfiguration,
  lightThemeRules,
  monarchLanguage,
  registerWQLLanguage
};
