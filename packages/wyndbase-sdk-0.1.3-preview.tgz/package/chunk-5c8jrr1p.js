// src/react.ts
import { useStore } from "zustand";
function createAuthStore(auth) {
  return function useAuthStore(selector) {
    return useStore(auth.store, selector);
  };
}

export { createAuthStore };

//# debugId=90DD1AFAEAB7F89864756E2164756E21
