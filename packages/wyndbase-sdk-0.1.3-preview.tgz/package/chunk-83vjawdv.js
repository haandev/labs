// src/Pluggable.ts
var pluginName = Symbol("pluginName");

class Pluggable {
  installerFunction(name, f, params) {
    if (this[name])
      throw new Error(`${name.toString()} already installed`);
    const plugged = f(this, ...params);
    Object.assign(this, { [name]: plugged });
    return this;
  }
  installerClass(name, CtorRef, ctorArgs) {
    if (this[name])
      throw new Error(`${name.toString()} already installed`);
    const instance = new CtorRef(this, ...ctorArgs);
    Object.assign(this, { [name]: instance });
    return this;
  }
  use(f, ...params) {
    const isClass = typeof f === "function" && !!f.prototype && f.prototype.constructor === f;
    if (isClass) {
      return this.installerClass(f[pluginName], f, params);
    } else {
      return this.installerFunction(f[pluginName], f, params);
    }
  }
  plugin(name, f, ...params) {
    const isClass = typeof f === "function" && !!f.prototype && f.prototype.constructor === f;
    if (isClass) {
      return this.installerClass(name, f, params);
    } else {
      return this.installerFunction(name, f, params);
    }
  }
}
function makePluggable(Base) {
  const NameNewClass = `Pluggable${Base.name}`;
  const PluggableClass = class extends Base {
  };
  Object.defineProperty(PluggableClass, "name", { value: NameNewClass });
  Object.assign(PluggableClass.prototype, Pluggable.prototype);
  return PluggableClass;
}
var definePlugin = (name, fn) => {
  return Object.defineProperty(fn, pluginName, {
    configurable: false,
    value: name,
    writable: false
  });
};

export { pluginName, Pluggable, makePluggable, definePlugin };

//# debugId=797C577674C281C064756E2164756E21
