// src/retry-policy.ts
var NON_RETRYABLE_STATUSES = new Set([400, 401, 404]);
var DEFAULT_QUERY_MAX_FAILURES = 5;
function shouldRetryQuery(failureCount, error, maxFailures = DEFAULT_QUERY_MAX_FAILURES) {
  const status = error?.status;
  if (typeof status === "number" && NON_RETRYABLE_STATUSES.has(status)) {
    return false;
  }
  return failureCount < maxFailures;
}

export { DEFAULT_QUERY_MAX_FAILURES, shouldRetryQuery };

//# debugId=C5ECBF11DE773AFE64756E2164756E21
