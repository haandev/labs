import {
  DEFAULT_QUERY_MAX_FAILURES,
  shouldRetryQuery
} from "./chunk-8rtgyjf5.js";
import {
  EventListener,
  SSEClient,
  computeJitteredDelay,
  openRealtimeStream,
  postWithRetry,
  realtimeUrl,
  subjectOf
} from "./chunk-ckfjhf8x.js";
import {
  HttpClient,
  HttpError,
  deferNotification,
  discardNotifications,
  flushNotifications
} from "./chunk-1vz930gy.js";
import {
  Pluggable
} from "./chunk-83vjawdv.js";

// src/core.ts
import { EdenFetchError, treaty } from "@elysiajs/eden";
import {
  QueryClient
} from "@tanstack/query-core";

// ../shared/src/enfurcer.ts
var sleep = (ms) => new Promise((res) => setTimeout(res, ms));
var enfurcer = async (retrier, options) => {
  const {
    maxRetries = 3,
    retryDelay = 1000,
    fix,
    onFix,
    onInvalid,
    timeout = 1e4,
    onStart,
    isCancelled,
    onCancelled,
    onFixError,
    abortSignal,
    onTimeout
  } = options;
  let result;
  let error;
  let isAborted = false;
  const abortHandler = async () => {
    isAborted = true;
    await onCancelled?.();
    await finallyFn();
  };
  const finallyFn = async () => {
    abortSignal?.removeEventListener("abort", abortHandler);
  };
  const success = () => Promise.resolve(result).finally(finallyFn);
  const failure = () => Promise.reject(error).finally(finallyFn);
  abortSignal?.addEventListener("abort", abortHandler, { once: true });
  await onStart?.();
  if (isCancelled?.() || abortSignal?.aborted) {
    error = new Error("Aborted");
    await onCancelled?.();
    return failure();
  }
  const timeoutSignal = timeout ? AbortSignal.timeout(timeout) : undefined;
  const check = async (attempt) => {
    try {
      result = await retrier(result, error, attempt);
      return true;
    } catch (err) {
      error = err;
      if (error?.message === "Aborted")
        isAborted = true;
      return false;
    }
  };
  if (await check(0))
    return success();
  onInvalid?.();
  for (let attempt = 0;attempt < (maxRetries || 3); attempt++) {
    if (isCancelled?.() || isAborted || abortSignal?.aborted) {
      error = new Error("Aborted");
      onCancelled?.();
      return failure();
    }
    if (timeoutSignal?.aborted) {
      error = new Error("Timeout");
      onTimeout?.();
      return failure();
    }
    let fixResult;
    try {
      fixResult = await fix?.(result);
    } catch (err) {
      onFixError?.(err);
    }
    if (await check(attempt + 1)) {
      onFix?.(fixResult);
      return success();
    }
    if (attempt < (maxRetries || 3) - 1) {
      await sleep(retryDelay);
    }
  }
  return failure();
};

// ../shared/src/queue.ts
var serializeTask = (task, running) => {
  return {
    createdAt: task.createdAt,
    currentRetry: task.currentRetry,
    metadata: task.metadata,
    priority: task.priority,
    running: running ?? false,
    timeout: task.timeout
  };
};

class Queue {
  _events = new EventListener;
  paused = false;
  running = 0;
  _tasks = [];
  _runningTasks = [];
  config;
  constructor(conf) {
    this.config = conf;
  }
  run(promiseFactory, options = {}) {
    return new Promise((resolve, reject) => {
      const task = {
        createdAt: Date.now(),
        currentRetry: 0,
        fn: () => enfurcer(async () => typeof promiseFactory === "function" ? await promiseFactory() : await promiseFactory, {
          abortSignal: options.signal,
          maxRetries: options.maxRetries ?? 0,
          retryDelay: options.retryDelay ?? 0,
          timeout: options.timeout ?? 0
        }).then((result) => {
          this._runningTasks.splice(this._runningTasks.indexOf(task), 1);
          this._events.emit("queueChanged", this.tasksSerialized);
          this._events.emit("taskSuccess", serializeTask(task));
          resolve(result);
        }).catch((error) => {
          this._events.emit("taskFailed", serializeTask(task));
          reject(error);
        }).finally(() => {
          this._events.emit("taskFinally", serializeTask(task));
          this.running--;
          this.dequeue();
        }),
        metadata: options.metadata,
        priority: options.priority ?? 0,
        reject,
        resolve,
        signal: options.signal,
        timeout: options.timeout
      };
      this._tasks.push(task);
      this._events.emit("queueChanged", this.tasksSerialized);
      this._events.emit("taskStarted", serializeTask(task));
      if (this.config.respectPriority) {
        this._tasks.sort((a, b) => b.priority - a.priority || a.createdAt - b.createdAt);
      }
      this.dequeue();
    });
  }
  clear() {
    for (const task of this._tasks) {
      task.reject(new Error("Queue cleared / task cancelled"));
    }
    this._tasks = [];
  }
  get status() {
    const { concurrency, respectPriority, timeout, signal } = this.config;
    const { length } = this._tasks;
    const run = this.running;
    return {
      concurrency,
      length,
      respectPriority,
      running: run,
      signal,
      timeout
    };
  }
  get tasks() {
    return [...this._tasks];
  }
  get tasksSerialized() {
    const tasks = Array.from(new Set([...this._tasks, ...this._runningTasks])).map((task) => serializeTask(task, this._runningTasks.includes(task)));
    return tasks;
  }
  set tasks(_tasks) {
    throw new Error("Cannot set tasks directly");
  }
  pause() {
    this.paused = true;
  }
  resume() {
    if (this.paused) {
      this.paused = false;
      this.dequeue();
    }
  }
  dequeue() {
    if (this.paused)
      return;
    while (this.running < (this.config.concurrency || 1) && this._tasks.length > 0) {
      const task = this._tasks.shift();
      this._runningTasks.push(task);
      this.running++;
      task.currentRetry++;
      this._events.emit("taskDequeued", serializeTask(task));
      this._events.emit("queueChanged", this.tasksSerialized);
      task.fn();
    }
  }
  get events() {
    return this._events;
  }
}

// ../shared/src/promice.ts
var ensure = Symbol("ensure");

class Promice {
  [Symbol.toStringTag] = "Promice";
  static queues = new Map;
  static unnamedqueues = [];
  static get allQueues() {
    return [...Promice.queues.values(), ...Promice.unnamedqueues];
  }
  executor;
  inner = null;
  [ensure]() {
    if (!this.inner) {
      this.inner = new Promise(this.executor);
    }
    return this.inner;
  }
  constructor(exec) {
    this.executor = exec;
  }
  exec() {
    return this[ensure]();
  }
  then(onfulfilled, onrejected) {
    return this[ensure]().then(onfulfilled, onrejected);
  }
  catch(onrejected) {
    return this[ensure]().catch(onrejected);
  }
  finally(onfinally) {
    return this[ensure]().finally(onfinally);
  }
  static resolve(value) {
    return new Promice((resolve) => resolve(value));
  }
  static reject(reason) {
    return new Promice((_, reject) => reject(reason));
  }
  static all(tasks, config = {}) {
    const queue = new Queue(config);
    Promice.unnamedqueues.push(queue);
    const queuedPromises = tasks.map((task) => queue.run(task));
    const promise = Promise.all(queuedPromises).finally(() => {
      Promice.unnamedqueues.splice(Promice.unnamedqueues.indexOf(queue), 1);
    });
    return new Promice((resolve, reject) => {
      promise.then(resolve, reject);
    });
  }
  static allSettled(tasks, config = {}) {
    const queue = new Queue(config);
    Promice.unnamedqueues.push(queue);
    const queuedPromises = tasks.map((task) => queue.run(task));
    const promise = Promise.allSettled(queuedPromises).finally(() => {
      Promice.unnamedqueues.splice(Promice.unnamedqueues.indexOf(queue), 1);
    });
    return new Promice((resolve, reject) => {
      promise.then(resolve, reject);
    });
  }
  static any(tasks, config = {}) {
    const queue = new Queue({
      ...config,
      concurrency: config.concurrency ?? Infinity
    });
    Promice.unnamedqueues.push(queue);
    const queuedPromises = tasks.map((task) => queue.run(task));
    const promise = Promise.any(queuedPromises).finally(() => {
      Promice.unnamedqueues.splice(Promice.unnamedqueues.indexOf(queue), 1);
      if (!config.keepRunning)
        queue.clear();
    });
    return new Promice((resolve, reject) => {
      promise.then(resolve, reject);
    });
  }
  static race(tasks, config = {}) {
    const queue = new Queue({
      ...config,
      concurrency: config.concurrency ?? Infinity
    });
    const queuedPromises = tasks.map((task) => queue.run(task));
    const promise = Promise.race(queuedPromises).finally(() => {
      Promice.unnamedqueues.splice(Promice.unnamedqueues.indexOf(queue), 1);
      if (!config.keepRunning)
        queue.clear();
    });
    return new Promice((resolve, reject) => {
      promise.then(resolve, reject);
    });
  }
  static withResolvers() {
    let resolveFn;
    let rejectFn;
    const promice = new Promice((resolve, reject) => {
      resolveFn = resolve;
      rejectFn = reject;
    });
    return {
      promice,
      reject: rejectFn,
      resolve: resolveFn
    };
  }
  static try(func, ...args) {
    return new Promice((resolve, reject) => {
      try {
        const result = func(...args);
        if (result instanceof Promice) {
          result.then(resolve, reject);
        } else {
          Promise.resolve(result).then(resolve, reject);
        }
      } catch (err) {
        reject(err);
      }
    });
  }
  static status(name) {
    const queue = Promice.queues.get(name);
    return queue?.status;
  }
  static createQueue(name, config) {
    const queue = new Queue(config);
    Promice.queues.set(name, queue);
    return queue;
  }
  static run(promiseFactory, queueName, options = {}) {
    const queue = Promice.queues.get(queueName) ?? Promice.createQueue(queueName, {
      concurrency: Infinity,
      timeout: Infinity
    });
    return queue.run(promiseFactory, options);
  }
  static clearQueue(name) {
    const queue = Promice.queues.get(name);
    if (queue)
      queue.clear();
  }
  static deleteQueue(name) {
    const queue = Promice.queues.get(name);
    if (queue) {
      queue.clear();
      Promice.queues.delete(name);
    }
  }
  static pauseQueue(name) {
    const queue = Promice.queues.get(name);
    if (queue)
      queue.pause();
  }
  static resumeQueue(name) {
    const queue = Promice.queues.get(name);
    if (queue)
      queue.resume();
  }
  static pauseAll() {
    for (const queue of Promice.allQueues) {
      queue.pause();
    }
  }
  static resumeAll() {
    for (const queue of Promice.allQueues) {
      queue.resume();
    }
  }
  static clearAll() {
    for (const queue of Promice.allQueues) {
      queue.clear();
    }
  }
}
var lazify = (fn) => {
  return new Promice((resolve, reject) => {
    fn().then(resolve, reject);
  });
};

// src/wql-rows.ts
import { replaceEqualDeep } from "@tanstack/query-core";
import { isTaggedWqlRows, tagWqlRows, wqlRowsMeta } from "@wyndbase/wql";
function wqlStructuralSharing(prev, next) {
  if (!isTaggedWqlRows(next))
    return replaceEqualDeep(prev, next);
  const previousRows = Array.isArray(prev) ? Array.prototype.slice.call(prev) : prev;
  const shared = replaceEqualDeep(previousRows, Array.prototype.slice.call(next));
  return tagWqlRows({ ...wqlRowsMeta(next), result: shared });
}

// src/network-meter.ts
var JOIN_WINDOW_MS = 50;
var PUSH_WINDOW_MS = 100;

class NetworkMeter {
  listeners = new Set;
  snapshot = {
    bytes: 0,
    durationMs: 0,
    inFlight: 0,
    requestCount: 0
  };
  lastPushAt = Number.NEGATIVE_INFINITY;
  inFlight = 0;
  burst = null;
  getSnapshot() {
    return this.snapshot;
  }
  subscribe(listener) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }
  notePush(now = performance.now()) {
    this.lastPushAt = now;
  }
  begin(now = performance.now()) {
    this.inFlight++;
    const joinable = this.burst !== null && (this.burst.open > 0 || now - this.burst.start <= JOIN_WINDOW_MS);
    if (joinable && this.burst) {
      this.burst.count++;
      this.burst.open++;
    } else {
      this.burst = {
        bytes: 0,
        count: 1,
        end: now,
        open: 1,
        pushDriven: now - this.lastPushAt <= PUSH_WINDOW_MS,
        start: now
      };
    }
    const burst = this.burst;
    this.publish({ ...this.snapshot, inFlight: this.inFlight });
    let ended = false;
    return (bytes = 0, endAt = performance.now()) => {
      if (ended)
        return;
      ended = true;
      this.inFlight--;
      burst.open--;
      burst.bytes += bytes;
      if (endAt > burst.end)
        burst.end = endAt;
      const settled = burst.open === 0 && !burst.pushDriven;
      this.publish(settled ? {
        bytes: burst.bytes,
        durationMs: burst.end - burst.start,
        inFlight: this.inFlight,
        requestCount: burst.count
      } : { ...this.snapshot, inFlight: this.inFlight });
    };
  }
  publish(next) {
    this.snapshot = next;
    for (const listener of this.listeners) {
      try {
        listener();
      } catch {}
    }
  }
}
// src/client-local-config.ts
var CLIENT_LOCAL_CONFIG = Object.freeze({
  mutation: undefined,
  overrideBaseId: undefined,
  silent: undefined
});
var CLIENT_LOCAL_KEYS = Object.keys(CLIENT_LOCAL_CONFIG);
function splitQueryConfig(config) {
  const wire = { ...config ?? {} };
  const local = {};
  for (const key of CLIENT_LOCAL_KEYS) {
    if (Object.hasOwn(wire, key)) {
      local[key] = wire[key];
      delete wire[key];
    }
  }
  return {
    local,
    wire
  };
}

// src/realtime-transport.ts
class DirectTransport {
  sse = null;
  connId = null;
  invalidateHandler;
  expiredHandler;
  reconnectedHandler;
  subscribeFailedHandler;
  statusHandler;
  status = "reconnecting";
  config = null;
  closed = false;
  subject;
  async init(config) {
    this.config = config;
    this.subject = subjectOf(config.headers);
    this.closed = false;
    return new Promise((resolve) => {
      this.connect(() => resolve());
    });
  }
  connect(onFirstConnect, isReconnect = false) {
    if (this.closed || !this.config)
      return;
    const url = realtimeUrl(this.config.baseURL, this.config.baseId, "stream");
    const sse = openRealtimeStream(url);
    this.sse = sse;
    let connectedBefore = false;
    sse.on("connected", (connId) => {
      const wasReconnect = isReconnect || connectedBefore;
      connectedBefore = true;
      this.connId = connId;
      this.setStatus("connected");
      if (onFirstConnect) {
        onFirstConnect();
        onFirstConnect = undefined;
      } else if (wasReconnect) {
        this.reconnectedHandler?.();
      }
    });
    sse.on("invalidate", (keyHash) => {
      this.invalidateHandler?.(keyHash);
    });
    sse.on("expired", (keyHash) => {
      this.expiredHandler?.(keyHash);
    });
    sse.on("drop", () => {
      this.connId = null;
      this.setStatus("reconnecting");
    });
    sse.on("fail", () => {
      this.connId = null;
      this.setStatus("disconnected");
      onFirstConnect?.();
      onFirstConnect = undefined;
    });
  }
  async subscribe(keyHash, trackingId, ttlMs) {
    if (!this.connId || !this.config) {
      this.subscribeFailedHandler?.(keyHash, "deferred");
      return;
    }
    const result = await postWithRetry(realtimeUrl(this.config.baseURL, this.config.baseId, "subscribe"), JSON.stringify({ connId: this.connId, keyHash, trackingId, ttlMs }), { ...this.config.headers, "Content-Type": "application/json" });
    if (result !== "ok")
      this.subscribeFailedHandler?.(keyHash, result);
  }
  async resubscribeBatch(keyHashes) {
    if (!this.connId || !this.config || keyHashes.length === 0) {
      return keyHashes;
    }
    try {
      const r = await fetch(realtimeUrl(this.config.baseURL, this.config.baseId, "resubscribe"), {
        body: JSON.stringify({ connId: this.connId, keyHashes }),
        headers: {
          ...this.config.headers,
          "Content-Type": "application/json"
        },
        method: "POST"
      });
      if (!r.ok)
        return keyHashes;
      const data = await r.json();
      return data.missing ?? [];
    } catch {
      return keyHashes;
    }
  }
  async unsubscribe(keyHash) {
    if (!this.connId || !this.config)
      return;
    await fetch(realtimeUrl(this.config.baseURL, this.config.baseId, "unsubscribe"), {
      body: JSON.stringify({ connId: this.connId, keyHash }),
      headers: {
        ...this.config.headers,
        "Content-Type": "application/json"
      },
      method: "POST"
    }).catch(() => {});
  }
  onInvalidate(handler) {
    this.invalidateHandler = handler;
  }
  onExpired(handler) {
    this.expiredHandler = handler;
  }
  onReconnected(handler) {
    this.reconnectedHandler = handler;
  }
  onSubscribeFailed(handler) {
    this.subscribeFailedHandler = handler;
  }
  onStatusChange(handler) {
    this.statusHandler = handler;
  }
  setStatus(status) {
    if (this.status === status)
      return;
    this.status = status;
    this.statusHandler?.(status);
  }
  updateHeaders(headers) {
    const previousSubject = this.subject;
    if (this.config)
      this.config.headers = headers;
    this.subject = subjectOf(headers);
    if (previousSubject !== undefined && this.subject !== previousSubject) {
      this.reconnect();
    }
  }
  reconnect() {
    if (this.closed)
      return;
    this.sse?.close();
    this.sse = null;
    this.connId = null;
    this.connect(undefined, true);
  }
  destroy() {
    this.closed = true;
    this.sse?.close();
    this.sse = null;
    this.connId = null;
    this.setStatus("disconnected");
  }
}

// src/shared-worker-transport.ts
class SharedWorkerTransport {
  worker = null;
  invalidateHandler;
  expiredHandler;
  reconnectedHandler;
  subscribeFailedHandler;
  statusHandler;
  pendingResubscribe = new Map;
  pendingSubscribe = new Map;
  nextRequestId = 1;
  async init(config) {
    this.worker = new SharedWorker(new URL("./realtime.worker.js", import.meta.url), { name: `wyndb-realtime-${config.baseId}`, type: "module" });
    const port = this.worker.port;
    port.start();
    return new Promise((resolve) => {
      let resolved = false;
      port.onmessage = (e) => {
        const data = e.data;
        switch (data?.type) {
          case "connected":
            if (!resolved) {
              resolved = true;
              resolve();
            }
            this.statusHandler?.("connected");
            break;
          case "invalidate":
            this.invalidateHandler?.(data.keyHash);
            break;
          case "expired":
            this.expiredHandler?.(data.keyHash);
            break;
          case "reconnected":
            this.statusHandler?.("connected");
            this.reconnectedHandler?.();
            break;
          case "subscribe-ok":
            this.settleSubscribe(data.requestId);
            break;
          case "subscribe-failed":
            this.subscribeFailedHandler?.(data.keyHash, data.reason === "unauthorized" || data.reason === "deferred" ? data.reason : "failed");
            this.settleSubscribe(data.requestId);
            break;
          case "disconnected":
            this.statusHandler?.("reconnecting");
            break;
          case "stream-failed":
            if (!resolved) {
              resolved = true;
              resolve();
            }
            this.statusHandler?.("disconnected");
            break;
          case "resubscribe-batch-result": {
            const resolver = this.pendingResubscribe.get(data.requestId);
            if (resolver) {
              this.pendingResubscribe.delete(data.requestId);
              resolver(data.missing ?? []);
            }
            break;
          }
        }
      };
      port.postMessage({
        baseId: config.baseId,
        baseURL: config.baseURL,
        headers: config.headers,
        type: "init"
      });
    });
  }
  settleSubscribe(requestId) {
    if (requestId === undefined)
      return;
    const resolve = this.pendingSubscribe.get(requestId);
    if (!resolve)
      return;
    this.pendingSubscribe.delete(requestId);
    resolve();
  }
  async subscribe(keyHash, trackingId, ttlMs) {
    const worker = this.worker;
    if (!worker) {
      this.subscribeFailedHandler?.(keyHash, "deferred");
      return;
    }
    const requestId = String(this.nextRequestId++);
    return new Promise((resolve) => {
      this.pendingSubscribe.set(requestId, resolve);
      worker.port.postMessage({
        keyHash,
        requestId,
        trackingId,
        ttlMs,
        type: "subscribe"
      });
    });
  }
  async unsubscribe(keyHash) {
    this.worker?.port.postMessage({ keyHash, type: "unsubscribe" });
  }
  async resubscribeBatch(keyHashes) {
    if (!this.worker || keyHashes.length === 0)
      return keyHashes;
    const requestId = String(this.nextRequestId++);
    return new Promise((resolve) => {
      this.pendingResubscribe.set(requestId, resolve);
      this.worker?.port.postMessage({
        keyHashes,
        requestId,
        type: "resubscribe-batch"
      });
    });
  }
  onInvalidate(handler) {
    this.invalidateHandler = handler;
  }
  onExpired(handler) {
    this.expiredHandler = handler;
  }
  onReconnected(handler) {
    this.reconnectedHandler = handler;
  }
  onSubscribeFailed(handler) {
    this.subscribeFailedHandler = handler;
  }
  onStatusChange(handler) {
    this.statusHandler = handler;
  }
  updateHeaders(headers) {
    this.worker?.port.postMessage({ headers, type: "update-headers" });
  }
  notifyClosing() {
    this.worker?.port.postMessage({ type: "port-closing" });
  }
  destroy() {
    this.notifyClosing();
    this.worker?.port.close();
    for (const resolve of this.pendingSubscribe.values())
      resolve();
    this.pendingSubscribe.clear();
    this.statusHandler?.("disconnected");
    this.worker = null;
  }
}

// src/realtime-manager.ts
function combineConnectionStates(states) {
  if (states.length === 0)
    return "idle";
  if (states.includes("disconnected"))
    return "disconnected";
  if (states.includes("reconnecting"))
    return "reconnecting";
  return "connected";
}
var MAX_SUBSCRIBE_ATTEMPTS = 5;
var RESUBSCRIBE_BASE_DELAY_MS = 250;
var RESUBSCRIBE_MAX_DELAY_MS = 30000;

class RealtimeManager {
  deps;
  transports = new Map;
  transportInit = new Map;
  watched = new Map;
  resubscribing = new Set;
  flushSeq = 0;
  flushToken = new Map;
  unauthorized = new Set;
  attempts = new Map;
  abandoned = new Set;
  reArmTimers = new Map;
  pendingBatch = new Map;
  baseSchedule = new Map;
  transportStatus = new Map;
  statusListeners = new Set;
  statusSnapshot = {
    connectionState: "idle",
    subscriptionCount: 0
  };
  constructor(deps) {
    this.deps = deps;
  }
  getSnapshot() {
    return this.statusSnapshot;
  }
  subscribe(listener) {
    this.statusListeners.add(listener);
    return () => this.statusListeners.delete(listener);
  }
  bumpStatus() {
    const states = [...this.transportStatus.values()];
    if (this.abandoned.size > 0)
      states.push("disconnected");
    const next = {
      connectionState: combineConnectionStates(states),
      subscriptionCount: this.watched.size
    };
    const prev = this.statusSnapshot;
    if (next.connectionState === prev.connectionState && next.subscriptionCount === prev.subscriptionCount)
      return;
    this.statusSnapshot = next;
    for (const listener of this.statusListeners) {
      try {
        listener();
      } catch {}
    }
  }
  hashQueryKey(queryKey) {
    const str = JSON.stringify(queryKey);
    let hash = 0xcbf29ce484222325n;
    const prime = 0x100000001b3n;
    const mask = 0xffffffffffffffffn;
    for (let i = 0;i < str.length; i++) {
      hash ^= BigInt(str.charCodeAt(i));
      hash = hash * prime & mask;
    }
    return hash.toString(36);
  }
  wireTransport(baseId, transport) {
    transport.onStatusChange((status) => {
      this.transportStatus.set(baseId, status);
      this.bumpStatus();
    });
    transport.onInvalidate((keyHash) => {
      const entry = this.watched.get(keyHash);
      if (!entry)
        return;
      this.deps.onPushApplied?.();
      this.deps.queryClient.invalidateQueries({ queryKey: entry.queryKey });
      for (const cb of entry.onInvalidateCallbacks)
        cb();
      for (const fr of entry.forceRefetchEntries) {
        this.deps.queryClient.fetchQuery(fr.queryOptions).then((data) => {
          if (typeof fr.handler === "function")
            fr.handler(data);
        }).catch(() => {});
      }
    });
    transport.onExpired((keyHash) => {
      this.handleExpired(keyHash);
    });
    transport.onSubscribeFailed((keyHash, reason) => {
      this.flushToken.delete(keyHash);
      if (reason === "unauthorized") {
        this.unauthorized.add(keyHash);
        this.resubscribing.delete(keyHash);
        return;
      }
      if (reason === "deferred") {
        this.resubscribing.delete(keyHash);
        return;
      }
      this.handleResubscribe(keyHash);
    });
    transport.onReconnected(() => {
      for (const entry of this.watched.values()) {
        if (entry.baseId !== baseId)
          continue;
        this.clearRecoveryBudget(entry.keyHash);
      }
      for (const entry of this.watched.values()) {
        if (entry.baseId === baseId)
          this.handleResubscribe(entry.keyHash);
      }
    });
  }
  async ensureTransport(baseId) {
    const existing = this.transports.get(baseId);
    if (existing)
      return existing;
    const pending = this.transportInit.get(baseId);
    if (pending)
      return pending;
    const init = (async () => {
      const transport = typeof SharedWorker !== "undefined" ? new SharedWorkerTransport : new DirectTransport;
      this.wireTransport(baseId, transport);
      const headers = {};
      for (const [key, value] of Object.entries(this.deps.http.defaults.headers)) {
        if (value)
          headers[key] = value;
      }
      await transport.init({
        baseId,
        baseURL: this.deps.http.defaults.baseURL,
        headers
      });
      this.transports.set(baseId, transport);
      if (!this.transportStatus.has(baseId))
        this.transportStatus.set(baseId, "connected");
      this.bumpStatus();
      return transport;
    })();
    this.transportInit.set(baseId, init);
    try {
      return await init;
    } finally {
      this.transportInit.delete(baseId);
    }
  }
  async watch(baseId, trackingId, queryKey, options) {
    const keyHash = this.hashQueryKey(queryKey);
    const {
      onInvalidate,
      forceRefetch,
      queryOptions,
      ttlMs,
      onExpire = "resubscribe",
      pauseWhenHidden = false
    } = options ?? {};
    let frEntry;
    if (forceRefetch && queryOptions) {
      frEntry = {
        handler: forceRefetch === true ? true : forceRefetch,
        queryOptions
      };
    }
    const existing = this.watched.get(keyHash);
    if (existing) {
      if (existing.dropped) {
        return () => {};
      }
      if (existing.pendingResubscribe) {
        if (existing.trackingId === trackingId)
          return () => {};
        existing.pendingResubscribe = false;
        existing.trackingId = trackingId;
        this.resubscribing.delete(keyHash);
        if (this.unauthorized.has(keyHash))
          return () => {};
        const transport2 = this.transports.get(existing.baseId);
        if (transport2) {
          const claim = this.flushToken.get(keyHash);
          transport2.subscribe(keyHash, trackingId, existing.ttlMs).then(() => this.noteRecovered(keyHash, claim)).catch(() => {});
        }
        return () => {};
      }
      existing.refCount++;
      if (onInvalidate)
        existing.onInvalidateCallbacks.add(onInvalidate);
      if (frEntry)
        existing.forceRefetchEntries.add(frEntry);
      let unwatched2 = false;
      return () => {
        if (unwatched2)
          return;
        unwatched2 = true;
        if (onInvalidate)
          existing.onInvalidateCallbacks.delete(onInvalidate);
        if (frEntry)
          existing.forceRefetchEntries.delete(frEntry);
        if (this.releasesForeignEntry(keyHash, existing))
          return;
        this.unwatch(keyHash);
      };
    }
    const transport = await this.ensureTransport(baseId);
    const callbacks = new Set;
    if (onInvalidate)
      callbacks.add(onInvalidate);
    const frEntries = new Set;
    if (frEntry)
      frEntries.add(frEntry);
    const entry = {
      baseId,
      dropped: false,
      forceRefetchEntries: frEntries,
      keyHash,
      onExpire,
      onInvalidateCallbacks: callbacks,
      pausedHidden: false,
      pauseWhenHidden,
      pendingResubscribe: false,
      queryKey,
      refCount: 1,
      trackingId,
      ttlMs
    };
    this.watched.set(keyHash, entry);
    this.bumpStatus();
    transport.subscribe(keyHash, trackingId, ttlMs).catch(() => {
      if (this.releasesForeignEntry(keyHash, entry))
        return;
      this.handleResubscribe(keyHash);
    });
    let unwatched = false;
    return () => {
      if (unwatched)
        return;
      unwatched = true;
      if (onInvalidate)
        callbacks.delete(onInvalidate);
      if (frEntry)
        frEntries.delete(frEntry);
      if (this.releasesForeignEntry(keyHash, entry))
        return;
      this.unwatch(keyHash);
    };
  }
  releasesForeignEntry(keyHash, held) {
    return this.watched.get(keyHash) !== held;
  }
  clearRecoveryBudget(keyHash) {
    this.attempts.delete(keyHash);
    this.abandoned.delete(keyHash);
    this.resubscribing.delete(keyHash);
    this.flushToken.delete(keyHash);
    const reArmTimer = this.reArmTimers.get(keyHash);
    if (reArmTimer !== undefined) {
      clearTimeout(reArmTimer);
      this.reArmTimers.delete(keyHash);
    }
    this.bumpStatus();
  }
  noteRecovered(keyHash, claim) {
    if (claim === undefined)
      return;
    if (this.flushToken.get(keyHash) !== claim)
      return;
    this.attempts.delete(keyHash);
    this.flushToken.delete(keyHash);
  }
  async noteExecuted(baseId, trackingId, queryKey, options) {
    const existing = this.watched.get(this.hashQueryKey(queryKey));
    if (!existing || existing.pendingResubscribe) {
      await this.watch(baseId, trackingId, queryKey, options);
    }
  }
  unwatchByKey(queryKey) {
    const keyHash = this.hashQueryKey(queryKey);
    const entry = this.watched.get(keyHash);
    if (!entry)
      return;
    entry.refCount = 0;
    this.unwatch(keyHash);
  }
  async unwatch(keyHash) {
    const entry = this.watched.get(keyHash);
    if (!entry)
      return;
    entry.refCount--;
    if (entry.refCount > 0)
      return;
    this.watched.delete(keyHash);
    this.unauthorized.delete(keyHash);
    this.clearRecoveryBudget(keyHash);
    this.pendingBatch.get(entry.baseId)?.delete(keyHash);
    this.bumpStatus();
    const transport = this.transports.get(entry.baseId);
    if (transport) {
      await transport.unsubscribe(keyHash).catch(() => {});
    }
    const hasOtherWatchers = [...this.watched.values()].some((w) => w.baseId === entry.baseId);
    if (!hasOtherWatchers) {
      transport?.destroy();
      this.transports.delete(entry.baseId);
      this.transportStatus.delete(entry.baseId);
      this.bumpStatus();
    }
  }
  handleExpired(keyHash) {
    const entry = this.watched.get(keyHash);
    if (!entry || entry.dropped)
      return;
    switch (entry.onExpire) {
      case "drop": {
        entry.dropped = true;
        return;
      }
      case "invalidate": {
        this.deps.queryClient.invalidateQueries({
          queryKey: entry.queryKey,
          refetchType: "none"
        }).catch(() => {});
        return;
      }
      default:
        this.handleResubscribe(keyHash);
    }
  }
  handleResubscribe(keyHash) {
    const entry = this.watched.get(keyHash);
    if (!entry || entry.dropped)
      return;
    if (this.unauthorized.has(keyHash))
      return;
    if (this.abandoned.has(keyHash))
      return;
    if (this.resubscribing.has(keyHash))
      return;
    const spent = (this.attempts.get(keyHash) ?? 0) + 1;
    if (spent > MAX_SUBSCRIBE_ATTEMPTS) {
      this.abandoned.add(keyHash);
      this.bumpStatus();
      const reArm = () => {
        this.clearRecoveryBudget(keyHash);
        this.handleResubscribe(keyHash);
      };
      this.reArmTimers.set(keyHash, setTimeout(reArm, computeJitteredDelay(RESUBSCRIBE_MAX_DELAY_MS)));
      return;
    }
    this.attempts.set(keyHash, spent);
    this.resubscribing.add(keyHash);
    this.flushToken.set(keyHash, ++this.flushSeq);
    let bucket = this.pendingBatch.get(entry.baseId);
    if (!bucket) {
      bucket = new Set;
      this.pendingBatch.set(entry.baseId, bucket);
    }
    bucket.add(keyHash);
    const delay = spent <= 1 ? 0 : Math.min(RESUBSCRIBE_BASE_DELAY_MS * 2 ** (spent - 2), RESUBSCRIBE_MAX_DELAY_MS);
    this.scheduleBaseFlush(entry.baseId, delay);
  }
  scheduleBaseFlush(baseId, delay) {
    const existing = this.baseSchedule.get(baseId);
    if (existing) {
      if (delay >= existing.delay)
        return;
      if (existing.timer !== null)
        clearTimeout(existing.timer);
    }
    const run = () => {
      this.baseSchedule.delete(baseId);
      this.flushResubscribeBatch(baseId);
    };
    if (delay === 0) {
      this.baseSchedule.set(baseId, { delay: 0, timer: null });
      queueMicrotask(run);
    } else {
      this.baseSchedule.set(baseId, {
        delay,
        timer: setTimeout(run, computeJitteredDelay(delay))
      });
    }
  }
  async flushResubscribeBatch(baseId) {
    const bucket = this.pendingBatch.get(baseId);
    if (!bucket)
      return;
    this.pendingBatch.delete(baseId);
    const keyHashes = Array.from(bucket);
    const transport = this.transports.get(baseId);
    if (!transport) {
      for (const kh of keyHashes)
        this.resubscribing.delete(kh);
      return;
    }
    const claimedTokens = new Map(keyHashes.map((kh) => [kh, this.flushToken.get(kh)]));
    let missing = [];
    try {
      missing = await transport.resubscribeBatch(keyHashes);
    } catch {
      missing = keyHashes;
    }
    const owns = (kh) => this.flushToken.get(kh) === claimedTokens.get(kh);
    const hits = new Set(keyHashes);
    for (const m of missing)
      hits.delete(m);
    for (const kh of hits) {
      if (!owns(kh))
        continue;
      this.clearRecoveryBudget(kh);
    }
    for (const keyHash of missing) {
      if (!owns(keyHash))
        continue;
      const entry = this.watched.get(keyHash);
      if (!entry) {
        this.resubscribing.delete(keyHash);
        continue;
      }
      this.deps.onPushApplied?.();
      entry.pendingResubscribe = true;
      this.deps.queryClient.invalidateQueries({
        queryKey: entry.queryKey,
        refetchType: "active"
      }).catch(() => {
        entry.pendingResubscribe = false;
        this.resubscribing.delete(keyHash);
      });
    }
  }
  notifyClosing() {
    for (const transport of this.transports.values()) {
      transport.notifyClosing?.();
    }
  }
  pauseHiddenSubscriptions() {
    for (const entry of this.watched.values()) {
      if (entry.dropped)
        continue;
      if (!entry.pauseWhenHidden)
        continue;
      if (entry.pausedHidden)
        continue;
      entry.pausedHidden = true;
      const transport = this.transports.get(entry.baseId);
      transport?.unsubscribe(entry.keyHash).catch(() => {});
    }
  }
  resumeHiddenSubscriptions() {
    for (const entry of this.watched.values()) {
      if (!entry.pausedHidden)
        continue;
      entry.pausedHidden = false;
      this.handleResubscribe(entry.keyHash);
    }
  }
  refreshTransportHeaders() {
    const headers = {};
    for (const [key, value] of Object.entries(this.deps.http.defaults.headers)) {
      if (value)
        headers[key] = value;
    }
    for (const transport of this.transports.values()) {
      transport.updateHeaders(headers);
    }
    const refused = Array.from(this.unauthorized);
    this.unauthorized.clear();
    for (const keyHash of refused) {
      this.clearRecoveryBudget(keyHash);
      this.handleResubscribe(keyHash);
    }
  }
  destroy() {
    for (const transport of this.transports.values())
      transport.destroy();
    this.unauthorized.clear();
    this.transports.clear();
    this.transportInit.clear();
    this.watched.clear();
    this.transportStatus.clear();
    for (const timer of this.reArmTimers.values())
      clearTimeout(timer);
    this.reArmTimers.clear();
    for (const schedule of this.baseSchedule.values()) {
      if (schedule.timer !== null)
        clearTimeout(schedule.timer);
    }
    this.baseSchedule.clear();
    this.attempts.clear();
    this.abandoned.clear();
    this.bumpStatus();
  }
}

// src/suppressed-read.ts
var SUPPRESSED_READ_META_KEY = "__wynSuppressedRead";

class SuppressedReadError extends Error {
  query;
  missing;
  constructor(report) {
    const which = report.missing.map((m) => `"${m}"`).join(", ");
    super(`Read "${report.query}" was not issued: required parameter${report.missing.length === 1 ? "" : "s"} ${which} ${report.missing.length === 1 ? "is" : "are"} absent.`);
    this.name = "SuppressedReadError";
    this.query = report.query;
    this.missing = [...report.missing];
  }
}
function suppressionReport(query, deps, args) {
  if (deps.length === 0)
    return;
  const missing = deps.filter((dep) => args[dep] === undefined || args[dep] === null);
  return missing.length ? { missing: [...missing], query } : undefined;
}
function isSuppressedRead(source) {
  if (typeof source !== "object" || source === null) {
    return { missing: [], suppressed: false };
  }
  const meta = source.meta;
  if (typeof meta !== "object" || meta === null) {
    return { missing: [], suppressed: false };
  }
  const report = meta[SUPPRESSED_READ_META_KEY];
  if (typeof report !== "object" || report === null || !Array.isArray(report.missing) || typeof report.query !== "string") {
    return { missing: [], suppressed: false };
  }
  const typedReport = report;
  return {
    missing: [...typedReport.missing],
    query: typedReport.query,
    suppressed: true
  };
}
// src/core.ts
var REALTIME_KEY_MARKER = "__realtime__";
var ENVELOPE_QUERY_OPTIONS = { retry: false };
var INVALIDATE_FILTERS = { refetchType: "all" };
function buildWatchOptions(config, queryOptionsForForceRefetch) {
  return {
    forceRefetch: config?.forceRefetch,
    onExpire: config?.onExpire,
    onInvalidate: config?.onInvalidate,
    pauseWhenHidden: config?.pauseWhenHidden,
    queryOptions: config?.forceRefetch ? queryOptionsForForceRefetch : undefined,
    ttlMs: config?.ttlMs
  };
}
var throwOnError = ({ error, data }) => {
  if (error) {
    const body = error?.value;
    const unwrapped = body?.error ?? (body !== undefined && body !== null ? body : error);
    const err = new Error(unwrapped?.message ?? String(unwrapped));
    err.name = unwrapped?.name ?? "Error";
    if (unwrapped && typeof unwrapped === "object")
      Object.assign(err, unwrapped);
    if (err.status === undefined && error?.status !== undefined)
      Object.assign(err, { status: error.status });
    throw err;
  }
  return data;
};
var isCancelledError = (error) => {
  if (!error || typeof error !== "object")
    return false;
  const err = error;
  const cancelled = typeof err === "object" ? err.name === "CancelledError" || err.name === "CanceledError" || err.message === "CancelledError" || err.message === "CanceledError" || "silent" in err || Object.hasOwn(err, "silent") || err.name === "AbortError" || err.code === "ERR_CANCELED" : err.includes("Cancel");
  if (!cancelled)
    return false;
  return true;
};
var collectInterceptors = (manager) => {
  const handlers = [];
  manager.forEach((h) => {
    handlers.push(h);
  });
  return handlers;
};
var forEachInterceptor = async (manager, callback) => {
  for (const h of collectInterceptors(manager))
    await callback(h);
};
var recoverFromInterceptors = async (manager, error) => {
  for (const h of collectInterceptors(manager)) {
    if (!h.rejected)
      continue;
    try {
      const result = await h.rejected(error);
      if (result !== undefined && result !== null)
        return result;
    } catch (thrown) {
      if (thrown === error)
        continue;
      throw thrown;
    }
  }
  return;
};
var isHttpResponseLike = (value) => typeof value === "object" && value !== null && ("status" in value) && ("data" in value);
var httpResponseToResponse = (result) => {
  try {
    const headers = new Headers(result.headers);
    headers.delete("content-length");
    const nullBody = result.status < 200 || [204, 205, 304].includes(result.status);
    const body = nullBody || result.data === null || result.data === undefined ? null : typeof result.data === "string" ? result.data : JSON.stringify(result.data);
    return new Response(body, {
      headers,
      status: result.status,
      statusText: result.statusText
    });
  } catch (cause) {
    console.warn("[wyndbase-sdk] a recovering interceptor returned a response that could not be rebuilt; falling back to the original", cause);
    return null;
  }
};
var createInterceptedFetcher = (client, meter) => async (url, options) => {
  const headers = new Headers;
  for (const [key, value] of Object.entries(client.defaults.headers)) {
    if (value)
      headers.set(key, value);
  }
  if (options?.headers) {
    const reqHeaders = options.headers instanceof Headers ? options.headers : new Headers(options.headers);
    reqHeaders.forEach((value, key) => {
      headers.set(key, value);
    });
  }
  let config = {
    headers,
    method: options?.method || "GET",
    url: url.toString()
  };
  if (options?.body !== undefined && options.body !== null) {
    config.data = options.body;
  }
  await forEachInterceptor(client.interceptors.request, async (h) => {
    if (h.fulfilled)
      config = await h.fulfilled(config);
  });
  const endSample = meter?.begin();
  let response;
  try {
    response = await fetch(url, {
      ...options,
      credentials: client.defaults.withCredentials ? "include" : "same-origin",
      headers: config.headers
    });
  } catch (error2) {
    endSample?.();
    throw error2;
  }
  endSample?.(Number(response.headers.get("content-length")) || 0);
  let httpResponse;
  try {
    const clone = response.clone();
    const contentType = clone.headers.get("content-type") ?? "";
    const data = contentType.includes("application/json") ? await clone.json().catch(() => null) : await clone.text().catch(() => null);
    httpResponse = {
      config,
      data,
      headers: clone.headers,
      status: clone.status,
      statusText: clone.statusText
    };
  } catch {
    return response;
  }
  if (response.ok) {
    try {
      await forEachInterceptor(client.interceptors.response, async (h) => {
        if (h.fulfilled)
          await h.fulfilled(httpResponse);
      });
    } catch (cause) {
      console.warn("[wyndbase-sdk] a response success handler threw; the response is unaffected", cause);
    }
    return response;
  }
  const error = new HttpError(`Request failed with status ${response.status}`, config, httpResponse);
  let recovered;
  try {
    recovered = await recoverFromInterceptors(client.interceptors.response, error);
  } catch (thrown) {
    flushNotifications(error);
    throw thrown;
  }
  if (isHttpResponseLike(recovered)) {
    const rebuilt = httpResponseToResponse(recovered);
    if (rebuilt) {
      discardNotifications(error);
      return rebuilt;
    }
  }
  flushNotifications(error);
  return response;
};
var warnedSuppressions = new Set;
var WARNED_SUPPRESSIONS_LIMIT = 200;
var SUPPRESSION_KEY_MAX_LENGTH = 200;
function suppressionCallSiteKey(variables) {
  const seen = new WeakSet;
  try {
    const encoded = JSON.stringify(variables, (_key, value) => {
      if (typeof value === "function")
        return "[fn]";
      if (typeof value === "object" && value !== null) {
        if (seen.has(value))
          return "[seen]";
        seen.add(value);
      }
      return value;
    });
    return (encoded ?? "undefined").slice(0, SUPPRESSION_KEY_MAX_LENGTH);
  } catch {
    return Object.keys(variables).sort().join(",");
  }
}
function warnSuppressedRead(report, variables) {
  if (true)
    return;
  const key = `${report.query}:${report.missing.join(",")}:${suppressionCallSiteKey(variables)}`;
  if (warnedSuppressions.has(key))
    return;
  if (warnedSuppressions.size >= WARNED_SUPPRESSIONS_LIMIT) {
    warnedSuppressions.clear();
  }
  warnedSuppressions.add(key);
  console.warn(`[wyndb-sdk] Read "${report.query}" was not issued: required parameter(s) ${report.missing.map((m) => `"${m}"`).join(", ")} absent. No request was made — an observed read stays idle ` + `with no data, and an imperative read (await, .fetch(), .ensure()) ` + `rejects with SuppressedReadError. Branch with isSuppressedRead() on the ` + `read, or catch the error.`);
}

class wyndbaseSDK extends Pluggable {
  config;
  http;
  treat;
  queryClient;
  realtimeManager;
  networkMeter = new NetworkMeter;
  wqlQuery;
  wqlMutation;
  wqlEnvelopeQuery;
  constructor(config) {
    super();
    this.config = config;
    const trimTrailingSlash = this.config.serverUrl.replace(/\/$/, "");
    this.config.serverUrl = trimTrailingSlash;
    this._activeBaseId = this.config.baseId;
    this.http = new HttpClient({
      baseURL: this.apiBase,
      headers: {},
      withCredentials: true
    });
    this.http.meter = this.networkMeter;
    this.http.interceptors.response.use((response) => {
      const resolved = response.headers?.get?.("x-wyn-base-id");
      if (resolved)
        this._canonicalBaseId = resolved;
      this.config.onSuccess?.(response);
      return response;
    }, (error) => {
      if (isCancelledError(error))
        return;
      deferNotification(error, () => this.config.onError?.(error));
      return Promise.reject(error);
    });
    const treatyClient = treaty(this.serverUrl, {
      fetcher: createInterceptedFetcher(this.http, this.networkMeter),
      parseDate: false
    });
    this.treat = treatyClient;
    this.queryClient = this.config.queryClient ?? new QueryClient;
    this.queryClient.setDefaultOptions({
      queries: {
        ...this.config.queryClient?.getDefaultOptions()?.queries,
        retry: (failureCount, error) => shouldRetryQuery(failureCount, error, DEFAULT_QUERY_MAX_FAILURES),
        structuralSharing: wqlStructuralSharing,
        throwOnError: false
      }
    });
    this.wqlQuery = this.defineQuery("wqlQuery", this._wqlQueryInner);
    this.wqlMutation = this.defineMutation(this._wqlMutationInner);
    this.wqlEnvelopeQuery = this.defineQuery("wqlEnvelopeQuery", this._wqlEnvelopeInner, undefined, ENVELOPE_QUERY_OPTIONS);
    this.realtimeManager = new RealtimeManager({
      http: this.http,
      onPushApplied: () => this.networkMeter.notePush(),
      queryClient: this.queryClient
    });
    this.queryClient.getQueryCache().subscribe((event) => {
      const query = event.query;
      if (!query.meta?.__realtime)
        return;
      if (event.type === "updated" && event.action.type === "success" && query.state.data) {
        const trackingId = query.state.data?.trackingId;
        if (trackingId && query.getObserversCount() > 0) {
          const realtimeConfig = query.meta.__realtimeConfig;
          this.realtimeManager.noteExecuted(query.meta.__realtimeBaseId, trackingId, query.queryKey, buildWatchOptions(realtimeConfig, {
            queryFn: query.options.queryFn,
            queryKey: query.queryKey
          }));
        }
      }
      if (event.type === "observerRemoved") {
        if (query.getObserversCount() === 0) {
          this.realtimeManager.unwatchByKey(query.queryKey);
        }
      }
    });
    if (typeof window !== "undefined") {
      window.addEventListener("pagehide", () => {
        this.realtimeManager.notifyClosing();
      });
    }
    if (typeof document !== "undefined") {
      document.addEventListener("visibilitychange", () => {
        if (document.visibilityState === "hidden") {
          this.realtimeManager.pauseHiddenSubscriptions();
        } else {
          this.realtimeManager.resumeHiddenSubscriptions();
        }
      });
    }
  }
  get base() {
    return this.baseFor();
  }
  baseFor(baseId) {
    return this.treat.api({ baseId: baseId ?? this.activeBaseId });
  }
  get tenant() {
    return this.treat.api({ baseId: this.baseRef });
  }
  get baseRef() {
    return this.config.baseId;
  }
  get canonicalBaseId() {
    return this._canonicalBaseId;
  }
  _canonicalBaseId;
  get baseId() {
    return this.baseRef;
  }
  _activeBaseId;
  get activeBaseId() {
    return this._activeBaseId;
  }
  get queryKeyContext() {
    return this.config.queryKeyContext?.();
  }
  setActiveBaseId(newBaseId) {
    this._activeBaseId = newBaseId;
    this.http.defaults.baseURL = this.apiBase;
  }
  get serverUrl() {
    const raw = this.config.serverUrl.trim();
    if (/^https?:\/\//i.test(raw)) {
      return raw.replace(/\/+$/, "");
    }
    const path = raw.replace(/^\/+/, "");
    return `${location.origin}${path ? `/${path}` : ""}`;
  }
  get apiBase() {
    return `${this.serverUrl}/api`;
  }
  get headers() {
    return this.http.defaults.headers;
  }
  defineQuery = (name, fn, deps = [], defaultOptions = {}, overrideBaseId) => {
    const getQueryKey = (_innerFn, args) => {
      const context = this.queryKeyContext;
      const queryKey = [
        overrideBaseId ? overrideBaseId : this.activeBaseId,
        name,
        args,
        ...context !== undefined ? [context] : []
      ];
      return queryKey;
    };
    const getQueryFn = (innerFn, args, ctxOverride) => async (context) => {
      const merged = {};
      Object.assign(merged, context, ctxOverride);
      if (overrideBaseId)
        merged.baseId = overrideBaseId;
      try {
        return await innerFn(merged, args);
      } catch (error) {
        if (isCancelledError(error)) {
          return new Promise(() => {});
        }
        throw error;
      }
    };
    const getOptions = (innerFn, variables, options = {}, ctxOverride, announce = true) => {
      const queryKey = getQueryKey(innerFn, variables);
      const queryFn = getQueryFn(innerFn, variables, ctxOverride);
      const output = {
        ...defaultOptions,
        ...options,
        queryFn,
        queryKey
      };
      const report = suppressionReport(name, deps, variables);
      if (report) {
        const explicitEnabled = output.enabled;
        output.enabled = false;
        output.meta = {
          ...output.meta ?? {},
          [SUPPRESSED_READ_META_KEY]: report
        };
        if (announce && explicitEnabled !== false) {
          warnSuppressedRead(report, variables);
        }
      } else {
        const inherited = output.meta;
        if (inherited && SUPPRESSED_READ_META_KEY in inherited) {
          const cleaned = { ...inherited };
          delete cleaned[SUPPRESSED_READ_META_KEY];
          output.meta = cleaned;
        }
        if (deps.length > 0) {
          const explicitEnabled = output.enabled;
          output.enabled = explicitEnabled ?? true;
        }
      }
      return output;
    };
    const refuseIfSuppressed = (opts) => {
      const report = opts.meta?.[SUPPRESSED_READ_META_KEY];
      if (report)
        throw new SuppressedReadError(report);
    };
    const getCaller = (innerFn) => (args = {}, ctx) => {
      const queryOptions = getOptions(innerFn, args, ctx, undefined, false);
      const result = lazify(async () => {
        refuseIfSuppressed(queryOptions);
        return await this.queryClient.fetchQuery(queryOptions);
      });
      return Object.assign(result, queryOptions, getParameterlessTSQFunctions(innerFn, args));
    };
    const getParameterizedTSQFunctions = (innerFn) => {
      const fetch2 = (args, options2) => lazify(() => {
        const opts = getOptions(innerFn, args, options2);
        refuseIfSuppressed(opts);
        return this.queryClient.fetchQuery(opts);
      });
      const ensure2 = (args, options2) => lazify(() => {
        const opts = getOptions(innerFn, args, options2);
        refuseIfSuppressed(opts);
        return this.queryClient.ensureQueryData(opts);
      });
      const invalidate = (args) => lazify(() => this.queryClient.invalidateQueries({
        ...INVALIDATE_FILTERS,
        queryKey: getQueryKey(innerFn, args)
      }));
      const options = (args, options2) => {
        return getOptions(innerFn, args, options2);
      };
      const realtime = (config) => {
        return (args) => {
          const baseId = overrideBaseId ?? this._activeBaseId;
          const baseOptions = getOptions(innerFn, args, {
            meta: {
              __realtime: true,
              __realtimeBaseId: baseId,
              __realtimeConfig: config
            }
          });
          const realtimeOptions = {
            ...baseOptions,
            queryKey: [...baseOptions.queryKey, REALTIME_KEY_MARKER]
          };
          let unwatchFn = null;
          const result = lazify(async () => {
            refuseIfSuppressed(realtimeOptions);
            const r = await this.queryClient.fetchQuery(realtimeOptions);
            const trackingId = r?.trackingId;
            if (trackingId) {
              unwatchFn = await this.realtimeManager.watch(baseId, trackingId, realtimeOptions.queryKey, buildWatchOptions(config, realtimeOptions));
            }
            return r;
          });
          return Object.assign(result, realtimeOptions, getParameterlessTSQFunctions(innerFn, args), {
            __realtime: true,
            __realtimeConfig: config,
            __realtimeKeyHash: this.realtimeManager.hashQueryKey(realtimeOptions.queryKey),
            unsubscribe: () => unwatchFn?.()
          });
        };
      };
      return { ensure: ensure2, fetch: fetch2, invalidate, options, realtime };
    };
    const getParameterlessTSQFunctions = (innerFn, parameters) => {
      const fetch2 = (options2) => lazify(async () => {
        const opts = getOptions(innerFn, parameters, options2);
        refuseIfSuppressed(opts);
        try {
          return await this.queryClient.fetchQuery(opts);
        } catch (error) {
          if (isCancelledError(error)) {
            return new Promise(() => {});
          }
          throw error;
        }
      });
      const ensure2 = (options2) => lazify(async () => {
        const opts = getOptions(innerFn, parameters, options2);
        refuseIfSuppressed(opts);
        try {
          return await this.queryClient.ensureQueryData(opts);
        } catch (error) {
          if (isCancelledError(error))
            return null;
          throw error;
        }
      });
      const invalidate = (options2) => lazify(() => this.queryClient.invalidateQueries({
        ...INVALIDATE_FILTERS,
        queryKey: getQueryKey(innerFn, parameters)
      }, options2));
      const options = (options2) => {
        return getOptions(innerFn, parameters, options2);
      };
      const realtime = (config) => {
        const baseId = overrideBaseId ?? this._activeBaseId;
        const baseOptions = getOptions(innerFn, parameters, {
          meta: {
            __realtime: true,
            __realtimeBaseId: baseId,
            __realtimeConfig: config
          }
        });
        const realtimeOptions = {
          ...baseOptions,
          queryKey: [...baseOptions.queryKey, REALTIME_KEY_MARKER]
        };
        let unwatchFn = null;
        const result = lazify(async () => {
          refuseIfSuppressed(realtimeOptions);
          const r = await this.queryClient.fetchQuery(realtimeOptions);
          const trackingId = r?.trackingId;
          if (trackingId) {
            unwatchFn = await this.realtimeManager.watch(baseId, trackingId, realtimeOptions.queryKey, buildWatchOptions(config, realtimeOptions));
          }
          return r;
        });
        return Object.assign(result, realtimeOptions, getParameterlessTSQFunctions(innerFn, parameters), {
          __realtime: true,
          __realtimeConfig: config,
          __realtimeKeyHash: this.realtimeManager.hashQueryKey(realtimeOptions.queryKey),
          unsubscribe: () => unwatchFn?.()
        });
      };
      return { ensure: ensure2, fetch: fetch2, invalidate, options, realtime };
    };
    return Object.assign(getCaller(fn), getParameterizedTSQFunctions(fn));
  };
  defineMutation = (fn, defaultOptions = {}) => {
    const mutationFn = (args) => fn(...args);
    const caller = (...args) => Object.assign(lazify(() => fn(...args)), {
      mutationFn: () => fn(...args)
    });
    return Object.assign(caller, { ...defaultOptions, mutationFn });
  };
  _wqlQueryInner = async (context, body) => {
    const { __silent, ...rest } = body ?? {};
    const requestBody = context.meta?.__realtime ? { ...rest, config: { ...rest.config, realtime: true } } : rest;
    const fetchOptions = { signal: context.signal };
    if (__silent)
      fetchOptions.headers = { "x-wql-silent": "1" };
    return await this.baseFor(context.baseId).browse.wql.post(requestBody, { fetch: fetchOptions }).then(throwOnError).then(tagWqlRows);
  };
  _wqlEnvelopeInner = async (context, body) => {
    const { __silent, ...rest } = body ?? {};
    const fetchOptions = { signal: context.signal };
    if (__silent)
      fetchOptions.headers = { "x-wql-silent": "1" };
    return await this.baseFor(context.baseId).browse.wqlEnvelope.post(rest, { fetch: fetchOptions }).then(throwOnError);
  };
  _wqlMutationInner = async (body) => {
    const { __baseId, __silent, ...rest } = body ?? {};
    const allowMutation = rest.config?.allowMutation !== false;
    const config = { ...rest.config, allowMutation };
    const fetchOptions = __silent ? { headers: { "x-wql-silent": "1" } } : undefined;
    return await this.baseFor(__baseId).browse.wql.post({ ...rest, config }, fetchOptions ? { fetch: fetchOptions } : undefined).then(throwOnError).then(tagWqlRows);
  };
  _wqlQueryCache = new Map;
  _wqlMutationCache = new Map;
  _wqlQueryFor(overrideBaseId) {
    if (!overrideBaseId)
      return this.wqlQuery;
    let cached = this._wqlQueryCache.get(overrideBaseId);
    if (!cached) {
      cached = this.defineQuery("wqlQuery", this._wqlQueryInner, undefined, undefined, overrideBaseId);
      this._wqlQueryCache.set(overrideBaseId, cached);
    }
    return cached;
  }
  _wqlEnvelopeCache = new Map;
  _wqlEnvelopeFor(overrideBaseId) {
    if (!overrideBaseId)
      return this.wqlEnvelopeQuery;
    let cached = this._wqlEnvelopeCache.get(overrideBaseId);
    if (!cached) {
      cached = this.defineQuery("wqlEnvelopeQuery", this._wqlEnvelopeInner, undefined, ENVELOPE_QUERY_OPTIONS, overrideBaseId);
      this._wqlEnvelopeCache.set(overrideBaseId, cached);
    }
    return cached;
  }
  _wqlMutationFor(overrideBaseId) {
    if (!overrideBaseId)
      return this.wqlMutation;
    let cached = this._wqlMutationCache.get(overrideBaseId);
    if (!cached) {
      cached = this.defineMutation((body) => this._wqlMutationInner({ ...body, __baseId: overrideBaseId }));
      this._wqlMutationCache.set(overrideBaseId, cached);
    }
    return cached;
  }
  query(queryInput, params = {}, config) {
    const { local, wire } = splitQueryConfig(config);
    const body = {
      __silent: local.silent,
      config: wire,
      params,
      query: queryInput
    };
    return this._wqlQueryFor(local.overrideBaseId)(body);
  }
  mutation(mutationInput, params = {}, config) {
    const { local, wire } = splitQueryConfig(config);
    const body = {
      __silent: local.silent,
      config: wire,
      params,
      query: mutationInput
    };
    return this._wqlMutationFor(local.overrideBaseId)(body);
  }
  wql(wqlInput, params = {}, config) {
    const { local, wire } = splitQueryConfig(config);
    const body = {
      __silent: local.silent,
      config: wire,
      params,
      query: wqlInput
    };
    if (local.mutation) {
      return this._wqlMutationFor(local.overrideBaseId)(body);
    }
    return this._wqlQueryFor(local.overrideBaseId)(body);
  }
  wqlEnvelope(wqlInput, params = {}, config) {
    const { local, wire } = splitQueryConfig(config);
    const body = {
      __silent: local.silent,
      config: wire,
      params,
      query: wqlInput
    };
    return this._wqlEnvelopeFor(local.overrideBaseId)(body);
  }
  get getServerInfo() {
    return this.defineQuery("getServerInfo", (context) => this.treat.api.definitions["server-info"].get({ fetch: { signal: context.signal } }).then(throwOnError), undefined, undefined, this.baseRef);
  }
  openXHR = (method, url, options = {}, { responseType = "json" } = {
    responseType: "json"
  }) => {
    const fullUrl = `${this.http.defaults.baseURL}${url}`;
    const xhr = new XMLHttpRequest;
    xhr.open(method, fullUrl);
    const headers = this.http.defaults.headers || {};
    for (const [key, value] of Object.entries(headers)) {
      if (value) {
        xhr.setRequestHeader(key, value);
      }
    }
    xhr.responseType = responseType;
    xhr.upload.onprogress = (event) => {
      options.onUploadProgress?.(event);
    };
    const send = (data) => {
      const prm = Promise.withResolvers();
      xhr.onload = () => prm.resolve(xhr.response);
      xhr.onerror = () => prm.reject(new Error(`Failed to ${method} ${url}`));
      if (options.signal) {
        options.signal.addEventListener("abort", () => {
          xhr.abort();
          prm.reject(new Error("Aborted"));
        }, { once: true });
      }
      xhr.send(data);
      return prm.promise;
    };
    return { send, xhr };
  };
  openSSE = (url, config = {}) => {
    const params = new URLSearchParams(Object.entries(config).filter(([_, value]) => value != null).map(([key, value]) => [key, String(value)]));
    const fullUrl = `${this.http.defaults.baseURL}${url}?${params.toString()}`;
    const authorization = String(this.http.defaults.headers.Authorization ?? "");
    const sse = new SSEClient(fullUrl, {
      authorization: authorization || undefined
    });
    return sse;
  };
}
export { NetworkMeter, RealtimeManager, SUPPRESSED_READ_META_KEY, SuppressedReadError, suppressionReport, isSuppressedRead, EdenFetchError, treaty, QueryClient, REALTIME_KEY_MARKER, throwOnError, createInterceptedFetcher, wyndbaseSDK };

//# debugId=4C37DB3D0EA21D3164756E2164756E21
