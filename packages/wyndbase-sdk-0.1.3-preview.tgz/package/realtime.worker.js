import {
  openRealtimeStream,
  postWithRetry,
  realtimeUrl,
  subjectOf
} from "./chunk-ckfjhf8x.js";
import"./chunk-hkqy0999.js";

// src/realtime.worker.ts
function isBroken(conn) {
  return conn.everConnected && conn.connId === null;
}
var connections = new Map;
var ports = new Map;
var subscriptionRefCount = new Map;
var keyHashToPorts = new Map;
function connectionKey(baseId, headers) {
  return `${baseId}\x00${subjectOf(headers) ?? "anon"}`;
}
function scopedKey(connKey, keyHash) {
  return `${connKey}\x00${keyHash}`;
}
function markNeedsRebind(connKey, keyHash) {
  for (const state of ports.values()) {
    if (state.connKey !== connKey)
      continue;
    if (state.subscriptions.has(keyHash))
      state.needsRebind.add(keyHash);
  }
}
function markAllNeedingRebind(connKey) {
  for (const state of ports.values()) {
    if (state.connKey !== connKey)
      continue;
    for (const keyHash of state.subscriptions)
      state.needsRebind.add(keyHash);
  }
}
function markedOnConnection(connKey, keyHash) {
  for (const state of ports.values()) {
    if (state.connKey !== connKey)
      continue;
    if (state.needsRebind.has(keyHash))
      return true;
  }
  return false;
}
function clearNeedsRebind(connKey, keyHash) {
  for (const state of ports.values()) {
    if (state.connKey !== connKey)
      continue;
    state.needsRebind.delete(keyHash);
  }
}
function ensureConnection(baseURL, baseId, headers) {
  const connKey = connectionKey(baseId, headers);
  const existing = connections.get(connKey);
  if (existing)
    return existing.ready;
  const url = realtimeUrl(baseURL, baseId, "stream");
  const sse = openRealtimeStream(url);
  let resolveReady;
  const ready = new Promise((resolve) => {
    resolveReady = resolve;
  });
  const conn = {
    connId: null,
    everConnected: false,
    failed: false,
    ready,
    resolveReady,
    sse
  };
  connections.set(connKey, conn);
  sse.on("connected", (newConnId) => {
    const wasReconnect = conn.everConnected;
    conn.everConnected = true;
    conn.connId = newConnId;
    if (!wasReconnect) {
      conn.resolveReady(newConnId);
    } else {
      markAllNeedingRebind(connKey);
      notifyReconnect(connKey);
    }
  });
  sse.on("invalidate", (keyHash) => {
    broadcastToInterestedPorts(connKey, keyHash, {
      keyHash,
      type: "invalidate"
    });
  });
  sse.on("expired", (keyHash) => {
    markNeedsRebind(connKey, keyHash);
    broadcastToInterestedPorts(connKey, keyHash, {
      keyHash,
      type: "expired"
    });
  });
  sse.on("drop", () => {
    conn.connId = null;
    notifyDisconnected(connKey);
  });
  sse.on("fail", () => {
    conn.failed = true;
    conn.connId = null;
    conn.resolveReady("");
    notifyStreamFailed(connKey);
  });
  return ready;
}
function broadcastToInterestedPorts(connKey, keyHash, message) {
  const set = keyHashToPorts.get(scopedKey(connKey, keyHash));
  if (!set)
    return;
  for (const port of set)
    port.postMessage(message);
}
function notifyReconnect(connKey) {
  for (const [port, state] of ports) {
    if (state.connKey !== connKey)
      continue;
    port.postMessage({ type: "reconnected" });
  }
}
function notifyDisconnected(connKey) {
  for (const [port, state] of ports) {
    if (state.connKey !== connKey)
      continue;
    port.postMessage({ type: "disconnected" });
  }
}
function notifyStreamFailed(connKey) {
  for (const [port, state] of ports) {
    if (state.connKey !== connKey)
      continue;
    port.postMessage({ type: "stream-failed" });
  }
}
function joinConnection(port, state, onHealthy) {
  if (connections.get(state.connKey)?.failed) {
    port.postMessage({ type: "stream-failed" });
    return;
  }
  ensureConnection(state.baseURL, state.baseId, state.headers).then(() => {
    if (connections.get(state.connKey)?.failed)
      return;
    onHealthy();
  });
}
async function subscribe(portState, port, keyHash, trackingId, ttlMs) {
  if (portState.subscriptions.has(keyHash)) {
    if (portState.needsRebind.has(keyHash)) {
      return rebind(portState, keyHash, trackingId, ttlMs);
    }
    return "ok";
  }
  const scoped = scopedKey(portState.connKey, keyHash);
  const currentCount = subscriptionRefCount.get(scoped) ?? 0;
  subscriptionRefCount.set(scoped, currentCount + 1);
  portState.subscriptions.add(keyHash);
  let portSet = keyHashToPorts.get(scoped);
  if (!portSet) {
    portSet = new Set;
    keyHashToPorts.set(scoped, portSet);
  }
  portSet.add(port);
  if (currentCount === 0) {
    await ensureConnection(portState.baseURL, portState.baseId, portState.headers);
    const conn = connections.get(portState.connKey);
    if (!conn?.connId) {
      rollbackSubscribe(portState, port, keyHash);
      return "deferred";
    }
    const result = await postWithRetry(realtimeUrl(portState.baseURL, portState.baseId, "subscribe"), JSON.stringify({ connId: conn.connId, keyHash, trackingId, ttlMs }), { ...portState.headers, "Content-Type": "application/json" });
    if (result !== "ok")
      rollbackSubscribe(portState, port, keyHash);
    return result;
  }
  if (markedOnConnection(portState.connKey, keyHash)) {
    return rebind(portState, keyHash, trackingId, ttlMs);
  }
  return "ok";
}
function rollbackSubscribe(portState, port, keyHash) {
  const scoped = scopedKey(portState.connKey, keyHash);
  portState.subscriptions.delete(keyHash);
  portState.needsRebind.delete(keyHash);
  const c = subscriptionRefCount.get(scoped) ?? 0;
  if (c <= 1)
    subscriptionRefCount.delete(scoped);
  else
    subscriptionRefCount.set(scoped, c - 1);
  const portSet = keyHashToPorts.get(scoped);
  if (portSet) {
    portSet.delete(port);
    if (portSet.size === 0)
      keyHashToPorts.delete(scoped);
  }
}
async function rebind(portState, keyHash, trackingId, ttlMs) {
  await ensureConnection(portState.baseURL, portState.baseId, portState.headers);
  const conn = connections.get(portState.connKey);
  if (!conn?.connId)
    return "deferred";
  const result = await postWithRetry(realtimeUrl(portState.baseURL, portState.baseId, "subscribe"), JSON.stringify({ connId: conn.connId, keyHash, trackingId, ttlMs }), { ...portState.headers, "Content-Type": "application/json" });
  if (result === "ok")
    clearNeedsRebind(portState.connKey, keyHash);
  return result;
}
async function unsubscribe(portState, port, keyHash) {
  if (!portState.subscriptions.has(keyHash))
    return;
  const scoped = scopedKey(portState.connKey, keyHash);
  portState.subscriptions.delete(keyHash);
  portState.needsRebind.delete(keyHash);
  const portSet = keyHashToPorts.get(scoped);
  if (portSet) {
    portSet.delete(port);
    if (portSet.size === 0)
      keyHashToPorts.delete(scoped);
  }
  const currentCount = subscriptionRefCount.get(scoped) ?? 0;
  const newCount = currentCount - 1;
  if (newCount <= 0) {
    subscriptionRefCount.delete(scoped);
    const conn = connections.get(portState.connKey);
    if (conn?.connId) {
      await fetch(realtimeUrl(portState.baseURL, portState.baseId, "unsubscribe"), {
        body: JSON.stringify({ connId: conn.connId, keyHash }),
        headers: {
          ...portState.headers,
          "Content-Type": "application/json"
        },
        method: "POST"
      }).catch(() => {});
    }
  } else {
    subscriptionRefCount.set(scoped, newCount);
  }
}
function cleanupPort(port) {
  const state = ports.get(port);
  if (!state)
    return;
  for (const keyHash of [...state.subscriptions]) {
    unsubscribe(state, port, keyHash);
  }
  ports.delete(port);
  closeUnusedConnections();
}
function closeUnusedConnections() {
  const activeKeys = new Set;
  for (const ps of ports.values())
    activeKeys.add(ps.connKey);
  for (const [connKey, conn] of connections) {
    if (!activeKeys.has(connKey)) {
      conn.sse.close();
      connections.delete(connKey);
    }
  }
}
function handleMessage(port, data) {
  switch (data.type) {
    case "init": {
      const headers = data.headers ?? {};
      const state = {
        baseId: data.baseId,
        baseURL: data.baseURL,
        connKey: connectionKey(data.baseId, headers),
        headers,
        needsRebind: new Set,
        subscriptions: new Set
      };
      ports.set(port, state);
      joinConnection(port, state, () => {
        port.postMessage({ type: "connected" });
        const conn = connections.get(state.connKey);
        if (conn && isBroken(conn))
          port.postMessage({ type: "disconnected" });
      });
      break;
    }
    case "subscribe": {
      const keyHash = data.keyHash;
      const requestId = data.requestId;
      const answer = (outcome) => {
        port.postMessage(outcome === "ok" ? { keyHash, requestId, type: "subscribe-ok" } : { keyHash, reason: outcome, requestId, type: "subscribe-failed" });
      };
      const state = ports.get(port);
      if (!state) {
        answer("deferred");
        break;
      }
      subscribe(state, port, keyHash, data.trackingId, data.ttlMs).then(answer).catch(() => answer("failed"));
      break;
    }
    case "unsubscribe": {
      const state = ports.get(port);
      if (state)
        unsubscribe(state, port, data.keyHash);
      break;
    }
    case "update-headers": {
      const state = ports.get(port);
      if (!state)
        break;
      state.headers = data.headers;
      const nextKey = connectionKey(state.baseId, state.headers);
      if (nextKey === state.connKey)
        break;
      for (const keyHash of [...state.subscriptions]) {
        unsubscribe(state, port, keyHash);
      }
      state.connKey = nextKey;
      closeUnusedConnections();
      joinConnection(port, state, () => port.postMessage({ type: "reconnected" }));
      break;
    }
    case "port-closing": {
      cleanupPort(port);
      break;
    }
    case "resubscribe-batch": {
      const state = ports.get(port);
      if (!state) {
        port.postMessage({
          missing: data.keyHashes ?? [],
          requestId: data.requestId,
          type: "resubscribe-batch-result"
        });
        break;
      }
      resubscribeBatch(state, port, data.requestId, data.keyHashes);
      break;
    }
  }
}
async function resubscribeBatch(portState, port, requestId, keyHashes) {
  const connKey = portState.connKey;
  const answer = (missing) => {
    for (const keyHash of missing)
      markNeedsRebind(connKey, keyHash);
    port.postMessage({ missing, requestId, type: "resubscribe-batch-result" });
  };
  const conn = connections.get(connKey);
  if (!conn?.connId) {
    answer(keyHashes);
    return;
  }
  try {
    const r = await fetch(realtimeUrl(portState.baseURL, portState.baseId, "resubscribe"), {
      body: JSON.stringify({ connId: conn.connId, keyHashes }),
      headers: { ...portState.headers, "Content-Type": "application/json" },
      method: "POST"
    });
    if (!r.ok) {
      answer(keyHashes);
      return;
    }
    const data = await r.json();
    const missing = data.missing ?? [];
    for (const keyHash of missing)
      markNeedsRebind(connKey, keyHash);
    const reexecute = [...missing];
    for (const keyHash of data.ok ?? []) {
      clearNeedsRebind(connKey, keyHash);
      if (!portState.subscriptions.has(keyHash))
        reexecute.push(keyHash);
    }
    port.postMessage({
      missing: reexecute,
      requestId,
      type: "resubscribe-batch-result"
    });
  } catch {
    answer(keyHashes);
  }
}
self.onconnect = (event) => {
  const port = event.ports[0];
  port.onmessage = (e) => handleMessage(port, e.data);
  port.onmessageerror = (e) => {
    if (typeof console !== "undefined") {
      console.error("[wyndb realtime worker] port message error", e);
    }
  };
  port.start();
};
export {
  connectionKey,
  scopedKey
};

//# debugId=CB7EF3029A4C61F464756E2164756E21
