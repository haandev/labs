import {
  throwOnError
} from "../chunk-sr1a5ekk.js";
import"../chunk-8rtgyjf5.js";
import"../chunk-ckfjhf8x.js";
import"../chunk-1vz930gy.js";
import {
  definePlugin
} from "../chunk-83vjawdv.js";
import"../chunk-hkqy0999.js";

// src/plugins/alerts.ts
var alertsInboxChannel = {
  id: "alerts",
  markSeen: {
    allNq: "system.markAllAlertNotificationsRead",
    idParam: "notificationId",
    kind: "item",
    nq: "system.markAlertNotificationRead"
  },
  queries: {
    all: { nq: "system.listMyAlertNotifications" },
    count: { nq: "system.countUnreadAlertNotifications" },
    unread: { nq: "system.listMyUnreadAlertNotifications" }
  },
  toItem: (n) => ({
    channelId: "alerts",
    description: n.type === "fired" ? "Fired" : "Resolved",
    id: n._id,
    occurredAt: n.occurredAt,
    title: n.payload?.alertName ?? "Alert",
    unread: !n.readAt
  })
};
var Alerts = definePlugin("alerts", (sdk) => ({
  accessWarnings(alertId) {
    return sdk.base.alerts({ alertId }).access.get().then(throwOnError);
  },
  create(input) {
    return sdk.base.alerts.post(input).then(throwOnError);
  },
  inbox: alertsInboxChannel,
  pause(alertId) {
    return sdk.base.alerts({ alertId }).pause.post().then(throwOnError);
  },
  remove(alertId) {
    return sdk.base.alerts({ alertId }).delete().then(throwOnError);
  },
  resume(alertId) {
    return sdk.base.alerts({ alertId }).resume.post().then(throwOnError);
  },
  update(alertId, patch) {
    return sdk.base.alerts({ alertId }).patch(patch).then(throwOnError);
  }
}));
export {
  Alerts,
  alertsInboxChannel
};

//# debugId=5355011203F3680164756E2164756E21
