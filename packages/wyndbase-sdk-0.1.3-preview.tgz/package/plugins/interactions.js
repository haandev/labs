import {
  definePlugin
} from "../chunk-83vjawdv.js";
import"../chunk-hkqy0999.js";

// src/plugins/interactions.ts
var interactionsInboxChannel = {
  id: "interactions",
  queries: {
    all: { nq: "system.listPendingInteractions" },
    count: { nq: "system.countPendingInteractions" },
    unread: { nq: "system.listPendingInteractions" }
  },
  toItem: (r) => ({
    channelId: "interactions",
    description: r.description || "Workflow form",
    id: r._id,
    occurredAt: r.createdAt,
    title: r.name,
    unread: true
  })
};
var Interactions = definePlugin("interactions", (_sdk) => ({
  inbox: interactionsInboxChannel
}));
export {
  Interactions,
  interactionsInboxChannel
};

//# debugId=F5ABBD84C47A6E6864756E2164756E21
