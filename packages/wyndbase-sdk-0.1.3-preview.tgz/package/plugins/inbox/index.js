import {
  definePlugin
} from "../../chunk-83vjawdv.js";
import"../../chunk-hkqy0999.js";

// src/plugins/inbox/handle.ts
var MUTATION = { allowMutation: true, mutation: true };
async function fetchRef(sdk, ref, baseId) {
  return await sdk.wql(ref.nq, ref.params, { overrideBaseId: baseId }).fetch({ staleTime: 0 });
}
function unwrapCount(countRows) {
  return Number(countRows[0]?.count ?? 0);
}
function sameKey(a, b) {
  return a.length === b.length && a.every((part, index) => part === b[index]);
}
function sameScope(a, b) {
  return a.baseId === b.baseId && a.context === b.context;
}
function createInboxHandle(sdk, channels, options = {}) {
  const typedChannels = channels;
  const ids = channels.map((channel) => channel.id);
  const resolveBaseId = options.resolveBaseId ?? (() => sdk.baseRef);
  const readScope = () => ({
    baseId: resolveBaseId(),
    context: sdk.queryKeyContext
  });
  const composedKey = (scope, mode) => [
    "inbox",
    scope.baseId,
    mode,
    ...ids,
    ...scope.context !== undefined ? [scope.context] : []
  ];
  const armed = new Map;
  const modeHolds = new Map;
  const subscriptions = new Set;
  let seenScope = readScope();
  let cacheWatch;
  const scopeKey = (scope) => `${scope.baseId}|${scope.context ?? ""}`;
  const armKey = (scope, mode, ref) => `${scopeKey(scope)}|${mode}|${ref.nq}|${JSON.stringify(ref.params ?? {})}`;
  const holdKey = (scope, mode) => `${scopeKey(scope)}|${mode}`;
  const currentScope = () => {
    const scope = readScope();
    if (sameScope(scope, seenScope))
      return seenScope;
    seenScope = scope;
    for (const subscription of [...subscriptions])
      subscription.rebase(scope);
    return scope;
  };
  const refsOf = (channel, mode) => [
    { isCount: false, ref: channel.queries[mode] },
    { isCount: true, ref: channel.queries.count }
  ];
  const toItems = (channel, rows) => rows.map((row) => channel.toItem(row)).sort((a, b) => Date.parse(b.occurredAt) - Date.parse(a.occurredAt));
  const invalidate = (queryKey) => sdk.queryClient.invalidateQueries({ exact: true, queryKey });
  const watchCache = () => {
    if (cacheWatch)
      return;
    cacheWatch = sdk.queryClient.getQueryCache().subscribe((event) => {
      if (event.type !== "removed")
        return;
      if (event.query.queryKey[0] !== "inbox")
        return;
      for (const [id, hold] of [...modeHolds])
        if (sameKey(event.query.queryKey, hold.composedKey))
          releaseHold(id);
    });
  };
  const emit = (key, rows) => {
    const child = armed.get(key);
    if (!child)
      return;
    child.latest = rows;
    for (const listener of child.listeners)
      listener(rows);
  };
  const armFields = (scope, mode, ref, isCount, notify, die) => {
    const reader = sdk.wql(ref.nq, ref.params, { overrideBaseId: scope.baseId });
    const caller = reader.realtime({
      forceRefetch: notify,
      onInvalidate: () => void invalidate(composedKey(scope, mode)),
      pauseWhenHidden: isCount ? false : undefined
    });
    const first = Promise.resolve(caller);
    first.then(notify, die);
    return {
      first,
      readKey: reader.queryKey,
      unsubscribe: () => {
        first.catch(() => {}).then(() => caller.unsubscribe());
      },
      watchKey: caller.queryKey
    };
  };
  const acquire = (scope, mode, channelId, ref, isCount) => {
    const key = armKey(scope, mode, ref);
    const notify = (rows) => emit(key, rows);
    const die = () => {
      const slot = armed.get(key);
      if (slot)
        slot.dead = true;
    };
    const existing = armed.get(key);
    if (existing) {
      existing.refCount += 1;
      if (existing.dead) {
        existing.dead = false;
        Object.assign(existing, armFields(scope, mode, ref, isCount, notify, die));
      }
      return existing;
    }
    watchCache();
    const child = {
      channelId,
      listeners: new Set,
      refCount: 1,
      scope,
      ...armFields(scope, mode, ref, isCount, notify, die)
    };
    armed.set(key, child);
    return child;
  };
  const release = (key) => {
    const child = armed.get(key);
    if (!child)
      return;
    child.refCount -= 1;
    if (child.refCount > 0)
      return;
    armed.delete(key);
    child.unsubscribe();
    if (armed.size > 0)
      return;
    cacheWatch?.();
    cacheWatch = undefined;
  };
  const releaseHold = (id) => {
    const hold = modeHolds.get(id);
    if (!hold)
      return;
    modeHolds.delete(id);
    for (const key of hold.keys)
      release(key);
  };
  const armMode = (scope, mode) => {
    const id = holdKey(scope, mode);
    if (modeHolds.has(id))
      return null;
    const keys = [];
    modeHolds.set(id, { composedKey: composedKey(scope, mode), keys });
    const fills = new Map;
    for (const channel of typedChannels)
      for (const { isCount, ref } of refsOf(channel, mode)) {
        const key = armKey(scope, mode, ref);
        const live = armed.get(key);
        const armedAlready = live !== undefined && !live.dead;
        const child = acquire(scope, mode, channel.id, ref, isCount);
        keys.push(key);
        if (!armedAlready)
          fills.set(key, child.first);
      }
    return (ref) => {
      const fill = fills.get(armKey(scope, mode, ref));
      if (!fill)
        return fetchRef(sdk, ref, scope.baseId);
      return fill.catch((error) => {
        releaseHold(id);
        throw error;
      });
    };
  };
  const plainRead = (scope) => (ref) => fetchRef(sdk, ref, scope.baseId);
  const loadChannel = async (channel, mode, read) => {
    const [rows, countRows] = await Promise.all([
      read(channel.queries[mode]),
      read(channel.queries.count)
    ]);
    return {
      count: unwrapCount(countRows),
      id: channel.id,
      items: toItems(channel, rows)
    };
  };
  const loadMode = async (mode, read) => {
    const loaded = await Promise.all(typedChannels.map((channel) => loadChannel(channel, mode, read)));
    const count = {};
    const itemsByChannel = {};
    let total = 0;
    for (const entry of loaded) {
      count[entry.id] = entry.count;
      itemsByChannel[entry.id] = entry.items;
      total += entry.count;
    }
    return { count, list: itemsByChannel, total };
  };
  const queryDefFor = (mode) => ({
    queryFn: () => loadMode(mode, plainRead(currentScope())),
    get queryKey() {
      return composedKey(readScope(), mode);
    },
    realtime: () => {
      const scope = currentScope();
      return {
        queryFn: () => loadMode(mode, armMode(scope, mode) ?? plainRead(scope)),
        queryKey: composedKey(scope, mode)
      };
    }
  });
  const subscribe = (opts) => {
    const baseline = new Map;
    const counts = new Map;
    let held = [];
    const attach = (scope2, channel, ref, isCount, listener) => {
      const child = acquire(scope2, "unread", channel.id, ref, isCount);
      child.listeners.add(listener);
      held.push({ key: armKey(scope2, "unread", ref), listener });
      if (child.latest)
        listener(child.latest);
    };
    const detach = () => {
      for (const { key, listener } of held) {
        armed.get(key)?.listeners.delete(listener);
        release(key);
      }
      held = [];
    };
    const emitCount = () => {
      const byChannel = {};
      let total = 0;
      for (const channel of typedChannels) {
        const value = counts.get(channel.id) ?? 0;
        byChannel[channel.id] = value;
        total += value;
      }
      opts.onCount?.(total, byChannel);
    };
    const attachAll = (scope2) => {
      for (const channel of typedChannels) {
        attach(scope2, channel, channel.queries.unread, false, (rows) => {
          const items = toItems(channel, rows);
          const previous = baseline.get(channel.id);
          baseline.set(channel.id, new Set(items.map((item) => item.id)));
          if (!previous)
            return;
          const fresh = items.filter((item) => !previous.has(item.id));
          if (fresh.length > 0)
            opts.onNew?.(fresh);
        });
        attach(scope2, channel, channel.queries.count, true, (rows) => {
          const next = unwrapCount(rows);
          if (counts.get(channel.id) === next)
            return;
          counts.set(channel.id, next);
          emitCount();
        });
      }
    };
    const entry = {
      rebase: (scope2) => {
        detach();
        baseline.clear();
        counts.clear();
        attachAll(scope2);
      }
    };
    const scope = currentScope();
    subscriptions.add(entry);
    attachAll(scope);
    let released = false;
    return {
      unsubscribe: () => {
        if (released)
          return;
        released = true;
        subscriptions.delete(entry);
        detach();
      }
    };
  };
  const runMutation = async (nq, params) => {
    await sdk.wql(nq, params, MUTATION);
  };
  const invalidateOwned = async (scope, channelId) => {
    const targets = [
      composedKey(scope, "unread"),
      composedKey(scope, "all")
    ];
    for (const child of armed.values())
      if (sameScope(child.scope, scope) && (channelId === undefined || child.channelId === channelId))
        targets.push(child.readKey, child.watchKey);
    await Promise.all(targets.map(invalidate));
  };
  const markSeen = async (channelId, ids2) => {
    const scope = currentScope();
    const strategy = typedChannels.find((channel) => channel.id === channelId)?.markSeen;
    try {
      if (strategy?.kind === "item")
        await Promise.all(ids2.map((id) => runMutation(strategy.nq, { [strategy.idParam]: id })));
    } finally {
      await invalidateOwned(scope, channelId);
    }
  };
  const markAllSeen = async () => {
    const scope = currentScope();
    const runs = [];
    for (const channel of typedChannels) {
      const strategy = channel.markSeen;
      if (strategy?.kind === "item" && strategy.allNq)
        runs.push(runMutation(strategy.allNq, {}));
    }
    try {
      await Promise.all(runs);
    } finally {
      await invalidateOwned(scope);
    }
  };
  return {
    all: queryDefFor("all"),
    markAllSeen,
    markSeen,
    subscribe,
    unread: queryDefFor("unread")
  };
}

// src/plugins/inbox/index.ts
var Inbox = definePlugin("inbox", (sdk) => ({
  channels: (...args) => {
    const [first, second] = args;
    const list = Array.isArray(first) ? first : args;
    const options = Array.isArray(first) ? second : undefined;
    return createInboxHandle(sdk, list, options);
  }
}));
export {
  Inbox
};

//# debugId=83CA9EDCDFBAC37164756E2164756E21
