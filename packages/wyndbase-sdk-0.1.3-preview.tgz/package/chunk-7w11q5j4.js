import {
  createStepUpChallenge
} from "./chunk-ad1fswck.js";
import {
  NOTIFICATION_SILENT_HEADER,
  isHttpError
} from "./chunk-1vz930gy.js";
import {
  pluginName
} from "./chunk-83vjawdv.js";

// ../shared/src/auth-factors/bearer.ts
var TOKEN_AUDIENCE_ERROR_DESCRIPTION = "token audience does not match this base";
var CHALLENGE_VALUE_CLASS = "A-Za-z0-9 ._:-";
var CHALLENGE_VALUE_PATTERN = new RegExp(`^[${CHALLENGE_VALUE_CLASS}]*$`);
var OUTSIDE_CHALLENGE_VALUE_CLASS = new RegExp(`[^${CHALLENGE_VALUE_CLASS}]`, "g");
var RESOURCE_PARAM = "resource";
function isTokenAudienceChallenge(challenge) {
  if (!challenge)
    return false;
  if (!/^\s*Bearer\b/i.test(challenge))
    return false;
  if (!/\berror\s*=\s*"?invalid_token"?/i.test(challenge))
    return false;
  if (!challenge.includes(`error_description="${TOKEN_AUDIENCE_ERROR_DESCRIPTION}"`))
    return false;
  return new RegExp(`\\b${RESOURCE_PARAM}\\s*=\\s*"?[^",\\s]+`, "i").test(challenge);
}

// ../shared/src/auth-factors/claims.ts
var AMR_VALUES = [
  "face",
  "fpt",
  "geo",
  "hwk",
  "iris",
  "kba",
  "mca",
  "mfa",
  "otp",
  "pin",
  "pop",
  "pwd",
  "rba",
  "retina",
  "sc",
  "sms",
  "swk",
  "tel",
  "user",
  "vbm",
  "wia"
];
var REGISTERED = new Set(AMR_VALUES);
function aalFromAcr(acr) {
  const n = acr ? Number(acr.replace(/^aal/, "")) : Number.NaN;
  return n === 2 || n === 3 ? n : 1;
}

// ../shared/src/auth-types.ts
import { z } from "zod";
var AuthorizeQuerySchema = z.object({
  client_id: z.string().min(1, "client_id is required"),
  code_challenge: z.string().min(1, "code_challenge is required"),
  code_challenge_method: z.string().default("S256").optional(),
  confirmed: z.string().optional(),
  redirect_uri: z.string().url("redirect_uri must be a valid URL"),
  redirected: z.string().optional(),
  response_type: z.string().default("code").optional(),
  scope: z.string().optional(),
  state: z.string().min(1, "state is required")
});
var OAuth2State = z.object({
  csrf: z.string().min(1, "csrf is required"),
  metadata: z.record(z.string(), z.any()).optional(),
  nonce: z.string().optional(),
  redirect: z.string().optional(),
  timestamp: z.number().optional()
});
var OAuth2StateCodec = z.codec(z.string(), OAuth2State, {
  decode: (value) => OAuth2State.parse(JSON.parse(value)),
  encode: (value) => JSON.stringify(value)
});
var OAuth2TokenResponse = z.object({
  access_token: z.string(),
  expires_in: z.number(),
  refresh_token: z.string().optional(),
  scopes: z.string().array(),
  token_type: z.string()
});
var OAuth2RequestCommons = z.object({
  client_id: z.string().min(1, "client_id is required"),
  grant_type: z.enum([
    "authorization_code",
    "refresh_token",
    "flow_start",
    "flow"
  ])
});
var OAuth2RequestGrantFlowStart = OAuth2RequestCommons.extend({
  captcha_token: z.string().optional(),
  grant_type: z.literal("flow_start"),
  identifier: z.string().min(1)
});
var OAuth2RequestGrantAuthorizationCode = OAuth2RequestCommons.extend({
  code: z.string().min(1),
  code_verifier: z.string(),
  grant_type: z.literal("authorization_code"),
  redirect_uri: z.string().optional(),
  scope: z.string().optional(),
  state: z.unknown().optional()
});
var OAuth2RequestGrantRefreshToken = OAuth2RequestCommons.extend({
  grant_type: z.literal("refresh_token"),
  refresh_token: z.string().min(1).optional()
});
var OAuth2RequestGrantFlow = OAuth2RequestCommons.extend({
  captcha_token: z.string().optional(),
  code: z.string().min(1),
  factor_id: z.string().optional(),
  factor_type: z.string().min(1),
  flow_token: z.string().min(1),
  grant_type: z.literal("flow")
});
var OAuth2Request = z.discriminatedUnion("grant_type", [
  OAuth2RequestGrantFlowStart,
  OAuth2RequestGrantAuthorizationCode,
  OAuth2RequestGrantRefreshToken,
  OAuth2RequestGrantFlow
]);
var JwtPayload = z.object({
  acr: z.string().optional(),
  amr: z.string().array().optional(),
  baseId: z.string(),
  clientId: z.string(),
  exp: z.number(),
  iss: z.string(),
  roles: z.string().array(),
  scope: z.string(),
  sid: z.string().optional(),
  sub: z.string(),
  typ: z.enum(["access", "session"]),
  userId: z.string()
});

// ../shared/src/nanoid.ts
import { customAlphabet } from "nanoid";
var alphabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_";
var length = 12;
var nanoid = customAlphabet(alphabet, length);
function fnv1a(str) {
  let h = 2166136261;
  for (let i = 0;i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = h * 16777619 >>> 0;
  }
  return h >>> 0;
}
function createDeterministicIdGenerator(alphabet2, length2) {
  const base = alphabet2.length;
  let index = 0;
  function next() {
    let hash = fnv1a(index.toString());
    index++;
    let out = "";
    while (out.length < length2) {
      out += alphabet2[hash % base];
      hash = fnv1a(hash.toString());
    }
    return out;
  }
  function reset() {
    index = 0;
  }
  return { next, reset };
}
var { next: nextId, reset: resetDeterministicId } = createDeterministicIdGenerator(alphabet, length);

// ../shared/src/signin-button.ts
var DEFAULT_SIGNIN_BUTTON_SIZE = "md";

// src/plugins/oauth2.ts
import { createStore } from "zustand/vanilla";

// src/util/safeBase64.ts
var safeBase64 = (input) => btoa(input).replace(/\+/g, "-").replace(/\//g, "_").replace(/=/g, "");

// src/plugins/hosted-step-up.ts
function stepUpCleared(outcome) {
  if (outcome.reachedAal === null)
    return false;
  return outcome.reachedAal >= outcome.requiredAal;
}
function hostedStepUpHandler(oauth2, options) {
  const challenge = createStepUpChallenge();
  const runCeremony = async (openedAal) => {
    const reachedAal = await new Promise((resolve) => {
      let answered = false;
      const settle = (aal) => {
        if (answered)
          return;
        answered = true;
        resolve(aal);
      };
      oauth2.authorize({
        acrValues: openedAal,
        onFinished: (result) => settle(result?.aal ?? null),
        popup: options?.popup ?? {}
      }).catch(() => settle(null));
    });
    challenge.settle(stepUpCleared({ reachedAal, requiredAal: openedAal }));
  };
  return (requiredAal) => challenge.join(requiredAal, () => {
    runCeremony(requiredAal);
  });
}

// src/plugins/step-up-replay.ts
async function replayAfterStepUp(requiredAal, config, deps) {
  const replayable = !!config && !config.stepUpRetried && !config.url?.includes("/account/step-up");
  if (!replayable)
    return { replayed: false };
  const cleared = await deps.onStepUpRequired?.(requiredAal);
  if (cleared !== true)
    return { replayed: false };
  config.stepUpRetried = true;
  const headers = config.headers instanceof Headers ? config.headers : new Headers;
  headers.set("Authorization", deps.authorization());
  return {
    replayed: true,
    response: await deps.request({ ...config, baseURL: "", headers })
  };
}

// src/plugins/oauth2.ts
var TOKEN_EXPIRY_SKEW_MS = 30000;
var POPUP_CLOSED_POLL_MS = 400;
var IDEMPOTENT_METHODS = new Set([
  "GET",
  "HEAD",
  "OPTIONS",
  "TRACE",
  "PUT",
  "DELETE"
]);

class TokenRequestError extends Error {
  classification;
  status;
  constructor(classification, status, message, options) {
    super(message, options);
    this.classification = classification;
    this.status = status;
    this.name = "TokenRequestError";
  }
}
var classifyTokenFailure = (status, body) => {
  if (status === 401)
    return "refused";
  if (status === 400) {
    const raw = body?.error;
    const code = typeof raw === "string" ? raw : raw?.code;
    if (code === "invalid_grant")
      return "refused";
  }
  return "unavailable";
};
var bodyFieldOf = (config, field) => {
  const data = config?.data;
  if (!data)
    return;
  const asString = (value) => typeof value === "string" ? value : undefined;
  if (typeof data === "string") {
    try {
      return asString(JSON.parse(data)[field]);
    } catch {
      return new URLSearchParams(data).get(field) ?? undefined;
    }
  }
  if (data instanceof URLSearchParams)
    return data.get(field) ?? undefined;
  if (typeof FormData !== "undefined" && data instanceof FormData)
    return asString(data.get(field));
  if (typeof data === "object")
    return asString(data[field]);
  return;
};
var grantTypeOf = (config) => bodyFieldOf(config, "grant_type");
var clientIdOf = (config) => bodyFieldOf(config, "client_id");

class OAuth2 {
  sdk;
  config;
  static [pluginName] = "auth";
  store;
  onStepUpRequired;
  refreshGrantEvicted = false;
  mintedClientId = null;
  clientEnsured = false;
  ensureClientPromise = null;
  recoverClientPromise = null;
  constructor(sdk, config) {
    this.sdk = sdk;
    this.config = config;
    this.mintedClientId = this.use("dcr_client_id") ?? null;
    this.initializeInterceptors();
    this.initializeStore();
    this.refresh(true, true).catch(() => {});
  }
  async getSignInButton(size = DEFAULT_SIGNIN_BUTTON_SIZE) {
    return await this.sdk.tenant.oauth2[`signin-button-${size}.svg`].get();
  }
  tokenRequest(request) {
    const req = {
      ...request,
      client_id: this.clientId
    };
    const factorType = req.factor_type;
    const queryKey = factorType ? `tokenRequest:${req.grant_type}:${factorType}` : `tokenRequest:${req.grant_type}`;
    const query = this.sdk.defineQuery(queryKey, (context) => this.sdk.tenant.oauth2.token.post(req, {
      fetch: { signal: context.signal }
    }).then((response) => {
      const status = response.status;
      if (response.error) {
        throw new TokenRequestError(classifyTokenFailure(status, response.error.value), status, "Token request failed");
      }
      if (!response.data) {
        throw new TokenRequestError("unavailable", status, "No data received from token endpoint");
      }
      return response.data;
    }).then((data) => {
      if (!data.flow_required) {
        this.setTokens(data);
      }
      return data;
    }).catch((error) => {
      if (error instanceof TokenRequestError) {
        if (error.classification === "refused")
          this.clearTokens();
        throw error;
      }
      throw new TokenRequestError("unavailable", isHttpError(error) ? error.response?.status : undefined, "Token request failed", { cause: error });
    }));
    const send = async () => await query.fetch({}, { retry: false, staleTime: 5000 });
    return { request: req, send };
  }
  get clientId() {
    return this.mintedClientId ?? this.config.clientId;
  }
  async ensureRegisteredClient() {
    if (!this.config.autoRegister || this.clientEnsured)
      return;
    if (!this.ensureClientPromise) {
      this.ensureClientPromise = this.resolveClientRegistration().then(() => {
        this.clientEnsured = true;
      }).finally(() => {
        this.ensureClientPromise = null;
      });
    }
    await this.ensureClientPromise;
  }
  async clientExists(clientId) {
    try {
      await this.sdk.http.get(`/${this.sdk.baseRef}/oauth2/client-info?client_id=${encodeURIComponent(clientId)}`);
      return true;
    } catch (error) {
      if (isHttpError(error) && error.response?.status === 404)
        return false;
      throw error;
    }
  }
  async resolveClientRegistration() {
    if (this.mintedClientId) {
      if (await this.clientExists(this.mintedClientId))
        return;
      this.mintedClientId = null;
      this.unset("dcr_client_id");
    }
    if (await this.clientExists(this.config.clientId))
      return;
    const auto = this.config.autoRegister;
    const opts = typeof auto === "object" && auto !== null ? auto : {};
    const { data } = await this.sdk.http.request({
      data: {
        client_name: opts.clientName ?? this.config.clientId,
        redirect_uris: opts.redirectUris ?? [this.canonicalRedirectUri()]
      },
      method: "POST",
      url: `/${this.sdk.baseRef}/oauth2/register-client`
    });
    if (!data?.client_id) {
      throw new Error("Client registration returned no client_id");
    }
    this.mintedClientId = data.client_id;
    this.set("dcr_client_id", data.client_id);
    this.sdk.http.defaults.headers["x-client-id"] = data.client_id;
  }
  unknownClientIdOf(error) {
    if (!isHttpError(error))
      return null;
    const body = error.response?.data;
    const message = (typeof body?.error === "object" ? body.error?.message : undefined) ?? body?.message;
    const match = /^Client not found: (.+)$/.exec(message ?? "");
    return match?.[1] ?? null;
  }
  recoverDeletedClient() {
    if (!this.recoverClientPromise) {
      this.recoverClientPromise = this.reRegisterAfterClientLoss().finally(() => {
        this.recoverClientPromise = null;
      });
    }
    return this.recoverClientPromise;
  }
  async reRegisterAfterClientLoss() {
    this.mintedClientId = null;
    this.unset("dcr_client_id");
    this.clientEnsured = false;
    this.logout();
    if (this.config.autoRegister) {
      try {
        await this.ensureRegisteredClient();
      } catch {}
    }
    this.config.onUnauthorized?.();
  }
  applyTokenResponse(tokens) {
    this.setTokens(tokens);
  }
  cleanReturnUrl() {
    const url = new URL(window.location.href);
    for (const param of ["code", "state", "grant_type", "scope"]) {
      url.searchParams.delete(param);
    }
    return url.toString();
  }
  canonicalRedirectUri() {
    const url = new URL(window.location.href);
    return `${url.origin}${url.pathname}`;
  }
  enableHostedStepUp(options) {
    this.onStepUpRequired = hostedStepUpHandler(this, options);
  }
  async authorize(config) {
    await this.ensureRegisteredClient();
    const pkce = await this.generatePKCE();
    this.set("pkce_code_verifier", pkce.codeVerifier);
    const csrfToken = nanoid();
    const nonce = nanoid();
    const timestamp = Date.now();
    const redirectUri = this.canonicalRedirectUri();
    const returnUrl = this.cleanReturnUrl();
    const stateData = {
      csrf: csrfToken,
      nonce,
      redirect: returnUrl,
      timestamp
    };
    const state = encodeURIComponent(JSON.stringify(stateData));
    this.set("csrf_state", csrfToken);
    this.set("oauth2_nonce", nonce);
    this.set("oauth2_timestamp", timestamp);
    const clientId = this.clientId;
    let finished = false;
    let closedPoll;
    const finish = (result) => {
      if (finished)
        return;
      finished = true;
      if (closedPoll !== undefined)
        clearInterval(closedPoll);
      window.removeEventListener("message", onAuthMessage);
      config?.onFinished?.(result);
    };
    const adoptAndFinish = () => {
      const accessToken = this.use("access_token");
      const tokenType = this.use("token_type") || "Bearer";
      let jwtPayload = null;
      if (accessToken) {
        jwtPayload = this.parseJwt(accessToken);
        this.setAuthorizationHeader(`${tokenType} ${accessToken}`);
        this.store.setState({ isAuthenticated: true, jwtPayload });
      }
      if (config?.onFinished) {
        const aal = jwtPayload ? aalFromAcr(jwtPayload.acr) : null;
        if (config.acrValues && (aal === null || aal < config.acrValues))
          return;
        return finish(aal === null ? null : { aal });
      }
      if (config?.onSuccess)
        return config.onSuccess();
      window.location.reload();
    };
    const onAuthMessage = (event) => {
      if (event.origin !== window.location.origin)
        return;
      if (event.data?.type !== "AUTH_SUCCESS")
        return;
      if (!config?.onFinished)
        window.removeEventListener("message", onAuthMessage);
      adoptAndFinish();
    };
    const authUrl = new URL(`${this.sdk.http.defaults.baseURL}/${this.sdk.baseRef}/oauth2/authorize`);
    this.set("oauth2_redirect_uri", redirectUri);
    this.set("registered_redirect_uri", redirectUri);
    authUrl.searchParams.set("client_id", clientId);
    authUrl.searchParams.set("redirect_uri", redirectUri);
    authUrl.searchParams.set("response_type", "code");
    authUrl.searchParams.set("state", state);
    authUrl.searchParams.set("code_challenge", pkce.codeChallenge);
    authUrl.searchParams.set("code_challenge_method", pkce.codeChallengeMethod);
    if (config?.scope?.length) {
      authUrl.searchParams.set("scope", config.scope.join(" "));
    }
    if (config?.acrValues) {
      authUrl.searchParams.set("acr_values", `aal${config.acrValues}`);
    }
    if (config?.redirect) {
      window.location.assign(authUrl.toString());
      return;
    }
    window.addEventListener("message", onAuthMessage);
    const popup = window.open(authUrl.toString(), config?.popup ? "wyndb_auth" : "_blank", config?.popup ? `width=${config.popup.width || 500},height=${config.popup.height || 600},scrollbars=yes,resizable=yes,status=yes,location=yes` : undefined);
    if (config?.popup && popup) {
      popup.focus();
    }
    if (config?.onFinished) {
      if (!popup)
        finish(null);
      else
        closedPoll = setInterval(() => {
          if (popup.closed)
            finish(null);
        }, POPUP_CLOSED_POLL_MS);
    }
  }
  async grant() {
    const searchParams = new URLSearchParams(window.location.search);
    const code = searchParams.get("code");
    const state = searchParams.get("state");
    const grant_type = searchParams.get("grant_type");
    if (!code || !state || !grant_type || grant_type !== "authorization_code")
      return;
    const validatedState = this.validateCSRFState(state);
    const codeVerifier = this.use("pkce_code_verifier");
    if (!codeVerifier) {
      throw new Error("PKCE code verifier not found. Please call authorize() first.");
    }
    const redirectUri = this.use("oauth2_redirect_uri");
    const grantedScope = searchParams.get("scope");
    const req = {
      code,
      code_verifier: codeVerifier,
      grant_type: "authorization_code",
      ...redirectUri ? { redirect_uri: redirectUri } : {},
      ...grantedScope ? { scope: grantedScope } : {},
      state: validatedState
    };
    await this.tokenRequest(req).send();
    this.unset("pkce_code_verifier");
    this.unset("csrf_state");
    this.unset("oauth2_nonce");
    this.unset("oauth2_timestamp");
    this.unset("oauth2_redirect_uri");
    return { returnUrl: this.sameOriginReturnUrl(validatedState?.redirect) };
  }
  sameOriginReturnUrl(raw) {
    if (!raw)
      return null;
    try {
      return new URL(raw).origin === window.location.origin ? raw : null;
    } catch {
      return null;
    }
  }
  async signIn(config) {
    const returning = new URLSearchParams(window.location.search).get("grant_type") === "authorization_code";
    if (returning) {
      let returnUrl = null;
      try {
        returnUrl = (await this.grant())?.returnUrl ?? null;
      } catch {
        return { status: "failed" };
      }
      if (window.opener) {
        this.complete();
      } else {
        config?.onSuccess?.({ returnUrl });
      }
      return { returnUrl, status: "granted" };
    }
    if (this.isAuthenticated()) {
      config?.onSuccess?.();
      return { status: "authenticated" };
    }
    await this.authorize({ redirect: true, scope: config?.scope });
    return { status: "redirecting" };
  }
  complete(config) {
    if (window.opener) {
      window.opener.postMessage({ grant: true, type: "AUTH_SUCCESS" }, window.location.origin);
      window.close();
      return;
    }
    if (config?.onSuccess)
      return config.onSuccess();
    window.location.reload();
  }
  logout(config) {
    this.clearTokens();
    if (config?.scope !== "sso")
      return;
    const url = new URL(`${this.sdk.http.defaults.baseURL}/${this.sdk.baseRef}/oauth2/logout`);
    url.searchParams.set("client_id", this.clientId);
    url.searchParams.set("post_logout_redirect_uri", config.postLogoutRedirectUri ?? this.use("registered_redirect_uri") ?? this.canonicalRedirectUri());
    window.location.assign(url.toString());
  }
  async getStepUpFactors(aal, client) {
    const account = this.sdk.tenant.account;
    const { data, error } = await account["step-up"].get({
      query: {
        aal,
        ...client?.webauthn === false ? { webauthn: "false" } : {}
      }
    });
    if (error)
      throw error;
    return data;
  }
  async stepUpChallenge(factorType) {
    const account = this.sdk.tenant.account;
    const { data, error } = await account["step-up"].challenge.post({
      factorType
    });
    if (error)
      throw error;
    return data;
  }
  async beginStepUpEnroll(payload) {
    const account = this.sdk.tenant.account;
    const { data, error } = await account["step-up"].factors.post(payload, {
      fetch: { headers: { [NOTIFICATION_SILENT_HEADER]: "1" } }
    });
    if (error)
      throw error;
    return data;
  }
  async stepUp(payload) {
    const account = this.sdk.tenant.account;
    const { data, error } = await account["step-up"].post({
      aal: payload.aal,
      challengeToken: payload.challengeToken,
      code: payload.code,
      factorId: payload.factorId,
      factorType: payload.factorType,
      intent: payload.intent ?? "verify",
      label: payload.label,
      response: payload.response
    });
    if (error)
      throw error;
    const res = data;
    this.setTokens({
      access_token: res.access_token,
      expires_in: res.expires_in,
      refresh_token: this.use("refresh_token") ?? "",
      scopes: [],
      token_type: res.token_type
    });
    return { aal: res.aal, recoveryCodes: res.recoveryCodes };
  }
  isAuthenticated() {
    const searchParams = new URLSearchParams(window.location.search);
    const barelyLoggedIn = searchParams.get("grant_type");
    if (barelyLoggedIn) {
      return false;
    }
    const accessToken = this.use("access_token");
    const loggedIn = !!accessToken;
    if (loggedIn) {
      const jwtPayload = this.parseJwt(accessToken);
      return jwtPayload;
    }
    return false;
  }
  discover() {}
  validateCSRFState(receivedState) {
    try {
      const stateObj = OAuth2StateCodec.decode(receivedState);
      const storedCsrfToken = this.use("csrf_state");
      const storedNonce = this.use("oauth2_nonce");
      const storedTimestamp = this.use("oauth2_timestamp");
      if (!storedCsrfToken) {
        return this.handleCSRFError("No stored CSRF token found");
      }
      if (!stateObj.csrf) {
        return this.handleCSRFError("No CSRF token in state parameter");
      }
      if (stateObj.csrf !== storedCsrfToken) {
        return this.handleCSRFError("CSRF token mismatch");
      }
      if (stateObj.nonce && storedNonce && stateObj.nonce !== storedNonce) {
        return this.handleCSRFError("Nonce mismatch");
      }
      if (stateObj.timestamp && storedTimestamp) {
        const maxAge = 15 * 60 * 1000;
        const age = Date.now() - stateObj.timestamp;
        if (age > maxAge) {
          return this.handleCSRFError("Authorization request has expired");
        }
        if (Math.abs(stateObj.timestamp - storedTimestamp) > 1000) {
          return this.handleCSRFError("Timestamp mismatch");
        }
      }
      return stateObj;
    } catch {
      this.handleCSRFError("Invalid state parameter format");
    }
  }
  handleCSRFError(reason) {
    this.clearTokens();
    if (typeof window !== "undefined" && window.dispatchEvent) {
      const securityEvent = new CustomEvent("oauth2-csrf-error", {
        detail: { reason, timestamp: Date.now() }
      });
      window.dispatchEvent(securityEvent);
    }
    console.warn("OAuth2 CSRF validation failed:", reason);
    throw new Error(`CSRF validation failed: ${reason}`);
  }
  generateCodeVerifier(length2 = 128) {
    return safeBase64(String.fromCharCode(...crypto.getRandomValues(new Uint8Array(length2))));
  }
  async generateCodeChallenge(codeVerifier) {
    return safeBase64(String.fromCharCode(...new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(codeVerifier)))));
  }
  async generatePKCE() {
    const codeVerifier = this.generateCodeVerifier();
    const codeChallenge = await this.generateCodeChallenge(codeVerifier);
    return {
      codeChallenge,
      codeChallengeMethod: "S256",
      codeVerifier
    };
  }
  getPrefixed(key) {
    return `${this.sdk.baseRef}_${this.config.clientId}_${key}`;
  }
  async start() {
    return await this.refresh();
  }
  async refresh(tokenOnly = false, force = false) {
    const accessToken = this.use("access_token");
    const tokenType = this.use("token_type") || "Bearer";
    const currentAuthHeader = accessToken ? `${tokenType} ${accessToken}` : undefined;
    const hasRefreshToken = this.use("refresh_token");
    if (!hasRefreshToken) {
      const isValid = accessToken && !this.isTokenExpired();
      this.store.setState({
        isAuthenticated: !!isValid,
        jwtPayload: isValid ? this.parseJwt(accessToken) : null
      });
      return currentAuthHeader;
    }
    const isExpired = this.isTokenExpired();
    if (!isExpired && !force) {
      this.store.setState({
        isAuthenticated: true,
        jwtPayload: this.parseJwt(accessToken)
      });
      return currentAuthHeader;
    }
    const refreshToken = this.use("refresh_token");
    if (!refreshToken)
      return currentAuthHeader;
    const req = {
      grant_type: "refresh_token",
      refresh_token: refreshToken
    };
    const data = await this.tokenRequest(req).send();
    const authorizationHeader = `${data.token_type} ${data.access_token}`;
    this.setAuthorizationHeader(authorizationHeader);
    if (tokenOnly)
      return data.access_token;
    return authorizationHeader;
  }
  set(key, value) {
    const storage = this.getStorage(key);
    storage.setItem(this.getPrefixed(key), JSON.stringify(value));
  }
  use(key) {
    const storage = this.getStorage(key);
    const value = storage.getItem(this.getPrefixed(key));
    if (!value || value === "undefined" || value === "null") {
      return null;
    }
    try {
      return JSON.parse(value);
    } catch {
      storage.removeItem(this.getPrefixed(key));
      return null;
    }
  }
  unset(key) {
    const storage = this.getStorage(key);
    storage.removeItem(this.getPrefixed(key));
  }
  getStorage(key) {
    const sessionKeys = [
      "csrf_state",
      "pkce_code_verifier",
      "oauth2_nonce",
      "oauth2_timestamp",
      "oauth2_redirect_uri",
      "signin_retried"
    ];
    return sessionKeys.includes(key) ? sessionStorage : localStorage;
  }
  setTokens(tokens) {
    this.set("access_token", tokens.access_token);
    if (tokens.refresh_token) {
      this.set("refresh_token", tokens.refresh_token);
    }
    this.set("token_expires", Date.now() + tokens.expires_in * 1000);
    this.set("token_type", tokens.token_type);
    if (this.config.onToken)
      this.config.onToken(tokens);
    this.store.setState({
      isAuthenticated: true,
      jwtPayload: this.parseJwt(tokens.access_token)
    });
    this.setAuthorizationHeader(`${tokens.token_type} ${tokens.access_token}`);
  }
  clearTokens() {
    this.unset("access_token");
    this.unset("refresh_token");
    this.unset("token_expires");
    this.unset("token_type");
    this.unset("pkce_code_verifier");
    this.unset("csrf_state");
    this.unset("oauth2_nonce");
    this.unset("oauth2_timestamp");
    this.unset("oauth2_redirect_uri");
    this.store.setState({
      isAuthenticated: false,
      jwtPayload: null,
      publicProfile: {}
    });
    this.setAuthorizationHeader("");
    this.config.onToken?.({
      access_token: "",
      expires_in: 0,
      refresh_token: "",
      scopes: [],
      token_type: ""
    });
  }
  isTokenExpired(skewMs = 0) {
    const expires = this.use("token_expires");
    const accessToken = this.use("access_token");
    if (!accessToken)
      return true;
    const payload = this.parseJwt(accessToken);
    if (!payload)
      return true;
    const expMs = payload.exp * 1000;
    const now = Date.now() + skewMs;
    return !expires || now > Number(expires) || now > expMs;
  }
  classifyUnauthorized(error) {
    const challenge = error.response?.headers?.get?.("www-authenticate") ?? "";
    const challengeError = /\berror\s*=\s*"?([\w.-]+)"?/i.exec(challenge)?.[1];
    if (challengeError) {
      if (challengeError.toLowerCase() !== "invalid_token")
        return "none";
      return isTokenAudienceChallenge(challenge) ? "none" : "rejected";
    }
    const body = error.response?.data;
    const bodyCode = typeof body?.error === "string" ? body.error : body?.error?.code;
    if (bodyCode === "invalid_token")
      return body?.error_description === TOKEN_AUDIENCE_ERROR_DESCRIPTION ? "none" : "rejected";
    if (!this.use("refresh_token"))
      return "none";
    return this.isTokenExpired(TOKEN_EXPIRY_SKEW_MS) ? "expired" : "none";
  }
  parseJwt(accessToken) {
    try {
      const base64 = accessToken.split(".")[1];
      const json = atob(base64.replace(/-/g, "+").replace(/_/g, "/"));
      return JSON.parse(json);
    } catch {
      return null;
    }
  }
  setAuthorizationHeader(token) {
    this.sdk.http.defaults.headers.Authorization = token;
    this.sdk.http.defaults.headers["x-client-id"] = this.clientId;
    this.sdk.realtimeManager?.refreshTransportHeaders();
  }
  initializeInterceptors() {
    const accessToken = this.use("access_token");
    const tokenType = this.use("token_type") || "Bearer";
    if (accessToken) {
      this.setAuthorizationHeader(`${tokenType} ${accessToken}`);
    }
    this.sdk.http.interceptors.response.use((response) => response, async (error) => {
      if (!isHttpError(error)) {
        throw error;
      }
      const stepUpData = error.response?.data;
      if (error.response?.status === 401 && stepUpData?.error?.code === "step_up_required") {
        const outcome = await replayAfterStepUp(Number(stepUpData.error.required_aal ?? 2), error.config, {
          authorization: () => `${this.use("token_type") || "Bearer"} ${this.use("access_token")}`,
          onStepUpRequired: this.onStepUpRequired,
          request: (config) => this.sdk.http.request(config)
        });
        if (outcome.replayed)
          return outcome.response;
        throw error;
      }
      const refreshGrantLostClient = error.response?.status === 401 && error.response.data?.error === "invalid_client" && Boolean(error.config?.url?.endsWith("/oauth2/token")) && grantTypeOf(error.config) === "refresh_token" && clientIdOf(error.config) === this.clientId;
      if ((this.unknownClientIdOf(error) === this.clientId || refreshGrantLostClient) && (this.mintedClientId !== null || Boolean(this.config.autoRegister))) {
        if (refreshGrantLostClient)
          this.refreshGrantEvicted = true;
        await this.recoverDeletedClient();
        throw error;
      }
      switch (error.response?.status) {
        case 401: {
          const config = error.config ?? {
            headers: new Headers,
            retry: { retries: 1 }
          };
          const { url, isRetry } = config;
          if (url?.endsWith("/oauth2/token")) {
            if (grantTypeOf(config) === "refresh_token") {
              this.refreshGrantEvicted = true;
              this.logout();
              this.config.onUnauthorized?.();
            }
            throw error;
          }
          const evidence = this.classifyUnauthorized(error);
          if (evidence === "none")
            throw error;
          if (isRetry || !this.use("refresh_token")) {
            this.logout();
            this.config.onUnauthorized?.();
            throw error;
          }
          let token;
          this.refreshGrantEvicted = false;
          try {
            token = await this.refresh(false, true);
          } catch (refreshError) {
            const refused = refreshError instanceof TokenRequestError && refreshError.classification === "refused";
            if (refused && !this.refreshGrantEvicted) {
              this.logout();
              this.config.onUnauthorized?.();
            }
            throw error;
          }
          const method = (config.method ?? "GET").toUpperCase();
          if (evidence !== "rejected" && !IDEMPOTENT_METHODS.has(method))
            throw error;
          config.isRetry = true;
          if (config.headers instanceof Headers) {
            config.headers.set("Authorization", token || "");
          } else {
            config.headers = new Headers;
            config.headers.set("Authorization", token || "");
          }
          try {
            return await this.sdk.http.request({ ...config, baseURL: "" });
          } catch (replayError) {
            if (!isHttpError(replayError))
              throw replayError;
            throw error;
          }
        }
        default: {
          throw error;
        }
      }
    });
    this.sdk.http.interceptors.request.use(async (config) => {
      const { url } = config;
      const isRefresh = url?.endsWith(`/oauth2/token`);
      if (!isRefresh) {
        config.headers = config.headers ?? new Headers;
        if (config.headers instanceof Headers) {
          const token = await this.refresh();
          config.headers.set("Authorization", token || "");
        }
      }
      return config;
    });
  }
  initializeStore() {
    this.store = createStore((_set, _get) => {
      return {
        accessToken: null,
        isAuthenticated: undefined,
        jwtPayload: null,
        publicProfile: {}
      };
    });
  }
  get getMe() {
    return this.sdk.defineQuery("getMe", async () => {
      const [row] = await this.sdk.wql("system.getMe", undefined, {
        overrideBaseId: this.sdk.baseRef
      }).fetch();
      return row ?? null;
    }, undefined, undefined, this.sdk.baseRef);
  }
  get getMyRoles() {
    return this.sdk.defineQuery("getMyRoles", async (_context, args) => {
      const [row] = await this.sdk.wql("system.getMyRoles", undefined, {
        overrideBaseId: args.baseId
      }).fetch();
      return {
        canAdministerBase: row?.canAdministerBase ?? false,
        isAdmin: row?.isAdmin ?? false,
        roles: (row?.roles ?? []).map((r) => r.name).filter((n) => typeof n === "string")
      };
    }, undefined, undefined, this.sdk.baseRef);
  }
  signInRouteOptions(getRouter, options) {
    return {
      loader: async ({ deps }) => {
        const { status } = await this.signIn({
          onSuccess: (ctx) => {
            const target = ctx?.returnUrl ? new URL(ctx.returnUrl).searchParams.get("redirect") : deps.redirect;
            getRouter().history.replace(target || "/");
          },
          scope: options?.scope
        });
        if (status === "failed") {
          if (!this.use("signin_retried")) {
            this.set("signin_retried", true);
            await this.authorize({ redirect: true, scope: options?.scope });
          } else {
            this.unset("signin_retried");
            throw new Error("Sign-in could not be completed. Please try again.");
          }
        } else {
          this.unset("signin_retried");
        }
        return { status };
      },
      loaderDeps: ({ search }) => ({
        redirect: search.redirect
      }),
      validateSearch: (search) => ({
        ...typeof search.redirect === "string" ? { redirect: search.redirect } : {}
      })
    };
  }
}

export { TokenRequestError, OAuth2 };

//# debugId=D5C72F3845D0994B64756E2164756E21
