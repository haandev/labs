// ../shared/src/event.ts
class EventListener {
  listeners = {};
  allListeners = new Set;
  constructor(initials = {}) {
    Object.entries(initials).forEach((ev) => {
      if (!ev)
        return;
    });
  }
  on(event, callback) {
    if (!this.listeners[event])
      this.listeners[event] = new Set;
    this.listeners[event].add(callback);
    return () => this.off(event, callback);
  }
  off(event, callback) {
    this.listeners[event]?.delete(callback);
    if (this.listeners[event]?.size === 0) {
      delete this.listeners[event];
    }
  }
  onAll(callback) {
    this.allListeners.add(callback);
    return () => this.offAll(callback);
  }
  offAll(callback) {
    this.allListeners.delete(callback);
  }
  once(event, callback) {
    const onceWrapper = (...args) => {
      this.off(event, onceWrapper);
      return callback(...args);
    };
    this.on(event, onceWrapper);
  }
  async emit(event, ...args) {
    const callbacks = this.listeners[event] ?? new Set;
    const results = [];
    const errors = [];
    let signal;
    if (args.length && args[args.length - 1] instanceof AbortSignal) {
      signal = args.pop();
    }
    for (const cb of callbacks) {
      if (signal?.aborted)
        break;
      try {
        const result = signal ? await cb(...args, signal) : await cb(...args);
        results.push(result);
      } catch (err) {
        errors.push(err);
        console.error(err);
      }
    }
    return { errors, results };
  }
  emitSync(event, ...args) {
    const callbacks = this.listeners[event] ?? new Set;
    const results = [];
    const errors = [];
    let signal;
    if (args.length && args[args.length - 1] instanceof AbortSignal) {
      signal = args.pop();
    }
    for (const cb of callbacks) {
      if (signal?.aborted)
        break;
      try {
        const result = signal ? cb(...args, signal) : cb(...args);
        results.push(result);
      } catch (err) {
        errors.push(err);
      }
    }
    return { errors, results };
  }
  hasListeners(event) {
    return !!this.listeners[event]?.size;
  }
  clear(event) {
    if (event) {
      delete this.listeners[event];
    } else {
      this.listeners = {};
      this.allListeners.clear();
    }
  }
  listeningEvents() {
    return Object.keys(this.listeners).filter((k) => this.listeners[k]?.size);
  }
  addListener(event, callback) {
    this.on(event, callback);
  }
  removeListener(event, callback) {
    this.off(event, callback);
  }
}

// ../shared/src/refusal.ts
var TERMINAL = new Set([404]);
function classifyRefusal(status) {
  return TERMINAL.has(status) ? "terminal" : "retryable";
}

// ../shared/src/sse-client.ts
function computeJitteredDelay(baseDelay) {
  const jitter = baseDelay * (Math.random() - 0.5);
  return Math.max(100, Math.floor(baseDelay + jitter));
}

class SSEClient extends EventListener {
  url;
  options;
  attempt = new AbortController;
  closed = false;
  retryTimer = null;
  idleTimer = null;
  wake = null;
  constructor(url, options = {}) {
    super();
    this.url = url;
    this.options = options;
    this.run();
  }
  close() {
    if (this.closed)
      return;
    this.closed = true;
    if (this.retryTimer)
      clearTimeout(this.retryTimer);
    this.wake?.();
    this.attempt.abort();
    this.clear();
  }
  emitLifecycle(event, message) {
    if (this.closed)
      return;
    const emit = this.emit.bind(this);
    emit(event, message);
  }
  dispatch(frame) {
    if (this.closed)
      return;
    const data = frame.split(`
`).filter((line) => line.startsWith("data:")).map((line) => line.slice("data:".length).trim()).join("");
    if (!data)
      return;
    try {
      const [action, ...args] = JSON.parse(data);
      const emit = this.emit.bind(this);
      emit(action, ...args);
    } catch {}
  }
  async run() {
    const policy = this.options.reconnect;
    const initialDelay = policy?.initialDelayMs ?? 1000;
    const maxDelay = policy?.maxDelayMs ?? 30000;
    let delay = initialDelay;
    while (true) {
      const { opened, reason, status } = await this.connectOnce();
      if (this.closed)
        return;
      if (!policy || status !== undefined && classifyRefusal(status) === "terminal") {
        this.emitLifecycle("fail", reason);
        return;
      }
      this.emitLifecycle("drop", reason);
      if (opened)
        delay = initialDelay;
      await this.sleep(computeJitteredDelay(delay));
      if (this.closed)
        return;
      delay = Math.min(delay * 2, maxDelay);
    }
  }
  sleep(ms) {
    return new Promise((resolve) => {
      this.wake = resolve;
      this.retryTimer = setTimeout(resolve, ms);
    });
  }
  armIdleWatchdog() {
    const ms = this.options.idleTimeoutMs;
    if (!ms)
      return;
    if (this.idleTimer)
      clearTimeout(this.idleTimer);
    this.idleTimer = setTimeout(() => {
      this.attempt.abort(new Error(`stream idle for ${ms}ms`));
    }, ms);
  }
  disarmIdleWatchdog() {
    if (this.idleTimer) {
      clearTimeout(this.idleTimer);
      this.idleTimer = null;
    }
  }
  async connectOnce() {
    this.attempt = new AbortController;
    let opened = false;
    try {
      const headers = { Accept: "text/event-stream" };
      if (this.options.authorization)
        headers.Authorization = this.options.authorization;
      const res = await fetch(this.url, {
        headers,
        signal: this.attempt.signal
      });
      if (!res.ok) {
        return {
          opened,
          reason: `stream refused with status ${res.status}`,
          status: res.status
        };
      }
      if (!res.body) {
        return { opened, reason: "stream carried no body" };
      }
      opened = true;
      this.armIdleWatchdog();
      const reader = res.body.getReader();
      const signal = this.attempt.signal;
      signal.addEventListener("abort", () => void reader.cancel().catch(() => {}), {
        once: true
      });
      const decoder = new TextDecoder;
      let buffer = "";
      while (!this.closed) {
        const { done, value } = await reader.read();
        if (done)
          break;
        this.armIdleWatchdog();
        buffer += decoder.decode(value, { stream: true });
        let boundary = buffer.indexOf(`

`);
        while (boundary !== -1) {
          this.dispatch(buffer.slice(0, boundary));
          buffer = buffer.slice(boundary + 2);
          boundary = buffer.indexOf(`

`);
        }
      }
      if (signal.aborted && signal.reason instanceof Error) {
        return { opened, reason: signal.reason.message };
      }
      return { opened, reason: "stream ended before it closed" };
    } catch (error) {
      const reason = this.attempt.signal.reason;
      if (reason instanceof Error)
        return { opened, reason: reason.message };
      return { opened, reason: error.message };
    } finally {
      this.disarmIdleWatchdog();
    }
  }
}

// src/realtime-stream.ts
var IDLE_TIMEOUT_MS = 25000;
var RECONNECT_POLICY = { initialDelayMs: 1000, maxDelayMs: 30000 };
function openRealtimeStream(url) {
  return new SSEClient(url, {
    idleTimeoutMs: IDLE_TIMEOUT_MS,
    reconnect: RECONNECT_POLICY
  });
}
function realtimeUrl(baseURL, baseId, path) {
  return `${baseURL}/${baseId}/realtime/${path}`;
}
function subjectOf(headers) {
  const header = headers?.Authorization ?? headers?.authorization;
  if (!header)
    return null;
  try {
    const [, payload] = header.replace(/^Bearer\s+/i, "").split(".");
    if (!payload)
      return null;
    const json = atob(payload.replace(/-/g, "+").replace(/_/g, "/"));
    const claims = JSON.parse(json);
    return typeof claims.userId === "string" ? claims.userId : null;
  } catch {
    return null;
  }
}
var MAX_RETRY_AFTER_MS = 30000;
async function postWithRetry(url, body, headers, attempts = 3) {
  for (let i = 0;i < attempts; i++) {
    let retryAfterMs = null;
    try {
      const r = await fetch(url, { body, headers, method: "POST" });
      if (r.ok)
        return "ok";
      if (r.status === 401 || r.status === 403)
        return "unauthorized";
      if (r.status === 404)
        return "failed";
      if (r.status === 429) {
        const headerValue = r.headers.get("Retry-After");
        if (headerValue !== null) {
          const seconds = Number(headerValue);
          if (Number.isFinite(seconds) && seconds > 0) {
            retryAfterMs = Math.min(seconds * 1000, MAX_RETRY_AFTER_MS);
          }
        }
      }
    } catch {}
    if (i < attempts - 1) {
      const baseDelay = retryAfterMs ?? 250 * 2 ** i;
      await new Promise((res) => setTimeout(res, computeJitteredDelay(baseDelay)));
    }
  }
  return "failed";
}

export { EventListener, computeJitteredDelay, SSEClient, openRealtimeStream, realtimeUrl, subjectOf, postWithRetry };

//# debugId=F8BF4282DF0A484B64756E2164756E21
