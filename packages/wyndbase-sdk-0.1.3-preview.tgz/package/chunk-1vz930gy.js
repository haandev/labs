// src/http-client.ts
var NOTIFICATION_SILENT_HEADER = "x-notification-silent";
var ERROR_SILENT_HEADER = "x-error-silent";

class HttpError extends Error {
  isHttpError = true;
  config;
  response;
  status;
  constructor(message, config, response) {
    super(message);
    this.name = "HttpError";
    this.config = config;
    this.response = response;
    this.status = response?.status;
  }
}
function httpStatusOf(error) {
  if (typeof error !== "object" || error === null)
    return;
  const { status } = error;
  return typeof status === "number" ? status : undefined;
}
function isHttpError(value) {
  return value instanceof HttpError || typeof value === "object" && value !== null && value.isHttpError === true;
}
var deferredNotifications = new WeakMap;
function deferNotification(error, notify) {
  if (!error || typeof error !== "object") {
    notify();
    return;
  }
  const parked = deferredNotifications.get(error);
  if (parked)
    parked.push(notify);
  else
    deferredNotifications.set(error, [notify]);
}
function flushNotifications(error) {
  if (!error || typeof error !== "object")
    return;
  const parked = deferredNotifications.get(error);
  if (!parked)
    return;
  deferredNotifications.delete(error);
  for (const notify of parked) {
    try {
      notify();
    } catch (err) {
      console.warn("[sdk] an error-notification handler threw; ignoring it", err);
    }
  }
}
function discardNotifications(error) {
  if (error && typeof error === "object")
    deferredNotifications.delete(error);
}

class InterceptorManager {
  handlers = [];
  use(fulfilled, rejected) {
    this.handlers.push({
      fulfilled: fulfilled ?? null,
      rejected: rejected ?? null
    });
    return this.handlers.length - 1;
  }
  eject(id) {
    if (this.handlers[id]) {
      this.handlers[id] = null;
    }
  }
  forEach(fn) {
    for (const handler of this.handlers) {
      if (handler !== null)
        fn(handler);
    }
  }
}

class HttpClient {
  meter;
  defaults;
  interceptors = {
    request: new InterceptorManager,
    response: new InterceptorManager
  };
  constructor(config) {
    this.defaults = {
      baseURL: config.baseURL ?? "",
      headers: config.headers ?? {},
      withCredentials: config.withCredentials ?? false
    };
  }
  mergeHeaders(requestHeaders) {
    const merged = new Headers;
    for (const [key, value] of Object.entries(this.defaults.headers)) {
      if (value)
        merged.set(key, value);
    }
    if (requestHeaders) {
      requestHeaders.forEach((value, key) => {
        merged.set(key, value);
      });
    }
    return merged;
  }
  async request(config) {
    try {
      return await this.dispatch(config);
    } catch (error) {
      flushNotifications(error);
      throw error;
    }
  }
  async dispatch(config) {
    let mergedConfig = {
      ...config,
      headers: this.mergeHeaders(config.headers)
    };
    if (!("baseURL" in config)) {
      mergedConfig.baseURL = this.defaults.baseURL;
    }
    const requestInterceptors = [];
    this.interceptors.request.forEach((h) => {
      requestInterceptors.push(h);
    });
    for (const interceptor of requestInterceptors) {
      if (interceptor.fulfilled) {
        try {
          mergedConfig = await interceptor.fulfilled(mergedConfig);
        } catch (error) {
          if (interceptor.rejected) {
            mergedConfig = await interceptor.rejected(error);
          } else {
            throw error;
          }
        }
      }
    }
    const url = (mergedConfig.baseURL ?? "") + (mergedConfig.url ?? "");
    const fetchInit = {
      credentials: this.defaults.withCredentials ? "include" : "same-origin",
      headers: mergedConfig.headers,
      method: mergedConfig.method ?? "GET",
      signal: AbortSignal.timeout(30000)
    };
    if (mergedConfig.data !== undefined) {
      if (typeof mergedConfig.data === "string") {
        fetchInit.body = mergedConfig.data;
      } else {
        fetchInit.body = JSON.stringify(mergedConfig.data);
        const headers = fetchInit.headers;
        if (headers && !headers.has("content-type")) {
          headers.set("content-type", "application/json");
        }
      }
    }
    let httpResponse;
    const endSample = this.meter?.begin();
    try {
      const response = await fetch(url, fetchInit);
      endSample?.(Number(response.headers.get("content-length")) || 0);
      const contentType = response.headers.get("content-type") ?? "";
      let data;
      if (contentType.includes("application/json")) {
        data = await response.json().catch(() => null);
      } else {
        data = await response.text().catch(() => null);
      }
      httpResponse = {
        config: mergedConfig,
        data,
        headers: response.headers,
        status: response.status,
        statusText: response.statusText
      };
      if (!response.ok) {
        throw new HttpError(`Request failed with status ${response.status}`, mergedConfig, httpResponse);
      }
    } catch (error) {
      endSample?.();
      if (isHttpError(error)) {
        let result2 = error;
        const responseInterceptors2 = [];
        this.interceptors.response.forEach((h) => {
          responseInterceptors2.push(h);
        });
        for (const interceptor of responseInterceptors2) {
          if (interceptor.rejected) {
            try {
              result2 = await interceptor.rejected(result2);
              if (result2 && typeof result2 === "object" && "status" in result2 && "data" in result2) {
                discardNotifications(error);
                return result2;
              }
            } catch (e) {
              result2 = e;
            }
          }
        }
        flushNotifications(error);
        if (result2 !== error)
          flushNotifications(result2);
        throw result2;
      }
      throw error;
    }
    let result = httpResponse;
    const responseInterceptors = [];
    this.interceptors.response.forEach((h) => {
      responseInterceptors.push(h);
    });
    for (const interceptor of responseInterceptors) {
      if (interceptor.fulfilled) {
        try {
          result = await interceptor.fulfilled(result);
        } catch (error) {
          if (!interceptor.rejected)
            throw error;
          let recovered;
          try {
            recovered = await interceptor.rejected(error);
          } catch (thrown) {
            flushNotifications(error);
            throw thrown;
          }
          if (recovered && typeof recovered === "object" && "status" in recovered && "data" in recovered) {
            discardNotifications(error);
            result = recovered;
          } else {
            flushNotifications(error);
          }
        }
      }
    }
    return result;
  }
  get(url, config) {
    return this.request({ ...config, method: "GET", url });
  }
  post(url, data, config) {
    return this.request({ ...config, data, method: "POST", url });
  }
  put(url, data, config) {
    return this.request({ ...config, data, method: "PUT", url });
  }
  patch(url, data, config) {
    return this.request({ ...config, data, method: "PATCH", url });
  }
  delete(url, config) {
    return this.request({ ...config, method: "DELETE", url });
  }
  upload(url, data, options) {
    return new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest;
      xhr.open("PUT", url);
      if (options?.headers) {
        for (const [key, value] of Object.entries(options.headers)) {
          xhr.setRequestHeader(key, value);
        }
      }
      xhr.upload.onprogress = (event) => {
        options?.onUploadProgress?.({
          loaded: event.loaded,
          total: event.total
        });
      };
      xhr.onload = () => {
        const headers = new Headers;
        xhr.getAllResponseHeaders().trim().split(`\r
`).forEach((line) => {
          const idx = line.indexOf(": ");
          if (idx !== -1) {
            headers.set(line.slice(0, idx), line.slice(idx + 2));
          }
        });
        resolve({ headers, status: xhr.status });
      };
      xhr.onerror = () => reject(new Error(`Upload failed: ${xhr.statusText}`));
      if (options?.signal) {
        if (options.signal.aborted) {
          reject(new DOMException("Upload aborted", "AbortError"));
          return;
        }
        options.signal.addEventListener("abort", () => {
          xhr.abort();
          reject(new DOMException("Upload aborted", "AbortError"));
        }, { once: true });
      }
      xhr.send(data);
    });
  }
}

export { NOTIFICATION_SILENT_HEADER, ERROR_SILENT_HEADER, HttpError, httpStatusOf, isHttpError, deferNotification, flushNotifications, discardNotifications, HttpClient };

//# debugId=654C97FA1DCDEC9A64756E2164756E21
