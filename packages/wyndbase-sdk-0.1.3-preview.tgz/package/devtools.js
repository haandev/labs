import {
  REALTIME_KEY_MARKER
} from "./chunk-sr1a5ekk.js";
import"./chunk-8rtgyjf5.js";
import"./chunk-ckfjhf8x.js";
import"./chunk-1vz930gy.js";
import"./chunk-83vjawdv.js";
import {
  __require
} from "./chunk-hkqy0999.js";

// ../ui/src/components/brand/dashboards/logo.tsx
import { useMemo } from "react";
// ../ui/src/components/brand/db/logo.tsx
import { useMemo as useMemo2 } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
function DatabaseLogo({ height = 26 }) {
  const width = useMemo2(() => {
    return height * (194 / 40);
  }, [height]);
  return /* @__PURE__ */ jsxs("svg", {
    fill: "none",
    height,
    viewBox: "0 0 194 40",
    width,
    xmlns: "http://www.w3.org/2000/svg",
    children: [
      /* @__PURE__ */ jsx("title", {
        children: "Database Logo"
      }),
      /* @__PURE__ */ jsx("path", {
        d: "M55.152 30L50.28 15.216H54.704L57.448 24.512L60.108 15.216H63.776L66.436 24.512L69.208 15.216H73.604L68.732 30H64.728L61.956 20.956L59.156 30H55.152ZM77.7071 35.46L79.7791 29.832L74.1511 15.216H78.5751L81.7671 24.204L85.0711 15.216H89.4671L81.7111 35.46H77.7071ZM91.3532 15.216H95.5532V17.176C96.1505 16.4667 96.8505 15.916 97.6532 15.524C98.4558 15.132 99.2865 14.936 100.145 14.936C100.929 14.936 101.638 15.076 102.273 15.356C102.926 15.636 103.477 16.028 103.925 16.532C104.392 17.036 104.756 17.6333 105.017 18.324C105.278 19.0147 105.409 19.7707 105.409 20.592V30H101.209V21.488C101.209 20.6667 100.976 20.004 100.509 19.5C100.061 18.996 99.4545 18.744 98.6892 18.744C98.2598 18.744 97.8585 18.8373 97.4852 19.024C97.1118 19.192 96.7852 19.4347 96.5052 19.752C96.2252 20.0693 96.0012 20.4427 95.8332 20.872C95.6652 21.3013 95.5718 21.768 95.5532 22.272V30H91.3532V15.216ZM114.576 14.964C115.546 14.964 116.424 15.16 117.208 15.552C118.01 15.944 118.682 16.504 119.224 17.232V9.84H123.424V30H119.224V28.012C118.794 28.7027 118.16 29.2533 117.32 29.664C116.498 30.056 115.584 30.252 114.576 30.252C113.568 30.252 112.634 30.0653 111.776 29.692C110.936 29.3 110.208 28.768 109.592 28.096C108.976 27.424 108.49 26.6213 108.136 25.688C107.8 24.7547 107.632 23.728 107.632 22.608C107.632 21.4693 107.8 20.4333 108.136 19.5C108.472 18.548 108.938 17.736 109.536 17.064C110.152 16.392 110.889 15.8787 111.748 15.524C112.606 15.1507 113.549 14.964 114.576 14.964ZM115.584 26.332C116.125 26.332 116.61 26.2387 117.04 26.052C117.488 25.8653 117.87 25.6133 118.188 25.296C118.524 24.96 118.776 24.568 118.944 24.12C119.13 23.672 119.224 23.1773 119.224 22.636C119.224 21.5347 118.888 20.6387 118.216 19.948C117.544 19.2573 116.666 18.912 115.584 18.912C115.061 18.912 114.576 19.0053 114.128 19.192C113.68 19.3787 113.288 19.64 112.952 19.976C112.634 20.2933 112.382 20.6853 112.196 21.152C112.028 21.6 111.944 22.0947 111.944 22.636C111.944 23.1587 112.037 23.6533 112.224 24.12C112.41 24.568 112.662 24.96 112.98 25.296C113.297 25.6133 113.68 25.8653 114.128 26.052C114.576 26.2387 115.061 26.332 115.584 26.332ZM135.392 14.964C136.437 14.964 137.389 15.1507 138.248 15.524C139.107 15.8787 139.835 16.392 140.432 17.064C141.048 17.736 141.524 18.548 141.86 19.5C142.196 20.4333 142.364 21.4693 142.364 22.608C142.364 23.728 142.187 24.7547 141.832 25.688C141.496 26.6213 141.02 27.424 140.404 28.096C139.788 28.768 139.051 29.3 138.192 29.692C137.333 30.0653 136.4 30.252 135.392 30.252C134.384 30.252 133.469 30.056 132.648 29.664C131.827 29.2533 131.201 28.7027 130.772 28.012V30H126.572V9.84H130.772V17.232C131.313 16.504 131.976 15.944 132.76 15.552C133.544 15.16 134.421 14.964 135.392 14.964ZM134.412 26.332C134.935 26.332 135.42 26.2387 135.868 26.052C136.316 25.8653 136.699 25.6133 137.016 25.296C137.333 24.96 137.585 24.568 137.772 24.12C137.959 23.6533 138.052 23.1587 138.052 22.636C138.052 22.0947 137.959 21.6 137.772 21.152C137.604 20.6853 137.352 20.2933 137.016 19.976C136.699 19.64 136.316 19.3787 135.868 19.192C135.439 19.0053 134.953 18.912 134.412 18.912C133.329 18.912 132.452 19.2573 131.78 19.948C131.108 20.6387 130.772 21.5347 130.772 22.636C130.772 23.1773 130.856 23.672 131.024 24.12C131.211 24.568 131.463 24.96 131.78 25.296C132.116 25.6133 132.508 25.8653 132.956 26.052C133.404 26.2387 133.889 26.332 134.412 26.332ZM150.888 14.964C151.859 14.964 152.736 15.16 153.52 15.552C154.323 15.944 154.995 16.504 155.536 17.232V15.216H159.736V30H155.536V28.012C155.107 28.7027 154.472 29.2533 153.632 29.664C152.811 30.056 151.896 30.252 150.888 30.252C149.88 30.252 148.947 30.0653 148.088 29.692C147.248 29.3 146.52 28.768 145.904 28.096C145.288 27.424 144.803 26.6213 144.448 25.688C144.112 24.7547 143.944 23.728 143.944 22.608C143.944 21.4693 144.112 20.4333 144.448 19.5C144.784 18.548 145.251 17.736 145.848 17.064C146.464 16.392 147.201 15.8787 148.06 15.524C148.919 15.1507 149.861 14.964 150.888 14.964ZM151.896 26.332C152.437 26.332 152.923 26.2387 153.352 26.052C153.8 25.8653 154.183 25.6133 154.5 25.296C154.836 24.96 155.088 24.568 155.256 24.12C155.443 23.672 155.536 23.1773 155.536 22.636C155.536 21.5347 155.2 20.6387 154.528 19.948C153.856 19.2573 152.979 18.912 151.896 18.912C151.373 18.912 150.888 19.0053 150.44 19.192C149.992 19.3787 149.6 19.64 149.264 19.976C148.947 20.2933 148.695 20.6853 148.508 21.152C148.34 21.6 148.256 22.0947 148.256 22.636C148.256 23.1587 148.349 23.6533 148.536 24.12C148.723 24.568 148.975 24.96 149.292 25.296C149.609 25.6133 149.992 25.8653 150.44 26.052C150.888 26.2387 151.373 26.332 151.896 26.332ZM162.632 19.612C162.632 18.1187 163.164 16.9707 164.228 16.168C165.311 15.3467 166.832 14.936 168.792 14.936C170.827 14.936 172.367 15.3653 173.412 16.224C174.476 17.0827 175.027 18.268 175.064 19.78H170.836C170.818 19.2387 170.631 18.828 170.276 18.548C169.922 18.2493 169.408 18.1 168.736 18.1C168.12 18.1 167.635 18.2213 167.28 18.464C166.926 18.688 166.748 19.0147 166.748 19.444C166.748 19.9667 166.982 20.34 167.448 20.564C167.915 20.7693 168.494 20.9467 169.184 21.096C169.8 21.2267 170.472 21.3573 171.2 21.488C171.928 21.6187 172.6 21.8333 173.216 22.132C173.851 22.4307 174.374 22.8507 174.784 23.392C175.195 23.9333 175.4 24.6707 175.4 25.604C175.4 27.0227 174.859 28.152 173.776 28.992C172.712 29.8133 171.098 30.224 168.932 30.224C166.692 30.224 165.022 29.7947 163.92 28.936C162.838 28.0587 162.296 26.8733 162.296 25.38H166.468C166.562 26.5187 167.383 27.088 168.932 27.088C169.66 27.088 170.211 26.976 170.584 26.752C170.976 26.5093 171.172 26.1733 171.172 25.744C171.172 25.464 171.088 25.24 170.92 25.072C170.771 24.8853 170.556 24.736 170.276 24.624C170.015 24.4933 169.698 24.3907 169.324 24.316C168.97 24.2413 168.587 24.1667 168.176 24.092C167.56 23.98 166.926 23.8587 166.272 23.728C165.619 23.5787 165.022 23.3453 164.48 23.028C163.939 22.7107 163.491 22.2907 163.136 21.768C162.8 21.2267 162.632 20.508 162.632 19.612ZM181.563 23.728C181.731 24.6613 182.123 25.3987 182.739 25.94C183.373 26.4627 184.167 26.724 185.119 26.724C185.791 26.724 186.369 26.584 186.855 26.304C187.359 26.024 187.704 25.632 187.891 25.128H192.063C191.633 26.7893 190.793 28.0587 189.543 28.936C188.292 29.8133 186.761 30.252 184.951 30.252C183.812 30.252 182.757 30.0653 181.787 29.692C180.835 29.3187 180.013 28.796 179.323 28.124C178.651 27.452 178.119 26.6493 177.727 25.716C177.353 24.764 177.167 23.728 177.167 22.608C177.167 21.488 177.353 20.4613 177.727 19.528C178.1 18.576 178.623 17.764 179.295 17.092C179.967 16.42 180.769 15.8973 181.703 15.524C182.636 15.132 183.663 14.936 184.783 14.936C185.809 14.936 186.761 15.0947 187.639 15.412C188.535 15.7293 189.309 16.168 189.963 16.728C190.635 17.288 191.176 17.9693 191.587 18.772C191.997 19.556 192.24 20.424 192.315 21.376C192.352 21.8053 192.371 22.1507 192.371 22.412C192.389 22.6547 192.399 22.8413 192.399 22.972C192.399 23.2333 192.389 23.4853 192.371 23.728H181.563ZM188.143 21.236C188.049 20.396 187.704 19.7427 187.107 19.276C186.528 18.7907 185.791 18.548 184.895 18.548C184.073 18.548 183.373 18.7907 182.795 19.276C182.216 19.7427 181.824 20.396 181.619 21.236H188.143Z",
        fill: "currentColor"
      }),
      /* @__PURE__ */ jsx("path", {
        d: "M19.6827 9.98785L20.7946 28.6958L12.3762 38.112L2.14952 38.1471C0.499202 38.1544 -0.535172 36.4119 0.289987 35.0206L15.6973 9.06321C16.7595 7.27244 19.5598 7.9235 19.6827 9.98785Z",
        fill: "currentColor"
      }),
      /* @__PURE__ */ jsx("path", {
        d: "M20.7946 28.6958L27.0535 21.6337C27.8625 20.7193 29.3519 20.8392 29.9957 21.8721L38.0907 34.8581C38.9568 36.2466 37.9312 38.0227 36.2633 38.0227H21.134L20.7946 28.6958Z",
        fill: "currentColor"
      }),
      /* @__PURE__ */ jsx("path", {
        clipRule: "evenodd",
        d: "M22.225 10.9273C22.225 10.9273 20.8545 4.40257 28.4019 2.48147C35.9494 0.560444 39.6722 1.05792 39.6722 1.05792C39.6722 1.05792 41.9167 7.03938 34.6297 7.08409C27.3427 7.12879 23.6017 8.23928 22.225 10.9273Z",
        fill: "#4EAEC7",
        fillRule: "evenodd"
      }),
      /* @__PURE__ */ jsx("path", {
        clipRule: "evenodd",
        d: "M39.7733 7.38741C39.7733 7.38741 41.1439 13.9121 33.5964 15.8332C26.049 17.7543 22.3261 17.2568 22.3261 17.2568C22.3261 17.2568 20.0816 11.2753 27.3687 11.2306C34.6557 11.1859 38.3967 10.0754 39.7733 7.38741Z",
        fill: "#3261A5",
        fillRule: "evenodd"
      })
    ]
  });
}
// ../ui/src/components/brand/db/logomark.tsx
import { jsx as jsx2, jsxs as jsxs2 } from "react/jsx-runtime";
function DatabaseLogomark({ size = 26 }) {
  return /* @__PURE__ */ jsxs2("svg", {
    fill: "none",
    height: size,
    viewBox: "0 0 40 40",
    width: size,
    xmlns: "http://www.w3.org/2000/svg",
    children: [
      /* @__PURE__ */ jsx2("title", {
        children: "Database Logomark"
      }),
      /* @__PURE__ */ jsx2("path", {
        d: "M19.6827 9.98785L20.7946 28.6958L12.3762 38.112L2.14952 38.1471C0.499202 38.1544 -0.535172 36.4119 0.289987 35.0206L15.6973 9.06321C16.7595 7.27244 19.5598 7.9235 19.6827 9.98785Z",
        fill: "currentColor"
      }),
      /* @__PURE__ */ jsx2("path", {
        d: "M20.7946 28.6958L27.0535 21.6337C27.8625 20.7193 29.3519 20.8392 29.9957 21.8721L38.0907 34.8581C38.9568 36.2466 37.9312 38.0227 36.2633 38.0227H21.134L20.7946 28.6958Z",
        fill: "currentColor"
      }),
      /* @__PURE__ */ jsx2("path", {
        clipRule: "evenodd",
        d: "M22.225 10.9273C22.225 10.9273 20.8545 4.40257 28.4019 2.48147C35.9494 0.560444 39.6722 1.05792 39.6722 1.05792C39.6722 1.05792 41.9167 7.03938 34.6297 7.08409C27.3427 7.12879 23.6017 8.23928 22.225 10.9273Z",
        fill: "#4EAEC7",
        fillRule: "evenodd"
      }),
      /* @__PURE__ */ jsx2("path", {
        clipRule: "evenodd",
        d: "M39.7733 7.38741C39.7733 7.38741 41.1439 13.9121 33.5964 15.8332C26.049 17.7543 22.3262 17.2568 22.3262 17.2568C22.3262 17.2568 20.0816 11.2753 27.3687 11.2306C34.6557 11.1859 38.3967 10.0754 39.7733 7.38741Z",
        fill: "#3261A5",
        fillRule: "evenodd"
      })
    ]
  });
}
// ../ui/src/components/brand/documents/logo.tsx
import { useMemo as useMemo3 } from "react";
// ../ui/src/components/brand/notebooks/logo.tsx
import { useMemo as useMemo4 } from "react";
// ../ui/src/components/brand/pages/logo.tsx
import { useMemo as useMemo5 } from "react";
// ../ui/src/components/brand/reports/logo.tsx
import { useMemo as useMemo6 } from "react";
// ../ui/src/components/brand/sheets/logo.tsx
import { useMemo as useMemo7 } from "react";
// ../ui/src/components/brand/webpages/logo.tsx
import { useMemo as useMemo8 } from "react";
// src/devtools.tsx
import {
  lazy,
  Suspense,
  useCallback,
  useEffect,
  useRef,
  useState,
  useSyncExternalStore
} from "react";
import { createPortal } from "react-dom";
import { jsx as jsx3, jsxs as jsxs3, Fragment } from "react/jsx-runtime";
var DevPanel = lazy(() => import("@tanstack/react-query-devtools").then((m) => ({ default: m.ReactQueryDevtoolsPanel })).catch(() => ({ default: () => null })));
var ProductionPanel = lazy(() => import("@tanstack/react-query-devtools/production").then((m) => ({ default: m.ReactQueryDevtoolsPanel })).catch(() => ({ default: () => null })));
var FLOATING_PANEL_HEIGHT = "min(450px, 90vh)";
function WyndbaseDevtools({
  client,
  keepOnProduction = false
}) {
  const [open, setOpen] = useState(false);
  return /* @__PURE__ */ jsxs3(Fragment, {
    children: [
      /* @__PURE__ */ jsx3("button", {
        "aria-expanded": open,
        "aria-label": open ? "Close wyndbase devtools" : "Open wyndbase devtools",
        onClick: () => setOpen((value) => !value),
        style: {
          alignItems: "center",
          background: "#16161e",
          border: "1px solid rgba(255, 255, 255, 0.15)",
          borderRadius: "50%",
          bottom: open ? `calc(${FLOATING_PANEL_HEIGHT} + 1rem)` : "1rem",
          boxShadow: "0 2px 10px rgba(0, 0, 0, 0.4)",
          color: "#e5e7eb",
          cursor: "pointer",
          display: "flex",
          height: "2.75rem",
          justifyContent: "center",
          position: "fixed",
          right: "1rem",
          width: "2.75rem",
          zIndex: 99999
        },
        type: "button",
        children: /* @__PURE__ */ jsx3(DatabaseLogomark, {
          size: 24
        })
      }),
      open && /* @__PURE__ */ jsx3("div", {
        style: {
          borderTop: "1px solid rgba(255, 255, 255, 0.15)",
          bottom: 0,
          height: FLOATING_PANEL_HEIGHT,
          left: 0,
          overflow: "hidden",
          position: "fixed",
          right: 0,
          zIndex: 99998
        },
        children: /* @__PURE__ */ jsx3(WyndbaseDevtoolsPanel, {
          client,
          keepOnProduction
        })
      })
    ]
  });
}
function WyndbaseDevtoolsPanel({
  client,
  keepOnProduction = false
}) {
  const Panel = keepOnProduction ? ProductionPanel : DevPanel;
  const hostRef = useRef(null);
  const [logoSlot, setLogoSlot] = useState(null);
  const [statusSlot, setStatusSlot] = useState(null);
  useEffect(() => {
    const host = hostRef.current;
    if (!host)
      return;
    const slot = document.createElement("span");
    slot.style.display = "contents";
    const statusRowSlot = document.createElement("span");
    statusRowSlot.style.display = "contents";
    const attach = () => {
      const logo10 = host.querySelector(".tsqd-text-logo-container");
      if (logo10) {
        if (logo10.previousElementSibling !== slot)
          logo10.before(slot);
        setLogoSlot(slot);
      }
      const statusRow = host.querySelector(".tsqd-query-status-container");
      if (statusRow) {
        if (statusRowSlot.parentElement !== statusRow) {
          statusRow.append(statusRowSlot);
        }
        setStatusSlot(statusRowSlot);
      }
    };
    attach();
    const observer = new MutationObserver(attach);
    observer.observe(host, { childList: true, subtree: true });
    return () => {
      observer.disconnect();
      slot.remove();
      statusRowSlot.remove();
    };
  }, []);
  return /* @__PURE__ */ jsxs3("div", {
    ref: hostRef,
    style: { display: "contents" },
    children: [
      /* @__PURE__ */ jsx3(Suspense, {
        fallback: null,
        children: /* @__PURE__ */ jsx3(Panel, {
          client,
          style: { height: "100%" }
        })
      }),
      logoSlot && createPortal(/* @__PURE__ */ jsxs3("span", {
        style: {
          alignItems: "center",
          display: "flex",
          gap: "0.5rem",
          opacity: 0.8
        },
        children: [
          /* @__PURE__ */ jsx3(DatabaseLogo, {
            height: 24
          }),
          /* @__PURE__ */ jsx3("span", {
            "aria-hidden": true,
            style: { color: "white", fontSize: "0.75rem", lineHeight: 1 },
            children: "×"
          })
        ]
      }), logoSlot),
      statusSlot && hostRef.current && /* @__PURE__ */ jsx3(RealtimeStatusTagPortal, {
        client,
        host: hostRef.current,
        slot: statusSlot
      })
    ]
  });
}
function RealtimeStatusTagPortal({
  client,
  host,
  slot
}) {
  const subscribe = useCallback((cb) => client.getQueryCache().subscribe(() => queueMicrotask(cb)), [client]);
  const getCount = useCallback(() => client.getQueryCache().getAll().filter((query) => query.queryKey.at(-1) === REALTIME_KEY_MARKER).length, [client]);
  const count = useSyncExternalStore(subscribe, getCount);
  const [active, setActive] = useState(false);
  const [native, setNative] = useState({});
  useEffect(() => {
    const tag = host.querySelector(".tsqd-query-status-tag");
    if (!tag)
      return;
    setNative({
      count: tag.querySelector("[class*=tag-count]")?.className,
      dot: tag.querySelector("[class*=tag-dot]")?.className,
      label: tag.querySelector("[class*=tag-label]")?.className,
      tag: [...tag.classList].filter((name) => !/^tsqd-query-status-tag-./.test(name)).join(" ")
    });
  }, [host]);
  useEffect(() => {
    const onInput = (event) => {
      const target = event.target;
      if (target?.classList?.contains("tsqd-query-filter-textfield")) {
        setActive(target.value === REALTIME_KEY_MARKER);
      }
    };
    host.addEventListener("input", onInput);
    return () => host.removeEventListener("input", onInput);
  }, [host]);
  const toggle = () => {
    const input = host.querySelector(".tsqd-query-filter-textfield");
    if (!input)
      return;
    const next = input.value === REALTIME_KEY_MARKER ? "" : REALTIME_KEY_MARKER;
    const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value")?.set;
    setter?.call(input, next);
    input.dispatchEvent(new Event("input", { bubbles: true }));
    setActive(next === REALTIME_KEY_MARKER);
  };
  return createPortal(/* @__PURE__ */ jsxs3("button", {
    "aria-pressed": active,
    className: native.tag ?? "tsqd-query-status-tag",
    onClick: toggle,
    style: {
      background: active ? "rgba(59, 130, 246, 0.25)" : undefined,
      cursor: "pointer"
    },
    title: "Only realtime-tracked queries",
    type: "button",
    children: [
      /* @__PURE__ */ jsx3("span", {
        className: native.dot,
        style: { background: "#3b82f6", borderRadius: "50%" }
      }),
      /* @__PURE__ */ jsx3("span", {
        className: native.label,
        children: "Realtime"
      }),
      /* @__PURE__ */ jsx3("span", {
        className: native.count,
        style: {
          background: "rgba(59, 130, 246, 0.18)",
          color: "rgb(147, 197, 253)"
        },
        children: count
      })
    ]
  }), slot);
}
export {
  WyndbaseDevtools,
  WyndbaseDevtoolsPanel
};

//# debugId=9DF2510542F2705764756E2164756E21
