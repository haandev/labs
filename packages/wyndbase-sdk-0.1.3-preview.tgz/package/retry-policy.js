import {
  DEFAULT_QUERY_MAX_FAILURES,
  shouldRetryQuery
} from "./chunk-8rtgyjf5.js";
import"./chunk-hkqy0999.js";
export {
  DEFAULT_QUERY_MAX_FAILURES,
  shouldRetryQuery
};

//# debugId=EA2924A9E765ED1564756E2164756E21
