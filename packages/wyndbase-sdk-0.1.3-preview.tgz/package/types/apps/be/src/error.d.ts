export interface StandardError {
    code: string;
    message: string;
    name?: string;
    status: number;
    details?: Record<string, any>;
    fields?: Array<{
        field: string;
        message: string;
        code: string;
    }>;
}
export declare const errorHandler: (ctx: any) => {
    error: {
        code: string;
        message: string;
        required_aal: number;
        status: number;
    };
} | {
    error: StandardError;
};
