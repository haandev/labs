/**
 * RFC 8414 authorization-server metadata for one base's OAuth2 server.
 *
 * Every endpoint named here is served by this app: `authorize`, `token`,
 * `userinfo` and `revoke` by `routes/oauth2flow.ts` and `register` by
 * `routes/oauth2-server.ts` — both mounted at `/api/:baseId/oauth2`, so
 * every base is a complete authorization server. The main base is just the
 * default `baseRef`.
 */
export type AuthorizationServerMetadata = {
    issuer: string;
    authorization_endpoint: string;
    token_endpoint: string;
    registration_endpoint: string;
    end_session_endpoint: string;
    revocation_endpoint: string;
    userinfo_endpoint: string;
    response_types_supported: string[];
    grant_types_supported: string[];
    code_challenge_methods_supported: string[];
    token_endpoint_auth_methods_supported: string[];
    scopes_supported: string[];
};
export declare function buildAuthorizationServerMetadata(origin: string, baseRef?: string): AuthorizationServerMetadata;
