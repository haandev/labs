import type { z } from 'zod';
import { HttpError } from '../../utils/httpErrors';
import type { EnvelopeConfigSchema } from './browse-query-config';
import { type WqlCallContext } from './wql-admission';
type EnvelopeConfig = z.infer<typeof EnvelopeConfigSchema>;
export type CompiledStatement = {
    sql: string;
    statements: string[];
    parameterMap: Record<string, unknown>;
    parameterMaps: Record<string, unknown>[];
    parameterMeta: Record<string, unknown>;
    parameterRawMeta: Record<string, unknown>;
};
export type WqlEnvelope = {
    statement: CompiledStatement;
    /** Absent only when the forced compile was itself refused. */
    policiedStatement?: CompiledStatement;
    policiedRefusal?: string;
    schema?: unknown;
    typescript?: string;
    plan?: unknown;
    warnings?: unknown[];
    /** The message a `BEGIN ON ERROR ROLLBACK <expr>` block would report if the
     *  transaction rolled back at RUN time. A compiler fact about a query that
     *  compiled successfully — never a failure, and named so no consumer can
     *  mistake it for one. Compile failures do not reach the envelope at all;
     *  they are refused as `WqlCompileRefusedError`. */
    rollbackMessage?: string;
    isMutation: boolean;
    mutatedTables: string[];
};
/** 403 — the envelope is the whole of what the run route withholds from a
 *  caller with no identity, so serving it at its own address would hand back
 *  exactly what that rule exists to keep back. Not 401: the request is
 *  well-formed and the caller is validly anonymous. */
export declare class EnvelopeAnonymousRefusedError extends HttpError {
    constructor();
}
/**
 * 400 — the caller's own query did not compile. A query that does not compile
 * is a fault in what was sent, not in this server: the envelope's whole purpose
 * is to report what compiling says, including that it failed. Carrying a real
 * 4xx keeps the global handler from capturing it to error monitoring and from
 * logging a stack for every settled keystroke on a half-typed query.
 *
 * The compiler's own message and error name are preserved, so the client keeps
 * the diagnostic it needs to fix the query.
 */
export declare class WqlCompileRefusedError extends HttpError {
    constructor(cause: Error);
}
/**
 * Compiles a query and answers with everything the compiler worked out. It
 * never executes the statement and never writes: translate-only returns before
 * execution, and the one plan mode it offers is the generic one, which plans
 * without running.
 */
export declare function compileWqlEnvelope(input: WqlCallContext & {
    config?: EnvelopeConfig;
}): Promise<WqlEnvelope>;
export {};
