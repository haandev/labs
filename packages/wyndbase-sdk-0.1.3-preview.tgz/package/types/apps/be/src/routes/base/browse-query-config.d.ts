import { z } from 'zod';
/**
 * The only fields a caller may send to the run route; an undeclared key is
 * refused, not dropped, so a client still sending a compile-only field learns
 * about it instead of silently losing it. `WQLOptions` fields like `user` and
 * `context` stay out — they'd let a caller disable or spoof policy enforcement.
 *
 * Both plan modes are not here: a plan with measured timings executes the
 * statement, so it belongs to this route; a plan without them does not, so it
 * belongs to the envelope.
 */
export declare const RunConfigSchema: z.ZodObject<{
    allowMutation: z.ZodOptional<z.ZodBoolean>;
    as: z.ZodOptional<z.ZodEnum<{
        "explain-analyze": "explain-analyze";
        run: "run";
    }>>;
    realtime: z.ZodOptional<z.ZodBoolean>;
    /** Selects the wire encoding of the rows, not anything about the query. */
    rowFormat: z.ZodOptional<z.ZodEnum<{
        array: "array";
        objects: "objects";
    }>>;
    /** Authority to run under; see `resolveRunAuthority`. Omitted keeps the
     *  route's own resolution. Replaces `forcePolicies`, which clamped
     *  enforcement onto every frame and so de-elevated elevated named queries. */
    runAs: z.ZodOptional<z.ZodEnum<{
        elevated: "elevated";
        policied: "policied";
    }>>;
}, z.core.$strict>;
/**
 * The envelope's fields. No `forcePolicies`: the envelope returns both the
 * caller's own compilation and the policy-forced one unconditionally, so the
 * flag has nothing left to say here. No `as`: the mode is implied, and `explain`
 * selects the one plan that does not execute the statement.
 */
export declare const EnvelopeConfigSchema: z.ZodObject<{
    allowMutation: z.ZodDefault<z.ZodOptional<z.ZodBoolean>>;
    explain: z.ZodOptional<z.ZodBoolean>;
    schema: z.ZodOptional<z.ZodBoolean>;
    typescript: z.ZodOptional<z.ZodBoolean>;
}, z.core.$strict>;
