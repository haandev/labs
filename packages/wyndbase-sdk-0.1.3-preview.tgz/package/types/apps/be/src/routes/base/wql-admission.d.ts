import type wyndbase from '../../../../../packages/driver/src/wyndbase';
import type { browseUserMode } from '../../../../../packages/driver/src/features/browse/browsePolicyMode';
import type { TransactionContext } from '../../../../../packages/shared/src/transaction';
import { HttpError } from '../../utils/httpErrors';
type BaseHandler = NonNullable<Awaited<ReturnType<typeof wyndbase.base>>>;
type BrowseUser = ReturnType<typeof browseUserMode>;
/** Everything both WQL routes know about a request before either decides what
 *  to send back. Shaping is the route's; admission and dispatch are shared, so
 *  the two routes cannot drift on who is allowed in. */
export type WqlCallContext = {
    base: BaseHandler;
    browseUser: BrowseUser;
    transactionContext: TransactionContext;
    headers: Record<string, string | undefined>;
    /** Authenticated caller, or `null` for an anonymous browse caller on a base that opted in. */
    userId: string | null;
    query: string;
    params?: Record<string, unknown>;
};
/** 403 — this client is registered for named queries only. Extends `HttpError`
 *  (not a bare `Error`) so the global handler reads a real `status` instead of
 *  reporting this as a server fault. Names the client and the two upgrade
 *  paths: the refusal is the message the blocked person forwards to their
 *  administrator, so it has to say what to ask for. */
export declare class RawWqlForbiddenError extends HttpError {
    constructor(clientName?: string);
}
/** Refuses a raw query from a named-query-only client and answers the client
 *  level the compiler needs. Both routes call this before anything else. */
export declare function admitWqlRequest(ctx: WqlCallContext): 'trusted' | 'public';
/** The one driver call both routes make. `config` is the caller's WQL options
 *  minus identity: the act-as branch and the plain branch each supply their own,
 *  so no route hand-builds a `context` the driver already derives. */
export declare function dispatchWql(ctx: WqlCallContext, config: Record<string, unknown>): Promise<any>;
export {};
