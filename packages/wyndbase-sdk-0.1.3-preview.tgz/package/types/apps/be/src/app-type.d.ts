export type { AppType } from './instance';
