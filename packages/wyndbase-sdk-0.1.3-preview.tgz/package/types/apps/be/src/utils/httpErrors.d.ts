/**
 * Elysia's thrown `status()` values lose their code before the global error
 * handler sees them and degrade to 500 — throw these instead to preserve it.
 */
export declare class HttpError extends Error {
    readonly status: number;
    constructor(status: number, message: string, name: string);
}
/** 401 — no credentials, or credentials that could not be verified. */
export declare class UnauthorizedError extends HttpError {
    readonly headers?: Record<string, string>;
    constructor(message?: string, headers?: Record<string, string>);
}
/** 403 — authenticated, but the identity lacks the required authority. */
export declare class ForbiddenError extends HttpError {
    constructor(message?: string);
}
/**
 * 400 for a refusal a route reaches after schema validation passes.
 * A bare `Error` here would report as a 500 server fault instead.
 */
export declare class BadRequestError extends HttpError {
    constructor(message?: string);
}
