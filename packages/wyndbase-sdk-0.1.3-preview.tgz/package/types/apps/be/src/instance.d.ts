import { Elysia } from 'elysia';
declare global {
    export interface AppContextVariables {
    }
}
declare const app: Elysia<"", {
    decorator: {
        jwt: {
            sign(signValue: {
                [x: string]: string | number | boolean | (string | number | boolean | (string | number | boolean | (string | number | boolean | (string | number | boolean | (string | number | boolean | (string | number | boolean | (string | number | boolean | (string | number | boolean | (string | number | boolean | (string | number | boolean | (string | number | boolean | /*elided*/ any | {
                    [key: string]: string | number | boolean | /*elided*/ any | /*elided*/ any | null | undefined;
                } | null | undefined)[] | {
                    [key: string]: string | number | boolean | any | any | null | undefined;
                } | null | undefined)[] | {
                    [key: string]: string | number | boolean | any | any | null | undefined;
                } | null | undefined)[] | {
                    [key: string]: string | number | boolean | any | any | null | undefined;
                } | null | undefined)[] | {
                    [key: string]: string | number | boolean | any | any | null | undefined;
                } | null | undefined)[] | {
                    [key: string]: string | number | boolean | any | any | null | undefined;
                } | null | undefined)[] | {
                    [key: string]: string | number | boolean | any | any | null | undefined;
                } | null | undefined)[] | {
                    [key: string]: string | number | boolean | any | any | null | undefined;
                } | null | undefined)[] | {
                    [key: string]: string | number | boolean | any | any | null | undefined;
                } | null | undefined)[] | {
                    [key: string]: string | number | boolean | any | any | null | undefined;
                } | null | undefined)[] | {
                    [key: string]: string | number | boolean | any | any | null | undefined;
                } | null | undefined)[] | {
                    [key: string]: string | number | boolean | any | any | null | undefined;
                } | null | undefined;
                iss?: string;
                sub?: string;
                aud?: string | string[];
                jti?: string;
                nbf?: string | number;
                exp?: string | number;
                iat?: boolean;
            }): Promise<string>;
            verify(jwt?: string, options?: import("jose").JWTVerifyOptions): Promise<false | ({
                [x: string]: string | number | boolean | (string | number | boolean | (string | number | boolean | (string | number | boolean | (string | number | boolean | (string | number | boolean | (string | number | boolean | (string | number | boolean | (string | number | boolean | (string | number | boolean | (string | number | boolean | (string | number | boolean | /*elided*/ any | {
                    [key: string]: string | number | boolean | /*elided*/ any | /*elided*/ any | null | undefined;
                } | null | undefined)[] | {
                    [key: string]: string | number | boolean | any | any | null | undefined;
                } | null | undefined)[] | {
                    [key: string]: string | number | boolean | any | any | null | undefined;
                } | null | undefined)[] | {
                    [key: string]: string | number | boolean | any | any | null | undefined;
                } | null | undefined)[] | {
                    [key: string]: string | number | boolean | any | any | null | undefined;
                } | null | undefined)[] | {
                    [key: string]: string | number | boolean | any | any | null | undefined;
                } | null | undefined)[] | {
                    [key: string]: string | number | boolean | any | any | null | undefined;
                } | null | undefined)[] | {
                    [key: string]: string | number | boolean | any | any | null | undefined;
                } | null | undefined)[] | {
                    [key: string]: string | number | boolean | any | any | null | undefined;
                } | null | undefined)[] | {
                    [key: string]: string | number | boolean | any | any | null | undefined;
                } | null | undefined)[] | {
                    [key: string]: string | number | boolean | any | any | null | undefined;
                } | null | undefined)[] | {
                    [key: string]: string | number | boolean | any | any | null | undefined;
                } | null | undefined;
            } & Omit<import("@elysiajs/jwt").JWTPayloadSpec, never>)>;
        };
    };
    store: {};
    derive: {
        readonly bearer: string | undefined;
    };
    resolve: {};
}, {
    typebox: {};
    error: {};
} & {
    typebox: {};
    error: {};
} & {
    typebox: {};
    error: {};
} & {
    typebox: {};
    error: {};
} & {
    typebox: {};
    error: {};
}, {
    schema: {};
    standaloneSchema: {};
    macro: {};
    macroFn: {};
    parser: {};
    response: {};
} & {
    schema: {};
    standaloneSchema: {};
    macro: {};
    macroFn: {};
    parser: {};
    response: {};
} & {
    schema: {};
    standaloneSchema: {};
    macro: {};
    macroFn: {};
    parser: {};
    response: {};
} & {
    schema: {};
    standaloneSchema: {};
    macro: {};
    macroFn: {};
    parser: {};
    response: {};
} & {
    schema: {};
    standaloneSchema: {};
    macro: {};
    macroFn: {};
    parser: {};
    response: import("elysia").ExtractErrorFromHandle<{
        readonly bearer: string | undefined;
    }>;
} & {
    schema: {};
    standaloneSchema: {};
    macro: Partial<{
        readonly stepUp: import("./plugins/step-up.plugin").StepUpRequirement;
    }>;
    macroFn: {
        readonly stepUp: (requirement: import("./plugins/step-up.plugin").StepUpRequirement) => {
            readonly beforeHandle: (ctx: {
                body: unknown;
                query: Record<string, string>;
                params: {};
                headers: Record<string, string | undefined>;
                cookie: Record<string, import("elysia").Cookie<unknown>>;
                server: import("elysia/universal/server").Server | null;
                redirect: import("elysia").redirect;
                set: {
                    headers: import("elysia").HTTPHeaders;
                    status?: number | keyof import("elysia").StatusMap;
                    redirect?: string;
                    cookie?: Record<string, import("elysia/cookies").ElysiaCookie>;
                };
                path: string;
                route: string;
                request: Request;
                store: {};
                status: <const Code extends number | keyof import("elysia").StatusMap, const T = Code extends 100 | 101 | 102 | 103 | 200 | 201 | 202 | 203 | 204 | 205 | 206 | 207 | 208 | 300 | 301 | 302 | 303 | 304 | 307 | 308 | 400 | 401 | 402 | 403 | 404 | 405 | 406 | 407 | 408 | 409 | 410 | 411 | 412 | 413 | 414 | 415 | 416 | 417 | 418 | 420 | 421 | 422 | 423 | 424 | 425 | 426 | 428 | 429 | 431 | 451 | 500 | 501 | 502 | 503 | 504 | 505 | 506 | 507 | 508 | 510 | 511 ? {
                    readonly 100: "Continue";
                    readonly 101: "Switching Protocols";
                    readonly 102: "Processing";
                    readonly 103: "Early Hints";
                    readonly 200: "OK";
                    readonly 201: "Created";
                    readonly 202: "Accepted";
                    readonly 203: "Non-Authoritative Information";
                    readonly 204: "No Content";
                    readonly 205: "Reset Content";
                    readonly 206: "Partial Content";
                    readonly 207: "Multi-Status";
                    readonly 208: "Already Reported";
                    readonly 300: "Multiple Choices";
                    readonly 301: "Moved Permanently";
                    readonly 302: "Found";
                    readonly 303: "See Other";
                    readonly 304: "Not Modified";
                    readonly 307: "Temporary Redirect";
                    readonly 308: "Permanent Redirect";
                    readonly 400: "Bad Request";
                    readonly 401: "Unauthorized";
                    readonly 402: "Payment Required";
                    readonly 403: "Forbidden";
                    readonly 404: "Not Found";
                    readonly 405: "Method Not Allowed";
                    readonly 406: "Not Acceptable";
                    readonly 407: "Proxy Authentication Required";
                    readonly 408: "Request Timeout";
                    readonly 409: "Conflict";
                    readonly 410: "Gone";
                    readonly 411: "Length Required";
                    readonly 412: "Precondition Failed";
                    readonly 413: "Payload Too Large";
                    readonly 414: "URI Too Long";
                    readonly 415: "Unsupported Media Type";
                    readonly 416: "Range Not Satisfiable";
                    readonly 417: "Expectation Failed";
                    readonly 418: "I'm a teapot";
                    readonly 420: "Enhance Your Calm";
                    readonly 421: "Misdirected Request";
                    readonly 422: "Unprocessable Content";
                    readonly 423: "Locked";
                    readonly 424: "Failed Dependency";
                    readonly 425: "Too Early";
                    readonly 426: "Upgrade Required";
                    readonly 428: "Precondition Required";
                    readonly 429: "Too Many Requests";
                    readonly 431: "Request Header Fields Too Large";
                    readonly 451: "Unavailable For Legal Reasons";
                    readonly 500: "Internal Server Error";
                    readonly 501: "Not Implemented";
                    readonly 502: "Bad Gateway";
                    readonly 503: "Service Unavailable";
                    readonly 504: "Gateway Timeout";
                    readonly 505: "HTTP Version Not Supported";
                    readonly 506: "Variant Also Negotiates";
                    readonly 507: "Insufficient Storage";
                    readonly 508: "Loop Detected";
                    readonly 510: "Not Extended";
                    readonly 511: "Network Authentication Required";
                }[Code] : Code>(code: Code, response?: T) => import("elysia").ElysiaCustomStatusResponse<Code, T, Code extends "Continue" | "Switching Protocols" | "Processing" | "Early Hints" | "OK" | "Created" | "Accepted" | "Non-Authoritative Information" | "No Content" | "Reset Content" | "Partial Content" | "Multi-Status" | "Already Reported" | "Multiple Choices" | "Moved Permanently" | "Found" | "See Other" | "Not Modified" | "Temporary Redirect" | "Permanent Redirect" | "Bad Request" | "Unauthorized" | "Payment Required" | "Forbidden" | "Not Found" | "Method Not Allowed" | "Not Acceptable" | "Proxy Authentication Required" | "Request Timeout" | "Conflict" | "Gone" | "Length Required" | "Precondition Failed" | "Payload Too Large" | "URI Too Long" | "Unsupported Media Type" | "Range Not Satisfiable" | "Expectation Failed" | "I'm a teapot" | "Enhance Your Calm" | "Misdirected Request" | "Unprocessable Content" | "Locked" | "Failed Dependency" | "Too Early" | "Upgrade Required" | "Precondition Required" | "Too Many Requests" | "Request Header Fields Too Large" | "Unavailable For Legal Reasons" | "Internal Server Error" | "Not Implemented" | "Bad Gateway" | "Service Unavailable" | "Gateway Timeout" | "HTTP Version Not Supported" | "Variant Also Negotiates" | "Insufficient Storage" | "Loop Detected" | "Not Extended" | "Network Authentication Required" ? {
                    readonly Continue: 100;
                    readonly 'Switching Protocols': 101;
                    readonly Processing: 102;
                    readonly 'Early Hints': 103;
                    readonly OK: 200;
                    readonly Created: 201;
                    readonly Accepted: 202;
                    readonly 'Non-Authoritative Information': 203;
                    readonly 'No Content': 204;
                    readonly 'Reset Content': 205;
                    readonly 'Partial Content': 206;
                    readonly 'Multi-Status': 207;
                    readonly 'Already Reported': 208;
                    readonly 'Multiple Choices': 300;
                    readonly 'Moved Permanently': 301;
                    readonly Found: 302;
                    readonly 'See Other': 303;
                    readonly 'Not Modified': 304;
                    readonly 'Temporary Redirect': 307;
                    readonly 'Permanent Redirect': 308;
                    readonly 'Bad Request': 400;
                    readonly Unauthorized: 401;
                    readonly 'Payment Required': 402;
                    readonly Forbidden: 403;
                    readonly 'Not Found': 404;
                    readonly 'Method Not Allowed': 405;
                    readonly 'Not Acceptable': 406;
                    readonly 'Proxy Authentication Required': 407;
                    readonly 'Request Timeout': 408;
                    readonly Conflict: 409;
                    readonly Gone: 410;
                    readonly 'Length Required': 411;
                    readonly 'Precondition Failed': 412;
                    readonly 'Payload Too Large': 413;
                    readonly 'URI Too Long': 414;
                    readonly 'Unsupported Media Type': 415;
                    readonly 'Range Not Satisfiable': 416;
                    readonly 'Expectation Failed': 417;
                    readonly "I'm a teapot": 418;
                    readonly 'Enhance Your Calm': 420;
                    readonly 'Misdirected Request': 421;
                    readonly 'Unprocessable Content': 422;
                    readonly Locked: 423;
                    readonly 'Failed Dependency': 424;
                    readonly 'Too Early': 425;
                    readonly 'Upgrade Required': 426;
                    readonly 'Precondition Required': 428;
                    readonly 'Too Many Requests': 429;
                    readonly 'Request Header Fields Too Large': 431;
                    readonly 'Unavailable For Legal Reasons': 451;
                    readonly 'Internal Server Error': 500;
                    readonly 'Not Implemented': 501;
                    readonly 'Bad Gateway': 502;
                    readonly 'Service Unavailable': 503;
                    readonly 'Gateway Timeout': 504;
                    readonly 'HTTP Version Not Supported': 505;
                    readonly 'Variant Also Negotiates': 506;
                    readonly 'Insufficient Storage': 507;
                    readonly 'Loop Detected': 508;
                    readonly 'Not Extended': 510;
                    readonly 'Network Authentication Required': 511;
                }[Code] : Code>;
            }) => Promise<void>;
        };
    };
    parser: {};
    response: {};
} & {
    schema: {};
    standaloneSchema: {};
    macro: {};
    macroFn: {};
    parser: {};
    response: {};
}, {
    ".well-known": {
        "oauth-protected-resource": {
            mcp: {
                get: {
                    body: unknown;
                    params: {};
                    query: unknown;
                    headers: unknown;
                    response: {
                        200: import("../../../packages/mcp/src/index").ProtectedResourceMetadata;
                    };
                };
            };
        };
    };
} & {
    ".well-known": {
        "oauth-protected-resource": {
            get: {
                body: unknown;
                params: {};
                query: unknown;
                headers: unknown;
                response: {
                    200: import("../../../packages/mcp/src/index").ProtectedResourceMetadata;
                };
            };
        };
    };
} & {
    api: {
        ":baseId": {
            oauth2: {
                ".well-known": {
                    "oauth-authorization-server": {
                        get: {
                            body: unknown;
                            params: {
                                baseId: string;
                            } & {};
                            query: unknown;
                            headers: unknown;
                            response: {
                                200: import("./lib/oauth2/metadata").AuthorizationServerMetadata;
                                404: {
                                    readonly error: "Base not found";
                                };
                                422: {
                                    type: 'validation';
                                    on: string;
                                    summary?: string;
                                    message?: string;
                                    found?: unknown;
                                    property?: string;
                                    expected?: string;
                                };
                            };
                        };
                    };
                };
            };
        };
    };
} & {
    ".well-known": {
        "oauth-authorization-server": {
            api: {
                ":baseId": {
                    oauth2: {
                        get: {
                            body: unknown;
                            params: {
                                baseId: string;
                            } & {};
                            query: unknown;
                            headers: unknown;
                            response: {
                                200: import("./lib/oauth2/metadata").AuthorizationServerMetadata;
                                404: {
                                    readonly error: "Base not found";
                                };
                                422: {
                                    type: 'validation';
                                    on: string;
                                    summary?: string;
                                    message?: string;
                                    found?: unknown;
                                    property?: string;
                                    expected?: string;
                                };
                            };
                        };
                    };
                };
            };
        };
    };
} & {
    ".well-known": {
        "oauth-authorization-server": {
            get: {
                body: unknown;
                params: {};
                query: unknown;
                headers: unknown;
                response: {
                    200: import("./lib/oauth2/metadata").AuthorizationServerMetadata;
                };
            };
        };
    };
} & {
    api: {
        ":baseId": {
            oauth2: {};
        };
    };
} & {
    api: {
        ":baseId": {
            oauth2: {
                "register-client": {
                    post: {
                        body: unknown;
                        params: {
                            baseId: string;
                        } & {};
                        query: unknown;
                        headers: unknown;
                        response: {
                            422: {
                                type: 'validation';
                                on: string;
                                summary?: string;
                                message?: string;
                                found?: unknown;
                                property?: string;
                                expected?: string;
                            };
                        };
                    };
                };
            };
        };
    };
} & {
    mcp: {
        [x: string]: {
            body: unknown;
            params: {};
            query: unknown;
            headers: unknown;
            response: {
                200: "" | Response;
            };
        };
    };
} & {
    api: {
        initialize: {
            post: {
                body: {
                    email?: {
                        fromEmail?: string | undefined;
                        fromName?: string | undefined;
                        host?: string | undefined;
                        password?: string | undefined;
                        port?: number | undefined;
                        secure?: boolean | undefined;
                        username?: string | undefined;
                    } | undefined;
                    initialDatabase: {
                        _id?: string | undefined;
                        description?: string | null | undefined;
                        displayName?: string | null | undefined;
                        folder?: string | null | undefined;
                        isDynamic?: boolean | null | undefined;
                        isSystem?: boolean | null | undefined;
                        metadata?: Record<string, any> | null | undefined;
                        name: string;
                        physicalName?: string | undefined;
                        immutable?: boolean | null | undefined;
                    };
                    owner: {
                        confirmPassword: string;
                        email: string;
                        name?: string | undefined;
                        password: string;
                        username: string;
                    };
                };
                params: {};
                query: unknown;
                headers: unknown;
                response: {
                    200: import("../../../packages/wql/src/index").BaseNode;
                    422: {
                        type: 'validation';
                        on: string;
                        summary?: string;
                        message?: string;
                        found?: unknown;
                        property?: string;
                        expected?: string;
                    };
                };
            };
        };
    };
} & {
    api: {
        definitions: {
            "server-info": {
                get: {
                    body: unknown;
                    params: {};
                    query: unknown;
                    headers: unknown;
                    response: {
                        200: {
                            buildNumber: string | null;
                            env: "development" | "production" | "test";
                            version: string;
                        };
                    };
                };
            };
        };
    };
} & {
    api: {
        dev: {
            bases: {
                post: {
                    body: {
                        _id?: string | undefined;
                        description?: string | null | undefined;
                        displayName?: string | null | undefined;
                        isSystem?: boolean | null | undefined;
                        metadata?: Record<string, any> | null | undefined;
                        name: string;
                        physicalName?: string | undefined;
                        immutable?: boolean | null | undefined;
                        type?: string | null | undefined;
                    };
                    params: {};
                    query: unknown;
                    headers: unknown;
                    response: {
                        200: import("../../../packages/wql/src/index").BaseNode;
                        422: {
                            type: 'validation';
                            on: string;
                            summary?: string;
                            message?: string;
                            found?: unknown;
                            property?: string;
                            expected?: string;
                        };
                    };
                };
            };
        } & {
            bases: {
                ":baseId": {
                    delete: {
                        body: unknown;
                        params: {
                            baseId: string;
                        };
                        query: unknown;
                        headers: unknown;
                        response: {
                            422: {
                                type: 'validation';
                                on: string;
                                summary?: string;
                                message?: string;
                                found?: unknown;
                                property?: string;
                                expected?: string;
                            };
                        };
                    };
                };
            };
        } & {
            bases: {
                ":baseId": {
                    put: {
                        body: {
                            description?: string | null | undefined;
                            displayName?: string | null | undefined;
                            immutable?: boolean | undefined;
                            metadata?: Record<string, any> | null | undefined;
                            name?: string | undefined;
                        };
                        params: {
                            baseId: string;
                        };
                        query: unknown;
                        headers: unknown;
                        response: {
                            200: {
                                _id: string;
                                physicalName: string;
                                name: string;
                                immutable: (boolean | null);
                                allowAnonymousAccess: (boolean | null);
                                displayName: (string | null);
                                description: (string | null);
                                metadata: ({
                                    [k: string]: unknown;
                                } | null);
                                isSystem: (boolean | null);
                                deletedAt: (string | null);
                                createdAt: string;
                                updatedAt: string;
                                createdBy: (string | null);
                                updatedBy: (string | null);
                            } & Record<any, unknown>;
                            422: {
                                type: 'validation';
                                on: string;
                                summary?: string;
                                message?: string;
                                found?: unknown;
                                property?: string;
                                expected?: string;
                            };
                        };
                    };
                };
            };
        };
    };
} & {
    api: {
        dev: {
            bases: {
                "management-authority": {
                    get: {
                        body: unknown;
                        params: {};
                        query: unknown;
                        headers: unknown;
                        response: {
                            200: {
                                canManageBases: boolean;
                            };
                            422: {
                                type: 'validation';
                                on: string;
                                summary?: string;
                                message?: string;
                                found?: unknown;
                                property?: string;
                                expected?: string;
                            };
                        };
                    };
                };
            };
        };
    };
} & {
    api: {
        dev: {
            migrations: {};
        } & {
            migrations: {
                plan: {
                    post: {
                        body: {
                            packages: "clientSettings"[];
                            source: {
                                baseId: string;
                                kind: "base";
                            } | {
                                bundle: any;
                                kind: "bundle";
                            };
                            targetBaseId: string;
                        };
                        params: {};
                        query: unknown;
                        headers: unknown;
                        response: {
                            200: import("../../../packages/driver/src/features/migration/plan/PlanResult").PlanResult | {
                                error: string;
                                message: string;
                            };
                            422: {
                                type: 'validation';
                                on: string;
                                summary?: string;
                                message?: string;
                                found?: unknown;
                                property?: string;
                                expected?: string;
                            };
                        };
                    };
                };
            };
        } & {
            migrations: {
                plan: {
                    ":planId": {
                        decisions: {
                            post: {
                                body: {
                                    decisions: {
                                        answer: "leave-absent" | "revive";
                                        nodeId: string;
                                    }[];
                                };
                                params: {
                                    planId: string;
                                };
                                query: unknown;
                                headers: unknown;
                                response: {
                                    200: {
                                        ok: boolean;
                                        error?: undefined;
                                        message?: undefined;
                                    } | {
                                        ok?: undefined;
                                        error: string;
                                        message: string;
                                    };
                                    422: {
                                        type: 'validation';
                                        on: string;
                                        summary?: string;
                                        message?: string;
                                        found?: unknown;
                                        property?: string;
                                        expected?: string;
                                    };
                                };
                            };
                        };
                    };
                };
            };
        } & {
            migrations: {
                execute: {
                    get: {
                        body: unknown;
                        params: {};
                        query: {
                            planId: string;
                        };
                        headers: unknown;
                        response: {
                            200: Response;
                            422: {
                                type: 'validation';
                                on: string;
                                summary?: string;
                                message?: string;
                                found?: unknown;
                                property?: string;
                                expected?: string;
                            };
                        };
                    };
                };
            };
        } & {
            migrations: {
                bundle: {
                    export: {
                        post: {
                            body: {
                                baseId: string;
                                packages: "clientSettings"[];
                            };
                            params: {};
                            query: unknown;
                            headers: unknown;
                            response: {
                                200: import("../../../packages/driver/src/types").MigrationBundle;
                                422: {
                                    type: 'validation';
                                    on: string;
                                    summary?: string;
                                    message?: string;
                                    found?: unknown;
                                    property?: string;
                                    expected?: string;
                                };
                            };
                        };
                    };
                };
            };
        };
    };
} & {
    docs: {
        get: {
            body: unknown;
            params: {};
            query: unknown;
            headers: unknown;
            response: {
                200: Response;
            };
        };
    };
} & {
    s3: {
        ":baseId": {
            "*": {
                [x: string]: {
                    body: unknown;
                    params: {
                        "*": string;
                        baseId: string;
                    } & {};
                    query: unknown;
                    headers: unknown;
                    response: {
                        200: Response;
                        422: {
                            type: 'validation';
                            on: string;
                            summary?: string;
                            message?: string;
                            found?: unknown;
                            property?: string;
                            expected?: string;
                        };
                    };
                };
            };
        };
    };
} & {
    public: {
        shares: {
            ":baseId": {
                d: {
                    ":token": {};
                };
            } & {
                d: {
                    ":token": {
                        get: {
                            body: unknown;
                            params: {
                                token: string;
                            };
                            query: unknown;
                            headers: unknown;
                            response: {
                                200: {
                                    exhausted: boolean;
                                    expired: boolean;
                                    expiresAt: string | null;
                                    requiresPassword: boolean;
                                    revoked: boolean;
                                };
                                422: {
                                    type: 'validation';
                                    on: string;
                                    summary?: string;
                                    message?: string;
                                    found?: unknown;
                                    property?: string;
                                    expected?: string;
                                };
                            };
                        };
                    };
                };
            } & {
                d: {
                    ":token": {
                        auth: {
                            post: {
                                body: {
                                    password?: string | undefined;
                                };
                                params: {
                                    token: string;
                                };
                                query: unknown;
                                headers: unknown;
                                response: {
                                    200: {
                                        reason?: "exhausted" | "expired" | "revoked" | undefined;
                                        success: boolean;
                                    };
                                    422: {
                                        type: 'validation';
                                        on: string;
                                        summary?: string;
                                        message?: string;
                                        found?: unknown;
                                        property?: string;
                                        expected?: string;
                                    };
                                };
                            };
                        };
                    };
                };
            } & {
                d: {
                    ":token": {
                        objects: {
                            get: {
                                body: unknown;
                                params: {
                                    token: string;
                                };
                                query: unknown;
                                headers: unknown;
                                response: {
                                    200: import("../../../packages/driver/src/types").ShareTreeItemType[];
                                    422: {
                                        type: 'validation';
                                        on: string;
                                        summary?: string;
                                        message?: string;
                                        found?: unknown;
                                        property?: string;
                                        expected?: string;
                                    };
                                };
                            };
                        };
                    } & {
                        download: {
                            get: {
                                body: unknown;
                                params: {
                                    token: string;
                                };
                                query: {
                                    key: string;
                                };
                                headers: unknown;
                                response: {
                                    200: {
                                        url: string;
                                    };
                                    422: {
                                        type: 'validation';
                                        on: string;
                                        summary?: string;
                                        message?: string;
                                        found?: unknown;
                                        property?: string;
                                        expected?: string;
                                    };
                                };
                            };
                        };
                    };
                };
            };
        };
    };
} & {
    public: {
        shares: {
            ":baseId": {
                u: {
                    ":token": {};
                };
            } & {
                u: {
                    ":token": {
                        get: {
                            body: unknown;
                            params: {
                                token: string;
                            };
                            query: unknown;
                            headers: unknown;
                            response: {
                                200: {
                                    allowedMimeTypes: string[] | null;
                                    exhausted: boolean;
                                    expired: boolean;
                                    expiresAt: string | null;
                                    maxFileSize: number | null;
                                    requiresPassword: boolean;
                                    revoked: boolean;
                                    uploadPrefix: string | undefined;
                                };
                                422: {
                                    type: 'validation';
                                    on: string;
                                    summary?: string;
                                    message?: string;
                                    found?: unknown;
                                    property?: string;
                                    expected?: string;
                                };
                            };
                        };
                    };
                };
            } & {
                u: {
                    ":token": {
                        auth: {
                            post: {
                                body: {
                                    password?: string | undefined;
                                };
                                params: {
                                    token: string;
                                };
                                query: unknown;
                                headers: unknown;
                                response: {
                                    200: {
                                        reason?: "exhausted" | "expired" | "revoked" | undefined;
                                        success: boolean;
                                    };
                                    422: {
                                        type: 'validation';
                                        on: string;
                                        summary?: string;
                                        message?: string;
                                        found?: unknown;
                                        property?: string;
                                        expected?: string;
                                    };
                                };
                            };
                        };
                    };
                };
            } & {
                u: {
                    ":token": {
                        upload: {
                            get: {
                                body: unknown;
                                params: {
                                    token: string;
                                };
                                query: {
                                    contentType?: string | undefined;
                                    key: string;
                                    size?: number | undefined;
                                };
                                headers: unknown;
                                response: {
                                    200: {
                                        url: string;
                                    };
                                    422: {
                                        type: 'validation';
                                        on: string;
                                        summary?: string;
                                        message?: string;
                                        found?: unknown;
                                        property?: string;
                                        expected?: string;
                                    };
                                };
                            };
                        };
                    } & {
                        upload: {
                            confirm: {
                                post: {
                                    body: unknown;
                                    params: {
                                        token: string;
                                    };
                                    query: {
                                        key: string;
                                    };
                                    headers: unknown;
                                    response: {
                                        200: {
                                            exists: boolean;
                                            size: number | null;
                                        };
                                        422: {
                                            type: 'validation';
                                            on: string;
                                            summary?: string;
                                            message?: string;
                                            found?: unknown;
                                            property?: string;
                                            expected?: string;
                                        };
                                    };
                                };
                            };
                        };
                    };
                };
            };
        };
    };
} & {
    metrics: {
        get: {
            body: unknown;
            params: {};
            query: unknown;
            headers: unknown;
            response: {
                200: string;
            };
        };
    };
} & {
    npm: {
        "*": {
            get: {
                body: unknown;
                params: {
                    "*": string;
                } & {};
                query: unknown;
                headers: unknown;
                response: {
                    200: Response | {
                        'dist-tags': {
                            latest: string;
                        };
                        name: string;
                        versions: {
                            [x: string]: {
                                name: string;
                                version: string;
                                dist: {
                                    integrity: string;
                                    shasum: string;
                                    tarball: string;
                                };
                            };
                        };
                    };
                    404: {
                        readonly error: "This server was built without the client packages; compile it with `turbo compile -- --npm` to serve them.";
                    } | {
                        readonly error: `Not served here: ${string}. Available: ${string}`;
                    };
                    422: {
                        type: 'validation';
                        on: string;
                        summary?: string;
                        message?: string;
                        found?: unknown;
                        property?: string;
                        expected?: string;
                    };
                };
            };
        };
    };
} & {
    api: {
        ":baseId": {
            oauth2: {
                ".well-known": {
                    "openid-configuration": {
                        get: {
                            body: unknown;
                            params: {
                                baseId: string;
                            } & {};
                            query: unknown;
                            headers: unknown;
                            response: {
                                200: {
                                    authorization_endpoint: string;
                                    issuer: string;
                                    token_endpoint: string;
                                    userinfo_endpoint: string;
                                };
                                422: {
                                    type: 'validation';
                                    on: string;
                                    summary?: string;
                                    message?: string;
                                    found?: unknown;
                                    property?: string;
                                    expected?: string;
                                };
                            };
                        };
                    };
                };
            };
        };
    };
} & {
    api: {
        ":baseId": {
            oauth2: {
                discover: {
                    get: {
                        body: unknown;
                        params: {
                            baseId: string;
                        } & {};
                        query: unknown;
                        headers: unknown;
                        response: {
                            200: {
                                allowedFirstFactors: string[];
                                allowRegister: boolean;
                                externalProviders: {
                                    displayName: string;
                                    id: string;
                                    startUrl: string;
                                    type: string;
                                }[];
                                providers: string[];
                            };
                            400: {
                                error: string;
                            };
                            422: {
                                type: 'validation';
                                on: string;
                                summary?: string;
                                message?: string;
                                found?: unknown;
                                property?: string;
                                expected?: string;
                            };
                        };
                    };
                };
            };
        };
    };
} & {
    api: {
        ":baseId": {
            oauth2: {
                federated: {
                    ":providerSlug": {
                        begin: {
                            post: {
                                body: unknown;
                                params: {
                                    baseId: string;
                                    providerSlug: string;
                                } & {};
                                query: unknown;
                                headers: unknown;
                                response: {
                                    200: {
                                        authorize_url: string;
                                    };
                                    400: {
                                        error: string;
                                    } | {
                                        readonly error: "return_to is not a registered return target for this base";
                                    };
                                    403: {
                                        readonly error: "This client cannot be entered through that provider";
                                    };
                                    422: {
                                        type: 'validation';
                                        on: string;
                                        summary?: string;
                                        message?: string;
                                        found?: unknown;
                                        property?: string;
                                        expected?: string;
                                    };
                                    500: {
                                        readonly error: "Could not start sign-in with that provider";
                                    };
                                };
                            };
                        };
                    };
                };
            };
        };
    };
} & {
    api: {
        ":baseId": {
            oauth2: {
                federated: {
                    ":providerSlug": {
                        callback: {
                            get: {
                                body: unknown;
                                params: {
                                    baseId: string;
                                    providerSlug: string;
                                } & {};
                                query: unknown;
                                headers: unknown;
                                response: {
                                    200: Response;
                                    422: {
                                        type: 'validation';
                                        on: string;
                                        summary?: string;
                                        message?: string;
                                        found?: unknown;
                                        property?: string;
                                        expected?: string;
                                    };
                                };
                            };
                        };
                    };
                };
            };
        };
    };
} & {
    api: {
        ":baseId": {
            oauth2: {
                password: {
                    "enroll-request": {
                        post: {
                            body: unknown;
                            params: {
                                baseId: string;
                            } & {};
                            query: unknown;
                            headers: unknown;
                            response: {
                                200: {
                                    message: string;
                                };
                                422: {
                                    type: 'validation';
                                    on: string;
                                    summary?: string;
                                    message?: string;
                                    found?: unknown;
                                    property?: string;
                                    expected?: string;
                                };
                            };
                        };
                    };
                };
            };
        };
    };
} & {
    api: {
        ":baseId": {
            oauth2: {
                register: {
                    post: {
                        body: unknown;
                        params: {
                            baseId: string;
                        } & {};
                        query: unknown;
                        headers: unknown;
                        response: {
                            200: {
                                message: string;
                            };
                            400: {
                                readonly error: "email is required";
                            };
                            422: {
                                type: 'validation';
                                on: string;
                                summary?: string;
                                message?: string;
                                found?: unknown;
                                property?: string;
                                expected?: string;
                            };
                        };
                    };
                };
            };
        };
    };
} & {
    api: {
        ":baseId": {
            oauth2: {
                password: {
                    "enroll-confirm": {
                        post: {
                            body: unknown;
                            params: {
                                baseId: string;
                            } & {};
                            query: unknown;
                            headers: unknown;
                            response: {
                                200: {
                                    message: string;
                                };
                                400: {
                                    readonly error: string;
                                };
                                422: {
                                    type: 'validation';
                                    on: string;
                                    summary?: string;
                                    message?: string;
                                    found?: unknown;
                                    property?: string;
                                    expected?: string;
                                };
                            };
                        };
                    };
                };
            };
        };
    };
} & {
    api: {
        ":baseId": {
            oauth2: {
                flow: {
                    enroll: {
                        post: {
                            body: unknown;
                            params: {
                                baseId: string;
                            } & {};
                            query: unknown;
                            headers: unknown;
                            response: {
                                200: {
                                    factor_id: string | undefined;
                                };
                                400: {
                                    readonly error: "flow_token and factor_type are required";
                                };
                                401: {
                                    readonly error: "Invalid or expired flow token";
                                };
                                422: {
                                    type: 'validation';
                                    on: string;
                                    summary?: string;
                                    message?: string;
                                    found?: unknown;
                                    property?: string;
                                    expected?: string;
                                };
                            };
                        };
                    };
                };
            };
        };
    };
} & {
    api: {
        ":baseId": {
            oauth2: {
                flow: {
                    enroll: {
                        confirm: {
                            post: {
                                body: unknown;
                                params: {
                                    baseId: string;
                                } & {};
                                query: unknown;
                                headers: unknown;
                                response: {
                                    200: {
                                        flow_required: boolean;
                                        flow_token: string;
                                        next: import("../../../packages/shared/src/auth-factors/index").FlowNext;
                                        recovery_codes: string[] | undefined;
                                        access_token?: undefined;
                                        expires_in?: undefined;
                                        refresh_token?: undefined;
                                        scopes?: undefined;
                                        token_type?: undefined;
                                    } | {
                                        flow_required?: undefined;
                                        flow_token?: undefined;
                                        next?: undefined;
                                        access_token: string;
                                        expires_in: number;
                                        recovery_codes: string[] | undefined;
                                        refresh_token: string;
                                        scopes: string[];
                                        token_type: "Bearer";
                                    };
                                    400: {
                                        readonly error: "flow_token and factor_type are required";
                                    };
                                    401: {
                                        readonly error: "Could not confirm enrollment";
                                    };
                                    422: {
                                        type: 'validation';
                                        on: string;
                                        summary?: string;
                                        message?: string;
                                        found?: unknown;
                                        property?: string;
                                        expected?: string;
                                    };
                                    429: {
                                        readonly error: string;
                                    };
                                };
                            };
                        };
                    };
                };
            };
        };
    };
} & {
    api: {
        ":baseId": {
            oauth2: {
                flow: {
                    password: {
                        update: {
                            post: {
                                body: unknown;
                                params: {
                                    baseId: string;
                                } & {};
                                query: unknown;
                                headers: unknown;
                                response: {
                                    200: {
                                        access_token?: undefined;
                                        expires_in?: undefined;
                                        refresh_token?: undefined;
                                        scopes?: undefined;
                                        token_type?: undefined;
                                        flow_required: boolean;
                                        flow_token: string;
                                        next: import("../../../packages/shared/src/auth-factors/index").FlowNext;
                                    } | {
                                        flow_required?: undefined;
                                        flow_token?: undefined;
                                        next?: undefined;
                                        access_token: string;
                                        expires_in: number;
                                        refresh_token: string;
                                        scopes: string[];
                                        token_type: "Bearer";
                                    };
                                    400: {
                                        readonly error: "flow_token and new_password are required";
                                    } | {
                                        readonly error: "Passwords do not match";
                                    } | {
                                        readonly code: "flow_expired" | "password_rejected";
                                        readonly error: "Could not update the password";
                                    };
                                    422: {
                                        type: 'validation';
                                        on: string;
                                        summary?: string;
                                        message?: string;
                                        found?: unknown;
                                        property?: string;
                                        expected?: string;
                                    };
                                };
                            };
                        };
                    };
                };
            };
        };
    };
} & {
    api: {
        ":baseId": {
            oauth2: {
                flow: {
                    challenge: {
                        post: {
                            body: unknown;
                            params: {
                                baseId: string;
                            } & {};
                            query: unknown;
                            headers: unknown;
                            response: {
                                200: Record<string, unknown>;
                                400: {
                                    readonly error: "flow_token and factor_type are required";
                                };
                                401: {
                                    readonly error: "Invalid or expired flow token";
                                };
                                422: {
                                    type: 'validation';
                                    on: string;
                                    summary?: string;
                                    message?: string;
                                    found?: unknown;
                                    property?: string;
                                    expected?: string;
                                };
                            };
                        };
                    };
                };
            };
        };
    };
} & {
    api: {
        ":baseId": {
            oauth2: {
                flow: {
                    discoverable: {
                        begin: {
                            post: {
                                body: unknown;
                                params: {
                                    baseId: string;
                                } & {};
                                query: unknown;
                                headers: unknown;
                                response: {
                                    200: {
                                        challengeToken: string;
                                        options: import("@simplewebauthn/server").PublicKeyCredentialRequestOptionsJSON;
                                    };
                                    422: {
                                        type: 'validation';
                                        on: string;
                                        summary?: string;
                                        message?: string;
                                        found?: unknown;
                                        property?: string;
                                        expected?: string;
                                    };
                                };
                            };
                        };
                    };
                };
            };
        };
    };
} & {
    api: {
        ":baseId": {
            oauth2: {
                flow: {
                    discoverable: {
                        complete: {
                            post: {
                                body: unknown;
                                params: {
                                    baseId: string;
                                } & {};
                                query: unknown;
                                headers: unknown;
                                response: {
                                    200: {
                                        access_token?: undefined;
                                        expires_in?: undefined;
                                        refresh_token?: undefined;
                                        scopes?: undefined;
                                        token_type?: undefined;
                                        flow_required: boolean;
                                        flow_token: string;
                                        next: import("../../../packages/shared/src/auth-factors/index").FlowNext;
                                    } | {
                                        flow_required?: undefined;
                                        flow_token?: undefined;
                                        next?: undefined;
                                        access_token: string;
                                        expires_in: number;
                                        refresh_token: string;
                                        scopes: string[];
                                        token_type: "Bearer";
                                    };
                                    400: {
                                        readonly error: "client_id, challengeToken and response are required";
                                    };
                                    401: {
                                        readonly error: "Passkey authentication failed";
                                    };
                                    422: {
                                        type: 'validation';
                                        on: string;
                                        summary?: string;
                                        message?: string;
                                        found?: unknown;
                                        property?: string;
                                        expected?: string;
                                    };
                                    429: {
                                        readonly error: string;
                                    };
                                };
                            };
                        };
                    };
                };
            };
        };
    };
} & {
    api: {
        ":baseId": {
            oauth2: {
                "client-info": {
                    get: {
                        body: unknown;
                        params: {
                            baseId: string;
                        } & {};
                        query: unknown;
                        headers: unknown;
                        response: {
                            200: {
                                baseName: any;
                                _id: string;
                                name: string;
                                shortName: string;
                                clientUri: (string | null);
                                consentRequired: boolean;
                                logoUri: (string | null);
                                verified: boolean;
                                publisherInfo: ({
                                    _id: string;
                                    name: string;
                                    domain: string;
                                    isTrusted: boolean;
                                    logoUri: (string | null);
                                } | null);
                            };
                            400: {
                                readonly error: "client_id is required";
                            };
                            404: {
                                readonly error: "Client not found";
                            };
                            422: {
                                type: 'validation';
                                on: string;
                                summary?: string;
                                message?: string;
                                found?: unknown;
                                property?: string;
                                expected?: string;
                            };
                        };
                    };
                };
            };
        };
    };
} & {
    api: {
        ":baseId": {
            oauth2: {
                authorize: {
                    get: {
                        body: unknown;
                        params: {
                            baseId: string;
                        } & {};
                        query: unknown;
                        headers: unknown;
                        response: {
                            200: Response | {
                                redirectTo: string;
                            };
                            400: {
                                readonly error: 'invalid_request';
                                readonly error_description: 'Unknown client';
                            } | {
                                readonly error: "invalid_request";
                                readonly error_description: "code_challenge is required (PKCE, RFC 7636)";
                            } | {
                                readonly error: "invalid_request";
                                readonly error_description: "code_challenge_method must be S256 or plain";
                            } | {
                                readonly error: "invalid_redirect_uri";
                                readonly error_description: "redirect_uri is not registered for this client (RFC 6749 §3.1.2.3)";
                            };
                            401: {
                                readonly error: "User not confirmed";
                            } | {
                                readonly error: "invalid_token";
                                readonly error_description: "token audience does not match this base";
                            } | {
                                readonly error: "No token provided";
                            };
                            422: {
                                type: 'validation';
                                on: string;
                                summary?: string;
                                message?: string;
                                found?: unknown;
                                property?: string;
                                expected?: string;
                            };
                            500: {
                                readonly error: "server_error";
                                readonly error_description: "PUBLIC_URL is not configured";
                            };
                        };
                    };
                };
            };
        };
    };
} & {
    api: {
        ":baseId": {
            oauth2: {
                token: {
                    post: {
                        body: unknown;
                        params: {
                            baseId: string;
                        } & {};
                        query: unknown;
                        headers: unknown;
                        response: {
                            200: {
                                flow_required?: undefined;
                                flow_token?: undefined;
                                next?: undefined;
                                access_token: string;
                                expires_in: number;
                                refresh_token: string;
                                scopes: string[];
                                token_type: "Bearer";
                            } | {
                                access_token?: undefined;
                                expires_in?: undefined;
                                refresh_token?: undefined;
                                scopes?: undefined;
                                token_type?: undefined;
                                flow_required: boolean;
                                flow_token: string;
                                next: import("../../../packages/shared/src/auth-factors/index").FlowNext;
                            };
                            400: {
                                readonly error: "captcha_required";
                                readonly error_description: "Too many failed attempts. A CAPTCHA solution is required.";
                            } | {
                                readonly error: "invalid_grant";
                                readonly error_description: "The provided authorization code is invalid or expired.";
                            } | {
                                readonly error: "invalid_grant";
                                readonly error_description: "The refresh token is invalid or expired.";
                            } | {
                                readonly error: "Unsupported grant type";
                            };
                            401: {
                                readonly error: 'invalid_client';
                                readonly error_description: 'Client authentication failed.';
                            } | {
                                readonly error: "No refresh token provided";
                            };
                            422: {
                                type: 'validation';
                                on: string;
                                summary?: string;
                                message?: string;
                                found?: unknown;
                                property?: string;
                                expected?: string;
                            };
                        };
                    };
                };
            };
        };
    };
} & {
    api: {
        ":baseId": {
            oauth2: {
                userinfo: {
                    get: {
                        body: unknown;
                        params: {
                            baseId: string;
                        } & {};
                        query: unknown;
                        headers: unknown;
                        response: {
                            200: Record<string, unknown>;
                            401: {
                                readonly error: "No token provided";
                            } | {
                                readonly error: "Invalid token";
                            } | {
                                readonly error: "invalid_token";
                                readonly error_description: "token audience does not match this base";
                            };
                            422: {
                                type: 'validation';
                                on: string;
                                summary?: string;
                                message?: string;
                                found?: unknown;
                                property?: string;
                                expected?: string;
                            };
                        };
                    };
                };
            };
        };
    };
} & {
    api: {
        ":baseId": {
            oauth2: {
                "signin-button-xs.svg": {
                    get: {
                        body: unknown;
                        params: {
                            baseId: string;
                        } & {};
                        query: unknown;
                        headers: unknown;
                        response: {
                            200: Response;
                            422: {
                                type: 'validation';
                                on: string;
                                summary?: string;
                                message?: string;
                                found?: unknown;
                                property?: string;
                                expected?: string;
                            };
                        };
                    };
                };
            };
        };
    };
} & {
    api: {
        ":baseId": {
            oauth2: {
                "signin-button-sm.svg": {
                    get: {
                        body: unknown;
                        params: {
                            baseId: string;
                        } & {};
                        query: unknown;
                        headers: unknown;
                        response: {
                            200: Response;
                            422: {
                                type: 'validation';
                                on: string;
                                summary?: string;
                                message?: string;
                                found?: unknown;
                                property?: string;
                                expected?: string;
                            };
                        };
                    };
                };
            };
        };
    };
} & {
    api: {
        ":baseId": {
            oauth2: {
                "signin-button-md.svg": {
                    get: {
                        body: unknown;
                        params: {
                            baseId: string;
                        } & {};
                        query: unknown;
                        headers: unknown;
                        response: {
                            200: Response;
                            422: {
                                type: 'validation';
                                on: string;
                                summary?: string;
                                message?: string;
                                found?: unknown;
                                property?: string;
                                expected?: string;
                            };
                        };
                    };
                };
            };
        };
    };
} & {
    api: {
        ":baseId": {
            oauth2: {
                "signin-button-lg.svg": {
                    get: {
                        body: unknown;
                        params: {
                            baseId: string;
                        } & {};
                        query: unknown;
                        headers: unknown;
                        response: {
                            200: Response;
                            422: {
                                type: 'validation';
                                on: string;
                                summary?: string;
                                message?: string;
                                found?: unknown;
                                property?: string;
                                expected?: string;
                            };
                        };
                    };
                };
            };
        };
    };
} & {
    api: {
        ":baseId": {
            oauth2: {
                revoke: {
                    post: {
                        body: unknown;
                        params: {
                            baseId: string;
                        } & {};
                        query: unknown;
                        headers: unknown;
                        response: {
                            200: {
                                success: boolean;
                            };
                            400: {
                                readonly error: "invalid_request";
                                readonly error_description: "client_id is required.";
                            } | {
                                readonly error: "invalid_request";
                                readonly error_description: "A session token is required.";
                            };
                            401: {
                                readonly error: 'invalid_client';
                                readonly error_description: 'Client authentication failed.';
                            };
                            422: {
                                type: 'validation';
                                on: string;
                                summary?: string;
                                message?: string;
                                found?: unknown;
                                property?: string;
                                expected?: string;
                            };
                        };
                    };
                };
            };
        };
    };
} & {
    api: {
        ":baseId": {
            oauth2: {
                logout: {
                    get: {
                        body: unknown;
                        params: {
                            baseId: string;
                        } & {};
                        query: unknown;
                        headers: unknown;
                        response: {
                            200: Response | {
                                success: boolean;
                            };
                            400: {
                                readonly error: "invalid_request";
                                readonly error_description: "post_logout_redirect_uri is not registered for this client";
                            };
                            422: {
                                type: 'validation';
                                on: string;
                                summary?: string;
                                message?: string;
                                found?: unknown;
                                property?: string;
                                expected?: string;
                            };
                        };
                    };
                };
            };
        };
    };
} & {
    api: {
        ":baseId": {};
    };
} & {
    api: {
        ":baseId": {
            browse: {};
        } & {
            browse: {
                wql: {
                    post: {
                        body: {
                            config?: {
                                allowMutation?: boolean | undefined;
                                as?: "explain-analyze" | "run" | undefined;
                                realtime?: boolean | undefined;
                                rowFormat?: "array" | "objects" | undefined;
                                runAs?: "elevated" | "policied" | undefined;
                            } | undefined;
                            params?: Record<string, any> | undefined;
                            query: string | Record<string, any>;
                        };
                        params: {};
                        query: unknown;
                        headers: unknown;
                        response: {
                            200: Response;
                            422: {
                                type: 'validation';
                                on: string;
                                summary?: string;
                                message?: string;
                                found?: unknown;
                                property?: string;
                                expected?: string;
                            };
                        };
                    };
                };
            };
        } & {
            browse: {
                wqlEnvelope: {
                    post: {
                        body: {
                            config?: {
                                allowMutation: boolean;
                                explain?: boolean | undefined;
                                schema?: boolean | undefined;
                                typescript?: boolean | undefined;
                            } | undefined;
                            params?: Record<string, any> | undefined;
                            query: string | Record<string, any>;
                        };
                        params: {};
                        query: unknown;
                        headers: unknown;
                        response: {
                            200: import("./routes/base/compile-wql").WqlEnvelope;
                            422: {
                                type: 'validation';
                                on: string;
                                summary?: string;
                                message?: string;
                                found?: unknown;
                                property?: string;
                                expected?: string;
                            };
                        };
                    };
                };
            };
        } & {
            browse: {
                ":modelId": {
                    post: {
                        body: any;
                        params: {
                            modelId: string;
                        };
                        query: unknown;
                        headers: unknown;
                        response: {
                            201: {
                                [x: string]: unknown;
                                _id: unknown;
                            };
                            422: {
                                type: 'validation';
                                on: string;
                                summary?: string;
                                message?: string;
                                found?: unknown;
                                property?: string;
                                expected?: string;
                            };
                        };
                    };
                };
            };
        } & {
            browse: {
                ":modelId": {
                    ":rowId": {
                        get: {
                            body: unknown;
                            params: {
                                modelId: string;
                                rowId: string;
                            };
                            query: {
                                decrypt?: string[] | undefined;
                                select?: string | string[] | undefined;
                                unmask?: string[] | undefined;
                            };
                            headers: unknown;
                            response: {
                                200: {
                                    _id: string;
                                } & Record<string, unknown>;
                                422: {
                                    type: 'validation';
                                    on: string;
                                    summary?: string;
                                    message?: string;
                                    found?: unknown;
                                    property?: string;
                                    expected?: string;
                                };
                            };
                        };
                    };
                };
            };
        } & {
            browse: {
                ":modelId": {
                    ":rowId": {
                        history: {
                            get: {
                                body: unknown;
                                params: {
                                    modelId: string;
                                    rowId: string;
                                };
                                query: unknown;
                                headers: unknown;
                                response: {
                                    200: ({
                                        _id: string;
                                    } & Record<string, unknown>)[];
                                    422: {
                                        type: 'validation';
                                        on: string;
                                        summary?: string;
                                        message?: string;
                                        found?: unknown;
                                        property?: string;
                                        expected?: string;
                                    };
                                };
                            };
                        };
                    };
                };
            };
        } & {
            browse: {
                ":modelId": {
                    ":rowId": {
                        put: {
                            body: any;
                            params: {
                                modelId: string;
                                rowId: string;
                            };
                            query: {
                                soft?: boolean | undefined;
                            };
                            headers: unknown;
                            response: {
                                200: ({
                                    _id: unknown;
                                } | {
                                    _id: unknown;
                                }) & Record<any, unknown>;
                                422: {
                                    type: 'validation';
                                    on: string;
                                    summary?: string;
                                    message?: string;
                                    found?: unknown;
                                    property?: string;
                                    expected?: string;
                                };
                            };
                        };
                    };
                };
            };
        } & {
            browse: {
                ":modelId": {
                    ":rowId": {
                        delete: {
                            body: unknown;
                            params: {
                                modelId: string;
                                rowId: string;
                            };
                            query: unknown;
                            headers: unknown;
                            response: {
                                200: {
                                    message: string;
                                };
                                422: {
                                    type: 'validation';
                                    on: string;
                                    summary?: string;
                                    message?: string;
                                    found?: unknown;
                                    property?: string;
                                    expected?: string;
                                };
                            };
                        };
                    };
                };
            };
        } & {
            browse: {
                ":modelId": {
                    delete: {
                        body: {
                            ids: string[];
                        };
                        params: {
                            modelId: string;
                        };
                        query: unknown;
                        headers: unknown;
                        response: {
                            200: {
                                message: string;
                            };
                            422: {
                                type: 'validation';
                                on: string;
                                summary?: string;
                                message?: string;
                                found?: unknown;
                                property?: string;
                                expected?: string;
                            };
                        };
                    };
                };
            };
        };
    };
} & {
    api: {
        ":baseId": {
            history: {};
        } & {
            history: {
                tag: {
                    post: {
                        body: {
                            operation: string;
                            tag: string;
                        };
                        params: {};
                        query: unknown;
                        headers: unknown;
                        response: {
                            200: {
                                message: string;
                            };
                            422: {
                                type: 'validation';
                                on: string;
                                summary?: string;
                                message?: string;
                                found?: unknown;
                                property?: string;
                                expected?: string;
                            };
                        };
                    };
                };
            };
        } & {
            history: {
                tag: {
                    ":tag": {
                        delete: {
                            body: unknown;
                            params: {
                                tag: string;
                            };
                            query: unknown;
                            headers: unknown;
                            response: {
                                200: {
                                    message: string;
                                };
                                422: {
                                    type: 'validation';
                                    on: string;
                                    summary?: string;
                                    message?: string;
                                    found?: unknown;
                                    property?: string;
                                    expected?: string;
                                };
                            };
                        };
                    };
                };
            };
        } & {
            history: {
                restore: {
                    ":point": {
                        get: {
                            body: unknown;
                            params: {
                                point: string;
                            };
                            query: unknown;
                            headers: unknown;
                            response: {
                                200: Response;
                                422: {
                                    type: 'validation';
                                    on: string;
                                    summary?: string;
                                    message?: string;
                                    found?: unknown;
                                    property?: string;
                                    expected?: string;
                                };
                            };
                        };
                    };
                };
            };
        };
    };
} & {
    api: {
        ":baseId": {
            models: {
                post: {
                    body: {
                        _id?: string | undefined;
                        description?: string | null | undefined;
                        displayName?: string | null | undefined;
                        folder?: string | null | undefined;
                        isDynamic?: boolean | null | undefined;
                        isSystem?: boolean | null | undefined;
                        name: string;
                        ordinal?: number | null | undefined;
                        physicalName?: string | undefined;
                        metadata?: {
                            allowDynamicColumns?: boolean | null | undefined;
                            displayFieldId?: string | null | undefined;
                            hasComments?: boolean | null | undefined;
                            hasVersion?: boolean | null | undefined;
                            transient?: boolean | null | undefined;
                        } | null | undefined;
                        parent: string;
                        type: "table";
                    } | {
                        _id?: string | undefined;
                        description?: string | null | undefined;
                        displayName?: string | null | undefined;
                        folder?: string | null | undefined;
                        isDynamic?: boolean | null | undefined;
                        isSystem?: boolean | null | undefined;
                        name: string;
                        ordinal?: number | null | undefined;
                        parent: string;
                        physicalName?: string | undefined;
                        metadata: {
                            allowEnd?: "both" | "exclusive-only" | "inclusive-only" | null | undefined;
                            allowedCountries?: string[] | null | undefined;
                            allowedMimeTypes?: string[] | null | undefined;
                            allowedTables?: string[] | null | undefined;
                            allowFilter?: boolean | null | undefined;
                            allowOpenEnd?: boolean | null | undefined;
                            allowOpenStart?: boolean | null | undefined;
                            allowSearch?: boolean | null | undefined;
                            allowStart?: "both" | "exclusive-only" | "inclusive-only" | null | undefined;
                            allowsAnyTable?: boolean | null | undefined;
                            bucket?: string | null | undefined;
                            canHaveMultiple?: boolean | null | undefined;
                            dataMask?: {
                                char?: string | null | undefined;
                                email?: boolean | null | undefined;
                                enabled?: boolean | null | undefined;
                                leading?: number | null | undefined;
                                separators?: boolean | null | undefined;
                                trailing?: number | null | undefined;
                            } | null | undefined;
                            defaultValue?: any;
                            encrypt?: boolean | null | undefined;
                            formula?: string | null | undefined;
                            hidden?: boolean | null | undefined;
                            immutable?: boolean | null | undefined;
                            inputMask?: string | null | undefined;
                            isArray?: boolean | null | undefined;
                            isDynamic?: boolean | null | undefined;
                            isMultiSelect?: "no" | "yes" | null | undefined;
                            isNqTarget?: boolean | null | undefined;
                            isPrimaryKey?: boolean | null | undefined;
                            isUnique?: boolean | null | undefined;
                            listName?: string | null | undefined;
                            maxFileSizeBytes?: number | null | undefined;
                            mirrorColumns?: {
                                _id?: string | null | undefined;
                                canHaveMultiple?: boolean | null | undefined;
                                name: string;
                                physicalName?: string | null | undefined;
                                table: string;
                            }[] | null | undefined;
                            notAllowedCountries?: string[] | null | undefined;
                            notNull?: boolean | null | undefined;
                            onDelete?: "cascade" | "keep" | "restrict" | "setNull" | null | undefined;
                            optimizeSort?: boolean | null | undefined;
                            precision?: number | null | undefined;
                            rules?: {
                                args?: any[] | null | undefined;
                                name: string;
                            }[] | null | undefined;
                            scale?: number | null | undefined;
                            schema?: Record<string, unknown> | null | undefined;
                            sensitive?: "always" | "explicitly-open" | null | undefined;
                            summaryTypes?: string[] | null | undefined;
                            targetTables?: {
                                junctionSourceColumn?: string | null | undefined;
                                junctionTable?: string | null | undefined;
                                junctionTargetColumn?: string | null | undefined;
                                table: string;
                                targetColumn?: string | null | undefined;
                            }[] | null | undefined;
                            type: string;
                            versioning?: boolean | null | undefined;
                        };
                        type: "column";
                    } | {
                        _id?: string | undefined;
                        description?: string | null | undefined;
                        displayName?: string | null | undefined;
                        folder?: string | null | undefined;
                        isDynamic?: boolean | null | undefined;
                        isSystem?: boolean | null | undefined;
                        metadata?: Record<string, any> | null | undefined;
                        name: string;
                        ordinal?: number | null | undefined;
                        physicalName?: string | undefined;
                        parent?: null | undefined;
                        type: "space";
                    } | {
                        _id?: string | undefined;
                        description?: string | null | undefined;
                        displayName?: string | null | undefined;
                        folder?: string | null | undefined;
                        isDynamic?: boolean | null | undefined;
                        isSystem?: boolean | null | undefined;
                        name: string;
                        ordinal?: number | null | undefined;
                        physicalName?: string | undefined;
                        metadata: {
                            elevated?: boolean | undefined;
                            exposure?: "public" | "service" | "trusted" | undefined;
                            query?: string | undefined;
                        };
                        parent: string;
                        type: "namedQuery";
                    };
                    params: {};
                    query: unknown;
                    headers: unknown;
                    response: {
                        422: {
                            type: 'validation';
                            on: string;
                            summary?: string;
                            message?: string;
                            found?: unknown;
                            property?: string;
                            expected?: string;
                        };
                    };
                };
            };
        } & {
            models: {
                structure: {
                    get: {
                        body: unknown;
                        params: {};
                        query: unknown;
                        headers: unknown;
                        response: {
                            200: import("../../../packages/wql/src/index").SpaceNode[];
                        };
                    };
                };
            };
        } & {
            models: {
                dump: {
                    get: {
                        body: unknown;
                        params: {};
                        query: unknown;
                        headers: unknown;
                        response: {
                            200: import("../../../packages/wql/src/index").WynModel;
                        };
                    };
                };
            };
        } & {
            models: {
                get: {
                    body: unknown;
                    params: {};
                    query: {
                        parentId?: string | undefined;
                        spaceName?: string | undefined;
                        type?: string | undefined;
                    };
                    headers: unknown;
                    response: {
                        422: {
                            type: 'validation';
                            on: string;
                            summary?: string;
                            message?: string;
                            found?: unknown;
                            property?: string;
                            expected?: string;
                        };
                    };
                };
            };
        } & {
            models: {
                resolve: {
                    get: {
                        body: unknown;
                        params: {};
                        query: {
                            identifier: string;
                            scope?: string | undefined;
                        };
                        headers: unknown;
                        response: {
                            200: import("../../../packages/wql/src/index").ResolvedNode;
                            422: {
                                type: 'validation';
                                on: string;
                                summary?: string;
                                message?: string;
                                found?: unknown;
                                property?: string;
                                expected?: string;
                            };
                        };
                    };
                };
            };
        } & {
            models: {
                ":modelId": {
                    get: {
                        body: unknown;
                        params: {
                            modelId: string;
                        };
                        query: {
                            childDepth: number;
                        };
                        headers: unknown;
                        response: {
                            200: import("../../../packages/wql/src/index").ColumnNode | import("../../../packages/wql/src/index").NamedQueryNode | import("../../../packages/wql/src/index").SpaceNode | import("../../../packages/wql/src/index").TableNode;
                            422: {
                                type: 'validation';
                                on: string;
                                summary?: string;
                                message?: string;
                                found?: unknown;
                                property?: string;
                                expected?: string;
                            };
                        };
                    };
                };
            };
        } & {
            models: {
                ":modelId": {
                    put: {
                        body: {
                            _id?: string | undefined;
                            description?: string | null | undefined;
                            displayName?: string | null | undefined;
                            folder?: string | null | undefined;
                            isDynamic?: boolean | null | undefined;
                            isSystem?: boolean | null | undefined;
                            name: string;
                            ordinal?: number | null | undefined;
                            physicalName?: string | undefined;
                            metadata?: {
                                allowDynamicColumns?: boolean | null | undefined;
                                displayFieldId?: string | null | undefined;
                                hasComments?: boolean | null | undefined;
                                hasVersion?: boolean | null | undefined;
                                transient?: boolean | null | undefined;
                            } | null | undefined;
                            parent: string;
                            type: "table";
                        } | {
                            _id?: string | undefined;
                            description?: string | null | undefined;
                            displayName?: string | null | undefined;
                            folder?: string | null | undefined;
                            isDynamic?: boolean | null | undefined;
                            isSystem?: boolean | null | undefined;
                            name: string;
                            ordinal?: number | null | undefined;
                            parent: string;
                            physicalName?: string | undefined;
                            metadata: {
                                allowEnd?: "both" | "exclusive-only" | "inclusive-only" | null | undefined;
                                allowedCountries?: string[] | null | undefined;
                                allowedMimeTypes?: string[] | null | undefined;
                                allowedTables?: string[] | null | undefined;
                                allowFilter?: boolean | null | undefined;
                                allowOpenEnd?: boolean | null | undefined;
                                allowOpenStart?: boolean | null | undefined;
                                allowSearch?: boolean | null | undefined;
                                allowStart?: "both" | "exclusive-only" | "inclusive-only" | null | undefined;
                                allowsAnyTable?: boolean | null | undefined;
                                bucket?: string | null | undefined;
                                canHaveMultiple?: boolean | null | undefined;
                                dataMask?: {
                                    char?: string | null | undefined;
                                    email?: boolean | null | undefined;
                                    enabled?: boolean | null | undefined;
                                    leading?: number | null | undefined;
                                    separators?: boolean | null | undefined;
                                    trailing?: number | null | undefined;
                                } | null | undefined;
                                defaultValue?: any;
                                encrypt?: boolean | null | undefined;
                                formula?: string | null | undefined;
                                hidden?: boolean | null | undefined;
                                immutable?: boolean | null | undefined;
                                inputMask?: string | null | undefined;
                                isArray?: boolean | null | undefined;
                                isDynamic?: boolean | null | undefined;
                                isMultiSelect?: "no" | "yes" | null | undefined;
                                isNqTarget?: boolean | null | undefined;
                                isPrimaryKey?: boolean | null | undefined;
                                isUnique?: boolean | null | undefined;
                                listName?: string | null | undefined;
                                maxFileSizeBytes?: number | null | undefined;
                                mirrorColumns?: {
                                    _id?: string | null | undefined;
                                    canHaveMultiple?: boolean | null | undefined;
                                    name: string;
                                    physicalName?: string | null | undefined;
                                    table: string;
                                }[] | null | undefined;
                                notAllowedCountries?: string[] | null | undefined;
                                notNull?: boolean | null | undefined;
                                onDelete?: "cascade" | "keep" | "restrict" | "setNull" | null | undefined;
                                optimizeSort?: boolean | null | undefined;
                                precision?: number | null | undefined;
                                rules?: {
                                    args?: any[] | null | undefined;
                                    name: string;
                                }[] | null | undefined;
                                scale?: number | null | undefined;
                                schema?: Record<string, unknown> | null | undefined;
                                sensitive?: "always" | "explicitly-open" | null | undefined;
                                summaryTypes?: string[] | null | undefined;
                                targetTables?: {
                                    junctionSourceColumn?: string | null | undefined;
                                    junctionTable?: string | null | undefined;
                                    junctionTargetColumn?: string | null | undefined;
                                    table: string;
                                    targetColumn?: string | null | undefined;
                                }[] | null | undefined;
                                type: string;
                                versioning?: boolean | null | undefined;
                            };
                            type: "column";
                        } | {
                            _id?: string | undefined;
                            description?: string | null | undefined;
                            displayName?: string | null | undefined;
                            folder?: string | null | undefined;
                            isDynamic?: boolean | null | undefined;
                            isSystem?: boolean | null | undefined;
                            metadata?: Record<string, any> | null | undefined;
                            name: string;
                            ordinal?: number | null | undefined;
                            physicalName?: string | undefined;
                            parent?: null | undefined;
                            type: "space";
                        } | {
                            _id?: string | undefined;
                            description?: string | null | undefined;
                            displayName?: string | null | undefined;
                            folder?: string | null | undefined;
                            isDynamic?: boolean | null | undefined;
                            isSystem?: boolean | null | undefined;
                            name: string;
                            ordinal?: number | null | undefined;
                            physicalName?: string | undefined;
                            metadata: {
                                elevated?: boolean | undefined;
                                exposure?: "public" | "service" | "trusted" | undefined;
                                query?: string | undefined;
                            };
                            parent: string;
                            type: "namedQuery";
                        };
                        params: {
                            modelId: string;
                        };
                        query: unknown;
                        headers: unknown;
                        response: {
                            422: {
                                type: 'validation';
                                on: string;
                                summary?: string;
                                message?: string;
                                found?: unknown;
                                property?: string;
                                expected?: string;
                            };
                        };
                    };
                };
            };
        } & {
            models: {
                ":modelId": {
                    order: {
                        put: {
                            body: {
                                columnIds: string[];
                            };
                            params: {
                                modelId: string;
                            };
                            query: unknown;
                            headers: unknown;
                            response: {
                                422: {
                                    type: 'validation';
                                    on: string;
                                    summary?: string;
                                    message?: string;
                                    found?: unknown;
                                    property?: string;
                                    expected?: string;
                                };
                            };
                        };
                    };
                };
            };
        } & {
            models: {
                ":modelId": {
                    delete: {
                        body: unknown;
                        params: {
                            modelId: string;
                        };
                        query: {
                            cascadeConstraints?: "false" | "true" | undefined;
                        };
                        headers: unknown;
                        response: {
                            200: Record<string, any>;
                            422: {
                                type: 'validation';
                                on: string;
                                summary?: string;
                                message?: string;
                                found?: unknown;
                                property?: string;
                                expected?: string;
                            };
                        };
                    };
                };
            };
        } & {
            models: {
                sources: {
                    get: {
                        body: unknown;
                        params: {};
                        query: {
                            modelId?: string | undefined;
                        };
                        headers: unknown;
                        response: {
                            200: any[];
                            422: {
                                type: 'validation';
                                on: string;
                                summary?: string;
                                message?: string;
                                found?: unknown;
                                property?: string;
                                expected?: string;
                            };
                        };
                    };
                };
            };
        };
    };
} & {
    api: {
        ":baseId": {
            constraints: {
                impact: {
                    ":columnId": {
                        get: {
                            body: unknown;
                            params: {
                                baseId: string;
                                columnId: string;
                            };
                            query: unknown;
                            headers: unknown;
                            response: {
                                200: import("../../../packages/driver/src/features/lifecycle/index").ConstraintRow[];
                                422: {
                                    type: 'validation';
                                    on: string;
                                    summary?: string;
                                    message?: string;
                                    found?: unknown;
                                    property?: string;
                                    expected?: string;
                                };
                            };
                        };
                    };
                };
            };
        } & {
            "link-delete-impact": {
                ":columnId": {
                    get: {
                        body: unknown;
                        params: {
                            baseId: string;
                            columnId: string;
                        };
                        query: unknown;
                        headers: unknown;
                        response: {
                            200: import("../../../packages/driver/src/features/lifecycle/index").LinkDeleteImpact;
                            422: {
                                type: 'validation';
                                on: string;
                                summary?: string;
                                message?: string;
                                found?: unknown;
                                property?: string;
                                expected?: string;
                            };
                        };
                    };
                };
            };
        } & {
            constraints: {
                post: {
                    body: {
                        isSystem?: boolean | undefined;
                        metadata: any;
                        name?: string | undefined;
                        tableId: string;
                    };
                    params: {};
                    query: unknown;
                    headers: unknown;
                    response: {
                        201: {
                            _id: string;
                            name: string;
                            physicalName: string;
                            type: 'constraint';
                            parentId: string;
                            metadata: import("../../../packages/wql/src/index").ConstraintMetadata;
                            isSystem: boolean;
                        };
                        422: {
                            type: 'validation';
                            on: string;
                            summary?: string;
                            message?: string;
                            found?: unknown;
                            property?: string;
                            expected?: string;
                        };
                    };
                };
            };
        } & {
            constraints: {
                ":constraintId": {
                    patch: {
                        body: {
                            metadata?: any;
                            name?: string | undefined;
                        };
                        params: {
                            baseId: string;
                            constraintId: string;
                        };
                        query: unknown;
                        headers: unknown;
                        response: {
                            200: import("../../../packages/driver/src/features/lifecycle/index").ConstraintRow;
                            422: {
                                type: 'validation';
                                on: string;
                                summary?: string;
                                message?: string;
                                found?: unknown;
                                property?: string;
                                expected?: string;
                            };
                        };
                    };
                };
            };
        } & {
            constraints: {
                ":constraintId": {
                    delete: {
                        body: unknown;
                        params: {
                            baseId: string;
                            constraintId: string;
                        };
                        query: unknown;
                        headers: unknown;
                        response: {
                            200: {
                                ok: boolean;
                            };
                            422: {
                                type: 'validation';
                                on: string;
                                summary?: string;
                                message?: string;
                                found?: unknown;
                                property?: string;
                                expected?: string;
                            };
                        };
                    };
                };
            };
        };
    };
} & {
    api: {
        ":baseId": {
            folders: {
                ":currentName": {
                    put: {
                        body: {
                            modelId: string;
                            newName: string;
                        };
                        params: {
                            currentName: string;
                        };
                        query: unknown;
                        headers: unknown;
                        response: {
                            200: {
                                message: string;
                            };
                            422: {
                                type: 'validation';
                                on: string;
                                summary?: string;
                                message?: string;
                                found?: unknown;
                                property?: string;
                                expected?: string;
                            };
                        };
                    };
                };
            };
        } & {
            folders: {
                ":currentName": {
                    delete: {
                        body: {
                            modelId: string;
                        };
                        params: {
                            currentName: string;
                        };
                        query: unknown;
                        headers: unknown;
                        response: {
                            200: {
                                message: string;
                            };
                            422: {
                                type: 'validation';
                                on: string;
                                summary?: string;
                                message?: string;
                                found?: unknown;
                                property?: string;
                                expected?: string;
                            };
                        };
                    };
                };
            };
        };
    };
} & {
    api: {
        ":baseId": {
            account: {};
        } & {
            account: {
                settings: {
                    sessions: {
                        all: {
                            delete: {
                                body: {};
                                params: {};
                                query: {};
                                headers: {};
                                response: {
                                    200: {
                                        message: string;
                                    };
                                };
                            };
                        };
                    };
                };
            };
        } & {
            account: {
                settings: {
                    sessions: {
                        ":sessionId": {
                            delete: {
                                body: {};
                                params: {
                                    sessionId: string;
                                };
                                query: {};
                                headers: {};
                                response: {
                                    200: {
                                        message: string;
                                    };
                                    404: {
                                        readonly message: "Session not found";
                                    };
                                    422: {
                                        type: 'validation';
                                        on: string;
                                        summary?: string;
                                        message?: string;
                                        found?: unknown;
                                        property?: string;
                                        expected?: string;
                                    };
                                };
                            };
                        };
                    };
                };
            };
        } & {
            account: {
                settings: {
                    emails: {
                        post: {
                            body: {
                                email: string;
                            };
                            params: {};
                            query: {};
                            headers: {};
                            response: {
                                200: {
                                    _id: string;
                                    email: string;
                                    verified: (string | null);
                                    primary: (boolean | null);
                                    user: (string | null);
                                    createdAt: string;
                                    updatedAt: string;
                                    createdBy: (string | null);
                                    updatedBy: (string | null);
                                } & Record<any, unknown>;
                                422: {
                                    type: 'validation';
                                    on: string;
                                    summary?: string;
                                    message?: string;
                                    found?: unknown;
                                    property?: string;
                                    expected?: string;
                                };
                            };
                        };
                    };
                };
            };
        } & {
            account: {
                settings: {
                    emails: {
                        ":emailId": {
                            primary: {
                                post: {
                                    body: {};
                                    params: {
                                        emailId: string;
                                    };
                                    query: {};
                                    headers: {};
                                    response: {
                                        200: import("../../../packages/wql/src/index").WqlRows<Record<any, unknown>, import("../../../packages/wql/src/index").WQLOptions<boolean, boolean, boolean, import("../../../packages/wql/src/index").WQLExecutionMode> & {
                                            raw?: boolean;
                                            model?: import("../../../packages/wql/src/index").WynModel | import("../../../packages/wql/src/index").WynModelTree;
                                            skipRealtimeInvalidation?: boolean;
                                            skipPolyDisplay?: boolean;
                                        }>;
                                        400: {
                                            readonly message: string;
                                        };
                                        404: {
                                            readonly message: "Email not found";
                                        };
                                        422: {
                                            type: 'validation';
                                            on: string;
                                            summary?: string;
                                            message?: string;
                                            found?: unknown;
                                            property?: string;
                                            expected?: string;
                                        };
                                    };
                                };
                            };
                        };
                    };
                };
            };
        } & {
            account: {
                settings: {
                    emails: {
                        ":emailId": {
                            verify: {
                                post: {
                                    body: {};
                                    params: {
                                        emailId: string;
                                    };
                                    query: {};
                                    headers: {};
                                    response: {
                                        200: {
                                            message: string;
                                        } | {
                                            message: string;
                                        };
                                        422: {
                                            type: 'validation';
                                            on: string;
                                            summary?: string;
                                            message?: string;
                                            found?: unknown;
                                            property?: string;
                                            expected?: string;
                                        };
                                        503: {
                                            message: string;
                                        } | {
                                            message: string;
                                        };
                                    };
                                };
                            };
                        };
                    };
                };
            };
        } & {
            account: {
                settings: {
                    emails: {
                        ":emailId": {
                            delete: {
                                body: {};
                                params: {
                                    emailId: string;
                                };
                                query: {};
                                headers: {};
                                response: {
                                    200: {
                                        message: string;
                                    };
                                    400: {
                                        readonly message: string;
                                    };
                                    404: {
                                        readonly message: "Email not found";
                                    };
                                    422: {
                                        type: 'validation';
                                        on: string;
                                        summary?: string;
                                        message?: string;
                                        found?: unknown;
                                        property?: string;
                                        expected?: string;
                                    };
                                };
                            };
                        };
                    };
                };
            };
        } & {
            account: {
                settings: {
                    password: {
                        change: {
                            post: {
                                body: {
                                    confirmPassword: string;
                                    currentPassword: string;
                                    newPassword: string;
                                };
                                params: {};
                                query: {};
                                headers: {};
                                response: {
                                    200: {
                                        message: string;
                                    };
                                    400: {
                                        readonly message: string;
                                    };
                                    401: {
                                        readonly message: "Current password is incorrect";
                                    };
                                    422: {
                                        type: 'validation';
                                        on: string;
                                        summary?: string;
                                        message?: string;
                                        found?: unknown;
                                        property?: string;
                                        expected?: string;
                                    };
                                };
                            };
                        };
                    };
                };
            };
        } & {
            account: {
                settings: {
                    password: {
                        set: {
                            post: {
                                body: {
                                    confirmPassword: string;
                                    newPassword: string;
                                };
                                params: {};
                                query: {};
                                headers: {};
                                response: {
                                    200: {
                                        message: string;
                                    };
                                    400: {
                                        readonly message: string;
                                    };
                                    422: {
                                        type: 'validation';
                                        on: string;
                                        summary?: string;
                                        message?: string;
                                        found?: unknown;
                                        property?: string;
                                        expected?: string;
                                    };
                                };
                            };
                        };
                    };
                };
            };
        } & {
            account: {
                factors: {
                    get: {
                        body: {};
                        params: {};
                        query: {};
                        headers: {};
                        response: {
                            200: ({
                                _id: string;
                                type: string;
                                createdAt: string;
                                label: string | null;
                                status: string;
                                lastUsedAt: string | null;
                                mustChange: boolean;
                                isPasskey: boolean;
                                source: 'factor' | 'passkey' | 'recovery';
                                canRemove: boolean;
                            } | {
                                canRemove: boolean;
                                _id: string;
                                type: string;
                                status: string;
                                label: (string | null);
                                lastUsedAt: (string | null);
                                createdAt: string;
                            })[];
                        };
                    };
                };
            };
        } & {
            account: {
                factors: {
                    post: {
                        body: {
                            label?: string | undefined;
                            type: "passkey_device_bound" | "passkey_synced" | "totp";
                        };
                        params: {};
                        query: {};
                        headers: {};
                        response: {
                            200: {
                                factorId: string | undefined;
                            };
                            422: {
                                type: 'validation';
                                on: string;
                                summary?: string;
                                message?: string;
                                found?: unknown;
                                property?: string;
                                expected?: string;
                            };
                        };
                    };
                };
            };
        } & {
            account: {
                factors: {
                    passkey: {
                        confirm: {
                            post: {
                                body: {};
                                params: {};
                                query: {};
                                headers: {};
                                response: {
                                    200: {
                                        recoveryCodes: string[];
                                        status: string;
                                    } | {
                                        recoveryCodes?: undefined;
                                        status: string;
                                    };
                                    400: {
                                        readonly message: any;
                                    };
                                    429: {
                                        readonly message: any;
                                    };
                                };
                            };
                        };
                    };
                };
            };
        } & {
            account: {
                factors: {
                    ":id": {
                        enrollment: {
                            get: {
                                body: {};
                                params: {
                                    id: string;
                                };
                                query: {};
                                headers: {};
                                response: {
                                    200: {
                                        factorId: string;
                                        secret: string;
                                        status: string;
                                        uri: string;
                                    };
                                    400: {
                                        readonly message: any;
                                    };
                                    422: {
                                        type: 'validation';
                                        on: string;
                                        summary?: string;
                                        message?: string;
                                        found?: unknown;
                                        property?: string;
                                        expected?: string;
                                    };
                                };
                            };
                        };
                    };
                };
            };
        } & {
            account: {
                factors: {
                    ":id": {
                        verify: {
                            post: {
                                body: {
                                    code: string;
                                };
                                params: {
                                    id: string;
                                };
                                query: {};
                                headers: {};
                                response: {
                                    200: {
                                        factorId: string;
                                        status: string;
                                    } | {
                                        factorId: string;
                                        status: string;
                                        recoveryCodes: string[];
                                    };
                                    400: {
                                        readonly message: any;
                                    };
                                    422: {
                                        type: 'validation';
                                        on: string;
                                        summary?: string;
                                        message?: string;
                                        found?: unknown;
                                        property?: string;
                                        expected?: string;
                                    };
                                    429: {
                                        readonly message: any;
                                    };
                                };
                            };
                        };
                    };
                };
            };
        } & {
            account: {
                factors: {
                    ":id": {
                        delete: {
                            body: {};
                            params: {
                                id: string;
                            };
                            query: {};
                            headers: {};
                            response: {
                                200: {
                                    message: string;
                                };
                                400: {
                                    readonly message: any;
                                };
                                403: {
                                    readonly message: any;
                                };
                                404: {
                                    readonly message: any;
                                };
                                422: {
                                    type: 'validation';
                                    on: string;
                                    summary?: string;
                                    message?: string;
                                    found?: unknown;
                                    property?: string;
                                    expected?: string;
                                };
                                429: {
                                    readonly message: any;
                                };
                            };
                        };
                    };
                };
            };
        } & {
            account: {
                "recovery-codes": {
                    get: {
                        body: {};
                        params: {};
                        query: {};
                        headers: {};
                        response: {
                            200: {
                                remaining: number;
                            };
                        };
                    };
                };
            };
        } & {
            account: {
                "recovery-codes": {
                    post: {
                        body: {};
                        params: {};
                        query: {};
                        headers: {};
                        response: {
                            200: {
                                codes: string[];
                            };
                        };
                    };
                };
            };
        } & {
            account: {
                "step-up": {
                    get: {
                        body: {};
                        params: {};
                        query: {
                            aal?: number | undefined;
                            webauthn?: "false" | "true" | undefined;
                        };
                        headers: {};
                        response: {
                            200: {
                                factors: string[];
                                mode: 'enroll' | 'unsatisfiable' | 'verify';
                                escapes: import("../../../packages/shared/src/auth-factors/index").FactorType[];
                                autoSelect?: import("../../../packages/shared/src/auth-factors/index").FactorType;
                                heldBackByGrace: boolean;
                                aal: number;
                            };
                            422: {
                                type: 'validation';
                                on: string;
                                summary?: string;
                                message?: string;
                                found?: unknown;
                                property?: string;
                                expected?: string;
                            };
                        };
                    };
                };
            };
        } & {
            account: {
                "step-up": {
                    challenge: {
                        post: {
                            body: {
                                factorType: string;
                            };
                            params: {};
                            query: {};
                            headers: {};
                            response: {
                                200: Record<string, unknown>;
                                400: {
                                    readonly message: any;
                                };
                                422: {
                                    type: 'validation';
                                    on: string;
                                    summary?: string;
                                    message?: string;
                                    found?: unknown;
                                    property?: string;
                                    expected?: string;
                                };
                            };
                        };
                    };
                };
            };
        } & {
            account: {
                "step-up": {
                    factors: {
                        post: {
                            body: {
                                label?: string | undefined;
                                type: "passkey_device_bound" | "passkey_synced" | "totp";
                            };
                            params: {};
                            query: {};
                            headers: {};
                            response: {
                                200: {
                                    factorId: string | undefined;
                                };
                                400: {
                                    readonly message: any;
                                };
                                422: {
                                    type: 'validation';
                                    on: string;
                                    summary?: string;
                                    message?: string;
                                    found?: unknown;
                                    property?: string;
                                    expected?: string;
                                };
                            };
                        };
                    };
                };
            };
        } & {
            account: {
                "step-up": {
                    post: {
                        body: {
                            aal?: number | undefined;
                            challengeToken?: string | undefined;
                            code?: string | undefined;
                            factorId?: string | undefined;
                            factorType: string;
                            intent: "enroll" | "verify";
                            label?: string | undefined;
                            response?: unknown;
                        };
                        params: {};
                        query: {};
                        headers: {};
                        response: {
                            200: {
                                aal: number;
                                access_token: string;
                                acr: string;
                                expires_in: number;
                                recoveryCodes?: string[] | undefined;
                                token_type: "Bearer";
                            };
                            400: {
                                readonly message: "A WebAuthn response is required for a passkey factor";
                            } | {
                                readonly message: "A code is required for this factor type";
                            } | {
                                readonly message: "factorId is required to confirm this enrollment";
                            };
                            401: {
                                readonly message: "No active session";
                            };
                            422: {
                                type: 'validation';
                                on: string;
                                summary?: string;
                                message?: string;
                                found?: unknown;
                                property?: string;
                                expected?: string;
                            };
                        };
                    };
                };
            };
        };
    };
} & {
    api: {
        ":baseId": {
            account: {};
        } & {
            account: {
                "verify-email": {
                    post: {
                        body: {
                            identifier: string;
                            token: string;
                        };
                        params: {};
                        query: unknown;
                        headers: unknown;
                        response: {
                            200: {
                                message: string;
                            };
                            400: {
                                readonly message: "Identifier and code are required";
                            } | {
                                readonly message: "Invalid identifier or token";
                            };
                            422: {
                                type: 'validation';
                                on: string;
                                summary?: string;
                                message?: string;
                                found?: unknown;
                                property?: string;
                                expected?: string;
                            };
                        };
                    };
                };
            };
        };
    };
} & {
    api: {
        ":baseId": {
            activity: {};
        } & {
            activity: {
                get: {
                    body: unknown;
                    params: {};
                    query: {
                        blockIO?: boolean | undefined;
                        sessions?: boolean | undefined;
                        tps?: boolean | undefined;
                        tuplesIn?: boolean | undefined;
                        tuplesOut?: boolean | undefined;
                    };
                    headers: unknown;
                    response: {
                        200: {
                            sessions?: import("../../../packages/driver/src/types").ActivitySession[];
                            tuplesIn?: import("../../../packages/driver/src/types").TupleIn[];
                            tuplesOut?: import("../../../packages/driver/src/types").TupleOut[];
                            blockIO?: import("../../../packages/driver/src/types").BlockIO[];
                            tps?: import("../../../packages/driver/src/types").TransactionStats[];
                        };
                        422: {
                            type: 'validation';
                            on: string;
                            summary?: string;
                            message?: string;
                            found?: unknown;
                            property?: string;
                            expected?: string;
                        };
                    };
                };
            };
        };
    };
} & {
    api: {
        ":baseId": {
            alerts: {};
        } & {
            alerts: {
                post: {
                    body: {
                        description?: string | undefined;
                        name: string;
                        notifyOnResolve?: boolean | undefined;
                        query: string;
                    };
                    params: {};
                    query: unknown;
                    headers: unknown;
                    response: {
                        200: (Record<string, unknown> & {
                            _id: string;
                            ownerId?: string;
                            trackingEntries?: {
                                tables?: string[];
                            }[];
                            warnings?: import("../../../packages/driver/src/types").AlertWarning[];
                            description?: string | null;
                            lastError?: string | null;
                        }) | null;
                        422: {
                            type: 'validation';
                            on: string;
                            summary?: string;
                            message?: string;
                            found?: unknown;
                            property?: string;
                            expected?: string;
                        };
                    };
                };
            };
        } & {
            alerts: {
                ":alertId": {
                    patch: {
                        body: {
                            description?: string | null | undefined;
                            name?: string | undefined;
                            notifyOnResolve?: boolean | undefined;
                            query?: string | undefined;
                        };
                        params: {
                            alertId: string;
                        };
                        query: unknown;
                        headers: unknown;
                        response: {
                            200: (Record<string, unknown> & {
                                _id: string;
                                ownerId?: string;
                                trackingEntries?: {
                                    tables?: string[];
                                }[];
                                warnings?: import("../../../packages/driver/src/types").AlertWarning[];
                                description?: string | null;
                                lastError?: string | null;
                            }) | null;
                            422: {
                                type: 'validation';
                                on: string;
                                summary?: string;
                                message?: string;
                                found?: unknown;
                                property?: string;
                                expected?: string;
                            };
                        };
                    };
                };
            };
        } & {
            alerts: {
                ":alertId": {
                    access: {
                        get: {
                            body: unknown;
                            params: {
                                alertId: string;
                            };
                            query: unknown;
                            headers: unknown;
                            response: {
                                200: {
                                    warnings: import("../../../packages/driver/src/types").AlertWarning[];
                                };
                                422: {
                                    type: 'validation';
                                    on: string;
                                    summary?: string;
                                    message?: string;
                                    found?: unknown;
                                    property?: string;
                                    expected?: string;
                                };
                            };
                        };
                    };
                };
            };
        } & {
            alerts: {
                ":alertId": {
                    delete: {
                        body: unknown;
                        params: {
                            alertId: string;
                        };
                        query: unknown;
                        headers: unknown;
                        response: {
                            200: {
                                ok: boolean;
                            };
                            422: {
                                type: 'validation';
                                on: string;
                                summary?: string;
                                message?: string;
                                found?: unknown;
                                property?: string;
                                expected?: string;
                            };
                        };
                    };
                };
            };
        } & {
            alerts: {
                ":alertId": {
                    pause: {
                        post: {
                            body: unknown;
                            params: {
                                alertId: string;
                            };
                            query: unknown;
                            headers: unknown;
                            response: {
                                200: (Record<string, unknown> & {
                                    _id: string;
                                    ownerId?: string;
                                    trackingEntries?: {
                                        tables?: string[];
                                    }[];
                                    warnings?: import("../../../packages/driver/src/types").AlertWarning[];
                                    description?: string | null;
                                    lastError?: string | null;
                                }) | null;
                                422: {
                                    type: 'validation';
                                    on: string;
                                    summary?: string;
                                    message?: string;
                                    found?: unknown;
                                    property?: string;
                                    expected?: string;
                                };
                            };
                        };
                    };
                };
            };
        } & {
            alerts: {
                ":alertId": {
                    resume: {
                        post: {
                            body: unknown;
                            params: {
                                alertId: string;
                            };
                            query: unknown;
                            headers: unknown;
                            response: {
                                200: (Record<string, unknown> & {
                                    _id: string;
                                    ownerId?: string;
                                    trackingEntries?: {
                                        tables?: string[];
                                    }[];
                                    warnings?: import("../../../packages/driver/src/types").AlertWarning[];
                                    description?: string | null;
                                    lastError?: string | null;
                                }) | null;
                                422: {
                                    type: 'validation';
                                    on: string;
                                    summary?: string;
                                    message?: string;
                                    found?: unknown;
                                    property?: string;
                                    expected?: string;
                                };
                            };
                        };
                    };
                };
            };
        };
    };
} & {
    api: {
        ":baseId": {
            appearance: {};
        } & {
            appearance: {
                get: {
                    body: unknown;
                    params: {};
                    query: unknown;
                    headers: unknown;
                    response: {
                        200: {
                            accent: string;
                            colorScheme: string;
                            linkPatterns: {
                                [k: string]: unknown;
                                url: string;
                                mask: string;
                                label?: string;
                            }[];
                            logoDark: ({
                                _id: string;
                                url: string;
                            } | {
                                _id: string;
                                url: null;
                            })[];
                            logoLight: ({
                                _id: string;
                                url: string;
                            } | {
                                _id: string;
                                url: null;
                            })[];
                            logomarkDark: ({
                                _id: string;
                                url: string;
                            } | {
                                _id: string;
                                url: null;
                            })[];
                            logomarkLight: ({
                                _id: string;
                                url: string;
                            } | {
                                _id: string;
                                url: null;
                            })[];
                            uploadTargets: {
                                columns: {
                                    readonly logoDark: '00000000-0000-7000-8000-00000000000c';
                                    readonly logoLight: '00000000-0000-7000-8000-00000000000d';
                                    readonly logomarkDark: '00000000-0000-7000-8000-00000000000e';
                                    readonly logomarkLight: '00000000-0000-7000-8000-00000000000f';
                                };
                                recordId: string;
                            };
                        };
                    };
                };
            };
        };
    };
} & {
    api: {
        ":baseId": {
            delegations: {};
        } & {
            delegations: {
                post: {
                    body: {
                        delegateId: string;
                        delegatorId?: string | undefined;
                        endsAt: string;
                        key: string;
                        startsAt: string;
                    };
                    params: {};
                    query: unknown;
                    headers: unknown;
                    response: {
                        200: {
                            _id: string;
                        };
                        422: {
                            type: 'validation';
                            on: string;
                            summary?: string;
                            message?: string;
                            found?: unknown;
                            property?: string;
                            expected?: string;
                        };
                    };
                };
            };
        };
    };
} & {
    api: {
        ":baseId": {
            diagnostics: {};
        } & {
            diagnostics: {
                export: {
                    get: {
                        body: unknown;
                        params: {};
                        query: unknown;
                        headers: unknown;
                        response: {
                            200: Uint8Array<ArrayBuffer>;
                        };
                    };
                };
            };
        } & {
            diagnostics: {
                "loki-export": {
                    get: {
                        body: unknown;
                        params: {};
                        query: {
                            hours?: string | undefined;
                        };
                        headers: unknown;
                        response: {
                            200: Uint8Array<ArrayBufferLike> | {
                                error: string;
                            };
                            422: {
                                type: 'validation';
                                on: string;
                                summary?: string;
                                message?: string;
                                found?: unknown;
                                property?: string;
                                expected?: string;
                            };
                        };
                    };
                };
            };
        };
    };
} & {
    api: {
        ":baseId": {
            email: {};
        } & {
            email: {
                providers: {
                    test: {
                        post: {
                            body: {
                                config?: Record<string, unknown> | undefined;
                                credential?: string | undefined;
                                fromEmail?: string | undefined;
                                fromName?: string | undefined;
                                providerType?: string | undefined;
                                replyTo?: string | undefined;
                                slug: string;
                                to: string;
                            };
                            params: {};
                            query: unknown;
                            headers: unknown;
                            response: {
                                200: {
                                    message: string;
                                };
                                400: {
                                    readonly message: string;
                                };
                                422: {
                                    type: 'validation';
                                    on: string;
                                    summary?: string;
                                    message?: string;
                                    found?: unknown;
                                    property?: string;
                                    expected?: string;
                                };
                            };
                        };
                    };
                };
            };
        } & {
            email: {
                messages: {
                    get: {
                        body: unknown;
                        params: {};
                        query: unknown;
                        headers: unknown;
                        response: {
                            200: {
                                body: string;
                                displayName: string;
                                id: import("../../../packages/driver/src/features/email/index").EmailMessageId;
                                subject: string;
                                trigger: string;
                                variables: readonly import("../../../packages/driver/src/features/email/index").EmailVariable[];
                            }[];
                        };
                    };
                };
            };
        } & {
            email: {
                messages: {
                    ":messageId": {
                        put: {
                            body: {
                                body: string;
                                subject: string;
                            };
                            params: {
                                messageId: string;
                            };
                            query: unknown;
                            headers: unknown;
                            response: {
                                200: {
                                    body: string;
                                    id: import("../../../packages/driver/src/features/email/index").EmailMessageId;
                                    subject: string;
                                };
                                400: {
                                    readonly message: `Unknown message: ${string}`;
                                } | {
                                    readonly available: string[];
                                    readonly message: string;
                                    readonly undeclared: string[];
                                };
                                422: {
                                    type: 'validation';
                                    on: string;
                                    summary?: string;
                                    message?: string;
                                    found?: unknown;
                                    property?: string;
                                    expected?: string;
                                };
                            };
                        };
                    };
                };
            };
        };
    };
} & {
    api: {
        ":baseId": {
            flows: {};
        } & {
            flows: {
                post: {
                    body: {
                        description: string | null;
                        isActive: boolean;
                        name: string;
                        nodes: ({
                            payload: {
                                attachments?: {
                                    cid: string;
                                    content: string;
                                    contentType?: string | undefined;
                                    filename?: string | undefined;
                                }[] | undefined;
                                bcc?: string[] | undefined;
                                body: string;
                                cc?: string[] | undefined;
                                fromName?: string | undefined;
                                providerSlug?: string | undefined;
                                replyTo?: string | undefined;
                                subject: string;
                                text?: string | undefined;
                                to: string;
                            };
                            type: "sendEmail";
                            id: string;
                            nextNodeId: string | null;
                        } | {
                            payload: {
                                body: string;
                                to: string;
                            };
                            type: "sendSms";
                            id: string;
                            nextNodeId: string | null;
                        } | {
                            payload: {
                                duration: number;
                            };
                            type: "wait";
                            id: string;
                            nextNodeId: string | null;
                        } | {
                            payload: {
                                body?: string | undefined;
                                headers?: Record<string, string> | undefined;
                                method: "DELETE" | "GET" | "PATCH" | "POST" | "PUT";
                                url: string;
                            };
                            type: "http";
                            id: string;
                            nextNodeId: string | null;
                        } | {
                            payload: {
                                falseBranch: string | null;
                                logic: string;
                                trueBranch: string | null;
                            };
                            type: "condition";
                            id: string;
                            nextNodeId: string | null;
                        } | {
                            payload: {
                                maxTransitions: number;
                                nodeId: string;
                            };
                            type: "bridge";
                            id: string;
                            nextNodeId: string | null;
                        } | {
                            payload: {
                                variables: {
                                    value: string;
                                    variableName: string;
                                }[];
                            };
                            type: "setVariable";
                            id: string;
                            nextNodeId: string | null;
                        } | {
                            payload: {
                                data: string;
                                repeatBranch: string;
                            };
                            type: "repeater";
                            id: string;
                            nextNodeId: string | null;
                        } | {
                            payload: {
                                outputSchema?: {
                                    properties: Record<string, unknown>;
                                } | undefined;
                                parameters?: Record<string, string> | undefined;
                                query: string;
                            };
                            type: "wql";
                            id: string;
                            nextNodeId: string | null;
                        } | {
                            payload: {
                                assignedTo?: string | undefined;
                                description: string;
                                name: string;
                                schema: any;
                            };
                            type: "interaction";
                            id: string;
                            nextNodeId: string | null;
                        })[];
                        startNodeId: string | null;
                        stateSchema?: {
                            defaultValue?: unknown;
                            id: string;
                            name: string;
                            type: "array" | "boolean" | "number" | "object" | "string";
                        }[] | undefined;
                        trigger: {
                            metadata: {
                                on: "DELETE" | "INSERT" | "UPDATE";
                                tableId: string;
                            };
                            type: "table";
                        } | {
                            metadata: {
                                cron: string;
                                end: string | null;
                                start: string | null;
                            };
                            type: "schedule";
                        } | {
                            metadata: {
                                headers: Record<string, string>;
                                parameters?: Record<string, unknown> | undefined;
                                withCredentials: boolean;
                            };
                            type: "webhook";
                        } | {
                            metadata: {
                                type?: "download" | "upload" | null | undefined;
                            };
                            type: "storageEvent";
                        };
                    };
                    params: {};
                    query: unknown;
                    headers: unknown;
                    response: {
                        200: {
                            _id: string;
                            name: string;
                            description: (string | null);
                            isActive: boolean;
                            nodes: {
                                id: string;
                                type: string;
                                payload?: {
                                    [k: string]: unknown;
                                };
                                nextNodeId?: (string | null);
                                [k: string]: unknown;
                            }[];
                            trigger: {
                                type: ("table" | "schedule" | "webhook" | "storageEvent");
                                metadata: {
                                    [k: string]: unknown;
                                };
                                [k: string]: unknown;
                            };
                            startNodeId: (string | null);
                            stateSchema: ({
                                id: string;
                                name: string;
                                type: ("string" | "number" | "array" | "object" | "boolean");
                                defaultValue?: unknown;
                                [k: string]: unknown;
                            }[] | null);
                            lock: boolean;
                            createdAt: string;
                            updatedAt: string;
                            createdBy: (string | null);
                            updatedBy: (string | null);
                        } & Record<any, unknown>;
                        422: {
                            type: 'validation';
                            on: string;
                            summary?: string;
                            message?: string;
                            found?: unknown;
                            property?: string;
                            expected?: string;
                        };
                    };
                };
            };
        } & {
            flows: {
                ":id": {
                    get: {
                        body: unknown;
                        params: {
                            id: string;
                        };
                        query: unknown;
                        headers: unknown;
                        response: {
                            200: {
                                _id: string;
                                name: string;
                                description: (string | null);
                                isActive: boolean;
                                nodes: {
                                    id: string;
                                    type: string;
                                    payload?: {
                                        [k: string]: unknown;
                                    };
                                    nextNodeId?: (string | null);
                                    [k: string]: unknown;
                                }[];
                                trigger: {
                                    type: ("table" | "schedule" | "webhook" | "storageEvent");
                                    metadata: {
                                        [k: string]: unknown;
                                    };
                                    [k: string]: unknown;
                                };
                                startNodeId: (string | null);
                                stateSchema: ({
                                    id: string;
                                    name: string;
                                    type: ("string" | "number" | "array" | "object" | "boolean");
                                    defaultValue?: unknown;
                                    [k: string]: unknown;
                                }[] | null);
                                lock: boolean;
                                createdAt: string;
                                updatedAt: string;
                                createdBy: (string | null);
                                updatedBy: (string | null);
                            } & Record<any, unknown>;
                            422: {
                                type: 'validation';
                                on: string;
                                summary?: string;
                                message?: string;
                                found?: unknown;
                                property?: string;
                                expected?: string;
                            };
                        };
                    };
                };
            };
        } & {
            flows: {
                ":id": {
                    delete: {
                        body: unknown;
                        params: {
                            id: string;
                        };
                        query: unknown;
                        headers: unknown;
                        response: {
                            200: {
                                _id: string;
                                name: string;
                                description: (string | null);
                                isActive: boolean;
                                nodes: {
                                    id: string;
                                    type: string;
                                    payload?: {
                                        [k: string]: unknown;
                                    };
                                    nextNodeId?: (string | null);
                                    [k: string]: unknown;
                                }[];
                                trigger: {
                                    type: ("table" | "schedule" | "webhook" | "storageEvent");
                                    metadata: {
                                        [k: string]: unknown;
                                    };
                                    [k: string]: unknown;
                                };
                                startNodeId: (string | null);
                                stateSchema: ({
                                    id: string;
                                    name: string;
                                    type: ("string" | "number" | "array" | "object" | "boolean");
                                    defaultValue?: unknown;
                                    [k: string]: unknown;
                                }[] | null);
                                lock: boolean;
                                createdAt: string;
                                updatedAt: string;
                                createdBy: (string | null);
                                updatedBy: (string | null);
                            } & Record<any, unknown>;
                            404: {
                                readonly error: "Flow not found";
                            };
                            422: {
                                type: 'validation';
                                on: string;
                                summary?: string;
                                message?: string;
                                found?: unknown;
                                property?: string;
                                expected?: string;
                            };
                        };
                    };
                };
            };
        } & {
            flows: {
                ":id": {
                    put: {
                        body: {
                            description?: string | null | undefined;
                            isActive?: boolean | undefined;
                            name?: string | undefined;
                            nodes?: ({
                                payload: {
                                    attachments?: {
                                        cid: string;
                                        content: string;
                                        contentType?: string | undefined;
                                        filename?: string | undefined;
                                    }[] | undefined;
                                    bcc?: string[] | undefined;
                                    body: string;
                                    cc?: string[] | undefined;
                                    fromName?: string | undefined;
                                    providerSlug?: string | undefined;
                                    replyTo?: string | undefined;
                                    subject: string;
                                    text?: string | undefined;
                                    to: string;
                                };
                                type: "sendEmail";
                                id: string;
                                nextNodeId: string | null;
                            } | {
                                payload: {
                                    body: string;
                                    to: string;
                                };
                                type: "sendSms";
                                id: string;
                                nextNodeId: string | null;
                            } | {
                                payload: {
                                    duration: number;
                                };
                                type: "wait";
                                id: string;
                                nextNodeId: string | null;
                            } | {
                                payload: {
                                    body?: string | undefined;
                                    headers?: Record<string, string> | undefined;
                                    method: "DELETE" | "GET" | "PATCH" | "POST" | "PUT";
                                    url: string;
                                };
                                type: "http";
                                id: string;
                                nextNodeId: string | null;
                            } | {
                                payload: {
                                    falseBranch: string | null;
                                    logic: string;
                                    trueBranch: string | null;
                                };
                                type: "condition";
                                id: string;
                                nextNodeId: string | null;
                            } | {
                                payload: {
                                    maxTransitions: number;
                                    nodeId: string;
                                };
                                type: "bridge";
                                id: string;
                                nextNodeId: string | null;
                            } | {
                                payload: {
                                    variables: {
                                        value: string;
                                        variableName: string;
                                    }[];
                                };
                                type: "setVariable";
                                id: string;
                                nextNodeId: string | null;
                            } | {
                                payload: {
                                    data: string;
                                    repeatBranch: string;
                                };
                                type: "repeater";
                                id: string;
                                nextNodeId: string | null;
                            } | {
                                payload: {
                                    outputSchema?: {
                                        properties: Record<string, unknown>;
                                    } | undefined;
                                    parameters?: Record<string, string> | undefined;
                                    query: string;
                                };
                                type: "wql";
                                id: string;
                                nextNodeId: string | null;
                            } | {
                                payload: {
                                    assignedTo?: string | undefined;
                                    description: string;
                                    name: string;
                                    schema: any;
                                };
                                type: "interaction";
                                id: string;
                                nextNodeId: string | null;
                            })[] | undefined;
                            startNodeId?: string | null | undefined;
                            stateSchema?: {
                                defaultValue?: unknown;
                                id: string;
                                name: string;
                                type: "array" | "boolean" | "number" | "object" | "string";
                            }[] | undefined;
                            trigger?: {
                                metadata: {
                                    on: "DELETE" | "INSERT" | "UPDATE";
                                    tableId: string;
                                };
                                type: "table";
                            } | {
                                metadata: {
                                    cron: string;
                                    end: string | null;
                                    start: string | null;
                                };
                                type: "schedule";
                            } | {
                                metadata: {
                                    headers: Record<string, string>;
                                    parameters?: Record<string, unknown> | undefined;
                                    withCredentials: boolean;
                                };
                                type: "webhook";
                            } | {
                                metadata: {
                                    type?: "download" | "upload" | null | undefined;
                                };
                                type: "storageEvent";
                            } | undefined;
                        };
                        params: {
                            id: string;
                        };
                        query: unknown;
                        headers: unknown;
                        response: {
                            200: import("../../../packages/driver/src/types").FlowLike;
                            404: {
                                readonly error: "Flow not found";
                            };
                            422: {
                                type: 'validation';
                                on: string;
                                summary?: string;
                                message?: string;
                                found?: unknown;
                                property?: string;
                                expected?: string;
                            };
                        };
                    };
                };
            };
        } & {
            flows: {
                ":id": {
                    webhook: {
                        post: {
                            body: unknown;
                            params: {
                                id: string;
                            };
                            query: unknown;
                            headers: unknown;
                            response: {
                                200: {
                                    success: boolean;
                                    error: string | null;
                                };
                                422: {
                                    type: 'validation';
                                    on: string;
                                    summary?: string;
                                    message?: string;
                                    found?: unknown;
                                    property?: string;
                                    expected?: string;
                                };
                            };
                        };
                    };
                };
            };
        };
    };
} & {
    api: {
        ":baseId": {
            inbox: {};
        } & {
            inbox: {
                interactions: {
                    submit: {
                        post: {
                            body: {
                                interactionId: string;
                                response: Record<string, unknown>;
                            };
                            params: {};
                            query: unknown;
                            headers: unknown;
                            response: {
                                422: {
                                    type: 'validation';
                                    on: string;
                                    summary?: string;
                                    message?: string;
                                    found?: unknown;
                                    property?: string;
                                    expected?: string;
                                };
                            };
                        };
                    };
                };
            };
        };
    };
} & {
    api: {
        ":baseId": {
            "openapi.json": {
                get: {
                    body: unknown;
                    params: {};
                    query: unknown;
                    headers: unknown;
                    response: {
                        200: Record<string, unknown>;
                    };
                };
            };
        } & {
            docs: {
                get: {
                    body: unknown;
                    params: {};
                    query: unknown;
                    headers: unknown;
                    response: {
                        200: Response;
                    };
                };
            };
        };
    };
} & {
    api: {
        ":baseId": {
            q: {};
        } & {
            q: {
                "*": {
                    post: {
                        body: Record<string, any> | undefined;
                        params: {
                            "*": string;
                        } & {};
                        query: unknown;
                        headers: unknown;
                        response: {
                            422: {
                                type: 'validation';
                                on: string;
                                summary?: string;
                                message?: string;
                                found?: unknown;
                                property?: string;
                                expected?: string;
                            };
                        };
                    };
                };
            };
        };
    };
} & {
    api: {
        ":baseId": {
            realtime: {
                stream: {
                    get: {
                        body: unknown;
                        params: {};
                        query: unknown;
                        headers: unknown;
                        response: {
                            200: Response;
                        };
                    };
                };
            };
        } & {
            realtime: {};
        } & {
            realtime: {
                subscribe: {
                    post: {
                        body: {
                            connId: string;
                            keyHash: string;
                            trackingId: string;
                            ttlMs?: number | undefined;
                        };
                        params: {};
                        query: unknown;
                        headers: unknown;
                        response: {
                            200: {
                                message: string;
                                ok?: undefined;
                            } | {
                                ok: boolean;
                                message?: undefined;
                            };
                            422: {
                                type: 'validation';
                                on: string;
                                summary?: string;
                                message?: string;
                                found?: unknown;
                                property?: string;
                                expected?: string;
                            };
                        };
                    };
                };
            };
        } & {
            realtime: {
                unsubscribe: {
                    post: {
                        body: {
                            connId: string;
                            keyHash: string;
                        };
                        params: {};
                        query: unknown;
                        headers: unknown;
                        response: {
                            200: {
                                ok: boolean;
                            };
                            422: {
                                type: 'validation';
                                on: string;
                                summary?: string;
                                message?: string;
                                found?: unknown;
                                property?: string;
                                expected?: string;
                            };
                        };
                    };
                };
            };
        } & {
            realtime: {
                resubscribe: {};
            };
        } & {
            realtime: {
                resubscribe: {
                    post: {
                        body: {
                            connId: string;
                            keyHashes: string[];
                        };
                        params: {};
                        query: unknown;
                        headers: unknown;
                        response: {
                            200: {
                                ok: string[];
                                missing: string[];
                            } | {
                                error: string;
                                retryAfter: number;
                                success: boolean;
                            };
                            422: {
                                type: 'validation';
                                on: string;
                                summary?: string;
                                message?: string;
                                found?: unknown;
                                property?: string;
                                expected?: string;
                            };
                        };
                    };
                };
            };
        } & {
            realtime: {
                inspect: {};
            } & {
                inspect: {
                    get: {
                        body: unknown;
                        params: {};
                        query: {
                            clients?: boolean | undefined;
                            idleHistogram?: boolean | undefined;
                            stats?: boolean | undefined;
                            subs?: boolean | undefined;
                            topTables?: boolean | undefined;
                            ttlHistogram?: boolean | undefined;
                        };
                        headers: unknown;
                        response: {
                            200: {
                                stats?: ReturnType<(baseId: string) => {
                                    connections: number;
                                    subscriptions: number;
                                    pendingTracking: number;
                                    trackingCacheSize: number;
                                    perBase: Record<string, number>;
                                    metrics: import("../../../packages/driver/src/features/realtime/RealtimeHub").RealtimeHubMetrics;
                                }>;
                                topTables?: ReturnType<(baseId: string, limit?: number) => Array<{
                                    table: string;
                                    count: number;
                                }>>;
                                clients?: ReturnType<(baseId: string) => Array<{
                                    connRef: string;
                                    connectedAt: number;
                                    idleMs: number | null;
                                    ip?: string;
                                    userAgent?: string;
                                    userId?: string;
                                    username?: string;
                                    clientId?: string;
                                    subCount: number;
                                    oldestSubAgeMs: number;
                                }>>;
                                subs?: ReturnType<(baseId: string, limit?: number) => Array<{
                                    keyHash: string;
                                    connRef: string;
                                    tables: string[];
                                    operation: string;
                                    ttlMs: number;
                                    createdAt: number;
                                    lastTouchedAt: number;
                                    idleMs: number;
                                    emittedCount: number;
                                    coalescedCount: number;
                                }>>;
                                ttlHistogram?: ReturnType<(baseId: string) => Array<{
                                    bucket: string;
                                    count: number;
                                }>>;
                                idleHistogram?: ReturnType<(baseId: string) => Array<{
                                    bucket: string;
                                    count: number;
                                }>>;
                            };
                            422: {
                                type: 'validation';
                                on: string;
                                summary?: string;
                                message?: string;
                                found?: unknown;
                                property?: string;
                                expected?: string;
                            };
                        };
                    };
                };
            };
        };
    };
} & {
    api: {
        ":baseId": {
            storage: {
                buckets: {};
            } & {
                buckets: {
                    post: {
                        body: {
                            name: string;
                        };
                        params: {};
                        query: unknown;
                        headers: unknown;
                        response: {
                            200: {
                                _id: string;
                                name: string;
                                creationDate: string;
                                versioning: (string | null);
                                type: string;
                                endpoint: (string | null);
                                accessKey: (string | null);
                                secretKey: string;
                                region: (string | null);
                                forcePathStyle: (boolean | null);
                                createdAt: string;
                                updatedAt: string;
                                createdBy: (string | null);
                                updatedBy: (string | null);
                            } & Record<any, unknown>;
                            422: {
                                type: 'validation';
                                on: string;
                                summary?: string;
                                message?: string;
                                found?: unknown;
                                property?: string;
                                expected?: string;
                            };
                        };
                    };
                };
            } & {
                buckets: {
                    connect: {
                        post: {
                            body: {
                                accessKey: string;
                                endpoint: string;
                                forcePathStyle?: boolean | undefined;
                                name: string;
                                region?: string | undefined;
                                secretKey: string;
                            };
                            params: {};
                            query: unknown;
                            headers: unknown;
                            response: {
                                200: {
                                    _id: string;
                                    name: string;
                                    endpoint: (string | null);
                                    accessKey: (string | null);
                                    region: (string | null);
                                    forcePathStyle: (boolean | null);
                                } & Record<any, unknown>;
                                422: {
                                    type: 'validation';
                                    on: string;
                                    summary?: string;
                                    message?: string;
                                    found?: unknown;
                                    property?: string;
                                    expected?: string;
                                };
                            };
                        };
                    };
                };
            } & {
                buckets: {
                    delete: {
                        body: {
                            id: string;
                        };
                        params: {};
                        query: unknown;
                        headers: unknown;
                        response: {
                            200: "OK";
                            422: {
                                type: 'validation';
                                on: string;
                                summary?: string;
                                message?: string;
                                found?: unknown;
                                property?: string;
                                expected?: string;
                            };
                        };
                    };
                };
            };
        } & {
            storage: {
                buckets: {
                    credentials: {};
                };
            } & {
                buckets: {
                    credentials: {
                        get: {
                            body: unknown;
                            params: {};
                            query: unknown;
                            headers: unknown;
                            response: {
                                200: {
                                    _id: string;
                                    accessKey: string;
                                    bucket?: string | null | undefined;
                                    bucketId?: string | null | undefined;
                                    creationDate: string;
                                    expiresAt?: string | null | undefined;
                                    isActive: boolean;
                                    isRoot: boolean;
                                    name: string;
                                    permissions: string[];
                                }[];
                                422: {
                                    type: 'validation';
                                    on: string;
                                    summary?: string;
                                    message?: string;
                                    found?: unknown;
                                    property?: string;
                                    expected?: string;
                                };
                            };
                        };
                    };
                };
            } & {
                buckets: {
                    credentials: {
                        post: {
                            body: {
                                bucketId?: string | null | undefined;
                                expiresAt?: string | null | undefined;
                                name: string;
                                permissions?: ("AbortMultipartUpload" | "CompleteMultipartUpload" | "CreateBucket" | "CreateMultipartUpload" | "DeleteBucket" | "DeleteObject" | "DeleteObjectTagging" | "GetBucketVersioning" | "GetObject" | "GetObjectTagging" | "HeadBucket" | "HeadObject" | "ListBuckets" | "ListMultipartUploads" | "ListObjectVersions" | "ListObjects" | "ListObjectsV2" | "ListParts" | "PutBucketVersioning" | "PutObject" | "PutObjectTagging" | "UploadPart")[] | undefined;
                            };
                            params: {};
                            query: unknown;
                            headers: unknown;
                            response: {
                                200: {
                                    _id: string;
                                    accessKey: string;
                                    bucket?: string | null | undefined;
                                    bucketId?: string | null | undefined;
                                    creationDate: string;
                                    expiresAt?: string | null | undefined;
                                    isActive: boolean;
                                    isRoot: boolean;
                                    name: string;
                                    permissions: string[];
                                    secretKey: string;
                                };
                                422: {
                                    type: 'validation';
                                    on: string;
                                    summary?: string;
                                    message?: string;
                                    found?: unknown;
                                    property?: string;
                                    expected?: string;
                                };
                            };
                        };
                    };
                };
            } & {
                buckets: {
                    credentials: {
                        ":id": {
                            delete: {
                                body: unknown;
                                params: {
                                    id: string;
                                } & {};
                                query: unknown;
                                headers: unknown;
                                response: {
                                    200: "OK";
                                    422: {
                                        type: 'validation';
                                        on: string;
                                        summary?: string;
                                        message?: string;
                                        found?: unknown;
                                        property?: string;
                                        expected?: string;
                                    };
                                };
                            };
                        };
                    };
                };
            } & {
                buckets: {
                    credentials: {
                        root: {
                            rotate: {
                                post: {
                                    body: unknown;
                                    params: {};
                                    query: unknown;
                                    headers: unknown;
                                    response: {
                                        200: {
                                            accessKey: string;
                                            secretKey: string;
                                        };
                                        422: {
                                            type: 'validation';
                                            on: string;
                                            summary?: string;
                                            message?: string;
                                            found?: unknown;
                                            property?: string;
                                            expected?: string;
                                        };
                                    };
                                };
                            };
                        };
                    };
                };
            };
        } & {
            storage: {
                objects: {};
            } & {
                objects: {
                    get: {
                        body: unknown;
                        params: {};
                        query: {
                            bucket: string;
                            prefix?: string | undefined;
                        };
                        headers: unknown;
                        response: {
                            200: {
                                folders: string[];
                                objects: {
                                    bucket: string;
                                    contentType: string;
                                    etag: string;
                                    key: string;
                                    lastModified: string;
                                    presignedUrl?: string | undefined;
                                    size: number;
                                }[];
                            };
                            422: {
                                type: 'validation';
                                on: string;
                                summary?: string;
                                message?: string;
                                found?: unknown;
                                property?: string;
                                expected?: string;
                            };
                        };
                    };
                };
            } & {
                objects: {
                    presigned: {
                        put: {
                            body: {
                                bucket: string;
                                key: string;
                            };
                            params: {};
                            query: unknown;
                            headers: unknown;
                            response: {
                                200: {
                                    url: string;
                                };
                                422: {
                                    type: 'validation';
                                    on: string;
                                    summary?: string;
                                    message?: string;
                                    found?: unknown;
                                    property?: string;
                                    expected?: string;
                                };
                            };
                        };
                    };
                };
            } & {
                objects: {
                    presigned: {
                        get: {
                            body: unknown;
                            params: {};
                            query: {
                                bucket: string;
                                key: string;
                            };
                            headers: unknown;
                            response: {
                                200: {
                                    url: string;
                                };
                                422: {
                                    type: 'validation';
                                    on: string;
                                    summary?: string;
                                    message?: string;
                                    found?: unknown;
                                    property?: string;
                                    expected?: string;
                                };
                            };
                        };
                    };
                };
            } & {
                objects: {
                    delete: {
                        body: {
                            bucket: string;
                            key: string;
                        };
                        params: {};
                        query: unknown;
                        headers: unknown;
                        response: {
                            200: import("@smithy/types").ResponseMetadata;
                            422: {
                                type: 'validation';
                                on: string;
                                summary?: string;
                                message?: string;
                                found?: unknown;
                                property?: string;
                                expected?: string;
                            };
                        };
                    };
                };
            } & {
                objects: {
                    bulk: {
                        delete: {
                            body: {
                                bucket: string;
                                keys?: string[] | undefined;
                                prefixes?: string[] | undefined;
                            };
                            params: {};
                            query: unknown;
                            headers: unknown;
                            response: {
                                200: {
                                    deleted: number;
                                    refused: {
                                        key: string;
                                        reason: string;
                                    }[];
                                };
                                422: {
                                    type: 'validation';
                                    on: string;
                                    summary?: string;
                                    message?: string;
                                    found?: unknown;
                                    property?: string;
                                    expected?: string;
                                };
                            };
                        };
                    };
                };
            } & {
                objects: {
                    multipart: {
                        init: {
                            post: {
                                body: {
                                    bucket: string;
                                    key: string;
                                };
                                params: {};
                                query: unknown;
                                headers: unknown;
                                response: {
                                    200: {
                                        uploadId: string;
                                    };
                                    422: {
                                        type: 'validation';
                                        on: string;
                                        summary?: string;
                                        message?: string;
                                        found?: unknown;
                                        property?: string;
                                        expected?: string;
                                    };
                                };
                            };
                        };
                    };
                };
            } & {
                objects: {
                    multipart: {
                        presigned: {
                            put: {
                                body: {
                                    bucket: string;
                                    key: string;
                                    partNumber: number;
                                    uploadId: string;
                                };
                                params: {};
                                query: unknown;
                                headers: unknown;
                                response: {
                                    200: {
                                        url: string;
                                    };
                                    422: {
                                        type: 'validation';
                                        on: string;
                                        summary?: string;
                                        message?: string;
                                        found?: unknown;
                                        property?: string;
                                        expected?: string;
                                    };
                                };
                            };
                        };
                    };
                };
            } & {
                objects: {
                    multipart: {
                        complete: {
                            post: {
                                body: {
                                    bucket: string;
                                    key: string;
                                    parts: {
                                        etag: string;
                                        partNumber: number;
                                    }[];
                                    uploadId: string;
                                };
                                params: {};
                                query: unknown;
                                headers: unknown;
                                response: {
                                    200: {
                                        success: boolean;
                                    };
                                    422: {
                                        type: 'validation';
                                        on: string;
                                        summary?: string;
                                        message?: string;
                                        found?: unknown;
                                        property?: string;
                                        expected?: string;
                                    };
                                };
                            };
                        };
                    };
                };
            } & {
                objects: {
                    multipart: {
                        abort: {
                            post: {
                                body: {
                                    bucket: string;
                                    key: string;
                                    uploadId: string;
                                };
                                params: {};
                                query: unknown;
                                headers: unknown;
                                response: {
                                    200: {
                                        success: boolean;
                                    };
                                    422: {
                                        type: 'validation';
                                        on: string;
                                        summary?: string;
                                        message?: string;
                                        found?: unknown;
                                        property?: string;
                                        expected?: string;
                                    };
                                };
                            };
                        };
                    };
                };
            };
        } & {
            storage: {
                fileAttachments: {};
            } & {
                fileAttachments: {
                    get: {
                        body: unknown;
                        params: {};
                        query: {
                            columnId: string;
                            recordId?: string | undefined;
                        };
                        headers: unknown;
                        response: {
                            200: import("../../../packages/driver/src/features/storage/index").FileAttachmentsType[];
                            422: {
                                type: 'validation';
                                on: string;
                                summary?: string;
                                message?: string;
                                found?: unknown;
                                property?: string;
                                expected?: string;
                            };
                        };
                    };
                };
            } & {
                fileAttachments: {
                    initUpload: {
                        post: {
                            body: {
                                columnId: string;
                                filename: string;
                                mimeType?: string | undefined;
                                recordId?: string | undefined;
                                size: number;
                            };
                            params: {};
                            query: unknown;
                            headers: unknown;
                            response: {
                                200: {
                                    attachmentId: string;
                                    presignedUrl: string;
                                };
                                422: {
                                    type: 'validation';
                                    on: string;
                                    summary?: string;
                                    message?: string;
                                    found?: unknown;
                                    property?: string;
                                    expected?: string;
                                };
                            };
                        };
                    };
                };
            } & {
                fileAttachments: {
                    completeUpload: {
                        post: {
                            body: {
                                attachmentId: string;
                            };
                            params: {};
                            query: unknown;
                            headers: unknown;
                            response: {
                                422: {
                                    type: 'validation';
                                    on: string;
                                    summary?: string;
                                    message?: string;
                                    found?: unknown;
                                    property?: string;
                                    expected?: string;
                                };
                            };
                        };
                    };
                };
            };
        } & {
            storage: {
                shares: {};
            } & {
                shares: {
                    download: {
                        post: {
                            body: {
                                bucketId: string;
                                expiresAt?: string | null | undefined;
                                maxUses?: number | null | undefined;
                                password?: string | null | undefined;
                                keys: string[] | null;
                                prefixes: string[] | null;
                            };
                            params: {};
                            query: unknown;
                            headers: unknown;
                            response: {
                                200: {
                                    pathName: string;
                                };
                                422: {
                                    type: 'validation';
                                    on: string;
                                    summary?: string;
                                    message?: string;
                                    found?: unknown;
                                    property?: string;
                                    expected?: string;
                                };
                            };
                        };
                    };
                };
            } & {
                shares: {
                    upload: {
                        post: {
                            body: {
                                bucketId: string;
                                expiresAt?: string | null | undefined;
                                maxUses?: number | null | undefined;
                                password?: string | null | undefined;
                                allowedMimeTypes?: string[] | null | undefined;
                                maxFileSize?: number | null | undefined;
                                uploadPrefix: string;
                            };
                            params: {};
                            query: unknown;
                            headers: unknown;
                            response: {
                                200: {
                                    pathName: string;
                                };
                                422: {
                                    type: 'validation';
                                    on: string;
                                    summary?: string;
                                    message?: string;
                                    found?: unknown;
                                    property?: string;
                                    expected?: string;
                                };
                            };
                        };
                    };
                };
            } & {
                shares: {
                    get: {
                        body: unknown;
                        params: {};
                        query: unknown;
                        headers: unknown;
                        response: {
                            200: {
                                _id: string;
                                bucketId: string;
                                createdAt: string;
                                expiresAt: string | null;
                                maxUses: number | null;
                                metadata: {
                                    allowedMimeTypes?: string[] | null | undefined;
                                    keys?: string[] | null | undefined;
                                    maxFileSize?: number | null | undefined;
                                    prefixes?: string[] | null | undefined;
                                    uploadPrefix?: string | null | undefined;
                                } | null;
                                requiresPassword: boolean;
                                revokedAt: string | null;
                                status: "active" | "exhausted" | "expired" | "revoked";
                                type: string;
                                usesCount: number;
                            }[];
                            422: {
                                type: 'validation';
                                on: string;
                                summary?: string;
                                message?: string;
                                found?: unknown;
                                property?: string;
                                expected?: string;
                            };
                        };
                    };
                } & {
                    ":id": {
                        delete: {
                            body: unknown;
                            params: {
                                id: string;
                            } & {};
                            query: unknown;
                            headers: unknown;
                            response: {
                                200: "OK";
                                422: {
                                    type: 'validation';
                                    on: string;
                                    summary?: string;
                                    message?: string;
                                    found?: unknown;
                                    property?: string;
                                    expected?: string;
                                };
                            };
                        };
                    };
                };
            };
        };
    };
} & {
    api: {
        ":baseId": {
            users: {};
        } & {
            users: {
                post: {
                    body: {
                        email: string;
                        familyName?: string | undefined;
                        givenName?: string | undefined;
                        name?: string | undefined;
                        username: string;
                        zoneinfo?: string | undefined;
                    };
                    params: {};
                    query: unknown;
                    headers: unknown;
                    response: {
                        201: {
                            readonly _id: string;
                            readonly email: string;
                        };
                        422: {
                            type: 'validation';
                            on: string;
                            summary?: string;
                            message?: string;
                            found?: unknown;
                            property?: string;
                            expected?: string;
                        };
                    };
                };
            };
        };
    };
} & {
    health: {
        get: {
            body: {};
            params: {};
            query: {};
            headers: {};
            response: {
                200: {
                    status: string;
                };
            };
        };
    };
}, {
    derive: {};
    resolve: {};
    schema: {};
    standaloneSchema: {};
    response: {};
}, {
    derive: {};
    resolve: {};
    schema: {};
    standaloneSchema: {};
    response: {
        200: {
            error: {
                code: string;
                message: string;
                required_aal: number;
                status: number;
            };
        } | {
            error: import("./error").StandardError;
        };
    };
} & {
    derive: {};
    resolve: {};
    schema: {};
    standaloneSchema: {};
    response: {};
} & {
    derive: {};
    resolve: {};
    schema: {};
    standaloneSchema: {};
    response: {};
}>;
export default app;
export type AppType = typeof app;
