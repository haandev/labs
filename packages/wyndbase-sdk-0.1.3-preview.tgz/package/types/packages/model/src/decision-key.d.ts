/**
 * The only formatter/parser pair for a decision key. A second copy anywhere
 * would let a mismatched key silently deny or grant nothing.
 */
import type { ResolvedTable } from './internal-types';
export type RowDecisionOperation = 'read' | 'readHard' | 'insert' | 'update' | 'updateHard' | 'delete' | 'deleteHard';
export type CellDecisionOperation = 'read' | 'insert' | 'update' | 'decrypt' | 'unmask' | 'filter';
export type DecisionTarget = {
    kind: 'row';
    space: string;
    table: string;
    operation: RowDecisionOperation;
} | {
    kind: 'cell';
    space: string;
    table: string;
    column: string;
    operation: CellDecisionOperation;
} | {
    kind: 'fsmTransition';
    space: string;
    table: string;
    column: string;
    from: string;
    to: string;
} | {
    kind: 'fsmState';
    space: string;
    table: string;
    column: string;
    stateId: string;
} | {
    kind: 'link';
    space: string;
    table: string;
    column: string;
};
export declare function formatDecisionKey(target: DecisionTarget): string;
/** Every row operation a decision key can name — the one home for the vocabulary. */
export declare const ROW_DECISION_OPERATIONS: readonly RowDecisionOperation[];
/** Every cell operation a decision key can name. */
export declare const CELL_DECISION_OPERATIONS: readonly CellDecisionOperation[];
/**
 * Exact inverse of `formatDecisionKey`; `null` for anything malformed. A
 * transition key's `from`/`to` must be separated by exactly one dot.
 */
export declare function parseDecisionKey(key: string): DecisionTarget | null;
/**
 * A policy is a named expression with no model target, so its key is authored
 * rather than derived — everything `parseDecisionKey` reads, plus the FSM gates
 * it refuses, belongs to the model.
 */
export declare function isPolicyKey(key: string): boolean;
/**
 * The namespace a flow interaction's audience key lives under. An interaction
 * node names the class of people who may answer it by holding a policy key;
 * these are those keys, kept in one namespace so they are recognisable in the
 * decision matrix beside the hand-written policies.
 */
export declare const INTERACTION_POLICY_PREFIX = "interaction:";
/** `interaction:leaveApproval` — the key an interaction node's name produces. */
export declare function interactionPolicyKey(name: string): string;
/** The name back out of the key; the whole key when it carries no prefix. */
export declare function interactionPolicyName(key: string): string;
export declare function isInteractionPolicyKey(key: string): boolean;
/**
 * The target of a decision, minus the space and table — those come from the
 * resolved node so a caller cannot supply them by hand.
 */
export type DecisionTargetOnNode = {
    kind: 'row';
    operation: RowDecisionOperation;
} | {
    kind: 'cell';
    column: string;
    operation: CellDecisionOperation;
} | {
    kind: 'fsmTransition';
    column: string;
    from: string;
    to: string;
} | {
    kind: 'fsmState';
    column: string;
    stateId: string;
} | {
    kind: 'link';
    column: string;
};
/**
 * Builds a key from a RESOLVED node's LOGICAL names (never `physicalName`
 * or an alias) — a mismatch here doesn't throw, a grant just silently disappears.
 */
export declare function decisionKeyFor(resolved: ResolvedTable, target: DecisionTargetOnNode): string;
