/**
 * The one definition of this repository's identifier convention: a reference
 * resolves against `_id`, then `physicalName`, then `name`. Both the
 * structural lookup (`findByPriority`) and the base lookup (`pickBaseRow`)
 * read it, so the order cannot drift between them.
 */
export type RefTier = 0 | 1 | 2 | 3;
export declare function refTier(item: {
    _id: string;
    physicalName?: string;
    name?: string;
}, ref: string): RefTier;
/** Structural so both a `BaseNode` and a raw `system.getBase` row satisfy it. */
export type BaseRowLike = {
    _id: string;
    name?: string;
    physicalName?: string;
    deletedAt?: unknown;
};
/**
 * A dropped-and-reused name can match two rows. Tier dominates liveness — a
 * soft-deleted `_id` match beats a live `physicalName` match — so identity
 * wins on its own and never depends on the order Postgres returned rows in.
 */
export declare function pickBaseRow<T extends BaseRowLike>(rows: readonly T[], ref: string): T | undefined;
