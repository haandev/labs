/** Double-quote an identifier to preserve case in PostgreSQL */
export declare function quote(name: string): string;
/**
 * Strip PostgreSQL identifier quoting — the inverse of {@link quote}. Resolve
 * against the model only after normalising, or a quoted spelling resolves to nothing.
 */
export declare function unquote(name: string): string;
/** Quote a table name that may contain schema prefix (e.g., "system.models" -> "system"."models") */
export declare function quoteTableName(name: string): string;
/** True when `name` already carries its backtick delimiters. */
export declare function isDelimitedWqlName(name: string): boolean;
/** Returns `name` unchanged if undelimited — a bare name or a value string. */
export declare function undelimitWqlName(name: string): string;
/** Wrap `name` in backticks, doubling any it already contains. */
export declare function delimitWqlName(name: string): string;
/**
 * Splits a possibly-scoped WQL reference into segments (delimiters left on).
 * A dot inside a whole-reference delimiter also separates scopes: `` `a.b` `` == `` `a`.`b` ``.
 */
export declare function splitScopedWqlName(name: string): string[];
/** Use this, NOT {@link undelimitWqlName}, on anything that may be scoped. */
export declare function undelimitScopedWqlName(name: string): string;
