import { z } from 'zod';
/**
 * Convert a JSON Schema object to a Zod type.
 * Delegates to Zod's native `z.fromJSONSchema()` for full JSON Schema support
 * including oneOf, anyOf, allOf, nullable, $ref, and all standard types.
 * Falls back to z.unknown() on any conversion error.
 */
export declare function jsonSchemaToZod(schema: Record<string, unknown>): z.ZodType;
