/**
 * SQL predicates are three-valued: a NULL comparison answers UNKNOWN, not
 * FALSE. This collapses that to two values, denying on UNKNOWN.
 */
export declare function denyOnUnknown(predicate: string): string;
