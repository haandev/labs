import type { ColumnBindContext } from '../types';
/**
 * `key`: a single equi-correlation, decorrelatable into a pre-aggregated CTE.
 * `raw`: an opaque predicate (polymorphic, LATERAL, …), never decorrelatable.
 */
export type LinkCorrelation = {
    kind: 'key';
    targetKeyExpr: string;
    sourceKeyExpr: string;
} | {
    kind: 'raw';
    predicate: string;
};
export interface LinkArrayConfig {
    /** jsonb_agg element expression, e.g. `"_mn_"."wyn_genre_name"` or `to_jsonb("_nqagg_")`. */
    selectExpr: string;
    /** Complete FROM clause incl. alias and any junction JOIN (e.g. `FROM … AS … JOIN …`). */
    fromClause: string;
    correlation: LinkCorrelation;
    /** AND-combined after the correlation: soft-filter, row policy, nested FILTER, discriminator. */
    bodyFilters?: Array<string | null | undefined>;
    /**
     * Set only when this projects off the OUTER base row, so a bulk read may
     * pre-aggregate it. Navigated/NQ-CTE arrays leave it unset and stay correlated.
     */
    bulkEligible?: boolean;
    /**
     * A cell read policy on the aggregated value, carried through so both
     * emitted shapes (correlated subquery and pre-aggregated CTE) honour it.
     */
    wholeArrayGate?: string | null;
}
/**
 * Single chokepoint for every x:M array projection, so the emitted SQL
 * *shape* is decided in one place instead of by each caller.
 */
export declare function buildLinkArray(ctx: Pick<ColumnBindContext, 'links'>, config: LinkArrayConfig): string;
