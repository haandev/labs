import type { ColumnNode, TableNode } from '../types';
export declare const COMMENTS_TARGET_TABLE = "system.comments";
export declare const COMMENTS_LINK_COLUMN_NAME = "_comments";
/**
 * A table opts into comments via `metadata.hasComments`; this synthesizes
 * the x:M pseudo-link it gains — the same shape as the `_originId` slot
 * `hasVersion` synthesizes in `starExpansionSlots`. Never persisted to the
 * model tree; called fresh by every reader from `findColumn` and
 * `starExpansionSlots`, the only two places that need to know this exists.
 */
export declare function syntheticCommentsColumn(table: TableNode): ColumnNode | undefined;
