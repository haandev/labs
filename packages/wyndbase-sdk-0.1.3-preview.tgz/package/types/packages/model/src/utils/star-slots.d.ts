import type { ColumnNode, TableNode } from '../types';
import { type SystemColumnDescriptor } from '../types/reserved-names';
/**
 * One output name `{ * }` produces. A slot with no `column` has no node in the
 * model: the base creates the column and the name is its own physical name.
 * `system` is present on the audit and version slots and carries the nullability
 * their declared type comes from.
 */
export type StarExpansionSlot = {
    name: string;
    column?: undefined;
    system?: SystemColumnDescriptor;
} | {
    name: string;
    column: ColumnNode;
    system?: undefined;
};
/**
 * The output names `{ * }` emits, in order. One walk for SQL generation, for
 * the inferred row type and for SORT occupancy, so none of the three can
 * disagree about what is present.
 *
 * A synthetic table is a query result, not a stored table: it has no identity
 * column of its own unless it carries one, and none of the system columns.
 */
export declare function starExpansionSlots(table: TableNode): Generator<StarExpansionSlot>;
