import type { ColumnNode } from '../types';
/** The JSONB column every dynamic value on a table is stored in. */
export declare const DYNAMIC_DATA_COLUMN = "dynamicData";
/**
 * Closed on purpose: `shape` is interpolated straight after `::` in the SQL
 * this module builds, so a `string` type here would be a silent injection point.
 */
export type DynamicColumnShape = 'boolean' | 'date' | 'float8' | 'integer' | 'json' | 'jsonb' | 'numeric' | 'text' | 'timestamp' | 'timestamptz' | 'uuid';
/**
 * `ownerRef` is passed through verbatim, NOT quoted here: callers hand in an
 * already-quoted alias, `''` for unqualified, or a placeholder substituted later.
 */
export declare function dynamicValueRef(ownerRef: string, key: string, shape: DynamicColumnShape): string;
/**
 * `key` is escaped by doubling single quotes only: with PostgreSQL's default
 * `standard_conforming_strings = on`, `\` is literal inside a `'...'` literal.
 */
export declare function dynamicValueRefFrom(blob: string, key: string, shape: DynamicColumnShape): string;
/**
 * The pg type a dynamic column's stored value is read and written as. The read
 * path, the write path and every reference builder ask here, so a column type
 * cannot be stored under one shape and read back under another.
 */
export declare function dynamicColumnShapeOf(col: ColumnNode): DynamicColumnShape;
