/**
 * Node Identity Utilities
 *
 * Centralized helpers for resolving node identifiers.
 * Handles stripped models where physicalName may be absent.
 */
/** Returns the SQL identifier for a node: physicalName if present, otherwise name. */
export declare function nodeIdentifier(node: {
    physicalName?: string;
    name: string;
}): string;
/** Build a fully-qualified SQL name: "schema"."table" */
export declare function qualifiedName(space: {
    physicalName?: string;
    name: string;
}, table: {
    physicalName?: string;
    name: string;
}): string;
