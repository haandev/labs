/**
 * JSON Schema path walking helpers for JSONB native field access.
 *
 * Used by both the schema-inference side (type inference for
 * `jsonbCol.field` references) and the SQL generator (cast selection for
 * `->>` extraction). Kept as pure functions in `@wyndb/models/utils` so
 * that both `@wyndb/wql` and `@wyndb/wql-sql` can share one canonical
 * implementation without either package taking a new dependency.
 *
 * Faz 1 handles single-level object-key lookup. Faz 2 will extend this to
 * deep object paths; Faz 3 adds array-index steps.
 */
import { z } from 'zod';
/**
 * Return the sub-schema at `key` inside an object schema, or `undefined`
 * if the parent schema is missing, is not an object, lacks `properties`,
 * or does not define that key.
 *
 *  - `{type: 'object', properties: {a: {type: 'string'}}}` + key `'a'`
 *     → `{type: 'string'}`
 *  - `{type: 'string'}` + any key → `undefined` (parent is not an object)
 *  - `{type: 'object'}` + any key → `undefined` (no `properties`)
 *  - Missing/undefined parent → `undefined`
 *
 * This helper is deliberately conservative: it only resolves keys that
 * the schema explicitly declares. Users relying on
 * `additionalProperties: true` fall through to `undefined` here and are
 * handled by the caller as "schema not known" (graceful degrade to raw
 * JSONB in SQL, `z.unknown()` in type inference).
 */
export declare function walkObjectField(schema: Record<string, unknown> | undefined, key: string): Record<string, unknown> | undefined;
/**
 * Convert a JSON Schema sub-schema to a Zod type, applying nullability
 * based on whether the parent listed this key in its `required` array.
 *
 * Returns `z.unknown()` if the sub-schema is missing (`undefined`), so
 * callers can blanket-pass an unresolved path without branching on
 * presence.
 */
export declare function fieldSchemaToZod(subSchema: Record<string, unknown> | undefined, isRequired: boolean): z.ZodType;
/**
 * True if `parent.required` (JSON Schema required array) lists `key`.
 * Defensive: returns `false` when `required` is missing or not an array.
 */
export declare function isJsonSchemaFieldRequired(parent: Record<string, unknown> | undefined, key: string): boolean;
/**
 * One step in a JSON Schema path. Either an object field access by name
 * (`.name`) or an array element access (`[n]` — the concrete index value
 * is irrelevant for type inference, since JSON Schema `items` is the
 * same shape for every index in a homogeneous array).
 *
 * Faz 3 introduces array-index steps. `'tuple'` variants of JSON Schema
 * `items: [T1, T2, T3]` are NOT modeled here — the walker treats every
 * array as homogeneous and falls through to `undefined` for tuple
 * shapes.
 */
export type JsonSchemaPathStep = {
    readonly kind: 'field';
    readonly name: string;
} | {
    readonly kind: 'index';
};
/**
 * Result of walking a JSON Schema along an ordered path.
 *
 * - `schema`: the leaf sub-schema, or `undefined` if any step could not
 *   be resolved (missing parent, shape mismatch, key not in
 *   `properties`, `items` not present on an array step, etc).
 * - `allRequired`: `true` only when every **field** step along the path
 *   was listed in its parent's `required` array. Index steps never
 *   contribute to nullability here because JSON Schema has no per-index
 *   required declaration — out-of-bounds access is a runtime concern.
 */
export interface JsonSchemaPathResult {
    schema: Record<string, unknown> | undefined;
    allRequired: boolean;
}
/**
 * Walk a JSON Schema along an ordered sequence of **field** keys. This
 * is the Faz 1/2 entry point; it is preserved as a thin wrapper over
 * `walkJsonSchemaPath` so pre-existing callers keep the simple string
 * API and do not need to construct `JsonSchemaPathStep` objects.
 */
export declare function walkObjectFieldPath(schema: Record<string, unknown> | undefined, path: readonly string[]): JsonSchemaPathResult;
/**
 * Walk a JSON Schema along a heterogeneous path of field and index steps.
 *
 *  - Field step (`.name`): parent must be an `object` with `properties`
 *    and the given key defined.
 *  - Index step (`[n]`): parent must be an `array` with a single `items`
 *    sub-schema (homogeneous). Tuple-typed arrays (`items: [...]`) abort
 *    the walk since downstream SQL generation has no way to resolve an
 *    arbitrary-index access against a finite tuple.
 *
 * Returns `{schema: undefined}` at any step that fails so callers can
 * degrade to `z.unknown()` / raw JSONB SQL without branching.
 */
export declare function walkJsonSchemaPath(schema: Record<string, unknown> | undefined, steps: readonly JsonSchemaPathStep[]): JsonSchemaPathResult;
/**
 * Convert the result of `walkObjectFieldPath` into a Zod type with the
 * right nullability wrapper. `undefined` leaf schemas collapse to
 * `z.unknown()`; otherwise the leaf is converted via `jsonSchemaToZod`
 * and wrapped as nullable unless every step was required.
 */
export declare function fieldPathSchemaToZod(result: JsonSchemaPathResult): z.ZodType;
