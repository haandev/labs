export type ArrayProjectionAggregate = 'array_agg' | 'jsonb_agg';
/**
 * Applies `elementExpr` to `colRef`, element-wise when the column is an array.
 * Use `jsonb_agg` for JSON results — `array_agg` over `jsonb` yields `jsonb[]`, undecodable by the driver.
 */
export declare function projectMaybeArray(isArray: boolean, colRef: string, elementExpr: (ref: string) => string, aggregate?: ArrayProjectionAggregate): string;
