export interface JsonbAggSubqueryConfig {
    /** The full SELECT expression inside jsonb_agg(), e.g. `"_ch"."label"` */
    selectExpr: string;
    /** Complete FROM clause including alias and optional JOINs */
    fromClause: string;
    /** WHERE condition (without the WHERE keyword) */
    whereCondition: string;
    /** Extra predicates AND-combined onto `whereCondition` (falsy entries dropped). */
    andConditions?: Array<string | null | undefined>;
    /**
     * Cell read policy on the aggregated value. Gates the whole array, not each
     * row — a per-row `CASE` would leak the row count through array length.
     */
    wholeArrayGate?: string | null;
}
export declare function buildWholeArrayGate(gate: string): string;
export declare function buildJsonbAggSubquery(config: JsonbAggSubqueryConfig): string;
