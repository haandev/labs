import { z } from 'zod';
/**
 * Zod for the model nodes a client may create, and the creation variants the
 * forms validate against. Here rather than in the driver because the browser
 * validates the same shapes the server does, and here rather than in
 * `@wyndb/shared` because these read `ColumnSchema` and `NQExposure` — and
 * `@wyndb/models` already depends on shared, so the reverse edge would cycle.
 */
/**
 * The key the model write routes hang advisory rule diagnostics on, beside the
 * node they wrote, and only when there is something to say.
 *
 * Here for the same reason the schemas above are: the browser and the server
 * have to agree on it, and they are the only two parties that ever touch it.
 * Written out in both places it was two spellings of one wire contract tied
 * together by nothing — which is how a field added on one side and read on the
 * other stops arriving with nothing going red.
 */
export declare const MODEL_WRITE_DIAGNOSTICS_KEY = "_diagnostics";
export declare const ModelSchema: z.ZodObject<{
    _id: z.ZodString;
    description: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    displayName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    folder: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    isSystem: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    metadata: z.ZodOptional<z.ZodNullable<z.ZodAny>>;
    name: z.ZodString;
    parent: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    physicalName: z.ZodString;
    type: z.ZodEnum<{
        base: "base";
        column: "column";
        namedQuery: "namedQuery";
        space: "space";
        table: "table";
    }>;
}, z.core.$strip>;
export type ModelSchema = z.infer<typeof ModelSchema>;
export declare const TableSchema: z.ZodObject<{
    _id: z.ZodString;
    description: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    displayName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    folder: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    isSystem: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    name: z.ZodString;
    physicalName: z.ZodString;
    metadata: z.ZodOptional<z.ZodNullable<z.ZodObject<{
        displayFieldId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        hasComments: z.ZodOptional<z.ZodBoolean>;
        hasVersion: z.ZodOptional<z.ZodBoolean>;
        transient: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strip>>>;
    parent: z.ZodString;
    type: z.ZodLiteral<"table">;
}, z.core.$strip>;
export type TableSchema = z.infer<typeof TableSchema>;
export declare const isTableSchema: (schema: any) => schema is TableSchema;
export declare const TableCreationSchema: z.ZodObject<{
    description: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    displayName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    folder: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    isSystem: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    name: z.ZodString;
    metadata: z.ZodOptional<z.ZodNullable<z.ZodObject<{
        displayFieldId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        hasComments: z.ZodOptional<z.ZodBoolean>;
        hasVersion: z.ZodOptional<z.ZodBoolean>;
        transient: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strip>>>;
    _id: z.ZodOptional<z.ZodString>;
    creationColumns: z.ZodOptional<z.ZodArray<z.ZodObject<{
        _id: z.ZodOptional<z.ZodString>;
        description: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        displayName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        folder: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        isDynamic: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        isSystem: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        name: z.ZodString;
        ordinal: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        parent: z.ZodString;
        physicalName: z.ZodOptional<z.ZodString>;
        metadata: z.ZodLazy<z.ZodDiscriminatedUnion<[z.ZodObject<{
            allowEnd: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                both: "both";
                "exclusive-only": "exclusive-only";
                "inclusive-only": "inclusive-only";
            }>>>;
            allowedCountries: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodEnum<{
                [x: string]: string;
            }>>>>;
            allowedMimeTypes: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodString>>>;
            allowedTables: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodString>>>;
            allowFilter: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            allowOpenEnd: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            allowOpenStart: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            allowSearch: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            allowStart: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                both: "both";
                "exclusive-only": "exclusive-only";
                "inclusive-only": "inclusive-only";
            }>>>;
            allowsAnyTable: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            bucket: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            canHaveMultiple: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            dataMask: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                char: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                email: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
                enabled: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
                leading: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
                separators: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
                trailing: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
            }, z.core.$strip>>>;
            defaultValue: z.ZodOptional<z.ZodNullable<z.ZodAny>>;
            encrypt: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            formula: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            hidden: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            immutable: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            inputMask: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            isArray: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            isDynamic: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            isMultiSelect: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                no: "no";
                yes: "yes";
            }>>>;
            isNqTarget: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            isPrimaryKey: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            isUnique: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            listName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            maxFileSizeBytes: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
            mirrorColumns: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodObject<{
                _id: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                canHaveMultiple: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
                name: z.ZodString;
                physicalName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                table: z.ZodString;
            }, z.core.$strip>>>>;
            notAllowedCountries: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodEnum<{
                [x: string]: string;
            }>>>>;
            notNull: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            onDelete: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                cascade: "cascade";
                keep: "keep";
                restrict: "restrict";
                setNull: "setNull";
            }>>>;
            optimizeSort: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            precision: z.ZodOptional<z.ZodNullable<z.ZodInt>>;
            rules: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodObject<{
                args: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodAny>>>;
                name: z.ZodString;
            }, z.core.$strip>>>>;
            scale: z.ZodOptional<z.ZodNullable<z.ZodInt>>;
            schema: z.ZodOptional<z.ZodNullable<z.ZodRecord<z.ZodString, z.ZodUnknown>>>;
            sensitive: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                always: "always";
                "explicitly-open": "explicitly-open";
            }>>>;
            summaryTypes: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodString>>>;
            targetTables: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodObject<{
                junctionSourceColumn: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                junctionTable: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                junctionTargetColumn: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                table: z.ZodString;
                targetColumn: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strip>>>>;
            type: z.ZodString;
            versioning: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        }, z.core.$strip>, ...z.ZodObject<{
            allowEnd: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                both: "both";
                "exclusive-only": "exclusive-only";
                "inclusive-only": "inclusive-only";
            }>>>;
            allowedCountries: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodEnum<{
                [x: string]: string;
            }>>>>;
            allowedMimeTypes: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodString>>>;
            allowedTables: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodString>>>;
            allowFilter: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            allowOpenEnd: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            allowOpenStart: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            allowSearch: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            allowStart: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                both: "both";
                "exclusive-only": "exclusive-only";
                "inclusive-only": "inclusive-only";
            }>>>;
            allowsAnyTable: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            bucket: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            canHaveMultiple: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            dataMask: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                char: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                email: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
                enabled: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
                leading: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
                separators: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
                trailing: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
            }, z.core.$strip>>>;
            defaultValue: z.ZodOptional<z.ZodNullable<z.ZodAny>>;
            encrypt: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            formula: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            hidden: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            immutable: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            inputMask: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            isArray: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            isDynamic: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            isMultiSelect: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                no: "no";
                yes: "yes";
            }>>>;
            isNqTarget: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            isPrimaryKey: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            isUnique: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            listName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            maxFileSizeBytes: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
            mirrorColumns: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodObject<{
                _id: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                canHaveMultiple: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
                name: z.ZodString;
                physicalName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                table: z.ZodString;
            }, z.core.$strip>>>>;
            notAllowedCountries: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodEnum<{
                [x: string]: string;
            }>>>>;
            notNull: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            onDelete: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                cascade: "cascade";
                keep: "keep";
                restrict: "restrict";
                setNull: "setNull";
            }>>>;
            optimizeSort: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            precision: z.ZodOptional<z.ZodNullable<z.ZodInt>>;
            rules: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodObject<{
                args: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodAny>>>;
                name: z.ZodString;
            }, z.core.$strip>>>>;
            scale: z.ZodOptional<z.ZodNullable<z.ZodInt>>;
            schema: z.ZodOptional<z.ZodNullable<z.ZodRecord<z.ZodString, z.ZodUnknown>>>;
            sensitive: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                always: "always";
                "explicitly-open": "explicitly-open";
            }>>>;
            summaryTypes: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodString>>>;
            targetTables: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodObject<{
                junctionSourceColumn: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                junctionTable: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                junctionTargetColumn: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                table: z.ZodString;
                targetColumn: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strip>>>>;
            type: z.ZodString;
            versioning: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        }, z.core.$strip>[]], "type">>;
        type: z.ZodPrefault<z.ZodLiteral<"column">>;
    }, z.core.$strip>>>;
    parent: z.ZodOptional<z.ZodString>;
    physicalName: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
export type TableCreationSchema = z.infer<typeof TableCreationSchema>;
export declare const NamedQuerySchema: z.ZodObject<{
    _id: z.ZodString;
    description: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    displayName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    folder: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    isSystem: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    name: z.ZodString;
    physicalName: z.ZodString;
    metadata: z.ZodObject<{
        elevated: z.ZodOptional<z.ZodBoolean>;
        exposure: z.ZodOptional<z.ZodEnum<{
            public: "public";
            service: "service";
            trusted: "trusted";
        }>>;
        query: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>;
    parent: z.ZodString;
    type: z.ZodLiteral<"namedQuery">;
}, z.core.$strip>;
export type NamedQuerySchema = z.infer<typeof NamedQuerySchema>;
export declare const isNamedQuerySchema: (schema: any) => schema is NamedQuerySchema;
export declare const NamedQueryCreationSchema: z.ZodObject<{
    description: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    displayName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    folder: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    isSystem: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    name: z.ZodString;
    metadata: z.ZodObject<{
        elevated: z.ZodOptional<z.ZodBoolean>;
        exposure: z.ZodOptional<z.ZodEnum<{
            public: "public";
            service: "service";
            trusted: "trusted";
        }>>;
        query: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>;
    _id: z.ZodOptional<z.ZodString>;
    parent: z.ZodOptional<z.ZodString>;
    physicalName: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
export type NamedQueryCreationSchema = z.infer<typeof NamedQueryCreationSchema>;
