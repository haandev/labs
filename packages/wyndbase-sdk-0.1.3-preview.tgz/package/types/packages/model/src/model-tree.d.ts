import type { BaseColumn } from './columns/base-column';
import type { ResolvedColumn, ResolvedNode, ResolvedTable, WynModel } from './internal-types';
import type { ColumnNode } from './types/column';
import type { NamedQueryNode } from './types/named-query';
import type { SpaceNode } from './types/space';
import type { TableNode } from './types/table';
export { DYNAMIC_DATA_COLUMN } from './utils/dynamic-value-ref';
export interface ResolvedNamedQuery {
    space: SpaceNode;
    namedQuery: NamedQueryNode;
}
/**
 * Single pass over `refTier`, keeping the first match at the best tier seen —
 * identical selection to three sequential `.find()` calls, at a third of the
 * cost on large models.
 */
export declare function findByPriority<T extends {
    _id: string;
    physicalName?: string;
    name?: string;
}>(items: T[], search: string): T | undefined;
export declare class WynModelTree {
    readonly raw: WynModel;
    private readonly spaceById;
    private readonly spaceByPhysicalName;
    private readonly spaceByName;
    private readonly tableById;
    private readonly tableByPhysicalName;
    private readonly tableByName;
    private readonly nqById;
    private readonly nqByPhysicalName;
    private readonly nqByName;
    private readonly spaceChildren;
    private _junctions;
    private readonly tableColumns;
    constructor(raw: WynModel);
    /**
     * A non-null id repeated at space, table, named-query (each global), or
     * column-within-one-table scope throws — ids identify a single node, so a
     * collision is a corrupt model, not a naming ambiguity. Names and
     * physicalNames stay first-wins, matching the old linear scan: they only
     * disambiguate resolution, so plenty of legitimate models share them
     * across spaces.
     */
    private buildIndexes;
    /**
     * Side effect: back-fills a missing `col.parent` with the owning table's
     * `_id` so consumers can resolve it without holding a reference.
     */
    private static buildColumnIndex;
    /**
     * `search` must ALREADY be undelimited — stripping again here would
     * peel a name that legally contains backticks twice.
     */
    private findColumn;
    /** Undelimits first, since every index is keyed on the undelimited spelling. */
    resolveSpace(name: string): SpaceNode | undefined;
    /** Table within one space, by _id -> physicalName -> name. */
    private static tableInSpace;
    /** Named query within one space, by _id -> physicalName -> name. */
    private static namedQueryInSpace;
    /** Named query across all spaces, by _id -> physicalName -> name. */
    private namedQueryEntry;
    /** Scoped name resolves space then table; unscoped searches all spaces. */
    resolveTable(name: string, defaultSpace?: string): ResolvedTable | undefined;
    /** Scoped name resolves space then NQ; unscoped searches all spaces. */
    resolveNamedQuery(name: string): ResolvedNamedQuery | undefined;
    resolveColumn(table: TableNode, name: string): ResolvedColumn | undefined;
    findColumnOrLink(table: TableNode, name: string): ColumnNode | undefined;
    resolveDisplayField(table: TableNode): ColumnNode | undefined;
    resolveChoiceTarget(): ResolvedTable | undefined;
    resolveFileTarget(): ResolvedTable | undefined;
    resolveParent(col: ColumnNode): ResolvedTable | undefined;
    /**
     * Resolve any node (space, table, column) by identifier + optional scope,
     * each segment matched _id → physicalName → name; a bare UUID ignores scope.
     */
    resolveNode(identifier: string, scope?: string): ResolvedNode | undefined;
    /** Resolve a single-segment identifier: try space first, then global table. */
    private resolveNodeSingle;
    /** Global table lookup by _id → physicalName → name. */
    private resolveTableEntry;
    /** Resolve a table within a specific space by ref. */
    private resolveNodeInSpaceByRef;
    /** Resolve identifier segments within a resolved space. */
    private resolveNodeInSpace;
    /** Resolve a column within a table, returning ResolvedNode or undefined. */
    private resolveColumnNode;
    private _columnCache;
    private get columnCache();
    /** Instances are ctx-free and reused across queries; `.bind(ctx)` for SQL. */
    getColumnInstance(col: ColumnNode): BaseColumn;
    /**
     * `_originId` on a versioned table, so link FKs keep resolving to the
     * active version after a soft update; `_id` otherwise.
     */
    static resolveIdColumn(tableMetadata?: TableNode['metadata']): '_id' | '_originId';
    /**
     * A junction is not flagged; it is whatever some link column names as its
     * `junctionTable`. Derived once, so every consumer agrees on the set.
     */
    isJunctionTable(table: TableNode): boolean;
    /** A junction column an M:N link names as its source or target end. */
    isJunctionEndpoint(col: ColumnNode): boolean;
    private junctions;
    private collectJunctions;
    /**
     * The junction a multi-value link names. Any other column shape yields
     * undefined, so a stray `junctionTable` key cannot invent a junction.
     */
    static junctionRefOf(col: ColumnNode): string | undefined;
    /**
     * A junction ref is scoped, or a bare name resolved against the link's own
     * space first and the whole model second. Sole resolver; every consumer
     * must agree on which table a link's junction is.
     */
    resolveJunctionRef(ref: string, sourceSpace?: SpaceNode): ResolvedTable | undefined;
    /**
     * True if this column's value lives off-row (link FK, junction, or
     * dynamicData) rather than its own column; corrupt input fails safe.
     */
    static isPseudoLinkColumn(col: ColumnNode): boolean;
    /**
     * True if this column gets its own `ADD COLUMN` — false for formula,
     * pseudo-link, and dynamic columns. Sole owner; driver negates and calls it.
     */
    static hasPhysicalStorage(col: ColumnNode): boolean;
    /** Includes regular and x:1 link FK columns; excludes pseudo links, dynamic, formula. */
    static getPhysicalColumns(table: TableNode): ColumnNode[];
}
