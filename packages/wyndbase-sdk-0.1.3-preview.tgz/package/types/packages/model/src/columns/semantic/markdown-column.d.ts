import { z } from 'zod';
import type { BoundColumnContract, ColumnBindContext, ColumnNode, ContainerKind, DataMask, EncryptInfo, ResolvedTable } from '../../types';
import type { ColumnValidationIssue, ModelValidationEnv } from '../base-column';
import { BaseColumn } from '../base-column';
/**
 * Carries `status` because a bare `Error` is classified 500 by the backend's
 * error handler — a server fault paged for what is the caller's typo.
 */
export declare class UnknownMarkdownFieldError extends Error {
    readonly status = 400;
    constructor(message: string);
}
/**
 * Markdown source together with the files attached to it, in one column.
 *
 * Extends `BaseColumn` rather than `PGTextColumn` because its physical type is
 * a composite, not text — `poly_ref` is the precedent.
 *
 * `attachments` is the authority on membership and is not redundant with the
 * reverse lookup through `file_attachments.columnId`: a file dropped into an
 * unsaved row has no `recordId` yet, so no reverse lookup can find it.
 */
export declare class MarkdownColumn extends BaseColumn {
    static readonly columnType = "markdown";
    static readonly group = "text";
    static readonly pgType: string;
    /** `inputSchema` defaults `attachments`, so a write that bypasses it differs. */
    static enforcesBeyondPgType: boolean;
    /**
     * The inherited `z.string()` would accept a bare string into a composite.
     * Overridden here rather than on `inputSchema` because `defaultValueSchema`
     * reads it too — otherwise the column editor offers a string field for a
     * default that `validateModel` then rejects as `invalid-default-value`.
     */
    static get zodSchema(): z.ZodType;
    static physicalPgType(_col: ColumnNode): string;
    /**
     * QUALIFIED, unlike `poly_ref`'s equivalent: the compiled statement runs on a
     * pooled connection nobody sets a `search_path` for, and a base schema may
     * hold a `markdown` of its own.
     *
     * `attachments` is optional and a set-based write reaches PostgreSQL without
     * `inputSchema` having defaulted it, so absent, empty and non-array all
     * degrade to `{}`. A JSON `null` stores NULL rather than `ROW(NULL, NULL)`,
     * which is a value the column would otherwise hold in place of nothing.
     */
    static writeValueSql: (_col: ColumnNode, paramRef: string) => string;
    /** See `FileColumn.attachmentArrayExpr`. The array is a composite field. */
    static attachmentArrayExpr(physicalName: string): string;
    /** Only the prose is searchable; the attachment ids are not words. */
    static searchTextExpr(colRef: string): string;
    /** `isArray` is omitted as on `FileColumn`: an array of composites has no meaning here. */
    static get metadataSchema(): z.ZodObject<{
        readonly [x: string]: z.core.$ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>;
        allowedMimeTypes: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodString>>>;
        maxFileSizeBytes: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        bucket: z.ZodString;
    }, z.core.$strip>;
    /** Computed over `body`; the same set `LongTextColumn` offers. */
    static get availableSummaryTypes(): readonly ['min', 'max', 'count', 'string_agg', 'array_agg'];
    validateModel(): ColumnValidationIssue[];
    /**
     * `encrypt` survives the base metadata pick, and `disclosure.ts` labels any
     * column carrying it as encrypted — so accepting the flag here would show
     * encryption UX over plaintext. Rejected rather than stripped, so the caller
     * learns the type cannot do it.
     */
    private encryptIssues;
    validateModelAsync(env: ModelValidationEnv): Promise<ColumnValidationIssue[]>;
    /**
     * Ids only, no join: a list view pulling 200 rows must not run 200
     * `file_attachments` subqueries nobody asked for.
     */
    get outputSchema(): z.ZodType;
    resolveTarget(): ResolvedTable | undefined;
    /**
     * Without this, `column-ref-type.ts` infers `unknown` for every dot path and
     * the published schema says nothing about `body_md.body`. The two composite
     * fields answer for themselves; anything else is an attachment column, and
     * the projection aggregates it, hence the array.
     */
    getFieldSchema(targetField: string): z.ZodType | undefined;
    resolveNestedTarget(): ResolvedTable | undefined;
    /** A composite, not a list of them. */
    get container(): ContainerKind;
    /**
     * Same reachability as `encryptInfo`: `dataMask` is read raw off metadata,
     * so an unvalidated caller reaches it, and masking a composite fabricates a
     * shape callers parse.
     */
    get dataMask(): DataMask | undefined;
    /**
     * Not redundant with `validateModel` above: `encrypt` is not stripped by the
     * metadata schema, so a caller that reaches the column without validating
     * would otherwise have the driver encrypt a composite.
     */
    get encryptInfo(): EncryptInfo | undefined;
    bind(ctx: Pick<ColumnBindContext, 'resolution'>): BoundColumnContract;
    get projectedPgType(): string | null;
}
