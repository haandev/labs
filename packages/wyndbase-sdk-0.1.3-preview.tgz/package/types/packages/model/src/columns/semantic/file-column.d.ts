import { z } from 'zod';
import type { BoundColumnContract, ColumnBindContext, ResolvedTable } from '../../types';
import type { ColumnValidationIssue, ModelValidationEnv } from '../base-column';
import { PGTextColumn } from '../postgre/pg-text-column';
export declare class FileColumn extends PGTextColumn {
    static readonly columnType = "file";
    static readonly group = "misc";
    static get metadataSchema(): z.ZodObject<{
        readonly [x: string]: z.core.$ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>;
        allowedMimeTypes: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodString>>>;
        maxFileSizeBytes: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        bucket: z.ZodString;
    }, z.core.$strip>;
    /**
     * Folds in base invariants first — this override used to replace them
     * outright, silently dropping the dynamic-column-can't-carry-`encrypt` rule.
     */
    validateModel(): ColumnValidationIssue[];
    validateModelAsync(env: ModelValidationEnv): Promise<ColumnValidationIssue[]>;
    /**
     * Where this column's attachment ids live, as SQL over a physical name.
     * A file cell is the array itself; a markdown cell keeps it in a composite
     * field.
     *
     * Alias-free, because callers outside query generation have no base alias to
     * qualify with. Correct only while such a query stays single-table.
     */
    static attachmentArrayExpr(physicalName: string): string;
    get outputSchema(): z.ZodType;
    resolveTarget(): ResolvedTable | undefined;
    resolveNestedTarget(): ResolvedTable | undefined;
    getFieldSchema(targetField: string): z.ZodType | undefined;
    bind(ctx: Pick<ColumnBindContext, 'resolution'>): BoundColumnContract;
}
