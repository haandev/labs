import type { z } from 'zod';
import { PGTextColumn } from '../postgre/pg-text-column';
export declare class PhoneColumn extends PGTextColumn {
    static readonly columnType = "phone";
    static readonly group = "internationalization";
    static readonly zodSchema: z.ZodType;
    static enforcesBeyondPgType: boolean;
    /**
     * Normalizes on `inputSchema`, not the static `zodSchema` — the latter is
     * converted to JSON Schema for column metadata, and transforms don't survive that.
     */
    get inputSchema(): z.ZodType;
    static get metadataSchema(): z.ZodObject<{
        readonly [x: string]: z.core.$ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>;
        allowedCountries: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodEnum<{
            [x: string]: string;
        }>>>>;
        notAllowedCountries: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodEnum<{
            [x: string]: string;
        }>>>>;
    }, z.core.$strip>;
    static get availableRules(): readonly [];
}
