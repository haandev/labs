import { PGRangeColumn } from './pg-range-column';
export declare class PGTsrangeColumn extends PGRangeColumn {
    static readonly pgType = "tsrange";
    readonly boundMetadataType = "timestamp";
}
