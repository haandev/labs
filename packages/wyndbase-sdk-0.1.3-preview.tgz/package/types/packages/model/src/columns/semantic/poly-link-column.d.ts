import { z } from 'zod';
import type { ColumnBindContext, ColumnNode, ContainerKind, DataMask, EncryptInfo, LinkStrategySchema, ResolvedTable } from '../../types';
import { LinkColumn } from './link-column';
/**
 * A link whose target table is named per row by the stored `poly_ref._ref`
 * rather than declared once in metadata. It extends `LinkColumn` because it is
 * one: target resolution, correlation and the display helpers are shared.
 * `LinkColumn.is` still answers false for it — that predicate asks about the
 * single-target variant, `isAnyLinkColumn` asks about the family.
 */
export declare class PolyLinkColumn extends LinkColumn {
    static readonly columnType = "polyLink";
    static readonly pgType: string;
    /** `inputSchema` narrows a bare string/id to the `{ _id, _ref }` shape, so a write that bypasses it differs. */
    static enforcesBeyondPgType: boolean;
    getFieldSchema(targetField: string): z.ZodType | undefined;
    static indexExpression(colRef: string): string;
    static physicalPgType(col: ColumnNode): string;
    /**
     * The inherited `z.string()` would accept a bare id into a composite.
     * `writeValueSql` accepts either a single `{ _id, _ref }` object or, for a
     * multi-valued poly link, an array of them — a choice normally made by
     * `applyInputConstraints` wrapping in `z.array` off `isArray`, but poly
     * links key their multiplicity off `canHaveMultiple` (see `isMultiLink`),
     * which `deriveIsArray` never looks at. With no column instance to branch
     * on here, both shapes are accepted unconditionally.
     */
    static get zodSchema(): z.ZodType;
    /**
     * QUALIFIED, like the DDL spelling above and like `markdown`'s equivalent:
     * a compiled statement cannot know its connection's `search_path`, and the
     * driver narrows it to `system` alone in at least one place, where a bare
     * `poly_ref` does not resolve.
     *
     * A payload that is not the shape the column stores — JSON `null`, an absent
     * key, a scalar, an object where an array is wanted — stores SQL NULL rather
     * than `ROW(NULL, NULL)`, which is a value the link would otherwise hold in
     * place of nothing and which no read arm can match. On a NotNull column that
     * is a not-null violation, which is the honest answer. For the multi-valued
     * form an empty array is a distinct answer from NULL and is preserved: the
     * link was cleared, not left unset.
     */
    static writeValueSql: (col: ColumnNode, paramRef: string) => string;
    /**
     * No `mirrorColumns`: a polymorphic link has no single target table to hang
     * a reverse column on, and nothing may be the reverse of one.
     */
    static get metadataSchema(): z.ZodObject<z.ZodRawShape>;
    private _polyStrategy?;
    get strategy(): LinkStrategySchema;
    /** Picked at runtime, so no single display field's policy could govern it. */
    resolveDisplayFieldGate(_ctx: Pick<ColumnBindContext, 'policy'>, _targetResolved: ResolvedTable, _rowAlias: string): string | null;
    protected get displayDisclosure(): undefined;
    get container(): ContainerKind;
    get dataMask(): DataMask | undefined;
    get encryptInfo(): EncryptInfo | undefined;
}
