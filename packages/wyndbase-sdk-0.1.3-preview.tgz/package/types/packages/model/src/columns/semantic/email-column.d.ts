import { z } from 'zod';
import type { DataMask } from '../../types';
import { PGTextColumn } from '../postgre/pg-text-column';
export declare const normalizeEmail: (value: string) => string;
export declare class EmailColumn extends PGTextColumn {
    static readonly columnType = "email";
    static readonly group = "text";
    static readonly defaultDataMask: DataMask;
    static enforcesBeyondPgType: boolean;
    static readonly normalizesInlineLiterals = true;
    get inputSchema(): z.ZodType;
    static get availableRules(): readonly ['enforceDomain', 'excludeDomain'];
}
