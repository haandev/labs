import { z } from 'zod';
import type { BoundColumnContract, ColumnBindContext, FilterOperator, ResolvedTable, TableNode } from '../../types';
import { type ArrayProjectionAggregate } from '../../utils/array-projection';
import { BaseColumn } from '../base-column';
export declare abstract class PGRangeColumn extends BaseColumn {
    abstract readonly boundMetadataType: string;
    /** Base Zod type: raw PG range literal as string (e.g. "[1,10)"). */
    static readonly zodSchema: z.ZodString;
    /** Read projection of ONE range value; default is the raw PG range literal. */
    rangeElementExpr(ref: string): string;
    /**
     * `jsonb_agg` because a range has no `array_agg`-friendly scalar form; types
     * whose element expression yields plain `text` override to `array_agg`.
     */
    get rangeProjectionAggregate(): ArrayProjectionAggregate;
    get rangeOutputCellSchema(): z.ZodType;
    get rangeInputCellSchema(): z.ZodType;
    get outputSchema(): z.ZodType;
    get inputSchema(): z.ZodType;
    static get availableOperations(): readonly FilterOperator[];
    static get availableSummaryTypes(): readonly ['count'];
    static get metadataSchema(): z.ZodObject<z.ZodRawShape>;
    getFieldSchema(targetField: string): z.ZodType | undefined;
    resolveNestedTarget(): ResolvedTable | undefined;
    get usesJsonbAgg(): boolean;
    bind(ctx: Pick<ColumnBindContext, 'resolution'>): BoundColumnContract;
    _buildVirtualTable(): TableNode;
}
