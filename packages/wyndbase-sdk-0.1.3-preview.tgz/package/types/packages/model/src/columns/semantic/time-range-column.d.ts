import { z } from 'zod';
import { PGTsrangeColumn } from '../postgre/pg-tsrange-column';
export declare class TimeRangeColumn extends PGTsrangeColumn {
    static readonly columnType = "timerange";
    static readonly _aliases: readonly ['tsrange'];
    static readonly group = "dateTime";
    static enforcesBeyondPgType: boolean;
    static writeSchemaIgnoresStoredLiteral: boolean;
    /**
     * `disallowFuture` / `disallowPast` are absent: a date-less wall clock anchored
     * to a sentinel has nothing for "future" / "past" to be relative to.
     */
    static get availableRules(): readonly ['allowedTimeWindow', 'maxDurationTime'];
    /**
     * A default is written the way a cell value is: the `[HH:MM|HH:MM:SS, …]`
     * tuple, not the sentinel `tsrange` literal.
     */
    static get defaultValueSchema(): z.ZodType;
    /** A clean `[HH:MM|HH:MM:SS, …]` tuple → a half-open sentinel tsrange literal. */
    get rangeInputCellSchema(): z.ZodType;
    /** Result shape is `["HH:MM:SS","HH:MM:SS"]`, not the inherited raw range literal. */
    get rangeOutputCellSchema(): z.ZodType;
    /** `to_char` on the bounds, so the sentinel storage date never reaches the wire. */
    rangeElementExpr(ref: string): string;
    get projectedPgType(): string | null;
}
