import { z } from 'zod';
import type { FilterOperator } from '../../types';
import { BaseColumn } from '../base-column';
export declare class PGJsonbColumn extends BaseColumn {
    static readonly pgType = "jsonb";
    /** Base Zod type: `z.unknown()` since JSONB can hold any valid JSON structure. */
    static readonly zodSchema: z.ZodUnknown;
    static get availableOperations(): readonly FilterOperator[];
    static get availableSummaryTypes(): readonly ['count'];
}
