import { PGRangeColumn } from './pg-range-column';
export declare class PGTstzrangeColumn extends PGRangeColumn {
    static readonly pgType = "tstzrange";
    readonly boundMetadataType = "timestamptz";
}
