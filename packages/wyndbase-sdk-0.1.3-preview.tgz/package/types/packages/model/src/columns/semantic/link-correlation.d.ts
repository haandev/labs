import type { BaseColumnRef, ResolvedTable } from '../../types';
/**
 * Correlates a target row's FK back to the base row. Registry-free so the
 * strategies can reach it without cycling back through the column classes.
 */
export declare function buildCorrelation(targetAlias: string, fkPhysicalName: string, baseColumn: BaseColumnRef, isMulti: boolean, baseIdColumn?: string): string;
/**
 * The correlation for a reverse hop landing on a POLYMORPHIC FK, or `null`
 * when the named column is not one and an ordinary join applies.
 * `baseIdColumn` lets a versioned base table correlate on its lineage id
 * so the mirror survives across versions of the base row.
 */
export declare function tryBuildPolyCorrelation(targetTable: ResolvedTable, targetColumnName: string, targetAlias: string, baseColumn: BaseColumnRef, baseIdColumn?: string): string | null;
