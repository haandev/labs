import { z } from 'zod';
import { PGJsonColumn } from '../postgre/pg-json-column';
/**
 * Semantic JSON column with optional JSON Schema metadata for type inference.
 *
 * When `metadata.schema` is provided (JSON Schema format), `outputSchema`
 * returns a typed Zod schema instead of `z.unknown()`. This enables
 * proper TypeScript generation for JSON column query results.
 *
 * Without `metadata.schema`, behaves identically to PGJsonColumn.
 */
export declare class JsonColumn extends PGJsonColumn {
    static readonly columnType = "json";
    static readonly group = "advanced";
    static get metadataSchema(): z.ZodObject<{
        readonly [x: string]: z.core.$ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>;
        schema: z.ZodOptional<z.ZodNullable<z.ZodRecord<z.ZodString, z.ZodUnknown>>>;
    }, z.core.$strip>;
    /**
     * Output schema: when `metadata.schema` (JSON Schema) is provided, converts it to a
     * typed Zod schema and applies array/nullable wrappers based on column constraints.
     * Follows the base-column convention: array -> z.array(), nullable -> z.nullable().
     * Falls back to the PGJsonColumn base behavior (`z.unknown()` + standard wrapping) otherwise.
     */
    get outputSchema(): z.ZodType;
    /**
     * Writes are validated against the same contract reads are typed with —
     * a declared `metadata.schema` is enforced, not advisory. Unsupported
     * schemas degrade to `z.unknown()` inside `jsonSchemaToZod`, so a
     * contract the runtime cannot model never rejects a write.
     */
    get inputSchema(): z.ZodType;
}
