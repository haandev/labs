import { z } from 'zod';
import type { BoundColumnContract, ColumnBindContext, ColumnNode, ContainerKind, ResolvedTable } from '../../types';
import { PGTextColumn } from '../postgre/pg-text-column';
export declare class ChoiceColumn extends PGTextColumn {
    static readonly columnType = "choice";
    static readonly group = "navigation";
    static readonly pgType: string;
    static enforcesBeyondPgType: boolean;
    static isMulti(col: ColumnNode): boolean;
    /** For callers holding only loose metadata, not a full column node. */
    static isMultiMetadata(metadata: {
        isMultiSelect?: string | null;
        type?: string | null;
    }): boolean;
    get isMulti(): boolean;
    static deriveIsArray(col: ColumnNode): boolean;
    static get metadataSchema(): z.ZodObject<{
        readonly [x: string]: z.core.$ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>;
        readonly [x: number]: z.core.$ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>;
        isMultiSelect: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            no: "no";
            yes: "yes";
        }>>>;
        listName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        choices: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodObject<{
            _id: z.ZodString;
            color: z.ZodString;
            createdAt: z.ZodOptional<z.ZodNullable<z.ZodISODateTime>>;
            icon: z.ZodString;
            key: z.ZodString;
            label: z.ZodString;
            listName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            meta: z.ZodOptional<z.ZodNullable<z.ZodRecord<z.ZodString, z.ZodUnknown>>>;
            sortOrder: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
            updatedAt: z.ZodOptional<z.ZodNullable<z.ZodISODateTime>>;
        }, z.core.$strip>>>>;
    }, z.core.$strip>;
    /** Widened to a union so a multi-select column can default to an id array. */
    static get zodSchema(): z.ZodType;
    get isArray(): boolean;
    /**
     * The base `inputSchema` would give `z.array(union)` for an `isArray` column,
     * which allows nested arrays. Keep validation strict per the multi flag.
     */
    get inputSchema(): z.ZodType;
    get outputSchema(): z.ZodType;
    resolveTarget(): ResolvedTable | undefined;
    resolveNestedTarget(): ResolvedTable | undefined;
    get usesJsonbAgg(): boolean;
    /**
     * SELECT projects multi-select labels via `jsonb_agg`, not as a PG array, so
     * disclosure matches that; only RETURNING sees the physical `uuid[]`.
     */
    get container(): ContainerKind;
    getFieldSchema(targetField: string): z.ZodType | undefined;
    get projectedPgType(): string | null;
    bind(ctx: Pick<ColumnBindContext, 'resolution'>): BoundColumnContract;
}
