import { z } from 'zod';
import type { FilterOperator } from '../../types';
import { BaseColumn } from '../base-column';
/**
 * `json` lacks a btree opclass, so filter/sort indexing is disabled centrally
 * off `pgType`; use `jsonb` when an index is needed.
 */
export declare class PGJsonColumn extends BaseColumn {
    static _aliases: readonly string[];
    static readonly pgType = "json";
    static readonly zodSchema: z.ZodUnknown;
    static get availableOperations(): readonly FilterOperator[];
    static get availableSummaryTypes(): readonly ['count'];
}
