import type { z } from 'zod';
import type { BoundColumnContract, ColumnBindContext } from '../../types';
import { PGTimestamptzColumn } from '../postgre/pg-timestamptz-column';
/**
 * Reuses `'timestamptz'` as its columnType so it wins over the PG class in
 * `columnRegistry` (registered later) — semantic layers over the raw PG type.
 */
export declare class DatetimeZonedColumn extends PGTimestamptzColumn {
    static readonly columnType = "timestamptz";
    static readonly group = "dateTime";
    static enforcesBeyondPgType: boolean;
    static castRecoversStoredValue: boolean;
    static get availableRules(): readonly ['minDateTime', 'maxDateTime', 'dateformula'];
    get inputSchema(): z.ZodType;
    bind(ctx: Pick<ColumnBindContext, 'resolution'>): BoundColumnContract;
    get projectedPgType(): string | null;
}
