/** PostgreSQL element type for binding `columnType` as an array. */
export declare function resolveArrayElementPgType(columnType: string | undefined): string;
/**
 * If `pgType` already declares an array dimension (a multi-link's
 * `poly_ref[]`), appending again would double it to `poly_ref[][]`.
 */
export declare function declaredPgType(pgType: string, isArray: boolean): string;
