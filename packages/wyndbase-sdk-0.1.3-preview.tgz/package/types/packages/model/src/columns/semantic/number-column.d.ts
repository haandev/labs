import { PGFloatColumn } from '../postgre/pg-float-column';
export declare class NumberColumn extends PGFloatColumn {
    static readonly columnType = "number";
    static readonly group = "numeric";
    static get availableRules(): readonly ['numberMin', 'numberMax', 'numberBetween'];
}
