import { z } from 'zod';
import type { FilterOperator } from '../../types';
import { BaseColumn } from '../base-column';
export declare class PGFloatColumn extends BaseColumn {
    static _aliases: readonly string[];
    static readonly pgType = "float8";
    /** Base Zod type: floating-point numbers validated by `z.number()`. */
    static readonly zodSchema: z.ZodNumber;
    static supportsDataMask: boolean;
    static get availableOperations(): readonly FilterOperator[];
    static get availableSummaryTypes(): string[];
}
