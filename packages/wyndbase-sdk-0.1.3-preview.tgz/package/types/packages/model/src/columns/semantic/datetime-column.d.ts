import type { z } from 'zod';
import type { BoundColumnContract, ColumnBindContext } from '../../types';
import { PGTimestampColumn } from '../postgre/pg-timestamp-column';
export declare class DatetimeColumn extends PGTimestampColumn {
    static readonly columnType = "datetime";
    static readonly group = "dateTime";
    static enforcesBeyondPgType: boolean;
    /**
     * `to_char(col, 'YYYY-MM-DD"T"HH24:MI:SS')::timestamp` is Postgres' own ISO
     * input form, so the projected text casts back to the stored instant.
     */
    static castRecoversStoredValue: boolean;
    static get availableRules(): readonly ['minDateTime', 'maxDateTime', 'dateformula'];
    /** Canonicalizes to `YYYY-MM-DDTHH:MM:SS` via the wire codec (no offset/`Z`). */
    get inputSchema(): z.ZodType;
    bind(ctx: Pick<ColumnBindContext, 'resolution'>): BoundColumnContract;
    get projectedPgType(): string | null;
}
