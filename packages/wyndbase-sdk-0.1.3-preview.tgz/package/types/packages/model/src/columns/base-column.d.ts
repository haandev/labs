import { z } from 'zod';
import type { WynModelTree } from '../model-tree';
import type { BoundColumnContract, ColumnBindContext, ColumnDescriptor, ColumnIdentity, ColumnNode, ContainerKind, DataMask, EncryptInfo, FilterOperator, ResolvedTable, WriteDecisionKeyEmitter, WriteMode } from '../types';
import { ColumnMetadataBaseSchema } from '../types/column-metadata';
export type { NestedResolution } from '../types';
/**
 * Environment lookups for async column validation. An absent capability skips
 * the dependent check rather than failing.
 */
export type ModelValidationEnv = {
    /** Must tolerate arbitrary strings: a malformed id resolves to `false`, never throws. */
    bucketExists?: (bucketId: string) => Promise<boolean>;
};
export type ColumnValidationIssue = {
    message: string;
    /** Client input path in dot notation, e.g. `metadata.bucket`. */
    field?: string;
    /** Stable machine code for the rule, e.g. `file-bucket-unresolved`. */
    code?: string;
};
export declare abstract class BaseColumn implements ColumnIdentity {
    readonly col: ColumnNode;
    readonly model: WynModelTree;
    static readonly group: string;
    static get columnType(): string;
    /** `metadata` is required by the type, but `deleteModel` arrives with plain
     *  `system.models` records that carry none. */
    static is(col: ColumnNode): boolean;
    static _aliases: readonly string[];
    /** Non-inheritable by design: a semantic subclass must not inherit PG aliases. */
    static get aliases(): readonly string[];
    /** The unwrapped scalar schema — `isArray` and nullable wrapping happen per instance. */
    static get zodSchema(): z.ZodType;
    /** The shape a default may take; whether one is acceptable is `validateModel`'s call. */
    static get defaultValueSchema(): z.ZodType;
    static get availableRules(): readonly string[];
    static readonly pgType: string;
    /**
     * A literal baked into WQL text bypasses `inputSchema`; opt in where the codec
     * canonicalizes (email lower-casing), or the row lands unmatchable.
     */
    static readonly normalizesInlineLiterals: boolean;
    static deriveIsArray(col: ColumnNode): boolean;
    /**
     * Must agree with the instance's `finalPgType` — disagreement left polymorphic
     * links casting to a type the DDL never created.
     */
    static physicalPgType(_col: ColumnNode): string;
    static defaultDataMask?: DataMask;
    static supportsDataMask: boolean;
    /**
     * True where `inputSchema` rejects or rewrites values the pgType would accept.
     * Only matters for writes that bypass it — set-based `INSERT … EACH`.
     */
    static enforcesBeyondPgType: boolean;
    /**
     * True when `inputSchema` accepts a wire form and not the literal already
     * stored. A same-storage change between two such types cannot be checked
     * by parsing stored rows.
     */
    static writeSchemaIgnoresStoredLiteral: boolean;
    /**
     * Whether the set-based `INSERT … EACH` form can write this type. `false`
     * refuses the whole statement: a type whose write carries a gate the bulk
     * path does not emit would otherwise store a value nothing checked.
     */
    static supportsBulkEach: boolean;
    /**
     * Not derivable: `to_char(d,'YYYY-MM-DD')::date` round-trips, while the same
     * seam over a range raises `malformed range literal`.
     */
    static castRecoversStoredValue: boolean;
    /**
     * How a BOUND value becomes the SQL written into the column, when binding it
     * directly will not do. Undefined — the default — means `$N` is the value.
     *
     * A composite cannot be bound as a parameter: the payload arrives as JSON and
     * the driver hands PostgreSQL its text form, which the record-literal parser
     * rejects. Such a class overrides this and projects the JSON into the
     * composite in SQL instead. Declared here so the write path dispatches on the
     * column's own class rather than testing for a type name.
     *
     * Takes the node for the same reason `physicalPgType` does: the storage
     * shape can vary per node, not just per class.
     */
    static writeValueSql?: (col: ColumnNode, paramRef: string) => string;
    /**
     * The text a searchable column's tsvector and trigram index read, over the
     * reference given (`"col"` for an index, `NEW."col"` for a trigger). A type
     * whose stored value is not itself text narrows to the field that is.
     */
    static searchTextExpr(colRef: string, isArray?: boolean | null): string;
    /** Whether this column's stored value is a link that deletes probe, so it is always indexed. */
    static indexesStorage(_col: ColumnNode): boolean;
    /** The indexed expression over the reference given; a composite narrows to its id. */
    static indexExpression(colRef: string): string;
    static get metadataSchema(): z.ZodObject<z.ZodRawShape>;
    static get availableSummaryTypes(): readonly string[];
    static get nonDynamicMetadataKeys(): readonly string[];
    /** Before refinement. `options.dynamic` narrows the non-dynamic keys to `never`. */
    protected static calculateMetadataSchema(options?: {
        dynamic?: boolean;
    }): typeof ColumnMetadataBaseSchema;
    static get finalMetadataSchema(): z.ZodObject<{
        allowEnd: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            both: "both";
            "exclusive-only": "exclusive-only";
            "inclusive-only": "inclusive-only";
        }>>>;
        allowedCountries: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodEnum<{
            [x: string]: string;
        }>>>>;
        allowedMimeTypes: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodString>>>;
        allowedTables: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodString>>>;
        allowFilter: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        allowOpenEnd: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        allowOpenStart: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        allowSearch: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        allowStart: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            both: "both";
            "exclusive-only": "exclusive-only";
            "inclusive-only": "inclusive-only";
        }>>>;
        allowsAnyTable: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        bucket: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        canHaveMultiple: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        dataMask: z.ZodOptional<z.ZodNullable<z.ZodObject<{
            char: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            email: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            enabled: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            leading: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
            separators: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            trailing: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        }, z.core.$strip>>>;
        defaultValue: z.ZodOptional<z.ZodNullable<z.ZodAny>>;
        encrypt: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        formula: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        hidden: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        immutable: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        inputMask: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        isArray: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        isDynamic: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        isMultiSelect: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            no: "no";
            yes: "yes";
        }>>>;
        isNqTarget: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        isPrimaryKey: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        isUnique: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        listName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        maxFileSizeBytes: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        mirrorColumns: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodObject<{
            _id: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            canHaveMultiple: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            name: z.ZodString;
            physicalName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            table: z.ZodString;
        }, z.core.$strip>>>>;
        notAllowedCountries: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodEnum<{
            [x: string]: string;
        }>>>>;
        notNull: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        onDelete: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            cascade: "cascade";
            keep: "keep";
            restrict: "restrict";
            setNull: "setNull";
        }>>>;
        optimizeSort: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        precision: z.ZodOptional<z.ZodNullable<z.ZodInt>>;
        rules: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodObject<{
            args: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodAny>>>;
            name: z.ZodString;
        }, z.core.$strip>>>>;
        scale: z.ZodOptional<z.ZodNullable<z.ZodInt>>;
        schema: z.ZodOptional<z.ZodNullable<z.ZodRecord<z.ZodString, z.ZodUnknown>>>;
        sensitive: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            always: "always";
            "explicitly-open": "explicitly-open";
        }>>>;
        summaryTypes: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodString>>>;
        targetTables: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodObject<{
            junctionSourceColumn: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            junctionTable: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            junctionTargetColumn: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            table: z.ZodString;
            targetColumn: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strip>>>>;
        type: z.ZodString;
        versioning: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    }, z.core.$strip>;
    static get finalDynamicMetadataSchema(): z.ZodObject<{
        allowEnd: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            both: "both";
            "exclusive-only": "exclusive-only";
            "inclusive-only": "inclusive-only";
        }>>>;
        allowedCountries: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodEnum<{
            [x: string]: string;
        }>>>>;
        allowedMimeTypes: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodString>>>;
        allowedTables: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodString>>>;
        allowFilter: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        allowOpenEnd: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        allowOpenStart: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        allowSearch: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        allowStart: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            both: "both";
            "exclusive-only": "exclusive-only";
            "inclusive-only": "inclusive-only";
        }>>>;
        allowsAnyTable: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        bucket: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        canHaveMultiple: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        dataMask: z.ZodOptional<z.ZodNullable<z.ZodObject<{
            char: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            email: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            enabled: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            leading: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
            separators: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            trailing: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        }, z.core.$strip>>>;
        defaultValue: z.ZodOptional<z.ZodNullable<z.ZodAny>>;
        encrypt: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        formula: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        hidden: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        immutable: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        inputMask: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        isArray: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        isDynamic: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        isMultiSelect: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            no: "no";
            yes: "yes";
        }>>>;
        isNqTarget: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        isPrimaryKey: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        isUnique: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        listName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        maxFileSizeBytes: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        mirrorColumns: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodObject<{
            _id: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            canHaveMultiple: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            name: z.ZodString;
            physicalName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            table: z.ZodString;
        }, z.core.$strip>>>>;
        notAllowedCountries: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodEnum<{
            [x: string]: string;
        }>>>>;
        notNull: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        onDelete: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            cascade: "cascade";
            keep: "keep";
            restrict: "restrict";
            setNull: "setNull";
        }>>>;
        optimizeSort: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        precision: z.ZodOptional<z.ZodNullable<z.ZodInt>>;
        rules: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodObject<{
            args: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodAny>>>;
            name: z.ZodString;
        }, z.core.$strip>>>>;
        scale: z.ZodOptional<z.ZodNullable<z.ZodInt>>;
        schema: z.ZodOptional<z.ZodNullable<z.ZodRecord<z.ZodString, z.ZodUnknown>>>;
        sensitive: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            always: "always";
            "explicitly-open": "explicitly-open";
        }>>>;
        summaryTypes: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodString>>>;
        targetTables: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodObject<{
            junctionSourceColumn: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            junctionTable: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            junctionTargetColumn: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            table: z.ZodString;
            targetColumn: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strip>>>>;
        type: z.ZodString;
        versioning: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    }, z.core.$strip>;
    static get availableOperations(): readonly FilterOperator[];
    static get typeDefinition(): ColumnDescriptor;
    constructor(col: ColumnNode, model: WynModelTree);
    /**
     * An empty list means valid. Overrides must fold in `super.validateModel()`,
     * and issues accumulate rather than short-circuit.
     */
    validateModel(): ColumnValidationIssue[];
    /**
     * Environment-dependent half of validation. Overrides fold in `super`, and
     * must not re-report what the sync hook already rejected.
     */
    validateModelAsync(_env: ModelValidationEnv): Promise<ColumnValidationIssue[]>;
    get resolved(): ResolvedTable | undefined;
    /** Pseudo = a virtual or reverse column with no physical DB column. */
    get isPseudo(): boolean;
    bind(ctx: Pick<ColumnBindContext, 'resolution'>): BoundColumnContract;
    get outputSchema(): z.ZodType;
    /**
     * A read gate widens the schema to nullable even when `notNull`: the emitter
     * wraps the projection in `CASE WHEN <policy> … ELSE NULL`.
     */
    protected applyOutputConstraints(element: z.ZodType): z.ZodType;
    get hasCellReadGate(): boolean;
    /**
     * Whether a write to this column carries a gate the mutation path must emit
     * — the write-side counterpart of `hasCellReadGate`. The gate's SQL is built
     * outside this package; this is the seam that decides whether to build one,
     * so no write-path module has to ask which type it is holding.
     */
    get hasWriteGate(): boolean;
    /**
     * The access-decision keys a write to this column spends, requested through
     * `emit`. Undefined — the default — means a write spends no keys of its own
     * beyond the cell key every written column already requests.
     *
     * `targetLiteral` is the written value when it is a string literal known at
     * compile time, and `undefined` for every other shape (a parameter, a
     * subquery, an expression): a known target narrows the request to the keys
     * that target can actually spend, an unknown one has to request them all.
     */
    writeDecisionKeys?(emit: WriteDecisionKeyEmitter, mode: WriteMode, targetLiteral: string | undefined): void;
    get inputSchema(): z.ZodType;
    /**
     * Schema for a value rendered as a bare SQL literal. Override only where the
     * wire value is not the text PostgreSQL needs.
     */
    get filterLiteralSchema(): z.ZodType;
    /**
     * Overrides of `inputSchema` must route through here — per-class wrapping once
     * left `isArray` unenforced, rejecting every array insert.
     */
    protected applyInputConstraints(element: z.ZodType): z.ZodType;
    /** Infer the schema of a sub-field accessed via dot notation. */
    getFieldSchema?(targetField: string): z.ZodType | undefined;
    /** Pure counterpart of the bound `resolveNavigation`, which also adds JOINs. */
    resolveNavigationTarget?(): ResolvedTable | undefined;
    resolveNestedTarget?(): ResolvedTable | undefined;
    get isArray(): boolean;
    /** Non-link columns are never traversed, so nothing arrives through them. */
    get isMultiValued(): boolean;
    get usesJsonbAgg(): boolean;
    /** Typed constructor reference — capital C to avoid conflict with native this.constructor */
    get Constructor(): typeof BaseColumn;
    get dataMask(): DataMask | undefined;
    get container(): ContainerKind;
    get encryptInfo(): EncryptInfo | undefined;
    get finalPgType(): string | null;
    /**
     * True when something other than this column's own `project()` builds the
     * projected value, so its type is not this column's to answer.
     *
     * Encryption and masking wrap the reference, and the wrapper picks its type
     * per delivery shape outside this package. A dynamic value is extracted from
     * the `dynamicData` blob and cast to the STORED shape instead, which is the
     * one thing the type's own projection rule is describing away.
     */
    get projectionIsRewritten(): boolean;
    get projectedPgType(): string | null;
}
