import { z } from 'zod';
import type { ColumnNode } from '../../types';
import type { ColumnValidationIssue, ModelValidationEnv } from '../base-column';
/**
 * A column that attaches files but names no bucket throws on first upload;
 * `.trim().min(1)` closes the empty/whitespace hole `z.string()` alone let
 * through.
 */
export declare const AttachmentBucketSchema: z.ZodString;
/** Widget metadata for the bucket field. */
export declare const attachmentBucketField: z.ZodString;
/**
 * The two column types that carry attachment ids. Kept a narrow structural
 * contract rather than a member on every column class: a date column has no
 * attachment array, and answering as if it did turns one unactionable
 * `file_attachments` row into a type error that aborts a whole cleanup scan.
 */
export interface AttachmentColumnConstructor {
    attachmentArrayExpr(physicalName: string): string;
}
export declare const isAttachmentColumnClass: (cls: unknown) => cls is AttachmentColumnConstructor;
/** The raw, unvalidated bucket — the validation rules below judge it. */
export declare const bucketOf: (col: ColumnNode) => unknown;
/**
 * The metadata keys every attachment-carrying column needs, added in one
 * place: a fourth key must not have to be remembered on each such class.
 */
export declare const withAttachmentBucketMetadata: <T extends z.ZodObject<z.ZodRawShape>>(schema: T) => z.ZodObject<{
    readonly [x: string]: z.core.$ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>;
    allowedMimeTypes: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodString>>>;
    maxFileSizeBytes: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    bucket: z.ZodString;
}, z.core.$strip>;
/** The synchronous rule: a bucket must be present and non-empty. */
export declare function attachmentBucketIssues(raw: unknown): ColumnValidationIssue[];
/**
 * The asynchronous rule: `metadata.bucket` is a `system.buckets._id`, not a
 * name — any non-empty string used to pass creation then fail the first upload.
 */
export declare function attachmentBucketAsyncIssues(raw: unknown, env: ModelValidationEnv): Promise<ColumnValidationIssue[]>;
