import { z } from 'zod';
import { PGTstzrangeColumn } from '../postgre/pg-tstzrange-column';
export declare class ZonedTimeRangeColumn extends PGTstzrangeColumn {
    static readonly columnType = "datetimerange";
    static readonly _aliases: readonly ['tstzrange'];
    static readonly group = "dateTime";
    static enforcesBeyondPgType: boolean;
    static writeSchemaIgnoresStoredLiteral: boolean;
    static get metadataSchema(): z.ZodObject<{
        readonly [x: string]: z.core.$ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>;
        allowOpenEnd: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        allowOpenStart: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    }, z.core.$strip>;
    static get availableRules(): readonly ['maxDuration', 'maxEndDateTime', 'minStartDateTime', 'disallowFuture', 'disallowPast'];
    /** A default is written as the `[start, end]` instant tuple, like a cell value — not the raw `tstzrange` literal. */
    static get defaultValueSchema(): z.ZodType;
    /**
     * Gates an open bound (`null`) against `allowOpenStart`/`allowOpenEnd` here,
     * the only layer holding both the value and the column metadata.
     */
    get rangeInputCellSchema(): z.ZodType;
    /**
     * Result shape: `[startZ|null, endZ|null]`, NOT the raw PG range literal
     * `z.string()` inherited from `PGRangeColumn.zodSchema`.
     */
    get rangeOutputCellSchema(): z.ZodType;
    /** An open bound (unbounded range) projects as `null`, not an error. */
    rangeElementExpr(ref: string): string;
    get projectedPgType(): string | null;
}
