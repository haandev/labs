import { z } from 'zod';
import { WynModelTree } from '../../model-tree';
import type { BoundLinkColumnContract, ColumnBindContext, ColumnNode, ContainerKind, DataMask, EncryptInfo, FilterOperator, LinkStrategySchema, ResolvedTable, SpaceNode } from '../../types';
import { BaseColumn, type ColumnValidationIssue } from '../base-column';
import { buildCorrelation } from './link-correlation';
/** Seen from the table owning the column: who holds the FK. */
export type LinkDirection = 'forward' | 'reverse' | 'manyToMany';
/** What deleting the linked row does to rows holding this link. */
export type LinkOnDelete = 'keep' | 'restrict' | 'cascade' | 'setNull';
/** A storing link into `table`, held by a column of `linking`. */
export interface IncomingLink {
    table: ResolvedTable;
    linking: ResolvedTable;
    column: ColumnNode;
    onDelete: LinkOnDelete;
}
export declare const LINK_ON_DELETE_VALUES: readonly LinkOnDelete[];
export declare class LinkColumn extends BaseColumn {
    static readonly columnType: string;
    static readonly group = "navigation";
    static readonly pgType: string;
    static enforcesBeyondPgType: boolean;
    static isMulti(col: ColumnNode): boolean;
    static hasMNJunction(col: ColumnNode): boolean;
    /** The column named by `targetTables[0].targetColumn` on the resolved target table. */
    private static resolvePartner;
    /** Whether this column holds the stored reference of its link pair. */
    static storesReference(col: ColumnNode, model: WynModelTree): boolean;
    /** Every link with its own physical column: the single-valued one the delete probe reads. */
    static indexesStorage(col: ColumnNode): boolean;
    static direction(col: ColumnNode, model: WynModelTree): LinkDirection;
    /**
     * The column of the pair that stores the reference: itself when it stores
     * one, its partner (resolved via `targetColumn`) when it is the mirror, or
     * undefined for a junction link or a polymorphic link (no fixed partner).
     */
    static storingColumn(col: ColumnNode, model: WynModelTree): ColumnNode | undefined;
    /** The storing column's `onDelete`, defaulting to `'keep'`. */
    static onDelete(col: ColumnNode, model: WynModelTree): LinkOnDelete;
    /** The table a link column stores keys of; undefined for a mirror, an M:N or a polymorphic link. */
    static storedTarget(model: WynModelTree, column: ColumnNode, space: SpaceNode | undefined): ResolvedTable | undefined;
    /**
     * Every storing link column in the model whose target resolves to `table`.
     * Mirrors are excluded: they never store the reference themselves; so are
     * M:N junction endpoints, since a delete leaves memberships as they are.
     * `table` is the resolved target; `linking` the table holding the column.
     */
    static incomingLinks(model: WynModelTree, table: ResolvedTable['table']): IncomingLink[];
    validateModel(): ColumnValidationIssue[];
    /** Refuses a declared `onDelete` the engine cannot honour, judged on the storing column. */
    private onDeleteIssues;
    /** Refuses a delete behaviour on a link none of whose columns stores the reference. */
    static noStoringColumnIssue(col: ColumnNode, model?: WynModelTree): ColumnValidationIssue;
    /**
     * The cascade links from `target` back to `own`, walking `incomingLinks`
     * backwards: deleting X cascades into each table holding a cascade link to X.
     */
    private static cascadeCycle;
    /** The model with `this.col` in place of its saved version, which may predate this edit. */
    private withThisColumn;
    /**
     * The table holding `col`, found by containment: a loaded node's `parent` is
     * its table's display name, not its `_id`.
     */
    private static ownerOf;
    private static linkName;
    /**
     * Schema-qualified: DDL runs on the init transaction, whose `search_path`
     * is `system` alone.
     */
    static physicalPgType(_col: ColumnNode): string;
    /**
     * Multi cardinality lives in pseudo columns (X:M) or a junction table
     * (M:N) — the source-side physical column, if any, is always singular.
     */
    static deriveIsArray(_col: ColumnNode): boolean;
    /**
     * A relationship filters by identity (the target row's id), never by
     * display value, so ordering/pattern/range operators are not offered.
     */
    static get availableOperations(): readonly FilterOperator[];
    static get metadataSchema(): z.ZodObject<z.ZodRawShape>;
    static resolveTarget(model: WynModelTree, linkCol: ColumnNode, sourceSpace?: SpaceNode): ResolvedTable | undefined;
    resolveTarget(sourceSpace?: SpaceNode): ResolvedTable | undefined;
    static readonly buildCorrelation: typeof buildCorrelation;
    static getDisplaySelectCol(table: ResolvedTable['table']): string;
    /**
     * `rowAlias` must be the row alias INSIDE the aggregate (the JOINed
     * target for M:N, not the junction) or PostgreSQL rejects the reference.
     */
    resolveDisplayFieldGate(ctx: Pick<ColumnBindContext, 'policy'>, targetResolved: ResolvedTable, rowAlias: string): string | null;
    private _strategy?;
    get strategy(): LinkStrategySchema;
    get isPseudo(): boolean;
    get isMulti(): boolean;
    /**
     * Resolves an ad-hoc NQ-target link descriptor, shared by the X:1 and X:M
     * strategies so target/column resolution can't diverge between them.
     */
    resolveNqTarget(ctx: Pick<ColumnBindContext, 'links'>): {
        targetRef: string;
        synthetic: ResolvedTable;
        onColumn: string;
        sourceColumn: string;
        isStaticCte: boolean;
    } | undefined;
    get outputSchema(): z.ZodType;
    /**
     * Nullable exactly when a read gate exists on the target's display field:
     * a denied caller then reads `NULL` instead of a truncated array.
     */
    multiOutputSchema(): z.ZodType;
    resolveNavigationTarget(): ResolvedTable | undefined;
    /**
     * The display field's disclosure controls, resolved once so `encryptInfo`,
     * `dataMask` and `container` can't drift apart from each other.
     */
    protected get displayDisclosure(): {
        col: ColumnNode;
        container: ContainerKind;
        resolvedTable: ResolvedTable;
    } | undefined;
    /**
     * The display field node paired with its table — a lookup on the table
     * holding the LINK would find the link node, which has no cell rule.
     */
    get displayFieldSource(): {
        col: ColumnNode;
        resolvedTable: ResolvedTable;
    } | undefined;
    get container(): ContainerKind;
    get isMultiValued(): boolean;
    get dataMask(): DataMask | undefined;
    get encryptInfo(): EncryptInfo | undefined;
    private _cachedDisplayZod;
    resolveDisplayZod(): z.ZodType;
    get finalPgType(): string | null;
    get projectedPgType(): string | null;
    bind(ctx: Pick<ColumnBindContext, 'resolution' | 'links'>): BoundLinkColumnContract;
}
