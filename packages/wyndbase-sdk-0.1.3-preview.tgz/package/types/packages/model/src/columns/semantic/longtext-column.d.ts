import { PGTextColumn } from '../postgre/pg-text-column';
export declare class LongTextColumn extends PGTextColumn {
    static readonly columnType = "longtext";
    static readonly group = "text";
    static get availableRules(): readonly ['minLength', 'maxLength', 'lengthBetween'];
    static get availableSummaryTypes(): readonly ['min', 'max', 'count', 'string_agg', 'array_agg'];
}
