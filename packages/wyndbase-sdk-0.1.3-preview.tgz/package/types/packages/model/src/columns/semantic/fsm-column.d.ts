import { z } from 'zod';
import type { WriteDecisionKeyEmitter, WriteMode } from '../../types';
import type { ColumnValidationIssue } from '../base-column';
import { PGTextColumn } from '../postgre/pg-text-column';
declare const FsmStateSchema: z.ZodObject<{
    color: z.ZodOptional<z.ZodString>;
    description: z.ZodOptional<z.ZodString>;
    id: z.ZodString;
    label: z.ZodString;
}, z.core.$strip>;
declare const FsmTransitionSchema: z.ZodObject<{
    from: z.ZodString;
    id: z.ZodString;
    label: z.ZodOptional<z.ZodString>;
    to: z.ZodString;
}, z.core.$strip>;
export type FsmState = z.infer<typeof FsmStateSchema>;
export type FsmTransition = z.infer<typeof FsmTransitionSchema>;
export declare class FSMColumn extends PGTextColumn {
    static readonly columnType = "fsm";
    static readonly group = "workflow";
    static readonly pgType: string;
    /**
     * A bulk INSERT emits no per-row FSM gate, so allowing one would store a
     * state nothing checked. Refused whole rather than silently ungated.
     */
    static supportsBulkEach: boolean;
    /**
     * `isArray` is omitted: an FSM holds exactly one state per row, and every
     * enforcement mechanism assumes a scalar column.
     */
    static get metadataSchema(): z.ZodObject<{
        readonly [x: string]: z.core.$ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>;
        readonly [x: number]: z.core.$ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>;
        states: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodObject<{
            color: z.ZodOptional<z.ZodString>;
            description: z.ZodOptional<z.ZodString>;
            id: z.ZodString;
            label: z.ZodString;
        }, z.core.$strip>>>>;
        transitions: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodObject<{
            from: z.ZodString;
            id: z.ZodString;
            label: z.ZodOptional<z.ZodString>;
            to: z.ZodString;
        }, z.core.$strip>>>>;
    }, z.core.$strip>;
    /**
     * The column DEFAULT is the FSM's entry state: it is what an INSERT that
     * omits the column lands on, and the only state an INSERT that names the
     * column may name. `validateModel` holds it to `states[].id`.
     */
    static get defaultValueSchema(): z.ZodType;
    static get availableSummaryTypes(): readonly string[];
    get states(): FsmState[];
    get transitions(): FsmTransition[];
    /** The entry state — a typed read of the one place it is stored. */
    get defaultValue(): string | null | undefined;
    transitionFor(fromStateId: string, targetStateId: string): FsmTransition | undefined;
    transitionsTo(targetStateId: string): FsmTransition[];
    transitionsFrom(fromStateId: string): FsmTransition[];
    hasState(stateId: string): boolean;
    resolveTransition(fromState: string, toState: string): FsmTransition | undefined;
    applicableFromStatesFor(targetState: string): string[];
    applicableToStatesFor(sourceState: string): string[];
    get hasWriteGate(): boolean;
    /**
     * INSERT has no source state, so it asks only for target-state validity;
     * UPDATE and UPSERT also ask for the `(from → to)` guards.
     *
     * The pair dedupe is load-bearing on a known target: one `* → target`
     * definition resolves for every non-self source, and all of them address the
     * same guard.
     */
    writeDecisionKeys(emit: WriteDecisionKeyEmitter, mode: WriteMode, targetLiteral: string | undefined): void;
    validateModel(): ColumnValidationIssue[];
}
export {};
