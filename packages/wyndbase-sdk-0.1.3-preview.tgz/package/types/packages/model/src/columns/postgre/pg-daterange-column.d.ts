import { PGRangeColumn } from './pg-range-column';
export declare class PGDaterangeColumn extends PGRangeColumn {
    static readonly pgType = "daterange";
    readonly boundMetadataType = "date";
}
