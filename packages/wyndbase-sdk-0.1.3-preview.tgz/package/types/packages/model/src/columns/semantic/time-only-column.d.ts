import type { z } from 'zod';
import type { BoundColumnContract, ColumnBindContext } from '../../types';
import { PGTimeColumn } from '../postgre/pg-time-column';
export declare class TimeOnlyColumn extends PGTimeColumn {
    static readonly columnType = "timeOnly";
    static readonly group = "dateTime";
    static _aliases: readonly ['time'];
    static enforcesBeyondPgType: boolean;
    /**
     * `to_char(col, 'HH24:MI:SS')::time` is Postgres' own ISO time input
     * form, so the projected text casts back to the stored time of day.
     */
    static castRecoversStoredValue: boolean;
    static get availableRules(): readonly ['minTime', 'maxTime'];
    /** Canonicalizes to `HH:MM:SS` via the wire codec. */
    get inputSchema(): z.ZodType;
    bind(ctx: Pick<ColumnBindContext, 'resolution'>): BoundColumnContract;
    get projectedPgType(): string | null;
}
