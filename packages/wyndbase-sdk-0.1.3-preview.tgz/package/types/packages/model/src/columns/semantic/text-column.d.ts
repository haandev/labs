import { PGTextColumn } from '../postgre/pg-text-column';
export declare class TextColumn extends PGTextColumn {
    static readonly columnType = "text";
    static readonly group = "text";
    static get metadataSchema(): import("zod").ZodObject<{
        readonly [x: string]: import("zod/v4/core").$ZodType<unknown, unknown, import("zod/v4/core").$ZodTypeInternals<unknown, unknown>>;
        inputMask: import("zod").ZodOptional<import("zod").ZodNullable<import("zod").ZodString>>;
    }, import("zod/v4/core").$strip>;
    static get availableRules(): readonly ['minLength', 'maxLength', 'lengthBetween', 'alphaOnly', 'alphaWithSpaceOnly', 'alphanumericOnly', 'alphanumericWithSpaceOnly', 'noWhitespace', 'noSpecialChar', 'mustStartWith', 'cannotStartWith', 'mustInclude', 'exclude', 'regex'];
}
