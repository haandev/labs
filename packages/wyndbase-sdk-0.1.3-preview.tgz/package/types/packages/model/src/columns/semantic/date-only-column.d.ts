import type { z } from 'zod';
import type { BoundColumnContract, ColumnBindContext } from '../../types';
import { PGDateColumn } from '../postgre/pg-date-column';
export declare class DateOnlyColumn extends PGDateColumn {
    static readonly columnType = "dateOnly";
    static readonly group = "dateTime";
    static enforcesBeyondPgType: boolean;
    static castRecoversStoredValue: boolean;
    static _aliases: readonly ['date-only', 'date'];
    static get availableRules(): readonly ['minDate', 'maxDate', 'dateformula'];
    get inputSchema(): z.ZodType;
    bind(ctx: Pick<ColumnBindContext, 'resolution'>): BoundColumnContract;
    get projectedPgType(): string | null;
}
