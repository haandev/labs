import type { ColumnNode } from '../../types';
/** The two members of the link family, named here so nothing re-spells them. */
export declare const LINK_COLUMN_TYPE = "link";
export declare const POLY_LINK_COLUMN_TYPE = "polyLink";
/**
 * A link that names its target table per row rather than declaring one at
 * model time.
 */
export declare function isPolyLinkColumn(col: ColumnNode | null | undefined): boolean;
/** The by-name form, for callers holding a bare discriminator string. */
export declare function isLinkColumnType(type: string | null | undefined): boolean;
/**
 * Both members of the family — the question "is this a relation", as opposed
 * to "is this a link with one declared target", which is `LinkColumn.is`.
 */
export declare function isAnyLinkColumn(col: ColumnNode | null | undefined): boolean;
/** `metadata.canHaveMultiple` — a link that holds more than one target. */
export declare function isMultiLink(col: ColumnNode): boolean;
/**
 * The candidate set of an `allowsAnyTable` polymorphic link is every table that
 * opted into being pointed at. One predicate, so the read path and the picker
 * that offers the tables cannot disagree about what is a candidate.
 */
export declare function isAnyTablePolyCandidate(node: {
    type?: string;
    metadata?: Record<string, unknown> | null;
}): boolean;
/**
 * `_id` holds a lineage identity (`_originId` when the target is versioned,
 * `_id` otherwise) and so is a uuid; `_ref` names the target table.
 */
export declare const POLY_REF_TYPE = "poly_ref";
export declare const POLY_REF_SCHEMA = "public";
/**
 * The spelling to emit. The bare name resolves only where `public` is on the
 * executing connection's `search_path`, and the driver narrows it to `system`
 * alone — see `systemSpaceHooks.afterCreate`. Neither DDL nor a compiled
 * statement can know which state it will run under, so both qualify.
 */
export declare const POLY_REF_QUALIFIED_TYPE = "public.poly_ref";
/** A multi-valued polymorphic link stores an array of the composite. */
export declare const POLY_REF_ARRAY_TYPE = "poly_ref[]";
export declare const POLY_REF_QUALIFIED_ARRAY_TYPE = "public.poly_ref[]";
/**
 * `qualified` picks the SPELLING, never the type. Pass it: see
 * `POLY_REF_QUALIFIED_TYPE` for why the bare name is not safe to emit.
 */
export declare function polyRefPgType(col: ColumnNode, opts?: {
    qualified?: boolean;
}): string;
