import type { BoundColumnContract, ColumnBindContext } from '../../types';
import { PGByteaColumn } from '../postgre/pg-bytea-column';
export declare class BinaryColumn extends PGByteaColumn {
    static readonly columnType = "binary";
    static readonly group = "misc";
    bind(ctx: Pick<ColumnBindContext, 'resolution'>): BoundColumnContract;
    get projectedPgType(): string | null;
}
