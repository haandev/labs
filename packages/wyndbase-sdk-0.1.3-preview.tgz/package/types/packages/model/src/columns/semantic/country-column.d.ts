import { z } from 'zod';
import type { ColumnNode } from '../../types';
import { PGJsonbColumn } from '../postgre/pg-jsonb-column';
export declare class CountryColumn extends PGJsonbColumn {
    static readonly columnType = "country";
    static readonly group = "internationalization";
    static isMulti(col: ColumnNode): boolean;
    get isMulti(): boolean;
    static get metadataSchema(): z.ZodObject<{
        readonly [x: string]: z.core.$ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>;
        readonly [x: number]: z.core.$ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>;
        allowedCountries: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodEnum<{
            [x: string]: string;
        }>>>>;
        isMultiSelect: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            no: "no";
            yes: "yes";
        }>>>;
        notAllowedCountries: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodEnum<{
            [x: string]: string;
        }>>>>;
    }, z.core.$strip>;
    /**
     * Filter literals must be JSON-encoded (`"TR"`) since countries are stored
     * as jsonb; validated against the enum first so a bad code is a stable 400.
     */
    get filterLiteralSchema(): z.ZodType;
    get outputSchema(): z.ZodType;
}
