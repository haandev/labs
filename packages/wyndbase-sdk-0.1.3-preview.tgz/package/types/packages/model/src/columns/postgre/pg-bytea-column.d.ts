import { z } from 'zod';
import type { FilterOperator } from '../../types';
import { BaseColumn } from '../base-column';
export declare class PGByteaColumn extends BaseColumn {
    static _aliases: readonly string[];
    static readonly pgType = "bytea";
    /** Base Zod type: binary data represented as a base64/hex string. */
    static readonly zodSchema: z.ZodString;
    static get availableOperations(): readonly FilterOperator[];
    static get availableSummaryTypes(): readonly ['count'];
}
