import { z } from 'zod';
import { type JsonSchemaPathStep } from '../../utils/json-schema-walk';
import { PGJsonbColumn } from '../postgre/pg-jsonb-column';
/**
 * A single SQL-emission step through a JSONB path. Field steps carry the
 * text key; index steps carry a pre-rendered SQL snippet for the index
 * expression (literal, parameter, or any WQL expression the generator
 * has already produced). Kept here rather than inside `@wyndb/wql-sql`
 * because `JsonbColumn.resolveFieldPathSql` needs to consume it and
 * `@wyndb/models` must not depend on `wql-sql`.
 */
export type JsonbResolvedPathStep = {
    kind: 'field';
    name: string;
} | {
    kind: 'index';
    sql: string;
};
/**
 * Semantic JSONB column with optional JSON Schema metadata for type inference.
 *
 * When `metadata.schema` is provided (JSON Schema format), `outputSchema`
 * returns a typed Zod schema instead of `z.unknown()`. This enables
 * proper TypeScript generation for JSONB column query results.
 *
 * Without `metadata.schema`, behaves identically to PGJsonbColumn.
 *
 * `getFieldSchema` and `resolveFieldSql` implement Faz 1 of native JSONB
 * field access: single-level object-key lookup against the column's
 * JSON Schema. The generator and schema-inference sides both rely on
 * these to produce typed `("col" ->> 'key')::cast` SQL and matching Zod
 * output types. Nested paths and bracket subscripts arrive in Faz 2/3.
 */
export declare class JsonbColumn extends PGJsonbColumn {
    static readonly columnType: 'jsonb';
    static readonly group: 'data';
    static get metadataSchema(): z.ZodObject<{
        readonly [x: string]: z.core.$ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>;
        schema: z.ZodOptional<z.ZodNullable<z.ZodRecord<z.ZodString, z.ZodUnknown>>>;
    }, z.core.$strip>;
    /**
     * Output schema: when `metadata.schema` (JSON Schema) is provided, converts it to a
     * typed Zod schema and applies array/nullable wrappers based on column constraints.
     * Follows the base-column convention: array -> z.array(), nullable -> z.nullable().
     * Falls back to the PGJsonbColumn base behavior (`z.unknown()` + standard wrapping) otherwise.
     */
    get outputSchema(): z.ZodType;
    /**
     * Writes are validated against the same contract reads are typed with —
     * a declared `metadata.schema` is enforced, not advisory. Unsupported
     * schemas degrade to `z.unknown()` inside `jsonSchemaToZod`, so a
     * contract the runtime cannot model never rejects a write.
     */
    get inputSchema(): z.ZodType;
    /**
     * Infer the Zod type for a single-level JSONB object-key access like
     * `jsonbCol.field`. Implemented as a delegation to `getFieldPathSchema`
     * so every path-depth gets the same JSON Schema walk and nullability
     * logic without duplicated code.
     *
     * This method remains in place because the existing `inferLinkPathType`
     * loop checks `col.getFieldSchema` as the hook for dot-notation access
     * on Choice/File/Range/JSONB columns. The two-segment projection case
     * (`jsonbCol.field`) therefore lands here.
     */
    getFieldSchema(fieldName: string): z.ZodType | undefined;
    /**
     * Infer the Zod type for an arbitrary JSONB path — any mix of object
     * fields and array indices (Faz 1 through Faz 3).
     *
     *   - If every object-field step is listed in its parent's `required`
     *     array, the leaf type is returned unwrapped.
     *   - If any field step along the path is optional, the leaf type is
     *     wrapped in `z.nullable(...)` because the full expression could be
     *     NULL at runtime.
     *   - Array index steps never contribute to nullability here (JSON
     *     Schema has no per-index required declaration; out-of-bounds
     *     access is a runtime concern).
     *   - If the schema does not describe the full path, falls back to
     *     `z.unknown()` so typegen emits a permissive type rather than an
     *     incorrect one.
     */
    getFieldPathSchema(path: readonly JsonSchemaPathStep[]): z.ZodType | undefined;
    /**
     * Generate PostgreSQL SQL for a single-level JSONB field extraction.
     * Preserved for callers that still have only a single field name on
     * hand. Internally defers to `resolveFieldPathSql` with a single
     * field step so the cast selection and operator chaining live in one
     * place.
     */
    resolveFieldSql(colRef: string, fieldName: string): string;
    /**
     * Generate PostgreSQL SQL for an arbitrary JSONB path — any mix of
     * object-field and array-index steps.
     *
     * Every step except the last uses the `->` operator (preserves JSONB).
     * The last step switches to `->>` for scalar leaves and stays `->`
     * for object/array/unknown leaves. Leaf casts (`::numeric`,
     * `::bigint`, `::boolean`) come from the JSON Schema walk:
     *
     *   JSON type    | op   | cast
     *   -------------|------|-----------
     *   number       | ->>  | ::numeric
     *   integer      | ->>  | ::bigint
     *   boolean      | ->>  | ::boolean
     *   string       | ->>  | (none)
     *   object/array | ->   | (none)
     *   unknown/none | ->   | (none)
     *
     * Example shapes:
     *
     *     metadata.type                   → ("t1"."metadata" ->> 'type')
     *     items[0]                        → "t1"."items" -> 0
     *     items[0].field                  → ("t1"."items" -> 0) ->> 'field'
     *     metadata.a.b.c (string leaf)    → (("t1"."metadata" -> 'a') -> 'b') ->> 'c'
     *     tree.nodes[$i].label (string)   → (("t1"."tree" -> 'nodes') -> ($1)::int) ->> 'label'
     *
     * `colRef` is the caller-rendered table-qualified column reference
     * (e.g. `"t1"."metadata"`). Index steps carry a pre-rendered SQL
     * snippet — callers are responsible for producing that SQL and for
     * casting parameters to `int` when the index is not a raw literal.
     */
    resolveFieldPathSql(colRef: string, path: readonly JsonbResolvedPathStep[]): string;
}
