import type { z } from 'zod';
import type { ArrayProjectionAggregate } from '../../utils/array-projection';
import { PGTsrangeColumn } from '../postgre/pg-tsrange-column';
export declare class MonthYearColumn extends PGTsrangeColumn {
    static readonly columnType = "monthYear";
    static readonly group = "dateTime";
    static _aliases: readonly ['monthyear'];
    static enforcesBeyondPgType: boolean;
    static writeSchemaIgnoresStoredLiteral: boolean;
    static get metadataSchema(): z.ZodObject<{
        readonly [x: string]: z.core.$ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>;
        readonly [x: number]: z.core.$ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>;
    }, z.core.$strip>;
    static get availableRules(): readonly ['minMonth', 'maxMonth'];
    /**
     * Anchors the write value to a calendar-month `tsrange` literal via the
     * wire codec (`YYYY-MM` → `[…,…)`). Read == write: the projection emits `YYYY-MM`.
     */
    get rangeInputCellSchema(): z.ZodType;
    /** The projection emits one `YYYY-MM` text, not a `[lower, upper]` pair. */
    get rangeProjectionAggregate(): ArrayProjectionAggregate;
    rangeElementExpr(ref: string): string;
    get projectedPgType(): string | null;
}
