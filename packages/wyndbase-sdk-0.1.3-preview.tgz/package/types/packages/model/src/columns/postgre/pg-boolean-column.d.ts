import { z } from 'zod';
import type { FilterOperator } from '../../types';
import { BaseColumn } from '../base-column';
export declare class PGBooleanColumn extends BaseColumn {
    static _aliases: readonly string[];
    static readonly pgType = "boolean";
    /** Base Zod type: boolean values. */
    static readonly zodSchema: z.ZodBoolean;
    static get availableOperations(): readonly FilterOperator[];
    static get availableSummaryTypes(): readonly ['count'];
}
