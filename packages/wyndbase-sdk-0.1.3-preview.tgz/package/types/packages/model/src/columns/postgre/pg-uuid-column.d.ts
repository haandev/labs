import { z } from 'zod';
import type { FilterOperator } from '../../types';
import { BaseColumn } from '../base-column';
/** A stored row id that is not a link: no navigation, the value outlives its referent. */
export declare class PGUuidColumn extends BaseColumn {
    static readonly pgType = "uuid";
    static _aliases: readonly string[];
    static get zodSchema(): z.ZodType;
    static get availableOperations(): readonly FilterOperator[];
    static get availableSummaryTypes(): readonly string[];
}
