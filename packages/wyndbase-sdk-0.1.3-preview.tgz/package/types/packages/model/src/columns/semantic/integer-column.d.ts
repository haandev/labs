import { PGIntegerColumn } from '../postgre/pg-integer-column';
export declare class IntegerColumn extends PGIntegerColumn {
    static readonly columnType = "integer";
    static readonly group = "numeric";
    static get availableRules(): readonly ['intMin', 'intMax', 'intBetween'];
}
