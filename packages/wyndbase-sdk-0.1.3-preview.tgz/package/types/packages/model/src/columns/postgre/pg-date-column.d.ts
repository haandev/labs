import { z } from 'zod';
import type { FilterOperator } from '../../types';
import { BaseColumn } from '../base-column';
export declare class PGDateColumn extends BaseColumn {
    static readonly pgType = "date";
    /** Base Zod type: date as ISO string (e.g. "2024-01-15"). */
    static readonly zodSchema: z.ZodString;
    static supportsDataMask: boolean;
    static get availableOperations(): readonly FilterOperator[];
    static get availableSummaryTypes(): readonly ['min', 'max', 'count'];
}
