import { z } from 'zod';
import type { FilterOperator } from '../../types';
import { BaseColumn } from '../base-column';
export declare class PGBigserialColumn extends BaseColumn {
    static _aliases: readonly string[];
    static readonly pgType = "bigserial";
    /** Base Zod type: auto-incrementing big integer validated by `z.int()`. */
    static readonly zodSchema: z.ZodInt;
    static get availableOperations(): readonly FilterOperator[];
    static get availableSummaryTypes(): readonly ['sum', 'avg', 'min', 'max', 'count', 'stddev', 'stddev_pop', 'stddev_samp', 'variance', 'var_pop', 'var_samp', 'corr', 'covar_pop', 'covar_samp'];
}
