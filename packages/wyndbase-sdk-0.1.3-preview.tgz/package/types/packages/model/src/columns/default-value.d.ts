import type { BaseColumn } from './base-column';
export type ColumnDefaultResolution = {
    ok: true;
    value: unknown;
} | {
    ok: false;
    message: string;
};
/**
 * A column's default, validated through `column.inputSchema` so it can't
 * accept a value the column's own write path would refuse.
 */
export declare function resolveColumnDefault(column: BaseColumn): ColumnDefaultResolution;
