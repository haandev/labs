import { PGRangeColumn } from './pg-range-column';
export declare class PGNumrangeColumn extends PGRangeColumn {
    static readonly pgType = "numrange";
    static _aliases: string[];
    readonly boundMetadataType = "number";
}
