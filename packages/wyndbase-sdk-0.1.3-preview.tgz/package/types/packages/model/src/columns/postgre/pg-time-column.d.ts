import { z } from 'zod';
import type { FilterOperator } from '../../types';
import { BaseColumn } from '../base-column';
export declare class PGTimeColumn extends BaseColumn {
    static readonly pgType = "time";
    /** Base Zod type: time-of-day as string (e.g. "14:30:00"). */
    static readonly zodSchema: z.ZodString;
    static supportsDataMask: boolean;
    static get availableOperations(): readonly FilterOperator[];
    static get availableSummaryTypes(): readonly ['min', 'max', 'count'];
}
