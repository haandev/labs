import type { z } from 'zod';
import type { WynModelTree } from '../model-tree';
import type { ColumnNode, TableNode } from '../types';
import type { BaseColumn } from './base-column';
import { PGBigserialColumn, PGBooleanColumn, PGByteaColumn, PGDateColumn, PGDaterangeColumn, PGFloatColumn, PGIntegerColumn, PGJsonColumn, PGNumrangeColumn, PGTextColumn, PGTimeColumn, PGTimestampColumn, PGTimestamptzColumn, PGTsrangeColumn, PGTstzrangeColumn, PGUuidColumn } from './postgre';
import { BinaryColumn, BooleanColumn, ChoiceColumn, CountryColumn, DateOnlyColumn, DateRangeColumn, DatetimeColumn, DatetimeZonedColumn, DecimalColumn, EmailColumn, FileColumn, FormulaColumn, FSMColumn, IntegerColumn, JsonbColumn, JsonColumn, LinkColumn, LongTextColumn, MarkdownColumn, MonthYearColumn, MonthYearZonedColumn, NumberColumn, NumberRangeColumn, PhoneColumn, PolyLinkColumn, TextColumn, TimeOnlyColumn, TimeRangeColumn, ZonedTimeRangeColumn } from './semantic';
export interface ColumnConstructor {
    new (col: ColumnNode, model: WynModelTree): BaseColumn;
    readonly name: string;
    /** The registered type name — what a `ColumnNode`'s `metadata.type` holds. */
    readonly columnType: string;
    readonly pgType: string;
    physicalPgType(col: ColumnNode): string;
    readonly aliases: readonly string[];
    readonly zodSchema: z.ZodType;
    readonly enforcesBeyondPgType: boolean;
    /** @see BaseColumn.writeSchemaIgnoresStoredLiteral */
    readonly writeSchemaIgnoresStoredLiteral: boolean;
    /** @see BaseColumn.supportsBulkEach */
    readonly supportsBulkEach: boolean;
    readonly castRecoversStoredValue: boolean;
    /** @see BaseColumn.writeValueSql */
    readonly writeValueSql?: (col: ColumnNode, paramRef: string) => string;
    /** @see BaseColumn.searchTextExpr */
    searchTextExpr(colRef: string, isArray?: boolean | null): string;
    /** @see BaseColumn.indexesStorage */
    indexesStorage(col: ColumnNode): boolean;
    /** @see BaseColumn.indexExpression */
    indexExpression(colRef: string): string;
    is(col: ColumnNode): boolean;
    deriveIsArray(col: ColumnNode): boolean;
}
export declare const columnRegistry: {
    readonly BinaryColumn: typeof BinaryColumn;
    readonly BooleanColumn: typeof BooleanColumn;
    readonly ChoiceColumn: typeof ChoiceColumn;
    readonly CountryColumn: typeof CountryColumn;
    readonly DateOnlyColumn: typeof DateOnlyColumn;
    readonly DateRangeColumn: typeof DateRangeColumn;
    readonly DatetimeColumn: typeof DatetimeColumn;
    readonly DatetimeZonedColumn: typeof DatetimeZonedColumn;
    readonly DecimalColumn: typeof DecimalColumn;
    readonly EmailColumn: typeof EmailColumn;
    readonly FileColumn: typeof FileColumn;
    readonly FormulaColumn: typeof FormulaColumn;
    readonly FSMColumn: typeof FSMColumn;
    readonly IntegerColumn: typeof IntegerColumn;
    readonly JsonbColumn: typeof JsonbColumn;
    readonly JsonColumn: typeof JsonColumn;
    readonly LinkColumn: typeof LinkColumn;
    readonly LongTextColumn: typeof LongTextColumn;
    readonly MarkdownColumn: typeof MarkdownColumn;
    readonly MonthYearColumn: typeof MonthYearColumn;
    readonly MonthYearZonedColumn: typeof MonthYearZonedColumn;
    readonly NumberColumn: typeof NumberColumn;
    readonly NumberRangeColumn: typeof NumberRangeColumn;
    readonly PGBigserialColumn: typeof PGBigserialColumn;
    readonly PGBooleanColumn: typeof PGBooleanColumn;
    readonly PGByteaColumn: typeof PGByteaColumn;
    readonly PGDateColumn: typeof PGDateColumn;
    readonly PGDaterangeColumn: typeof PGDaterangeColumn;
    readonly PGFloatColumn: typeof PGFloatColumn;
    readonly PGIntegerColumn: typeof PGIntegerColumn;
    readonly PGJsonColumn: typeof PGJsonColumn;
    readonly PGNumrangeColumn: typeof PGNumrangeColumn;
    readonly PGTextColumn: typeof PGTextColumn;
    readonly PGTimeColumn: typeof PGTimeColumn;
    readonly PGTimestampColumn: typeof PGTimestampColumn;
    readonly PGTimestamptzColumn: typeof PGTimestamptzColumn;
    readonly PGTsrangeColumn: typeof PGTsrangeColumn;
    readonly PGTstzrangeColumn: typeof PGTstzrangeColumn;
    readonly PGUuidColumn: typeof PGUuidColumn;
    readonly PhoneColumn: typeof PhoneColumn;
    readonly PolyLinkColumn: typeof PolyLinkColumn;
    readonly TextColumn: typeof TextColumn;
    readonly TimeOnlyColumn: typeof TimeOnlyColumn;
    readonly TimeRangeColumn: typeof TimeRangeColumn;
    readonly ZonedTimeRangeColumn: typeof ZonedTimeRangeColumn;
};
export type RegisteredColumnClass = (typeof columnRegistry)[keyof typeof columnRegistry];
/**
 * The single discriminator for "internal column type". Do NOT re-derive it from
 * the `pg-` name prefix — the prefix is a formatting detail, the group is intent.
 */
export declare const INTERNAL_COLUMN_GROUP = "native";
export declare const isInternalColumnClass: (cls: {
    group: string;
}) => boolean;
/** Unknown types return `false` — they are rejected elsewhere with a clearer error. */
export declare const isInternalColumnType: (columnType: string) => boolean;
/**
 * `ModelSchema` must keep accepting `pg-*` so legacy columns stay editable,
 * so only a caller holding the current type can decide this — not Zod.
 */
export declare const internalColumnTypeRejection: (params: {
    columnName?: string | null;
    currentType?: string | null;
    nextType?: string | null;
}) => string | null;
export declare const userFacingColumns: () => RegisteredColumnClass[];
/** Exported so callers holding only a `metadata.type` string can reach the class. */
export declare const columnMap: Map<string, ColumnConstructor>;
export declare function getColumnConstructor(col: ColumnNode): ColumnConstructor;
export declare function getColumn(table: TableNode, name: string, model: WynModelTree): BaseColumn | null;
export declare function getColumnInstance(col: ColumnNode, model: WynModelTree): BaseColumn;
/**
 * The column's searchable-text expression with its arrayness already bound, so
 * no caller re-derives either half.
 */
export declare const searchTextExprFor: (col: ColumnNode) => ((colRef: string) => string);
/** Whether the column's own class marks its stored value as always indexed. */
export declare const indexesStorageFor: (col: ColumnNode) => boolean;
/** The column's indexed expression, as SQL over the reference passed in. */
export declare const indexExprFor: (col: ColumnNode) => ((colRef: string) => string);
