import type { z } from 'zod';
import type { ColumnNode } from '../../types';
import { ColumnMetadataBaseSchema } from '../../types/column-metadata';
import { PGNumericColumn } from '../postgre/pg-numeric-column';
export declare const DECIMAL_DEFAULT_PRECISION = 38;
export declare const DECIMAL_DEFAULT_SCALE = 2;
export declare class DecimalColumn extends PGNumericColumn {
    static readonly columnType = "decimal";
    static _aliases: readonly string[];
    static readonly group = "numeric";
    /** Scale overflow must reject, not round — a ledger drifts silently otherwise. */
    static enforcesBeyondPgType: boolean;
    /**
     * Inline literals must hit the same scale gate as parameters — a constant
     * compiled straight into SQL would let PG round to the column scale silently.
     */
    static readonly normalizesInlineLiterals = true;
    static get availableRules(): readonly ['numberMin', 'numberMax', 'numberBetween'];
    static get metadataSchema(): z.ZodObject<{
        readonly [x: string]: z.core.$ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>;
        precision: z.ZodOptional<z.ZodNullable<z.ZodInt>>;
        scale: z.ZodOptional<z.ZodNullable<z.ZodInt>>;
    }, z.core.$strip>;
    protected static calculateMetadataSchema(options?: {
        dynamic?: boolean;
    }): typeof ColumnMetadataBaseSchema;
    static physicalPgType(col: ColumnNode): string;
    static boundedSchema(col: ColumnNode): z.ZodType;
    get inputSchema(): z.ZodType;
}
