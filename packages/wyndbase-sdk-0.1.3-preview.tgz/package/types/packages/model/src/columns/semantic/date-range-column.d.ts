import { z } from 'zod';
import { PGDaterangeColumn } from '../postgre/pg-daterange-column';
export declare class DateRangeColumn extends PGDaterangeColumn {
    static readonly columnType = "daterange";
    static readonly group = "dateTime";
    static enforcesBeyondPgType: boolean;
    static writeSchemaIgnoresStoredLiteral: boolean;
    static get metadataSchema(): z.ZodObject<{
        readonly [x: string]: z.core.$ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>;
        allowOpenEnd: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        allowOpenStart: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    }, z.core.$strip>;
    static get availableRules(): readonly ['maxDurationDays', 'maxEndDate', 'minStartDate', 'disallowFuture', 'disallowPast'];
    /**
     * A default is written as the `[start, end]` wire tuple, same as a cell
     * value, not the raw `daterange` literal.
     */
    static get defaultValueSchema(): z.ZodType;
    /**
     * An open bound (`null` on the wire) is accepted only when this
     * column's `allowOpenStart`/`allowOpenEnd` permits it.
     */
    get rangeInputCellSchema(): z.ZodType;
    get rangeOutputCellSchema(): z.ZodType;
    rangeElementExpr(ref: string): string;
    get projectedPgType(): string | null;
}
