/**
 * The semantic column type name, as it appears in `metadata.type`. It happens
 * to equal the PostgreSQL type name below today; nothing should rely on that.
 */
export declare const MARKDOWN_COLUMN_TYPE = "markdown";
/** The PostgreSQL composite type's name. */
export declare const MARKDOWN_TYPE = "markdown";
/**
 * `public` because it is on PostgreSQL's default `search_path`, which the
 * compiler's unqualified casts rely on — the same reason `poly_ref` lives there.
 */
export declare const MARKDOWN_SCHEMA = "public";
/**
 * DDL must use this: base initialisation runs under `SET search_path = system`,
 * where a bare `markdown` does not resolve.
 */
export declare const MARKDOWN_QUALIFIED_TYPE = "public.markdown";
