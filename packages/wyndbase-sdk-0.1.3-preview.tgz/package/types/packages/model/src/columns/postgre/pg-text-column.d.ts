import { z } from 'zod';
import type { FilterOperator } from '../../types';
import { BaseColumn } from '../base-column';
export declare class PGTextColumn extends BaseColumn {
    static pgType: string;
    /**
     * Declared as `z.ZodType` (not `z.string()`) so subclasses like `ChoiceColumn`
     * can widen it to a union without breaking the static-side variance check.
     */
    static readonly zodSchema: z.ZodType;
    static supportsDataMask: boolean;
    static get metadataSchema(): z.ZodObject<z.ZodRawShape>;
    static get availableOperations(): readonly FilterOperator[];
    static get availableSummaryTypes(): readonly string[];
}
