import { PGBooleanColumn } from '../postgre/pg-boolean-column';
export declare class BooleanColumn extends PGBooleanColumn {
    static readonly columnType = "boolean";
    static readonly group = "basic";
}
