import { z } from 'zod';
import type { FilterOperator } from '../../types';
import { BaseColumn } from '../base-column';
export declare class PGIntegerColumn extends BaseColumn {
    static _aliases: readonly string[];
    static readonly pgType = "integer";
    /** Base Zod type: integer values validated by `z.int()`. */
    static readonly zodSchema: z.ZodInt;
    static supportsDataMask: boolean;
    static get availableOperations(): readonly FilterOperator[];
    static get availableSummaryTypes(): string[];
}
