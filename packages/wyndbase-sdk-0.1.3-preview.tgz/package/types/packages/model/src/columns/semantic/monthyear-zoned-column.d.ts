import type { z } from 'zod';
import type { ArrayProjectionAggregate } from '../../utils/array-projection';
import { PGTstzrangeColumn } from '../postgre/pg-tstzrange-column';
export declare class MonthYearZonedColumn extends PGTstzrangeColumn {
    static readonly columnType = "monthyear-zoned";
    static readonly group = "dateTime";
    static enforcesBeyondPgType: boolean;
    static writeSchemaIgnoresStoredLiteral: boolean;
    static get metadataSchema(): z.ZodObject<{
        readonly [x: string]: z.core.$ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>;
        readonly [x: number]: z.core.$ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>;
    }, z.core.$strip>;
    static get availableRules(): readonly ['minMonth', 'maxMonth'];
    get rangeInputCellSchema(): z.ZodType;
    get rangeProjectionAggregate(): ArrayProjectionAggregate;
    rangeElementExpr(ref: string): string;
    get projectedPgType(): string | null;
}
