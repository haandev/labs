import { PGNumrangeColumn } from '../postgre/pg-numrange-column';
/**
 * The wire form is the raw PG range literal (`"[1,5)"`), not a
 * `[lower, upper]` tuple, so none of `PGRangeColumn`'s hooks apply here.
 */
export declare class NumberRangeColumn extends PGNumrangeColumn {
    static readonly columnType = "numberrange";
    static readonly group: 'numeric';
    static enforcesBeyondPgType: boolean;
    static get availableRules(): readonly ['numberMin', 'numberMax', 'numberBetween'];
}
