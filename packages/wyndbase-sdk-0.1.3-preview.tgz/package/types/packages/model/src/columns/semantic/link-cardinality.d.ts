import { z } from 'zod';
/**
 * High-level link cardinality, and its translation to the canonical storage
 * flags. Storage exposes two booleans — source-side `canHaveMultiple` and a
 * mirror's own `canHaveMultiple` — plus `targetTables[0].junctionTable` for
 * many-to-many. That shape is right for storage and unergonomic everywhere a
 * person or an agent picks a relationship, so both the MCP link tools and the
 * column editor speak this enum and translate here.
 *
 * One owner on purpose: the mapping was duplicated once and the two copies
 * silently disagreed about `one-to-many` versus `many-to-one`, which reached
 * production.
 *
 * Read source → target:
 *   - `one-to-one`   — both sides single.
 *   - `one-to-many`  — a source row holds many targets; the mirror is the
 *                      single reference on the target side.
 *   - `many-to-one`  — many source rows per target; the source holds the
 *                      single reference, the mirror is the collection.
 *   - `many-to-many` — both sides multi, through a junction table.
 *   - `self-ref`     — the target is the source table; the mirror is a
 *                      collection on that same table.
 */
export declare const linkCardinalitySchema: z.ZodEnum<{
    "many-to-many": "many-to-many";
    "many-to-one": "many-to-one";
    "one-to-many": "one-to-many";
    "one-to-one": "one-to-one";
    "self-ref": "self-ref";
}>;
export type LinkCardinality = z.infer<typeof linkCardinalitySchema>;
export type LinkCardinalityFlags = {
    sourceMulti: boolean;
    mirrorMulti: boolean;
    isManyToMany: boolean;
};
export declare function linkCardinalityFlags(c: LinkCardinality): LinkCardinalityFlags;
