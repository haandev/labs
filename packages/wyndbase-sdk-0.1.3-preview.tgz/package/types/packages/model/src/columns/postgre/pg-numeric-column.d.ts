import type { FilterOperator } from '../../types';
import { BaseColumn } from '../base-column';
export declare class PGNumericColumn extends BaseColumn {
    static readonly pgType = "numeric";
    /** Exact decimal wire values: strings on the wire, never a JS double. */
    static readonly zodSchema: import("zod").ZodCodec<import("zod").ZodUnion<readonly [import("zod").ZodString, import("zod").ZodNumber]>, import("zod").ZodString>;
    static supportsDataMask: boolean;
    static get availableOperations(): readonly FilterOperator[];
    static get availableSummaryTypes(): string[];
}
