import { z } from 'zod';
import type { BoundColumnContract, ColumnBindContext } from '../../types';
import { BaseColumn } from '../base-column';
/**
 * Virtual/computed column with no physical DB storage — the formula (WQL
 * expression) is expanded inline at query time by the WQL generator layer.
 */
export declare class FormulaColumn extends BaseColumn {
    static readonly columnType = "formula";
    static readonly group = "misc";
    static _aliases: readonly ['computed', 'calculated'];
    static readonly pgType: string;
    static get zodSchema(): z.ZodType;
    static get metadataSchema(): z.ZodObject<{
        readonly [x: string]: z.core.$ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>;
        formula: z.ZodString;
    }, z.core.$strip>;
    get isPseudo(): boolean;
    get formula(): string | null | undefined;
    /**
     * Output type is inferred from the expression body in the WQL layer
     * (`inferFormulaColumnType`); a direct call here is a bug, so throw.
     */
    get outputSchema(): z.ZodType;
    bind(ctx: Pick<ColumnBindContext, 'resolution' | 'formula'>): BoundColumnContract;
    get projectedPgType(): string | null;
}
