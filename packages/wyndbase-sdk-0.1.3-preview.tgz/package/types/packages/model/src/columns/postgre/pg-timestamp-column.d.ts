import { z } from 'zod';
import type { FilterOperator } from '../../types';
import { BaseColumn } from '../base-column';
export declare class PGTimestampColumn extends BaseColumn {
    static _aliases: readonly string[];
    static readonly pgType = "timestamp";
    /** Base Zod type: timestamp without timezone as ISO string. */
    static readonly zodSchema: z.ZodString;
    static supportsDataMask: boolean;
    static get availableOperations(): readonly FilterOperator[];
    static get availableSummaryTypes(): readonly ['min', 'max', 'count'];
}
