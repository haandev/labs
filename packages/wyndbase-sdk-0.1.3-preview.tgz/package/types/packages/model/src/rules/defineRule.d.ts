import type { TaggedLiteral } from '../../../shared/src/fragment';
import { z } from 'zod';
/** How a rule's predicate is installed in Postgres: `check` wraps it in a
 *  CHECK constraint re-evaluated on every row write; `onWrite` wraps it in a
 *  BEFORE trigger that runs only when the guarded cell is inserted or
 *  actually changes. */
export type RuleEnforcement = 'check' | 'onWrite';
export type RuleContext = {
    /** SQL reference to the validated value (column ref, or `value` inside an
     *  array-element trigger). */
    value: TaggedLiteral;
    /** Injected by the driver for rules whose arg is a WQL expression: compiles
     *  it to a SQL predicate over the written row. Absent outside the driver. */
    compileExpression?: (source: string) => Promise<string>;
};
export type DefinedRule = ReturnType<typeof defineRule>;
export declare const defineRule: <T extends z.ZodTuple | z.ZodUnion<[z.ZodTuple, z.ZodTuple]>, P extends z.infer<T>, N extends string>(options: {
    readonly name: N;
    readonly configSchema: T;
    readonly description?: string;
    readonly validator: (...params: NoInfer<P>) => z.ZodType;
    /** The single SQL source; `enforcement` picks the wrapper. */
    readonly predicate?: (ctx: RuleContext, ...params: NoInfer<P> & {
        length: number;
    }) => TaggedLiteral | undefined | Promise<TaggedLiteral | undefined>;
    readonly enforcement?: RuleEnforcement;
    /** Index of the arg holding a WQL expression the driver validates at DDL
     *  time (parse → shape checks → EXPLAIN probe). */
    readonly expressionArg?: number;
}) => {
    enforcement: RuleEnforcement;
    expressionArg: number | undefined;
    name: N;
    predicate: ((ctx: RuleContext, ...params: NoInfer<P> & {
        length: number;
    }) => TaggedLiteral | undefined | Promise<TaggedLiteral | undefined>) | undefined;
    schema: z.ZodObject<{
        args: T;
        name: z.ZodLiteral<N>;
    }, z.core.$strip>;
    validator: (...params: NoInfer<P>) => z.ZodType;
};
