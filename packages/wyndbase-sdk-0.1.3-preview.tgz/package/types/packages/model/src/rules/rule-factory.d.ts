export declare const ruleRegistry: {
    readonly allowedTimeWindow: {
        enforcement: import("./defineRule").RuleEnforcement;
        expressionArg: number | undefined;
        name: "allowedTimeWindow";
        predicate: ((ctx: import("./defineRule").RuleContext, ...params: NoInfer<[string, string]> & {
            length: number;
        }) => import("../../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodUnion<readonly [import("zod").ZodISODateTime, import("zod").ZodISOTime]>, import("zod").ZodUnion<readonly [import("zod").ZodISODateTime, import("zod").ZodISOTime]>], null>;
            name: import("zod").ZodLiteral<"allowedTimeWindow">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[string, string]>) => import("zod").ZodType;
    };
    readonly alphanumericOnly: {
        enforcement: import("./defineRule").RuleEnforcement;
        expressionArg: number | undefined;
        name: "alphanumericOnly";
        predicate: ((ctx: import("./defineRule").RuleContext, ...params: NoInfer<[]> & {
            length: number;
        }) => import("../../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[], null>;
            name: import("zod").ZodLiteral<"alphanumericOnly">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[]>) => import("zod").ZodType;
    };
    readonly alphanumericWithSpaceOnly: {
        enforcement: import("./defineRule").RuleEnforcement;
        expressionArg: number | undefined;
        name: "alphanumericWithSpaceOnly";
        predicate: ((ctx: import("./defineRule").RuleContext, ...params: NoInfer<[]> & {
            length: number;
        }) => import("../../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[], null>;
            name: import("zod").ZodLiteral<"alphanumericWithSpaceOnly">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[]>) => import("zod").ZodType;
    };
    readonly alphaOnly: {
        enforcement: import("./defineRule").RuleEnforcement;
        expressionArg: number | undefined;
        name: "alphaOnly";
        predicate: ((ctx: import("./defineRule").RuleContext, ...params: NoInfer<[]> & {
            length: number;
        }) => import("../../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[], null>;
            name: import("zod").ZodLiteral<"alphaOnly">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[]>) => import("zod").ZodType;
    };
    readonly alphaWithSpaceOnly: {
        enforcement: import("./defineRule").RuleEnforcement;
        expressionArg: number | undefined;
        name: "alphaWithSpaceOnly";
        predicate: ((ctx: import("./defineRule").RuleContext, ...params: NoInfer<[]> & {
            length: number;
        }) => import("../../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[], null>;
            name: import("zod").ZodLiteral<"alphaWithSpaceOnly">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[]>) => import("zod").ZodType;
    };
    readonly cannotStartWith: {
        enforcement: import("./defineRule").RuleEnforcement;
        expressionArg: number | undefined;
        name: "cannotStartWith";
        predicate: ((ctx: import("./defineRule").RuleContext, ...params: NoInfer<[string]> & {
            length: number;
        }) => import("../../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodString], null>;
            name: import("zod").ZodLiteral<"cannotStartWith">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[string]>) => import("zod").ZodType;
    };
    readonly dateformula: {
        enforcement: import("./defineRule").RuleEnforcement;
        expressionArg: number | undefined;
        name: "dateformula";
        predicate: ((ctx: import("./defineRule").RuleContext, ...params: NoInfer<[string]> & {
            length: number;
        }) => import("../../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodString], null>;
            name: import("zod").ZodLiteral<"dateformula">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[string]>) => import("zod").ZodType;
    };
    readonly disallowFuture: {
        enforcement: import("./defineRule").RuleEnforcement;
        expressionArg: number | undefined;
        name: "disallowFuture";
        predicate: ((ctx: import("./defineRule").RuleContext, ...params: NoInfer<[]> & {
            length: number;
        }) => import("../../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[], null>;
            name: import("zod").ZodLiteral<"disallowFuture">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[]>) => import("zod").ZodType;
    };
    readonly disallowPast: {
        enforcement: import("./defineRule").RuleEnforcement;
        expressionArg: number | undefined;
        name: "disallowPast";
        predicate: ((ctx: import("./defineRule").RuleContext, ...params: NoInfer<[]> & {
            length: number;
        }) => import("../../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[], null>;
            name: import("zod").ZodLiteral<"disallowPast">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[]>) => import("zod").ZodType;
    };
    readonly enforceDomain: {
        enforcement: import("./defineRule").RuleEnforcement;
        expressionArg: number | undefined;
        name: "enforceDomain";
        predicate: ((ctx: import("./defineRule").RuleContext, ...params: NoInfer<[string[]]> & {
            length: number;
        }) => import("../../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodArray<import("zod").ZodString>], null>;
            name: import("zod").ZodLiteral<"enforceDomain">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[string[]]>) => import("zod").ZodType;
    };
    readonly exclude: {
        enforcement: import("./defineRule").RuleEnforcement;
        expressionArg: number | undefined;
        name: "exclude";
        predicate: ((ctx: import("./defineRule").RuleContext, ...params: NoInfer<[string]> & {
            length: number;
        }) => import("../../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodString], null>;
            name: import("zod").ZodLiteral<"exclude">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[string]>) => import("zod").ZodType;
    };
    readonly excludeDomain: {
        enforcement: import("./defineRule").RuleEnforcement;
        expressionArg: number | undefined;
        name: "excludeDomain";
        predicate: ((ctx: import("./defineRule").RuleContext, ...params: NoInfer<[string[]]> & {
            length: number;
        }) => import("../../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodArray<import("zod").ZodString>], null>;
            name: import("zod").ZodLiteral<"excludeDomain">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[string[]]>) => import("zod").ZodType;
    };
    readonly intBetween: {
        enforcement: import("./defineRule").RuleEnforcement;
        expressionArg: number | undefined;
        name: "intBetween";
        predicate: ((ctx: import("./defineRule").RuleContext, ...params: NoInfer<[number, number]> & {
            length: number;
        }) => import("../../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodInt, import("zod").ZodInt], null>;
            name: import("zod").ZodLiteral<"intBetween">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[number, number]>) => import("zod").ZodType;
    };
    readonly intMax: {
        enforcement: import("./defineRule").RuleEnforcement;
        expressionArg: number | undefined;
        name: "intMax";
        predicate: ((ctx: import("./defineRule").RuleContext, ...params: NoInfer<[number]> & {
            length: number;
        }) => import("../../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodNumber], null>;
            name: import("zod").ZodLiteral<"intMax">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[number]>) => import("zod").ZodType;
    };
    readonly intMin: {
        enforcement: import("./defineRule").RuleEnforcement;
        expressionArg: number | undefined;
        name: "intMin";
        predicate: ((ctx: import("./defineRule").RuleContext, ...params: NoInfer<[number]> & {
            length: number;
        }) => import("../../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodInt], null>;
            name: import("zod").ZodLiteral<"intMin">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[number]>) => import("zod").ZodType;
    };
    readonly lengthBetween: {
        enforcement: import("./defineRule").RuleEnforcement;
        expressionArg: number | undefined;
        name: "lengthBetween";
        predicate: ((ctx: import("./defineRule").RuleContext, ...params: NoInfer<[number, number]> & {
            length: number;
        }) => import("../../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodInt, import("zod").ZodInt], null>;
            name: import("zod").ZodLiteral<"lengthBetween">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[number, number]>) => import("zod").ZodType;
    };
    readonly maxDate: {
        enforcement: import("./defineRule").RuleEnforcement;
        expressionArg: number | undefined;
        name: "maxDate";
        predicate: ((ctx: import("./defineRule").RuleContext, ...params: NoInfer<[string]> & {
            length: number;
        }) => import("../../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodString], null>;
            name: import("zod").ZodLiteral<"maxDate">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[string]>) => import("zod").ZodType;
    };
    readonly maxDateTime: {
        enforcement: import("./defineRule").RuleEnforcement;
        expressionArg: number | undefined;
        name: "maxDateTime";
        predicate: ((ctx: import("./defineRule").RuleContext, ...params: NoInfer<[string]> & {
            length: number;
        }) => import("../../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodString], null>;
            name: import("zod").ZodLiteral<"maxDateTime">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[string]>) => import("zod").ZodType;
    };
    readonly maxDuration: {
        enforcement: import("./defineRule").RuleEnforcement;
        expressionArg: number | undefined;
        name: "maxDuration";
        predicate: ((ctx: import("./defineRule").RuleContext, ...params: NoInfer<[number, string]> & {
            length: number;
        }) => import("../../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodNumber, import("zod").ZodString], null>;
            name: import("zod").ZodLiteral<"maxDuration">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[number, string]>) => import("zod").ZodType;
    };
    readonly maxDurationDays: {
        enforcement: import("./defineRule").RuleEnforcement;
        expressionArg: number | undefined;
        name: "maxDurationDays";
        predicate: ((ctx: import("./defineRule").RuleContext, ...params: NoInfer<[number]> & {
            length: number;
        }) => import("../../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodNumber], null>;
            name: import("zod").ZodLiteral<"maxDurationDays">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[number]>) => import("zod").ZodType;
    };
    readonly maxDurationTime: {
        enforcement: import("./defineRule").RuleEnforcement;
        expressionArg: number | undefined;
        name: "maxDurationTime";
        predicate: ((ctx: import("./defineRule").RuleContext, ...params: NoInfer<[number, string]> & {
            length: number;
        }) => import("../../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodNumber, import("zod").ZodString], null>;
            name: import("zod").ZodLiteral<"maxDurationTime">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[number, string]>) => import("zod").ZodType;
    };
    readonly maxEndDate: {
        enforcement: import("./defineRule").RuleEnforcement;
        expressionArg: number | undefined;
        name: "maxEndDate";
        predicate: ((ctx: import("./defineRule").RuleContext, ...params: NoInfer<[string]> & {
            length: number;
        }) => import("../../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodString], null>;
            name: import("zod").ZodLiteral<"maxEndDate">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[string]>) => import("zod").ZodType;
    };
    readonly maxEndDateTime: {
        enforcement: import("./defineRule").RuleEnforcement;
        expressionArg: number | undefined;
        name: "maxEndDateTime";
        predicate: ((ctx: import("./defineRule").RuleContext, ...params: NoInfer<[string]> & {
            length: number;
        }) => import("../../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodString], null>;
            name: import("zod").ZodLiteral<"maxEndDateTime">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[string]>) => import("zod").ZodType;
    };
    readonly maxLength: {
        enforcement: import("./defineRule").RuleEnforcement;
        expressionArg: number | undefined;
        name: "maxLength";
        predicate: ((ctx: import("./defineRule").RuleContext, ...params: NoInfer<[number]> & {
            length: number;
        }) => import("../../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodInt], null>;
            name: import("zod").ZodLiteral<"maxLength">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[number]>) => import("zod").ZodType;
    };
    readonly maxMonth: {
        enforcement: import("./defineRule").RuleEnforcement;
        expressionArg: number | undefined;
        name: "maxMonth";
        predicate: ((ctx: import("./defineRule").RuleContext, ...params: NoInfer<[string]> & {
            length: number;
        }) => import("../../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodUnion<readonly [import("zod").ZodString, import("zod").ZodISODateTime]>], null>;
            name: import("zod").ZodLiteral<"maxMonth">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[string]>) => import("zod").ZodType;
    };
    readonly maxTime: {
        enforcement: import("./defineRule").RuleEnforcement;
        expressionArg: number | undefined;
        name: "maxTime";
        predicate: ((ctx: import("./defineRule").RuleContext, ...params: NoInfer<[string]> & {
            length: number;
        }) => import("../../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodUnion<readonly [import("zod").ZodISODateTime, import("zod").ZodISOTime]>], null>;
            name: import("zod").ZodLiteral<"maxTime">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[string]>) => import("zod").ZodType;
    };
    readonly minDate: {
        enforcement: import("./defineRule").RuleEnforcement;
        expressionArg: number | undefined;
        name: "minDate";
        predicate: ((ctx: import("./defineRule").RuleContext, ...params: NoInfer<[string]> & {
            length: number;
        }) => import("../../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodString], null>;
            name: import("zod").ZodLiteral<"minDate">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[string]>) => import("zod").ZodType;
    };
    readonly minDateTime: {
        enforcement: import("./defineRule").RuleEnforcement;
        expressionArg: number | undefined;
        name: "minDateTime";
        predicate: ((ctx: import("./defineRule").RuleContext, ...params: NoInfer<[string]> & {
            length: number;
        }) => import("../../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodString], null>;
            name: import("zod").ZodLiteral<"minDateTime">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[string]>) => import("zod").ZodType;
    };
    readonly minLength: {
        enforcement: import("./defineRule").RuleEnforcement;
        expressionArg: number | undefined;
        name: "minLength";
        predicate: ((ctx: import("./defineRule").RuleContext, ...params: NoInfer<[number]> & {
            length: number;
        }) => import("../../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodInt], null>;
            name: import("zod").ZodLiteral<"minLength">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[number]>) => import("zod").ZodType;
    };
    readonly minMonth: {
        enforcement: import("./defineRule").RuleEnforcement;
        expressionArg: number | undefined;
        name: "minMonth";
        predicate: ((ctx: import("./defineRule").RuleContext, ...params: NoInfer<[string]> & {
            length: number;
        }) => import("../../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodUnion<readonly [import("zod").ZodString, import("zod").ZodISODateTime]>], null>;
            name: import("zod").ZodLiteral<"minMonth">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[string]>) => import("zod").ZodType;
    };
    readonly minStartDate: {
        enforcement: import("./defineRule").RuleEnforcement;
        expressionArg: number | undefined;
        name: "minStartDate";
        predicate: ((ctx: import("./defineRule").RuleContext, ...params: NoInfer<[string]> & {
            length: number;
        }) => import("../../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodString], null>;
            name: import("zod").ZodLiteral<"minStartDate">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[string]>) => import("zod").ZodType;
    };
    readonly minStartDateTime: {
        enforcement: import("./defineRule").RuleEnforcement;
        expressionArg: number | undefined;
        name: "minStartDateTime";
        predicate: ((ctx: import("./defineRule").RuleContext, ...params: NoInfer<[string]> & {
            length: number;
        }) => import("../../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodString], null>;
            name: import("zod").ZodLiteral<"minStartDateTime">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[string]>) => import("zod").ZodType;
    };
    readonly minTime: {
        enforcement: import("./defineRule").RuleEnforcement;
        expressionArg: number | undefined;
        name: "minTime";
        predicate: ((ctx: import("./defineRule").RuleContext, ...params: NoInfer<[string]> & {
            length: number;
        }) => import("../../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodUnion<readonly [import("zod").ZodISODateTime, import("zod").ZodISOTime]>], null>;
            name: import("zod").ZodLiteral<"minTime">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[string]>) => import("zod").ZodType;
    };
    readonly mustInclude: {
        enforcement: import("./defineRule").RuleEnforcement;
        expressionArg: number | undefined;
        name: "mustInclude";
        predicate: ((ctx: import("./defineRule").RuleContext, ...params: NoInfer<[string]> & {
            length: number;
        }) => import("../../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodString], null>;
            name: import("zod").ZodLiteral<"mustInclude">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[string]>) => import("zod").ZodType;
    };
    readonly mustStartWith: {
        enforcement: import("./defineRule").RuleEnforcement;
        expressionArg: number | undefined;
        name: "mustStartWith";
        predicate: ((ctx: import("./defineRule").RuleContext, ...params: NoInfer<[string]> & {
            length: number;
        }) => import("../../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodString], null>;
            name: import("zod").ZodLiteral<"mustStartWith">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[string]>) => import("zod").ZodType;
    };
    readonly noSpecialChar: {
        enforcement: import("./defineRule").RuleEnforcement;
        expressionArg: number | undefined;
        name: "noSpecialChar";
        predicate: ((ctx: import("./defineRule").RuleContext, ...params: NoInfer<[]> & {
            length: number;
        }) => import("../../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[], null>;
            name: import("zod").ZodLiteral<"noSpecialChar">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[]>) => import("zod").ZodType;
    };
    readonly noWhitespace: {
        enforcement: import("./defineRule").RuleEnforcement;
        expressionArg: number | undefined;
        name: "noWhitespace";
        predicate: ((ctx: import("./defineRule").RuleContext, ...params: NoInfer<[]> & {
            length: number;
        }) => import("../../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[], null>;
            name: import("zod").ZodLiteral<"noWhitespace">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[]>) => import("zod").ZodType;
    };
    readonly numberBetween: {
        enforcement: import("./defineRule").RuleEnforcement;
        expressionArg: number | undefined;
        name: "numberBetween";
        predicate: ((ctx: import("./defineRule").RuleContext, ...params: NoInfer<[number, number]> & {
            length: number;
        }) => import("../../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodNumber, import("zod").ZodNumber], null>;
            name: import("zod").ZodLiteral<"numberBetween">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[number, number]>) => import("zod").ZodType;
    };
    readonly numberMax: {
        enforcement: import("./defineRule").RuleEnforcement;
        expressionArg: number | undefined;
        name: "numberMax";
        predicate: ((ctx: import("./defineRule").RuleContext, ...params: NoInfer<[number]> & {
            length: number;
        }) => import("../../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodNumber], null>;
            name: import("zod").ZodLiteral<"numberMax">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[number]>) => import("zod").ZodType;
    };
    readonly numberMin: {
        enforcement: import("./defineRule").RuleEnforcement;
        expressionArg: number | undefined;
        name: "numberMin";
        predicate: ((ctx: import("./defineRule").RuleContext, ...params: NoInfer<[number]> & {
            length: number;
        }) => import("../../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodNumber], null>;
            name: import("zod").ZodLiteral<"numberMin">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[number]>) => import("zod").ZodType;
    };
    readonly regex: {
        enforcement: import("./defineRule").RuleEnforcement;
        expressionArg: number | undefined;
        name: "regex";
        predicate: ((ctx: import("./defineRule").RuleContext, ...params: NoInfer<[string, (string | null | undefined)?]> & {
            length: number;
        }) => import("../../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodString, import("zod").ZodOptional<import("zod").ZodNullable<import("zod").ZodString>>], null>;
            name: import("zod").ZodLiteral<"regex">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[string, (string | null | undefined)?]>) => import("zod").ZodType;
    };
};
export declare const schemaIndex: (import("zod").ZodObject<{
    args: import("zod").ZodTuple<[], null>;
    name: import("zod").ZodLiteral<"alphanumericOnly">;
}, import("zod/v4/core").$strip> | import("zod").ZodObject<{
    args: import("zod").ZodTuple<[import("zod").ZodString], null>;
    name: import("zod").ZodLiteral<"cannotStartWith">;
}, import("zod/v4/core").$strip> | import("zod").ZodObject<{
    args: import("zod").ZodTuple<[], null>;
    name: import("zod").ZodLiteral<"disallowFuture">;
}, import("zod/v4/core").$strip> | import("zod").ZodObject<{
    args: import("zod").ZodTuple<[import("zod").ZodArray<import("zod").ZodString>], null>;
    name: import("zod").ZodLiteral<"excludeDomain">;
}, import("zod/v4/core").$strip> | import("zod").ZodObject<{
    args: import("zod").ZodTuple<[import("zod").ZodInt, import("zod").ZodInt], null>;
    name: import("zod").ZodLiteral<"lengthBetween">;
}, import("zod/v4/core").$strip> | import("zod").ZodObject<{
    args: import("zod").ZodTuple<[import("zod").ZodNumber, import("zod").ZodString], null>;
    name: import("zod").ZodLiteral<"maxDuration">;
}, import("zod/v4/core").$strip> | import("zod").ZodObject<{
    args: import("zod").ZodTuple<[import("zod").ZodString], null>;
    name: import("zod").ZodLiteral<"maxEndDateTime">;
}, import("zod/v4/core").$strip> | import("zod").ZodObject<{
    args: import("zod").ZodTuple<[import("zod").ZodString], null>;
    name: import("zod").ZodLiteral<"minDate">;
}, import("zod/v4/core").$strip> | import("zod").ZodObject<{
    args: import("zod").ZodTuple<[import("zod").ZodString], null>;
    name: import("zod").ZodLiteral<"minStartDate">;
}, import("zod/v4/core").$strip> | import("zod").ZodObject<{
    args: import("zod").ZodTuple<[import("zod").ZodString], null>;
    name: import("zod").ZodLiteral<"mustStartWith">;
}, import("zod/v4/core").$strip> | import("zod").ZodObject<{
    args: import("zod").ZodTuple<[import("zod").ZodNumber, import("zod").ZodNumber], null>;
    name: import("zod").ZodLiteral<"numberBetween">;
}, import("zod/v4/core").$strip> | import("zod").ZodObject<{
    args: import("zod").ZodTuple<[], null>;
    name: import("zod").ZodLiteral<"alphaOnly">;
}, import("zod/v4/core").$strip> | import("zod").ZodObject<{
    args: import("zod").ZodTuple<[], null>;
    name: import("zod").ZodLiteral<"alphaWithSpaceOnly">;
}, import("zod/v4/core").$strip> | import("zod").ZodObject<{
    args: import("zod").ZodTuple<[], null>;
    name: import("zod").ZodLiteral<"alphanumericWithSpaceOnly">;
}, import("zod/v4/core").$strip> | import("zod").ZodObject<{
    args: import("zod").ZodTuple<[], null>;
    name: import("zod").ZodLiteral<"disallowPast">;
}, import("zod/v4/core").$strip> | import("zod").ZodObject<{
    args: import("zod").ZodTuple<[], null>;
    name: import("zod").ZodLiteral<"noSpecialChar">;
}, import("zod/v4/core").$strip> | import("zod").ZodObject<{
    args: import("zod").ZodTuple<[], null>;
    name: import("zod").ZodLiteral<"noWhitespace">;
}, import("zod/v4/core").$strip> | import("zod").ZodObject<{
    args: import("zod").ZodTuple<[import("zod").ZodArray<import("zod").ZodString>], null>;
    name: import("zod").ZodLiteral<"enforceDomain">;
}, import("zod/v4/core").$strip> | import("zod").ZodObject<{
    args: import("zod").ZodTuple<[import("zod").ZodInt], null>;
    name: import("zod").ZodLiteral<"intMin">;
}, import("zod/v4/core").$strip> | import("zod").ZodObject<{
    args: import("zod").ZodTuple<[import("zod").ZodInt], null>;
    name: import("zod").ZodLiteral<"maxLength">;
}, import("zod/v4/core").$strip> | import("zod").ZodObject<{
    args: import("zod").ZodTuple<[import("zod").ZodInt], null>;
    name: import("zod").ZodLiteral<"minLength">;
}, import("zod/v4/core").$strip> | import("zod").ZodObject<{
    args: import("zod").ZodTuple<[import("zod").ZodNumber], null>;
    name: import("zod").ZodLiteral<"intMax">;
}, import("zod/v4/core").$strip> | import("zod").ZodObject<{
    args: import("zod").ZodTuple<[import("zod").ZodNumber], null>;
    name: import("zod").ZodLiteral<"maxDurationDays">;
}, import("zod/v4/core").$strip> | import("zod").ZodObject<{
    args: import("zod").ZodTuple<[import("zod").ZodNumber], null>;
    name: import("zod").ZodLiteral<"numberMax">;
}, import("zod/v4/core").$strip> | import("zod").ZodObject<{
    args: import("zod").ZodTuple<[import("zod").ZodNumber], null>;
    name: import("zod").ZodLiteral<"numberMin">;
}, import("zod/v4/core").$strip> | import("zod").ZodObject<{
    args: import("zod").ZodTuple<[import("zod").ZodString], null>;
    name: import("zod").ZodLiteral<"dateformula">;
}, import("zod/v4/core").$strip> | import("zod").ZodObject<{
    args: import("zod").ZodTuple<[import("zod").ZodString], null>;
    name: import("zod").ZodLiteral<"exclude">;
}, import("zod/v4/core").$strip> | import("zod").ZodObject<{
    args: import("zod").ZodTuple<[import("zod").ZodString], null>;
    name: import("zod").ZodLiteral<"maxDate">;
}, import("zod/v4/core").$strip> | import("zod").ZodObject<{
    args: import("zod").ZodTuple<[import("zod").ZodString], null>;
    name: import("zod").ZodLiteral<"maxDateTime">;
}, import("zod/v4/core").$strip> | import("zod").ZodObject<{
    args: import("zod").ZodTuple<[import("zod").ZodString], null>;
    name: import("zod").ZodLiteral<"maxEndDate">;
}, import("zod/v4/core").$strip> | import("zod").ZodObject<{
    args: import("zod").ZodTuple<[import("zod").ZodString], null>;
    name: import("zod").ZodLiteral<"minDateTime">;
}, import("zod/v4/core").$strip> | import("zod").ZodObject<{
    args: import("zod").ZodTuple<[import("zod").ZodString], null>;
    name: import("zod").ZodLiteral<"minStartDateTime">;
}, import("zod/v4/core").$strip> | import("zod").ZodObject<{
    args: import("zod").ZodTuple<[import("zod").ZodString], null>;
    name: import("zod").ZodLiteral<"mustInclude">;
}, import("zod/v4/core").$strip> | import("zod").ZodObject<{
    args: import("zod").ZodTuple<[import("zod").ZodUnion<readonly [import("zod").ZodISODateTime, import("zod").ZodISOTime]>], null>;
    name: import("zod").ZodLiteral<"maxTime">;
}, import("zod/v4/core").$strip> | import("zod").ZodObject<{
    args: import("zod").ZodTuple<[import("zod").ZodUnion<readonly [import("zod").ZodISODateTime, import("zod").ZodISOTime]>], null>;
    name: import("zod").ZodLiteral<"minTime">;
}, import("zod/v4/core").$strip> | import("zod").ZodObject<{
    args: import("zod").ZodTuple<[import("zod").ZodUnion<readonly [import("zod").ZodString, import("zod").ZodISODateTime]>], null>;
    name: import("zod").ZodLiteral<"maxMonth">;
}, import("zod/v4/core").$strip> | import("zod").ZodObject<{
    args: import("zod").ZodTuple<[import("zod").ZodUnion<readonly [import("zod").ZodString, import("zod").ZodISODateTime]>], null>;
    name: import("zod").ZodLiteral<"minMonth">;
}, import("zod/v4/core").$strip> | import("zod").ZodObject<{
    args: import("zod").ZodTuple<[import("zod").ZodInt, import("zod").ZodInt], null>;
    name: import("zod").ZodLiteral<"intBetween">;
}, import("zod/v4/core").$strip> | import("zod").ZodObject<{
    args: import("zod").ZodTuple<[import("zod").ZodNumber, import("zod").ZodString], null>;
    name: import("zod").ZodLiteral<"maxDurationTime">;
}, import("zod/v4/core").$strip> | import("zod").ZodObject<{
    args: import("zod").ZodTuple<[import("zod").ZodString, import("zod").ZodOptional<import("zod").ZodNullable<import("zod").ZodString>>], null>;
    name: import("zod").ZodLiteral<"regex">;
}, import("zod/v4/core").$strip> | import("zod").ZodObject<{
    args: import("zod").ZodTuple<[import("zod").ZodUnion<readonly [import("zod").ZodISODateTime, import("zod").ZodISOTime]>, import("zod").ZodUnion<readonly [import("zod").ZodISODateTime, import("zod").ZodISOTime]>], null>;
    name: import("zod").ZodLiteral<"allowedTimeWindow">;
}, import("zod/v4/core").$strip>)[];
export declare const validatorCall: <T extends keyof typeof ruleRegistry>(ruleName: T, args: Parameters<(typeof ruleRegistry)[T]['validator']>) => import("zod").ZodType<unknown, unknown, import("zod/v4/core").$ZodTypeInternals<unknown, unknown>>;
