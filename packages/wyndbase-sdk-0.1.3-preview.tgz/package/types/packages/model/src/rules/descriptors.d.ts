/**
 * Rule descriptor helpers — produce FE-friendly metadata for each rule by
 * introspecting its Zod `configSchema` tuple. The returned `args` array is
 * shaped to be compatible with `@wyndb/widget`'s `WidgetProps` so the FE
 * rule editor can render input widgets directly from the response of
 * `/api/definitions/rules`.
 *
 * Per-arg metadata comes from the `.meta(...)` calls on each tuple element.
 * Missing `size` is auto-derived from tuple length (2 args → '1/2',
 * 3 → '1/3', 4 → '1/4') so multi-arg rules stay side-by-side without each
 * rule having to repeat layout hints.
 */
import { type WidgetProps } from '../../../wyn-widget/src/index';
import type { RuleName } from './types';
export type RuleDescriptor = {
    name: string;
    /** Rule-level documentation from the schema meta — what the rule does and,
     *  for expression rules, the formula language and anchors. */
    description?: string;
    /** 'check' re-validates on every row write; 'onWrite' only when the guarded
     *  cell is inserted or actually changes. */
    enforcement: 'check' | 'onWrite';
    args?: WidgetProps[];
};
export declare const getRuleDescriptors: (ruleNames: readonly RuleName[]) => Record<string, RuleDescriptor>;
