import { z } from 'zod';
/** ASCII-only so PostgreSQL's `~` and JS regex agree regardless of locale —
 * `[[:alnum:]]`/`\p{N}` don't match the same set across engines. */
export declare const NO_SPECIAL_CHAR_PATTERN: RegExp;
export declare const NO_SPECIAL_CHAR_MESSAGE = "Use only letters (A-Z), digits, space, and . _ : -";
declare const noSpecialChar: {
    enforcement: import("./defineRule").RuleEnforcement;
    expressionArg: number | undefined;
    name: "noSpecialChar";
    predicate: ((ctx: import("./defineRule").RuleContext, ...params: NoInfer<[]> & {
        length: number;
    }) => import("../../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../../shared/src/index").TaggedLiteral | undefined>) | undefined;
    schema: z.ZodObject<{
        args: z.ZodTuple<[], null>;
        name: z.ZodLiteral<"noSpecialChar">;
    }, z.core.$strip>;
    validator: (...params: NoInfer<[]>) => z.ZodType;
};
export declare const NoSpecialCharRuleSchema: z.ZodObject<{
    args: z.ZodTuple<[], null>;
    name: z.ZodLiteral<"noSpecialChar">;
}, z.core.$strip>;
export type NoSpecialCharRuleSchema = z.infer<typeof NoSpecialCharRuleSchema>;
export default noSpecialChar;
