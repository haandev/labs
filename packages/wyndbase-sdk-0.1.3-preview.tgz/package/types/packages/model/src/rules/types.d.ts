import { z } from 'zod';
import { ruleRegistry } from './rule-factory';
export declare const RuleName: z.ZodEnum<{
    allowedTimeWindow: "allowedTimeWindow";
    alphaOnly: "alphaOnly";
    alphaWithSpaceOnly: "alphaWithSpaceOnly";
    alphanumericOnly: "alphanumericOnly";
    alphanumericWithSpaceOnly: "alphanumericWithSpaceOnly";
    cannotStartWith: "cannotStartWith";
    dateformula: "dateformula";
    disallowFuture: "disallowFuture";
    disallowPast: "disallowPast";
    enforceDomain: "enforceDomain";
    exclude: "exclude";
    excludeDomain: "excludeDomain";
    intBetween: "intBetween";
    intMax: "intMax";
    intMin: "intMin";
    lengthBetween: "lengthBetween";
    maxDate: "maxDate";
    maxDateTime: "maxDateTime";
    maxDuration: "maxDuration";
    maxDurationDays: "maxDurationDays";
    maxDurationTime: "maxDurationTime";
    maxEndDate: "maxEndDate";
    maxEndDateTime: "maxEndDateTime";
    maxLength: "maxLength";
    maxMonth: "maxMonth";
    maxTime: "maxTime";
    minDate: "minDate";
    minDateTime: "minDateTime";
    minLength: "minLength";
    minMonth: "minMonth";
    minStartDate: "minStartDate";
    minStartDateTime: "minStartDateTime";
    minTime: "minTime";
    mustInclude: "mustInclude";
    mustStartWith: "mustStartWith";
    noSpecialChar: "noSpecialChar";
    noWhitespace: "noWhitespace";
    numberBetween: "numberBetween";
    numberMax: "numberMax";
    numberMin: "numberMin";
    regex: "regex";
}>;
export type RuleName = keyof typeof ruleRegistry;
export declare const RuleSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    args: z.ZodTuple<[], null>;
    name: z.ZodLiteral<"alphanumericWithSpaceOnly">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodString], null>;
    name: z.ZodLiteral<"dateformula">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[], null>;
    name: z.ZodLiteral<"disallowPast">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodInt, z.ZodInt], null>;
    name: z.ZodLiteral<"intBetween">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodNumber], null>;
    name: z.ZodLiteral<"maxDurationDays">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodInt], null>;
    name: z.ZodLiteral<"maxLength">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodString], null>;
    name: z.ZodLiteral<"minDateTime">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodString], null>;
    name: z.ZodLiteral<"minStartDateTime">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[], null>;
    name: z.ZodLiteral<"noSpecialChar">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodNumber], null>;
    name: z.ZodLiteral<"numberMax">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[], null>;
    name: z.ZodLiteral<"alphaOnly">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[], null>;
    name: z.ZodLiteral<"alphaWithSpaceOnly">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[], null>;
    name: z.ZodLiteral<"alphanumericOnly">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[], null>;
    name: z.ZodLiteral<"disallowFuture">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[], null>;
    name: z.ZodLiteral<"noWhitespace">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodArray<z.ZodString>], null>;
    name: z.ZodLiteral<"enforceDomain">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodArray<z.ZodString>], null>;
    name: z.ZodLiteral<"excludeDomain">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodInt], null>;
    name: z.ZodLiteral<"intMin">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodInt], null>;
    name: z.ZodLiteral<"minLength">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodNumber], null>;
    name: z.ZodLiteral<"intMax">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodNumber], null>;
    name: z.ZodLiteral<"numberMin">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodString], null>;
    name: z.ZodLiteral<"cannotStartWith">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodString], null>;
    name: z.ZodLiteral<"exclude">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodString], null>;
    name: z.ZodLiteral<"maxDate">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodString], null>;
    name: z.ZodLiteral<"maxDateTime">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodString], null>;
    name: z.ZodLiteral<"maxEndDate">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodString], null>;
    name: z.ZodLiteral<"maxEndDateTime">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodString], null>;
    name: z.ZodLiteral<"minDate">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodString], null>;
    name: z.ZodLiteral<"minStartDate">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodString], null>;
    name: z.ZodLiteral<"mustInclude">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodString], null>;
    name: z.ZodLiteral<"mustStartWith">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodUnion<readonly [z.ZodISODateTime, z.ZodISOTime]>], null>;
    name: z.ZodLiteral<"maxTime">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodUnion<readonly [z.ZodISODateTime, z.ZodISOTime]>], null>;
    name: z.ZodLiteral<"minTime">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodUnion<readonly [z.ZodString, z.ZodISODateTime]>], null>;
    name: z.ZodLiteral<"maxMonth">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodUnion<readonly [z.ZodString, z.ZodISODateTime]>], null>;
    name: z.ZodLiteral<"minMonth">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodInt, z.ZodInt], null>;
    name: z.ZodLiteral<"lengthBetween">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
    name: z.ZodLiteral<"numberBetween">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodNumber, z.ZodString], null>;
    name: z.ZodLiteral<"maxDuration">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodNumber, z.ZodString], null>;
    name: z.ZodLiteral<"maxDurationTime">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodString, z.ZodOptional<z.ZodNullable<z.ZodString>>], null>;
    name: z.ZodLiteral<"regex">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodUnion<readonly [z.ZodISODateTime, z.ZodISOTime]>, z.ZodUnion<readonly [z.ZodISODateTime, z.ZodISOTime]>], null>;
    name: z.ZodLiteral<"allowedTimeWindow">;
}, z.core.$strip>, ...(z.ZodObject<{
    args: z.ZodTuple<[], null>;
    name: z.ZodLiteral<"alphanumericWithSpaceOnly">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodString], null>;
    name: z.ZodLiteral<"dateformula">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[], null>;
    name: z.ZodLiteral<"disallowPast">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodInt, z.ZodInt], null>;
    name: z.ZodLiteral<"intBetween">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodNumber], null>;
    name: z.ZodLiteral<"maxDurationDays">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodInt], null>;
    name: z.ZodLiteral<"maxLength">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodString], null>;
    name: z.ZodLiteral<"minDateTime">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodString], null>;
    name: z.ZodLiteral<"minStartDateTime">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[], null>;
    name: z.ZodLiteral<"noSpecialChar">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodNumber], null>;
    name: z.ZodLiteral<"numberMax">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[], null>;
    name: z.ZodLiteral<"alphaOnly">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[], null>;
    name: z.ZodLiteral<"alphaWithSpaceOnly">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[], null>;
    name: z.ZodLiteral<"alphanumericOnly">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[], null>;
    name: z.ZodLiteral<"disallowFuture">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[], null>;
    name: z.ZodLiteral<"noWhitespace">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodArray<z.ZodString>], null>;
    name: z.ZodLiteral<"enforceDomain">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodArray<z.ZodString>], null>;
    name: z.ZodLiteral<"excludeDomain">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodInt], null>;
    name: z.ZodLiteral<"intMin">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodInt], null>;
    name: z.ZodLiteral<"minLength">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodNumber], null>;
    name: z.ZodLiteral<"intMax">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodNumber], null>;
    name: z.ZodLiteral<"numberMin">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodString], null>;
    name: z.ZodLiteral<"cannotStartWith">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodString], null>;
    name: z.ZodLiteral<"exclude">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodString], null>;
    name: z.ZodLiteral<"maxDate">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodString], null>;
    name: z.ZodLiteral<"maxDateTime">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodString], null>;
    name: z.ZodLiteral<"maxEndDate">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodString], null>;
    name: z.ZodLiteral<"maxEndDateTime">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodString], null>;
    name: z.ZodLiteral<"minDate">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodString], null>;
    name: z.ZodLiteral<"minStartDate">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodString], null>;
    name: z.ZodLiteral<"mustInclude">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodString], null>;
    name: z.ZodLiteral<"mustStartWith">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodUnion<readonly [z.ZodISODateTime, z.ZodISOTime]>], null>;
    name: z.ZodLiteral<"maxTime">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodUnion<readonly [z.ZodISODateTime, z.ZodISOTime]>], null>;
    name: z.ZodLiteral<"minTime">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodUnion<readonly [z.ZodString, z.ZodISODateTime]>], null>;
    name: z.ZodLiteral<"maxMonth">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodUnion<readonly [z.ZodString, z.ZodISODateTime]>], null>;
    name: z.ZodLiteral<"minMonth">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodInt, z.ZodInt], null>;
    name: z.ZodLiteral<"lengthBetween">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
    name: z.ZodLiteral<"numberBetween">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodNumber, z.ZodString], null>;
    name: z.ZodLiteral<"maxDuration">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodNumber, z.ZodString], null>;
    name: z.ZodLiteral<"maxDurationTime">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodString, z.ZodOptional<z.ZodNullable<z.ZodString>>], null>;
    name: z.ZodLiteral<"regex">;
}, z.core.$strip> | z.ZodObject<{
    args: z.ZodTuple<[z.ZodUnion<readonly [z.ZodISODateTime, z.ZodISOTime]>, z.ZodUnion<readonly [z.ZodISODateTime, z.ZodISOTime]>], null>;
    name: z.ZodLiteral<"allowedTimeWindow">;
}, z.core.$strip>)[]], "name">;
export type RuleSchema = z.infer<typeof RuleSchema>;
export declare const getRuleDescriptions: (ruleNames: RuleName[]) => any;
