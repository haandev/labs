import { z } from 'zod';
import * as registry from './registry';
declare const columnsAsArray: () => (typeof registry.PGBigserialColumn | typeof registry.PGBooleanColumn | typeof registry.PGByteaColumn | typeof registry.PGDateColumn | typeof registry.PGDaterangeColumn | typeof registry.PGFloatColumn | typeof registry.PGIntegerColumn | typeof registry.PGJsonColumn | typeof registry.PGNumrangeColumn | typeof registry.PGTextColumn | typeof registry.PGTimeColumn | typeof registry.PGTimestampColumn | typeof registry.PGTimestamptzColumn | typeof registry.PGTsrangeColumn | typeof registry.PGTstzrangeColumn | typeof registry.PGUuidColumn | typeof registry.BinaryColumn | typeof registry.BooleanColumn | typeof registry.ChoiceColumn | typeof registry.CountryColumn | typeof registry.DateOnlyColumn | typeof registry.DateRangeColumn | typeof registry.DatetimeColumn | typeof registry.DatetimeZonedColumn | typeof registry.DecimalColumn | typeof registry.EmailColumn | typeof registry.FileColumn | typeof registry.FormulaColumn | typeof registry.FSMColumn | typeof registry.IntegerColumn | typeof registry.JsonColumn | typeof registry.JsonbColumn | typeof registry.LinkColumn | typeof registry.LongTextColumn | typeof registry.MarkdownColumn | typeof registry.MonthYearColumn | typeof registry.MonthYearZonedColumn | typeof registry.NumberColumn | typeof registry.NumberRangeColumn | typeof registry.PhoneColumn | typeof registry.PolyLinkColumn | typeof registry.TextColumn | typeof registry.TimeOnlyColumn | typeof registry.TimeRangeColumn | typeof registry.ZonedTimeRangeColumn)[];
declare const rulesAsArray: () => ({
    enforcement: registry.RuleEnforcement;
    expressionArg: number | undefined;
    name: "alphaOnly";
    predicate: ((ctx: registry.RuleContext, ...params: NoInfer<[]> & {
        length: number;
    }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
    schema: z.ZodObject<{
        args: z.ZodTuple<[], null>;
        name: z.ZodLiteral<"alphaOnly">;
    }, z.core.$strip>;
    validator: (...params: NoInfer<[]>) => z.ZodType;
} | {
    enforcement: registry.RuleEnforcement;
    expressionArg: number | undefined;
    name: "alphaWithSpaceOnly";
    predicate: ((ctx: registry.RuleContext, ...params: NoInfer<[]> & {
        length: number;
    }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
    schema: z.ZodObject<{
        args: z.ZodTuple<[], null>;
        name: z.ZodLiteral<"alphaWithSpaceOnly">;
    }, z.core.$strip>;
    validator: (...params: NoInfer<[]>) => z.ZodType;
} | {
    enforcement: registry.RuleEnforcement;
    expressionArg: number | undefined;
    name: "alphanumericOnly";
    predicate: ((ctx: registry.RuleContext, ...params: NoInfer<[]> & {
        length: number;
    }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
    schema: z.ZodObject<{
        args: z.ZodTuple<[], null>;
        name: z.ZodLiteral<"alphanumericOnly">;
    }, z.core.$strip>;
    validator: (...params: NoInfer<[]>) => z.ZodType;
} | {
    enforcement: registry.RuleEnforcement;
    expressionArg: number | undefined;
    name: "alphanumericWithSpaceOnly";
    predicate: ((ctx: registry.RuleContext, ...params: NoInfer<[]> & {
        length: number;
    }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
    schema: z.ZodObject<{
        args: z.ZodTuple<[], null>;
        name: z.ZodLiteral<"alphanumericWithSpaceOnly">;
    }, z.core.$strip>;
    validator: (...params: NoInfer<[]>) => z.ZodType;
} | {
    enforcement: registry.RuleEnforcement;
    expressionArg: number | undefined;
    name: "disallowFuture";
    predicate: ((ctx: registry.RuleContext, ...params: NoInfer<[]> & {
        length: number;
    }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
    schema: z.ZodObject<{
        args: z.ZodTuple<[], null>;
        name: z.ZodLiteral<"disallowFuture">;
    }, z.core.$strip>;
    validator: (...params: NoInfer<[]>) => z.ZodType;
} | {
    enforcement: registry.RuleEnforcement;
    expressionArg: number | undefined;
    name: "disallowPast";
    predicate: ((ctx: registry.RuleContext, ...params: NoInfer<[]> & {
        length: number;
    }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
    schema: z.ZodObject<{
        args: z.ZodTuple<[], null>;
        name: z.ZodLiteral<"disallowPast">;
    }, z.core.$strip>;
    validator: (...params: NoInfer<[]>) => z.ZodType;
} | {
    enforcement: registry.RuleEnforcement;
    expressionArg: number | undefined;
    name: "noSpecialChar";
    predicate: ((ctx: registry.RuleContext, ...params: NoInfer<[]> & {
        length: number;
    }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
    schema: z.ZodObject<{
        args: z.ZodTuple<[], null>;
        name: z.ZodLiteral<"noSpecialChar">;
    }, z.core.$strip>;
    validator: (...params: NoInfer<[]>) => z.ZodType;
} | {
    enforcement: registry.RuleEnforcement;
    expressionArg: number | undefined;
    name: "noWhitespace";
    predicate: ((ctx: registry.RuleContext, ...params: NoInfer<[]> & {
        length: number;
    }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
    schema: z.ZodObject<{
        args: z.ZodTuple<[], null>;
        name: z.ZodLiteral<"noWhitespace">;
    }, z.core.$strip>;
    validator: (...params: NoInfer<[]>) => z.ZodType;
} | {
    enforcement: registry.RuleEnforcement;
    expressionArg: number | undefined;
    name: "enforceDomain";
    predicate: ((ctx: registry.RuleContext, ...params: NoInfer<[string[]]> & {
        length: number;
    }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
    schema: z.ZodObject<{
        args: z.ZodTuple<[z.ZodArray<z.ZodString>], null>;
        name: z.ZodLiteral<"enforceDomain">;
    }, z.core.$strip>;
    validator: (...params: NoInfer<[string[]]>) => z.ZodType;
} | {
    enforcement: registry.RuleEnforcement;
    expressionArg: number | undefined;
    name: "excludeDomain";
    predicate: ((ctx: registry.RuleContext, ...params: NoInfer<[string[]]> & {
        length: number;
    }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
    schema: z.ZodObject<{
        args: z.ZodTuple<[z.ZodArray<z.ZodString>], null>;
        name: z.ZodLiteral<"excludeDomain">;
    }, z.core.$strip>;
    validator: (...params: NoInfer<[string[]]>) => z.ZodType;
} | {
    enforcement: registry.RuleEnforcement;
    expressionArg: number | undefined;
    name: "intMin";
    predicate: ((ctx: registry.RuleContext, ...params: NoInfer<[number]> & {
        length: number;
    }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
    schema: z.ZodObject<{
        args: z.ZodTuple<[z.ZodInt], null>;
        name: z.ZodLiteral<"intMin">;
    }, z.core.$strip>;
    validator: (...params: NoInfer<[number]>) => z.ZodType;
} | {
    enforcement: registry.RuleEnforcement;
    expressionArg: number | undefined;
    name: "maxLength";
    predicate: ((ctx: registry.RuleContext, ...params: NoInfer<[number]> & {
        length: number;
    }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
    schema: z.ZodObject<{
        args: z.ZodTuple<[z.ZodInt], null>;
        name: z.ZodLiteral<"maxLength">;
    }, z.core.$strip>;
    validator: (...params: NoInfer<[number]>) => z.ZodType;
} | {
    enforcement: registry.RuleEnforcement;
    expressionArg: number | undefined;
    name: "minLength";
    predicate: ((ctx: registry.RuleContext, ...params: NoInfer<[number]> & {
        length: number;
    }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
    schema: z.ZodObject<{
        args: z.ZodTuple<[z.ZodInt], null>;
        name: z.ZodLiteral<"minLength">;
    }, z.core.$strip>;
    validator: (...params: NoInfer<[number]>) => z.ZodType;
} | {
    enforcement: registry.RuleEnforcement;
    expressionArg: number | undefined;
    name: "intMax";
    predicate: ((ctx: registry.RuleContext, ...params: NoInfer<[number]> & {
        length: number;
    }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
    schema: z.ZodObject<{
        args: z.ZodTuple<[z.ZodNumber], null>;
        name: z.ZodLiteral<"intMax">;
    }, z.core.$strip>;
    validator: (...params: NoInfer<[number]>) => z.ZodType;
} | {
    enforcement: registry.RuleEnforcement;
    expressionArg: number | undefined;
    name: "maxDurationDays";
    predicate: ((ctx: registry.RuleContext, ...params: NoInfer<[number]> & {
        length: number;
    }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
    schema: z.ZodObject<{
        args: z.ZodTuple<[z.ZodNumber], null>;
        name: z.ZodLiteral<"maxDurationDays">;
    }, z.core.$strip>;
    validator: (...params: NoInfer<[number]>) => z.ZodType;
} | {
    enforcement: registry.RuleEnforcement;
    expressionArg: number | undefined;
    name: "numberMax";
    predicate: ((ctx: registry.RuleContext, ...params: NoInfer<[number]> & {
        length: number;
    }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
    schema: z.ZodObject<{
        args: z.ZodTuple<[z.ZodNumber], null>;
        name: z.ZodLiteral<"numberMax">;
    }, z.core.$strip>;
    validator: (...params: NoInfer<[number]>) => z.ZodType;
} | {
    enforcement: registry.RuleEnforcement;
    expressionArg: number | undefined;
    name: "numberMin";
    predicate: ((ctx: registry.RuleContext, ...params: NoInfer<[number]> & {
        length: number;
    }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
    schema: z.ZodObject<{
        args: z.ZodTuple<[z.ZodNumber], null>;
        name: z.ZodLiteral<"numberMin">;
    }, z.core.$strip>;
    validator: (...params: NoInfer<[number]>) => z.ZodType;
} | {
    enforcement: registry.RuleEnforcement;
    expressionArg: number | undefined;
    name: "cannotStartWith";
    predicate: ((ctx: registry.RuleContext, ...params: NoInfer<[string]> & {
        length: number;
    }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
    schema: z.ZodObject<{
        args: z.ZodTuple<[z.ZodString], null>;
        name: z.ZodLiteral<"cannotStartWith">;
    }, z.core.$strip>;
    validator: (...params: NoInfer<[string]>) => z.ZodType;
} | {
    enforcement: registry.RuleEnforcement;
    expressionArg: number | undefined;
    name: "dateformula";
    predicate: ((ctx: registry.RuleContext, ...params: NoInfer<[string]> & {
        length: number;
    }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
    schema: z.ZodObject<{
        args: z.ZodTuple<[z.ZodString], null>;
        name: z.ZodLiteral<"dateformula">;
    }, z.core.$strip>;
    validator: (...params: NoInfer<[string]>) => z.ZodType;
} | {
    enforcement: registry.RuleEnforcement;
    expressionArg: number | undefined;
    name: "exclude";
    predicate: ((ctx: registry.RuleContext, ...params: NoInfer<[string]> & {
        length: number;
    }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
    schema: z.ZodObject<{
        args: z.ZodTuple<[z.ZodString], null>;
        name: z.ZodLiteral<"exclude">;
    }, z.core.$strip>;
    validator: (...params: NoInfer<[string]>) => z.ZodType;
} | {
    enforcement: registry.RuleEnforcement;
    expressionArg: number | undefined;
    name: "maxDate";
    predicate: ((ctx: registry.RuleContext, ...params: NoInfer<[string]> & {
        length: number;
    }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
    schema: z.ZodObject<{
        args: z.ZodTuple<[z.ZodString], null>;
        name: z.ZodLiteral<"maxDate">;
    }, z.core.$strip>;
    validator: (...params: NoInfer<[string]>) => z.ZodType;
} | {
    enforcement: registry.RuleEnforcement;
    expressionArg: number | undefined;
    name: "maxDateTime";
    predicate: ((ctx: registry.RuleContext, ...params: NoInfer<[string]> & {
        length: number;
    }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
    schema: z.ZodObject<{
        args: z.ZodTuple<[z.ZodString], null>;
        name: z.ZodLiteral<"maxDateTime">;
    }, z.core.$strip>;
    validator: (...params: NoInfer<[string]>) => z.ZodType;
} | {
    enforcement: registry.RuleEnforcement;
    expressionArg: number | undefined;
    name: "maxEndDate";
    predicate: ((ctx: registry.RuleContext, ...params: NoInfer<[string]> & {
        length: number;
    }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
    schema: z.ZodObject<{
        args: z.ZodTuple<[z.ZodString], null>;
        name: z.ZodLiteral<"maxEndDate">;
    }, z.core.$strip>;
    validator: (...params: NoInfer<[string]>) => z.ZodType;
} | {
    enforcement: registry.RuleEnforcement;
    expressionArg: number | undefined;
    name: "maxEndDateTime";
    predicate: ((ctx: registry.RuleContext, ...params: NoInfer<[string]> & {
        length: number;
    }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
    schema: z.ZodObject<{
        args: z.ZodTuple<[z.ZodString], null>;
        name: z.ZodLiteral<"maxEndDateTime">;
    }, z.core.$strip>;
    validator: (...params: NoInfer<[string]>) => z.ZodType;
} | {
    enforcement: registry.RuleEnforcement;
    expressionArg: number | undefined;
    name: "minDate";
    predicate: ((ctx: registry.RuleContext, ...params: NoInfer<[string]> & {
        length: number;
    }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
    schema: z.ZodObject<{
        args: z.ZodTuple<[z.ZodString], null>;
        name: z.ZodLiteral<"minDate">;
    }, z.core.$strip>;
    validator: (...params: NoInfer<[string]>) => z.ZodType;
} | {
    enforcement: registry.RuleEnforcement;
    expressionArg: number | undefined;
    name: "minDateTime";
    predicate: ((ctx: registry.RuleContext, ...params: NoInfer<[string]> & {
        length: number;
    }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
    schema: z.ZodObject<{
        args: z.ZodTuple<[z.ZodString], null>;
        name: z.ZodLiteral<"minDateTime">;
    }, z.core.$strip>;
    validator: (...params: NoInfer<[string]>) => z.ZodType;
} | {
    enforcement: registry.RuleEnforcement;
    expressionArg: number | undefined;
    name: "minStartDate";
    predicate: ((ctx: registry.RuleContext, ...params: NoInfer<[string]> & {
        length: number;
    }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
    schema: z.ZodObject<{
        args: z.ZodTuple<[z.ZodString], null>;
        name: z.ZodLiteral<"minStartDate">;
    }, z.core.$strip>;
    validator: (...params: NoInfer<[string]>) => z.ZodType;
} | {
    enforcement: registry.RuleEnforcement;
    expressionArg: number | undefined;
    name: "minStartDateTime";
    predicate: ((ctx: registry.RuleContext, ...params: NoInfer<[string]> & {
        length: number;
    }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
    schema: z.ZodObject<{
        args: z.ZodTuple<[z.ZodString], null>;
        name: z.ZodLiteral<"minStartDateTime">;
    }, z.core.$strip>;
    validator: (...params: NoInfer<[string]>) => z.ZodType;
} | {
    enforcement: registry.RuleEnforcement;
    expressionArg: number | undefined;
    name: "mustInclude";
    predicate: ((ctx: registry.RuleContext, ...params: NoInfer<[string]> & {
        length: number;
    }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
    schema: z.ZodObject<{
        args: z.ZodTuple<[z.ZodString], null>;
        name: z.ZodLiteral<"mustInclude">;
    }, z.core.$strip>;
    validator: (...params: NoInfer<[string]>) => z.ZodType;
} | {
    enforcement: registry.RuleEnforcement;
    expressionArg: number | undefined;
    name: "mustStartWith";
    predicate: ((ctx: registry.RuleContext, ...params: NoInfer<[string]> & {
        length: number;
    }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
    schema: z.ZodObject<{
        args: z.ZodTuple<[z.ZodString], null>;
        name: z.ZodLiteral<"mustStartWith">;
    }, z.core.$strip>;
    validator: (...params: NoInfer<[string]>) => z.ZodType;
} | {
    enforcement: registry.RuleEnforcement;
    expressionArg: number | undefined;
    name: "maxTime";
    predicate: ((ctx: registry.RuleContext, ...params: NoInfer<[string]> & {
        length: number;
    }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
    schema: z.ZodObject<{
        args: z.ZodTuple<[z.ZodUnion<readonly [z.ZodISODateTime, z.ZodISOTime]>], null>;
        name: z.ZodLiteral<"maxTime">;
    }, z.core.$strip>;
    validator: (...params: NoInfer<[string]>) => z.ZodType;
} | {
    enforcement: registry.RuleEnforcement;
    expressionArg: number | undefined;
    name: "minTime";
    predicate: ((ctx: registry.RuleContext, ...params: NoInfer<[string]> & {
        length: number;
    }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
    schema: z.ZodObject<{
        args: z.ZodTuple<[z.ZodUnion<readonly [z.ZodISODateTime, z.ZodISOTime]>], null>;
        name: z.ZodLiteral<"minTime">;
    }, z.core.$strip>;
    validator: (...params: NoInfer<[string]>) => z.ZodType;
} | {
    enforcement: registry.RuleEnforcement;
    expressionArg: number | undefined;
    name: "maxMonth";
    predicate: ((ctx: registry.RuleContext, ...params: NoInfer<[string]> & {
        length: number;
    }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
    schema: z.ZodObject<{
        args: z.ZodTuple<[z.ZodUnion<readonly [z.ZodString, z.ZodISODateTime]>], null>;
        name: z.ZodLiteral<"maxMonth">;
    }, z.core.$strip>;
    validator: (...params: NoInfer<[string]>) => z.ZodType;
} | {
    enforcement: registry.RuleEnforcement;
    expressionArg: number | undefined;
    name: "minMonth";
    predicate: ((ctx: registry.RuleContext, ...params: NoInfer<[string]> & {
        length: number;
    }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
    schema: z.ZodObject<{
        args: z.ZodTuple<[z.ZodUnion<readonly [z.ZodString, z.ZodISODateTime]>], null>;
        name: z.ZodLiteral<"minMonth">;
    }, z.core.$strip>;
    validator: (...params: NoInfer<[string]>) => z.ZodType;
} | {
    enforcement: registry.RuleEnforcement;
    expressionArg: number | undefined;
    name: "intBetween";
    predicate: ((ctx: registry.RuleContext, ...params: NoInfer<[number, number]> & {
        length: number;
    }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
    schema: z.ZodObject<{
        args: z.ZodTuple<[z.ZodInt, z.ZodInt], null>;
        name: z.ZodLiteral<"intBetween">;
    }, z.core.$strip>;
    validator: (...params: NoInfer<[number, number]>) => z.ZodType;
} | {
    enforcement: registry.RuleEnforcement;
    expressionArg: number | undefined;
    name: "lengthBetween";
    predicate: ((ctx: registry.RuleContext, ...params: NoInfer<[number, number]> & {
        length: number;
    }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
    schema: z.ZodObject<{
        args: z.ZodTuple<[z.ZodInt, z.ZodInt], null>;
        name: z.ZodLiteral<"lengthBetween">;
    }, z.core.$strip>;
    validator: (...params: NoInfer<[number, number]>) => z.ZodType;
} | {
    enforcement: registry.RuleEnforcement;
    expressionArg: number | undefined;
    name: "numberBetween";
    predicate: ((ctx: registry.RuleContext, ...params: NoInfer<[number, number]> & {
        length: number;
    }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
    schema: z.ZodObject<{
        args: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
        name: z.ZodLiteral<"numberBetween">;
    }, z.core.$strip>;
    validator: (...params: NoInfer<[number, number]>) => z.ZodType;
} | {
    enforcement: registry.RuleEnforcement;
    expressionArg: number | undefined;
    name: "maxDuration";
    predicate: ((ctx: registry.RuleContext, ...params: NoInfer<[number, string]> & {
        length: number;
    }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
    schema: z.ZodObject<{
        args: z.ZodTuple<[z.ZodNumber, z.ZodString], null>;
        name: z.ZodLiteral<"maxDuration">;
    }, z.core.$strip>;
    validator: (...params: NoInfer<[number, string]>) => z.ZodType;
} | {
    enforcement: registry.RuleEnforcement;
    expressionArg: number | undefined;
    name: "maxDurationTime";
    predicate: ((ctx: registry.RuleContext, ...params: NoInfer<[number, string]> & {
        length: number;
    }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
    schema: z.ZodObject<{
        args: z.ZodTuple<[z.ZodNumber, z.ZodString], null>;
        name: z.ZodLiteral<"maxDurationTime">;
    }, z.core.$strip>;
    validator: (...params: NoInfer<[number, string]>) => z.ZodType;
} | {
    enforcement: registry.RuleEnforcement;
    expressionArg: number | undefined;
    name: "regex";
    predicate: ((ctx: registry.RuleContext, ...params: NoInfer<[string, (string | null | undefined)?]> & {
        length: number;
    }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
    schema: z.ZodObject<{
        args: z.ZodTuple<[z.ZodString, z.ZodOptional<z.ZodNullable<z.ZodString>>], null>;
        name: z.ZodLiteral<"regex">;
    }, z.core.$strip>;
    validator: (...params: NoInfer<[string, (string | null | undefined)?]>) => z.ZodType;
} | {
    enforcement: registry.RuleEnforcement;
    expressionArg: number | undefined;
    name: "allowedTimeWindow";
    predicate: ((ctx: registry.RuleContext, ...params: NoInfer<[string, string]> & {
        length: number;
    }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
    schema: z.ZodObject<{
        args: z.ZodTuple<[z.ZodUnion<readonly [z.ZodISODateTime, z.ZodISOTime]>, z.ZodUnion<readonly [z.ZodISODateTime, z.ZodISOTime]>], null>;
        name: z.ZodLiteral<"allowedTimeWindow">;
    }, z.core.$strip>;
    validator: (...params: NoInfer<[string, string]>) => z.ZodType;
})[];
export type ColumnGroup = ReturnType<typeof columnsAsArray>[number]['group'];
export type ColumnType = ReturnType<typeof columnsAsArray>[number]['columnType'];
export type RuleName = ReturnType<typeof rulesAsArray>[number]['name'];
export declare const ColumnMetadataDiscriminatedUnion: z.ZodLazy<z.ZodDiscriminatedUnion<[z.ZodObject<{
    allowEnd: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
        both: "both";
        "exclusive-only": "exclusive-only";
        "inclusive-only": "inclusive-only";
    }>>>;
    allowedCountries: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodEnum<{
        [x: string]: string;
    }>>>>;
    allowedMimeTypes: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodString>>>;
    allowedTables: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodString>>>;
    allowFilter: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    allowOpenEnd: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    allowOpenStart: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    allowSearch: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    allowStart: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
        both: "both";
        "exclusive-only": "exclusive-only";
        "inclusive-only": "inclusive-only";
    }>>>;
    allowsAnyTable: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    bucket: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    canHaveMultiple: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    dataMask: z.ZodOptional<z.ZodNullable<z.ZodObject<{
        char: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        email: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        enabled: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        leading: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        separators: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        trailing: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    }, z.core.$strip>>>;
    defaultValue: z.ZodOptional<z.ZodNullable<z.ZodAny>>;
    encrypt: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    formula: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    hidden: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    immutable: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    inputMask: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    isArray: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    isDynamic: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    isMultiSelect: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
        no: "no";
        yes: "yes";
    }>>>;
    isNqTarget: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    isPrimaryKey: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    isUnique: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    listName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    maxFileSizeBytes: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    mirrorColumns: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodObject<{
        _id: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        canHaveMultiple: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        name: z.ZodString;
        physicalName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        table: z.ZodString;
    }, z.core.$strip>>>>;
    notAllowedCountries: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodEnum<{
        [x: string]: string;
    }>>>>;
    notNull: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    onDelete: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
        cascade: "cascade";
        keep: "keep";
        restrict: "restrict";
        setNull: "setNull";
    }>>>;
    optimizeSort: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    precision: z.ZodOptional<z.ZodNullable<z.ZodInt>>;
    rules: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodObject<{
        args: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodAny>>>;
        name: z.ZodString;
    }, z.core.$strip>>>>;
    scale: z.ZodOptional<z.ZodNullable<z.ZodInt>>;
    schema: z.ZodOptional<z.ZodNullable<z.ZodRecord<z.ZodString, z.ZodUnknown>>>;
    sensitive: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
        always: "always";
        "explicitly-open": "explicitly-open";
    }>>>;
    summaryTypes: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodString>>>;
    targetTables: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodObject<{
        junctionSourceColumn: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        junctionTable: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        junctionTargetColumn: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        table: z.ZodString;
        targetColumn: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, z.core.$strip>>>>;
    type: z.ZodString;
    versioning: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
}, z.core.$strip>, ...z.ZodObject<{
    allowEnd: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
        both: "both";
        "exclusive-only": "exclusive-only";
        "inclusive-only": "inclusive-only";
    }>>>;
    allowedCountries: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodEnum<{
        [x: string]: string;
    }>>>>;
    allowedMimeTypes: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodString>>>;
    allowedTables: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodString>>>;
    allowFilter: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    allowOpenEnd: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    allowOpenStart: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    allowSearch: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    allowStart: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
        both: "both";
        "exclusive-only": "exclusive-only";
        "inclusive-only": "inclusive-only";
    }>>>;
    allowsAnyTable: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    bucket: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    canHaveMultiple: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    dataMask: z.ZodOptional<z.ZodNullable<z.ZodObject<{
        char: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        email: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        enabled: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        leading: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        separators: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        trailing: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    }, z.core.$strip>>>;
    defaultValue: z.ZodOptional<z.ZodNullable<z.ZodAny>>;
    encrypt: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    formula: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    hidden: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    immutable: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    inputMask: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    isArray: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    isDynamic: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    isMultiSelect: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
        no: "no";
        yes: "yes";
    }>>>;
    isNqTarget: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    isPrimaryKey: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    isUnique: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    listName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    maxFileSizeBytes: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    mirrorColumns: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodObject<{
        _id: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        canHaveMultiple: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        name: z.ZodString;
        physicalName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        table: z.ZodString;
    }, z.core.$strip>>>>;
    notAllowedCountries: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodEnum<{
        [x: string]: string;
    }>>>>;
    notNull: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    onDelete: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
        cascade: "cascade";
        keep: "keep";
        restrict: "restrict";
        setNull: "setNull";
    }>>>;
    optimizeSort: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    precision: z.ZodOptional<z.ZodNullable<z.ZodInt>>;
    rules: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodObject<{
        args: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodAny>>>;
        name: z.ZodString;
    }, z.core.$strip>>>>;
    scale: z.ZodOptional<z.ZodNullable<z.ZodInt>>;
    schema: z.ZodOptional<z.ZodNullable<z.ZodRecord<z.ZodString, z.ZodUnknown>>>;
    sensitive: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
        always: "always";
        "explicitly-open": "explicitly-open";
    }>>>;
    summaryTypes: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodString>>>;
    targetTables: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodObject<{
        junctionSourceColumn: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        junctionTable: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        junctionTargetColumn: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        table: z.ZodString;
        targetColumn: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, z.core.$strip>>>>;
    type: z.ZodString;
    versioning: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
}, z.core.$strip>[]], "type">>;
export declare const ColumnDynamicMetadataDiscriminatedUnion: z.ZodLazy<z.ZodDiscriminatedUnion<[z.ZodObject<{
    allowEnd: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
        both: "both";
        "exclusive-only": "exclusive-only";
        "inclusive-only": "inclusive-only";
    }>>>;
    allowedCountries: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodEnum<{
        [x: string]: string;
    }>>>>;
    allowedMimeTypes: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodString>>>;
    allowedTables: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodString>>>;
    allowFilter: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    allowOpenEnd: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    allowOpenStart: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    allowSearch: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    allowStart: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
        both: "both";
        "exclusive-only": "exclusive-only";
        "inclusive-only": "inclusive-only";
    }>>>;
    allowsAnyTable: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    bucket: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    canHaveMultiple: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    dataMask: z.ZodOptional<z.ZodNullable<z.ZodObject<{
        char: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        email: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        enabled: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        leading: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        separators: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        trailing: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    }, z.core.$strip>>>;
    defaultValue: z.ZodOptional<z.ZodNullable<z.ZodAny>>;
    encrypt: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    formula: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    hidden: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    immutable: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    inputMask: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    isArray: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    isDynamic: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    isMultiSelect: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
        no: "no";
        yes: "yes";
    }>>>;
    isNqTarget: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    isPrimaryKey: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    isUnique: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    listName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    maxFileSizeBytes: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    mirrorColumns: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodObject<{
        _id: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        canHaveMultiple: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        name: z.ZodString;
        physicalName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        table: z.ZodString;
    }, z.core.$strip>>>>;
    notAllowedCountries: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodEnum<{
        [x: string]: string;
    }>>>>;
    notNull: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    onDelete: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
        cascade: "cascade";
        keep: "keep";
        restrict: "restrict";
        setNull: "setNull";
    }>>>;
    optimizeSort: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    precision: z.ZodOptional<z.ZodNullable<z.ZodInt>>;
    rules: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodObject<{
        args: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodAny>>>;
        name: z.ZodString;
    }, z.core.$strip>>>>;
    scale: z.ZodOptional<z.ZodNullable<z.ZodInt>>;
    schema: z.ZodOptional<z.ZodNullable<z.ZodRecord<z.ZodString, z.ZodUnknown>>>;
    sensitive: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
        always: "always";
        "explicitly-open": "explicitly-open";
    }>>>;
    summaryTypes: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodString>>>;
    targetTables: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodObject<{
        junctionSourceColumn: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        junctionTable: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        junctionTargetColumn: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        table: z.ZodString;
        targetColumn: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, z.core.$strip>>>>;
    type: z.ZodString;
    versioning: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
}, z.core.$strip>, ...z.ZodObject<{
    allowEnd: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
        both: "both";
        "exclusive-only": "exclusive-only";
        "inclusive-only": "inclusive-only";
    }>>>;
    allowedCountries: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodEnum<{
        [x: string]: string;
    }>>>>;
    allowedMimeTypes: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodString>>>;
    allowedTables: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodString>>>;
    allowFilter: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    allowOpenEnd: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    allowOpenStart: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    allowSearch: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    allowStart: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
        both: "both";
        "exclusive-only": "exclusive-only";
        "inclusive-only": "inclusive-only";
    }>>>;
    allowsAnyTable: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    bucket: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    canHaveMultiple: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    dataMask: z.ZodOptional<z.ZodNullable<z.ZodObject<{
        char: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        email: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        enabled: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        leading: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        separators: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        trailing: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    }, z.core.$strip>>>;
    defaultValue: z.ZodOptional<z.ZodNullable<z.ZodAny>>;
    encrypt: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    formula: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    hidden: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    immutable: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    inputMask: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    isArray: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    isDynamic: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    isMultiSelect: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
        no: "no";
        yes: "yes";
    }>>>;
    isNqTarget: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    isPrimaryKey: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    isUnique: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    listName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    maxFileSizeBytes: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    mirrorColumns: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodObject<{
        _id: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        canHaveMultiple: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        name: z.ZodString;
        physicalName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        table: z.ZodString;
    }, z.core.$strip>>>>;
    notAllowedCountries: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodEnum<{
        [x: string]: string;
    }>>>>;
    notNull: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    onDelete: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
        cascade: "cascade";
        keep: "keep";
        restrict: "restrict";
        setNull: "setNull";
    }>>>;
    optimizeSort: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    precision: z.ZodOptional<z.ZodNullable<z.ZodInt>>;
    rules: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodObject<{
        args: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodAny>>>;
        name: z.ZodString;
    }, z.core.$strip>>>>;
    scale: z.ZodOptional<z.ZodNullable<z.ZodInt>>;
    schema: z.ZodOptional<z.ZodNullable<z.ZodRecord<z.ZodString, z.ZodUnknown>>>;
    sensitive: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
        always: "always";
        "explicitly-open": "explicitly-open";
    }>>>;
    summaryTypes: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodString>>>;
    targetTables: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodObject<{
        junctionSourceColumn: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        junctionTable: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        junctionTargetColumn: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        table: z.ZodString;
        targetColumn: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, z.core.$strip>>>>;
    type: z.ZodString;
    versioning: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
}, z.core.$strip>[]], "type">>;
export declare const RulesDiscriminatedUnion: z.ZodLazy<z.ZodDiscriminatedUnion<[z.ZodObject<{
    args: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodAny>>>;
    name: z.ZodString;
}, z.core.$strip>, ...z.ZodObject<{
    args: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodAny>>>;
    name: z.ZodString;
}, z.core.$strip>[]], "name">>;
export type Rule = z.infer<typeof RulesDiscriminatedUnion>;
export {};
