import { z } from 'zod';
export declare const NON_DYNAMIC_METADATA_KEYS: readonly ['encrypt'];
/**
 * The one wording for the rejection, so the Zod error, the driver error and
 * any future surface cannot drift apart.
 */
export declare function dynamicMetadataRejectionMessage(key: string): string;
export declare function forbidOnDynamic(schema: z.ZodObject<z.ZodRawShape>, keys: readonly string[]): z.ZodObject<z.ZodRawShape>;
