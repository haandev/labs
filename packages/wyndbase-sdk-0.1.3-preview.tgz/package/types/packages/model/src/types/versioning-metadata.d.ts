import type { TableNode } from './table';
/**
 * Column metadata keys that only mean anything on a table with
 * `metadata.hasVersion: true`. `versioning` marks a column as one whose write
 * opens a new version, so on a table that has no version lineage there is no
 * cycle for it to trigger and nothing for the flag to say.
 */
export declare const VERSIONED_TABLE_ONLY_METADATA_KEYS: readonly ['versioning'];
/** Whether the table opts into temporal versioning (`hasVersion: true`). */
export declare function isVersionedTable(table: Pick<TableNode, 'metadata'> | undefined | null): boolean;
/**
 * The one wording for the rejection, so the driver error and the editor's
 * reason for hiding the field cannot drift apart.
 */
export declare function versionedTableOnlyMetadataRejectionMessage(key: string, tableName?: string): string;
