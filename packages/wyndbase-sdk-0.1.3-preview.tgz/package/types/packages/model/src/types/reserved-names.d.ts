export declare const RESERVED_COLUMN_NAMES: readonly ['_id', '_originId', 'createdAt', 'updatedAt', 'createdBy', 'updatedBy', 'startAt', 'endAt', 'deletedBy', '_snippets'];
export type ReservedColumnName = (typeof RESERVED_COLUMN_NAMES)[number];
export declare function isReservedColumnName(name: string): boolean;
export declare const SYSTEM_COLUMN_TIER: Record<string, 'structural' | 'audit' | 'temporal' | 'lineage'>;
/**
 * Returns the system tier for a reserved column name, or undefined if the
 * name is not a reserved system column.
 *
 * Tiers:
 * - structural: _id — the only tier that accepts explicit user input
 * - audit:      createdAt, updatedAt, createdBy, updatedBy — motor-written on every mutation
 * - temporal:   startAt, endAt, deletedBy — motor-written on versioned table mutations
 * - lineage:    _originId — motor-written, tracks origin row across versions
 */
export declare function systemTierOf(columnName: string): 'structural' | 'audit' | 'temporal' | 'lineage' | undefined;
/**
 * A system column the DDL creates on every table (`audit`) or on a versioned
 * table (`temporal`). `nullable` is the DDL's own answer — see
 * `packages/driver/src/ddl/system-columns.ts` — and it is what both the star
 * projection's declared type and a named reference's type are derived from.
 *
 * `_id` and `_originId` are deliberately absent: they carry their own rules
 * (structural, lineage) and are already special-cased by their consumers.
 */
export interface SystemColumnDescriptor {
    readonly name: ReservedColumnName;
    readonly tier: 'audit' | 'temporal';
    readonly nullable: boolean;
}
export declare const AUDIT_SYSTEM_COLUMNS: readonly SystemColumnDescriptor[];
export declare const VERSION_SYSTEM_COLUMNS: readonly SystemColumnDescriptor[];
/** The descriptor for an audit or version column, or undefined for anything else. */
export declare function systemColumnDescriptor(name: string): SystemColumnDescriptor | undefined;
export declare function isSystemTimestampColumn(name: string): boolean;
/**
 * The `to_char` format for a projected system timestamp
 * (`createdAt`/`updatedAt`/`startAt`/`endAt`). Deliberately its own constant
 * rather than a reuse of `TIMESTAMPTZ_TO_CHAR_FORMAT` (the format a
 * user-declared `timestamptz` column gets via `BoundTemporalColumn`): that
 * format is second precision, which is fine for a declared column's display
 * but wrong here. These four are engine-written on every mutation and
 * compared by driver code to decide ordering — see
 * `packages/driver/src/system/flow/runner/schedule.runner.ts`, which parses
 * `flow.updatedAt` and an event's snapshot `updatedAt` back into `Date`s and
 * compares them to detect a stale event. Truncating to the second collapses
 * two writes that land in the same second to equal, so a real supersession
 * goes undetected and a stale event runs. `.MS` restores millisecond
 * precision — exactly what a JavaScript `Date` carries, so this is lossless
 * relative to what the comparison could ever observe — while keeping the
 * same UTC ISO shape, lexicographic ordering, and `new Date(...)` UTC
 * parsing the declared-column format also has.
 */
export declare const SYSTEM_TIMESTAMP_TO_CHAR_FORMAT = "YYYY-MM-DD\"T\"HH24:MI:SS.MS\"Z\"";
/**
 * The projection SQL for a system column already resolved to `ref` (e.g.
 * `"t1"."createdAt"`). A UTC-instant column projects through
 * `to_char(... AT TIME ZONE 'UTC' ...)` using `SYSTEM_TIMESTAMP_TO_CHAR_FORMAT`
 * (see its comment for why that is not the declared-column format). Every
 * other system column (`_id`, `_originId`, and the UUID
 * `createdBy`/`updatedBy`/`deletedBy`) projects as `ref` unchanged.
 *
 * This is the ONE place a projected system column's wire shape is decided —
 * every star site and the named-column projection path call through here so
 * none of them can answer differently from the others.
 */
export declare function systemColumnProjectionExpr(name: string, ref: string): string;
/**
 * A self-contained star/RETURNING entry for a system column: `ref` unchanged
 * when no formatting applies, or the formatted expression aliased back to
 * `name`. Needed because `to_char(...)` does not inherit Postgres's implicit
 * "output column name follows a bare column reference" behaviour the way an
 * unformatted `ref` does — the alias has to be explicit whenever the
 * expression changed from `ref`.
 */
export declare function projectSystemColumnEntry(name: string, ref: string): string;
