import { z } from 'zod';
export declare const FolderSchema: z.ZodObject<{
    currentName: z.ZodString;
    modelId: z.ZodString;
    newName: z.ZodString;
}, z.core.$strip>;
export declare const FolderUpdateSchema: z.ZodObject<{
    modelId: z.ZodString;
    newName: z.ZodString;
}, z.core.$strip>;
export declare const FolderDeleteSchema: z.ZodObject<{
    modelId: z.ZodString;
}, z.core.$strip>;
export type FolderSchema = z.infer<typeof FolderSchema>;
export type FolderUpdateSchema = z.infer<typeof FolderUpdateSchema>;
export type FolderDeleteSchema = z.infer<typeof FolderDeleteSchema>;
