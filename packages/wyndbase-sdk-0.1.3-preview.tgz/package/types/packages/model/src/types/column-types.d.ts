import type { z } from 'zod';
import type { ColumnMetadataBaseSchema } from './column-metadata';
/**
 * Per-type column metadata exports.
 *
 * Each `XxxColumnMetadata` type aliases the loose base metadata shape with a
 * narrowed `type` literal. This preserves the FE-consumed shape that used to
 * come from `packages/driver/src/columns/*.schema.ts` after the migration to
 * model-sourced types. Fields remain optional/`nullish` from
 * `ColumnMetadataBaseSchema`; consumers access only the fields relevant to
 * their column type.
 *
 * The `type` literal values match each column class's `static readonly columnType`.
 */
type BaseColumnMetadata = z.infer<typeof ColumnMetadataBaseSchema>;
type WithType<T extends string> = Omit<BaseColumnMetadata, 'type'> & {
    type: T;
};
export type TextColumnMetadata = WithType<'text'>;
export type LongTextColumnMetadata = WithType<'longtext'>;
export type MarkdownColumnMetadata = WithType<'markdown'>;
export type EmailColumnMetadata = WithType<'email'>;
export type PhoneColumnMetadata = WithType<'phone'>;
export type IntegerColumnMetadata = WithType<'integer'>;
export type NumberColumnMetadata = WithType<'number'>;
export type DecimalColumnMetadata = WithType<'decimal'>;
export type BooleanColumnMetadata = WithType<'boolean'>;
export type DateOnlyColumnMetadata = WithType<'dateOnly'>;
export type DateTimeColumnMetadata = WithType<'datetime'>;
export type DatetimeZonedColumnMetadata = WithType<'timestamptz'>;
export type DateRangeColumnMetadata = WithType<'daterange'>;
export type DateTimeRangeColumnMetadata = WithType<'datetimerange'>;
export type TimeRangeColumnMetadata = WithType<'timerange'>;
export type TimeOnlyColumnMetadata = WithType<'timeOnly'>;
export type MonthYearColumnMetadata = WithType<'monthYear'>;
export type MonthYearZonedColumnMetadata = WithType<'monthyear-zoned'>;
export type NumberRangeColumnMetadata = WithType<'numberrange'>;
export type CountryColumnMetadata = WithType<'country'>;
export type JsonColumnMetadata = WithType<'json'>;
export type JsonbColumnMetadata = WithType<'jsonb'>;
export type BinaryColumnMetadata = WithType<'binary'>;
export type FileColumnMetadata = WithType<'file'>;
export type ChoiceColumnMetadata = WithType<'choice'>;
export type LinkColumnMetadata = WithType<'link'>;
export {};
