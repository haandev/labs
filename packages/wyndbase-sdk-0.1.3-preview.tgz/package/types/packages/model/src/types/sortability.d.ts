import type { DataMask } from '../internal-types';
import type { DisclosureInput, DisclosureSortCode } from './disclosure';
declare const STRUCTURAL_SORT_REJECTION_CODES: readonly ['MULTI_VALUE_SORT_COLUMN', 'UNKNOWN_SORT_COLUMN', 'UNORDERABLE_SORT_COLUMN'];
/** Breaks the declaration below at compile time if the union widens to `string`. */
type NarrowStringUnion<T extends string> = string extends T ? ['ERROR: the disclosure code union widened to string', never] : T;
/** Doubles as the `error.code` of the 400 returned by the browse list route. */
export type SortRejectionCode = NarrowStringUnion<(typeof STRUCTURAL_SORT_REJECTION_CODES)[number] | DisclosureSortCode>;
export declare const SORT_REJECTION_CODES: readonly SortRejectionCode[];
export interface SortRejection {
    code: SortRejectionCode;
    message: string;
}
interface SortableColumnLike {
    name: string;
    metadata?: {
        canHaveMultiple?: boolean | null;
        dataMask?: DataMask | null;
        encrypt?: boolean | null;
        isMultiSelect?: string | null;
        type?: string | null;
    } | null;
}
/**
 * The one sortability predicate, shared by the browse route and the grid so the
 * UI never offers a sort the server then rejects. `null` means sortable.
 */
export declare function sortRejectionFor(columnName: string, column: SortableColumnLike | undefined | null, effectiveMask?: DataMask | null): SortRejection | null;
/**
 * Three outcomes: `'sortable'` short-circuits a system column past disclosure,
 * `null` means no structural objection.
 */
export declare function structuralSortRejection(columnName: string, column: SortableColumnLike | undefined | null): SortRejection | 'sortable' | null;
/**
 * `ORDER BY` reads the raw column before the projection masks or encrypts it,
 * so a caller who cannot read a value must not be allowed to sort by it.
 */
export declare function sortDisclosureRejection(columnName: string, input: DisclosureInput): SortRejection | null;
export declare const isColumnSortable: (columnName: string, column: SortableColumnLike | undefined | null, effectiveMask?: DataMask | null) => boolean;
export {};
