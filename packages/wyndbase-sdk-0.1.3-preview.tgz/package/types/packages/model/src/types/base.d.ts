import { z } from 'zod';
export declare const BaseSchema: z.ZodObject<{
    _id: z.ZodOptional<z.ZodString>;
    description: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    displayName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    folder: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    isDynamic: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    isSystem: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    metadata: z.ZodOptional<z.ZodNullable<z.ZodRecord<z.ZodString, z.ZodAny>>>;
    name: z.ZodString;
    physicalName: z.ZodOptional<z.ZodString>;
    immutable: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
}, z.core.$strip>;
export type BaseSchema = z.infer<typeof BaseSchema>;
export type BaseNode = Omit<z.infer<typeof BaseSchema>, '_id' | 'physicalName'> & {
    _id: string;
    deletedAt?: string | null;
    physicalName: string;
};
