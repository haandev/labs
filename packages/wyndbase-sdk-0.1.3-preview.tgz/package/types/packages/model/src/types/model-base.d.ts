import { z } from 'zod';
/** Schema for the model */
export declare const ModelBaseSchema: z.ZodObject<{
    _id: z.ZodOptional<z.ZodString>;
    description: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    displayName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    folder: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    isDynamic: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    isSystem: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    metadata: z.ZodOptional<z.ZodNullable<z.ZodRecord<z.ZodString, z.ZodAny>>>;
    name: z.ZodString;
    ordinal: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    parent: z.ZodString;
    physicalName: z.ZodOptional<z.ZodString>;
    type: z.ZodString;
}, z.core.$strip>;
export type ModelBaseNode = Omit<z.infer<typeof ModelBaseSchema>, '_id' | 'parent'> & {
    _id: string;
    parent?: string | null;
    physicalName: string;
};
