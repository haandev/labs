import { z } from 'zod';
import { type ModelBaseNode } from './model-base';
import type { NamedQueryNode } from './named-query';
import type { TableNode } from './table';
export declare const SpaceSchema: z.ZodObject<{
    _id: z.ZodOptional<z.ZodString>;
    description: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    displayName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    folder: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    isDynamic: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    isSystem: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    metadata: z.ZodOptional<z.ZodNullable<z.ZodRecord<z.ZodString, z.ZodAny>>>;
    name: z.ZodString;
    ordinal: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    physicalName: z.ZodOptional<z.ZodString>;
    parent: z.ZodOptional<z.ZodNull>;
    type: z.ZodPrefault<z.ZodLiteral<"space">>;
}, z.core.$strip>;
export type SpaceSchema = z.infer<typeof SpaceSchema>;
export type SpaceNode = Omit<ModelBaseNode, 'type' | 'parent'> & {
    type: 'space';
    parent?: null | undefined;
    children: (TableNode | NamedQueryNode)[];
};
