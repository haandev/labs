import type { DataMask } from '../internal-types';
/**
 * Resolve the mask that governs a column's cells. Column metadata wins
 * WHOLESALE over the type-level default — the two are never merged.
 */
export declare const resolveDataMask: (metadataMask: DataMask | null | undefined, typeDefaultMask: DataMask | null | undefined) => DataMask | undefined;
/**
 * True when a column's cells are masked in the projection. One flag, because
 * `ColumnCommonMetadata.dataMask` declares `enabled` and nothing else.
 */
export declare const isMaskActive: (mask: DataMask | null | undefined) => boolean;
/**
 * The surfaces a column's value can be inferred through. All take their
 * verdict from {@link DISCLOSURE_RULES}; nothing else decides it.
 */
export type DisclosureSurface = 'conflictTarget' | 'filter' | 'sort';
/** The column metadata a disclosure rule may read. Structural fields such as
 *  `canHaveMultiple` are absent: those are not disclosure kinds. */
export interface DisclosureMetadata {
    dataMask?: DataMask | null;
    encrypt?: boolean | null;
    type?: string | null;
}
/**
 * Always false: a READ gate lives in `system.decision_matrix` and resolves per
 * caller, so no node-derived answer exists — callers hand theirs in instead.
 */
export declare function hasCellReadGate(_metadata?: DisclosureMetadata | null): boolean;
/**
 * Everything a rule may look at. Registry-free by construction: a row that
 * reached for the registry would close the cycle classes -> types -> registry.
 */
export interface DisclosureInput {
    /**
     * Whether a cell-level READ gate governs this column for the caller being
     * judged. Resolved per caller, so only the caller can hand it in.
     */
    cellReadGate?: boolean;
    /** The mask actually governing the column. `undefined` means the caller had
     *  no registry access and the column's own metadata is the best answer. */
    mask?: DataMask | null;
    metadata?: DisclosureMetadata | null;
    /** True when `metadata.type` is not in the column registry, so disclosure
     *  rules cannot be established at all. Only a registry-aware caller sets it. */
    unresolvableType?: boolean;
}
/**
 * One blocked-metadata kind, and everything all three surfaces need to know
 * about it. Adding a kind is adding a row here.
 */
export interface DisclosureRule {
    /** Whether `isNull` / `isNotNull` still pass on this kind. */
    allowsValuelessOps: boolean;
    applies: (input: DisclosureInput) => boolean;
    /** The refusal code, or `null` when this kind does not block an
     *  `ON CONFLICT` target. */
    conflictTarget: string | null;
    /** The 400 code, or `null` when this kind does not block value-carrying
     *  filter conditions. */
    filter: string | null;
    /** Typed `string` rather than {@link DisclosureKind} because that union is
     *  DERIVED from this table; a synthetic test table carries kinds of its own. */
    kind: string;
    /** Noun phrase for both the API message and the UI reason, so the two cannot
     *  describe the same kind differently. */
    noun: string;
    /** Why a surface this row leaves ungated is safe without a gate. Keyed BY
     *  SURFACE: one row can leave two surfaces open for two unrelated reasons. */
    rationale?: Partial<Record<DisclosureSurface, string>>;
    /** The 400 code, or `null` when this kind does not block sorting. */
    sort: string | null;
}
/**
 * Order is precedence. Annotating `: DisclosureRule[]` rather than declaring
 * `as const satisfies` widens the codes and kills FE exhaustiveness checking.
 */
export declare const DISCLOSURE_RULES: readonly [{
    readonly allowsValuelessOps: true;
    readonly applies: (input: DisclosureInput) => boolean;
    readonly conflictTarget: 'UNRESOLVABLE_CONFLICT_TARGET';
    readonly filter: 'UNRESOLVABLE_FILTER_COLUMN';
    readonly kind: 'unresolvableType';
    readonly noun: 'a column of an unregistered type';
    readonly sort: 'UNRESOLVABLE_SORT_COLUMN';
}, {
    readonly allowsValuelessOps: true;
    readonly applies: (input: DisclosureInput) => boolean;
    readonly conflictTarget: null;
    readonly filter: null;
    readonly kind: 'encrypted';
    readonly noun: 'an encrypted column';
    readonly rationale: {
        readonly conflictTarget: string;
        readonly filter: string;
    };
    readonly sort: 'ENCRYPTED_SORT_COLUMN';
}, {
    readonly allowsValuelessOps: true;
    readonly applies: (input: DisclosureInput) => boolean;
    readonly conflictTarget: 'MASKED_CONFLICT_TARGET';
    readonly filter: 'MASKED_FILTER_COLUMN';
    readonly kind: 'masked';
    readonly noun: 'a masked column';
    readonly sort: 'MASKED_SORT_COLUMN';
}, {
    readonly allowsValuelessOps: true;
    readonly applies: (input: DisclosureInput) => boolean;
    readonly conflictTarget: 'RESTRICTED_CONFLICT_TARGET';
    readonly filter: null;
    readonly kind: 'cellRead';
    readonly noun: 'a column with a cell read policy';
    readonly rationale: {
        readonly filter: string;
        readonly sort: string;
    };
    readonly sort: null;
}];
export type DisclosureKind = (typeof DISCLOSURE_RULES)[number]['kind'];
/** Sort codes owned by the disclosure table (structural codes are not here). */
export type DisclosureSortCode = NonNullable<(typeof DISCLOSURE_RULES)[number]['sort']>;
export type DisclosureFilterCode = NonNullable<(typeof DISCLOSURE_RULES)[number]['filter']>;
export type DisclosureConflictTargetCode = NonNullable<(typeof DISCLOSURE_RULES)[number]['conflictTarget']>;
export interface DisclosureMatch<C extends string = string> {
    code: C;
    kind: string;
    noun: string;
}
/**
 * The first row of the table that blocks `surface`. `op` is filter-only: a
 * value-less operator reveals nothing beyond presence, so opted-in rows pass.
 */
export declare const disclosureRejectionFor: <R extends DisclosureRule, S extends DisclosureSurface>(rules: readonly R[], surface: S, input: DisclosureInput, op?: string) => DisclosureMatch<NonNullable<R[S]>> | null;
/**
 * Membership, not precedence: a caller refusing exactly ONE named kind must
 * ask this, or a row inserted ahead of that kind silently disarms the gate.
 */
export declare const disclosureRuleApplies: <R extends DisclosureRule>(rules: readonly R[], kind: R['kind'], input: DisclosureInput) => boolean;
/** Every code a rule table publishes for one surface, in table order. */
export declare const disclosureCodesFor: <R extends DisclosureRule, S extends DisclosureSurface>(rules: readonly R[], surface: S) => readonly NonNullable<R[S]>[];
export declare const sortDisclosureReason: (noun: string) => string;
export declare const filterDisclosureReason: (noun: string) => string;
export declare const conflictTargetDisclosureReason: (noun: string) => string;
/**
 * Disabled-reason copy for one surface, keyed by code — so the menu wording
 * and the 400 message come from the same `noun` and cannot disagree.
 */
export declare const disclosureReasonsFor: <R extends DisclosureRule, S extends DisclosureSurface>(rules: readonly R[], surface: S) => Record<NonNullable<R[S]>, string>;
/**
 * The container a protected value sits in; mask and encrypt wrappers must
 * match. `jsonbArray` as `scalar` produced `encode(jsonb, 'hex')`, no such fn.
 */
export type ContainerKind = 'scalar' | 'pgArray' | 'jsonbArray';
