import { z } from 'zod';
import type { ColumnNode } from './column';
import { type ModelBaseNode } from './model-base';
/** Currently we only have one table type, but future table types will follow the same pattern with column discriminator.
 * this const will serve as catalog of possible metadata properties on table level and discriminator will be on metadata.tableType
 */
export declare const TableMetadataSchema: z.ZodOptional<z.ZodNullable<z.ZodObject<{
    allowDynamicColumns: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    displayFieldId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    hasComments: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    hasVersion: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    transient: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
}, z.core.$strip>>>;
/**
 * The cannonical schema for validating table models.
 *
 * Even if currently we have only one table type, future table types will follow same pattern with column discriminator.
 */
export declare const TableSchema: z.ZodObject<{
    _id: z.ZodOptional<z.ZodString>;
    description: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    displayName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    folder: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    isDynamic: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    isSystem: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    name: z.ZodString;
    ordinal: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    physicalName: z.ZodOptional<z.ZodString>;
    metadata: z.ZodOptional<z.ZodNullable<z.ZodOptional<z.ZodNullable<z.ZodObject<{
        allowDynamicColumns: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        displayFieldId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        hasComments: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        hasVersion: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        transient: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    }, z.core.$strip>>>>>;
    parent: z.ZodString;
    type: z.ZodPrefault<z.ZodLiteral<"table">>;
}, z.core.$strip>;
export type TableNode = ModelBaseNode & {
    type: 'table';
    metadata?: z.infer<typeof TableMetadataSchema> | null;
    children: ColumnNode[];
};
export declare const isStrictTableNode: (node: unknown) => node is TableNode;
export declare const isTableNode: (node: unknown) => node is TableNode;
/**
 * Canonical "create-a-table-with-constraints" shape. Used internally by table
 * factory code and by agent-facing CRUD surfaces (MCP tool registrations,
 * future BE API routes, FE forms) that project to their own input record.
 *
 * Extends {@link TableSchema} with an optional `constraints` array; system
 * fields (`_id`, `physicalName`) and renames (`parent` → `spaceId`) are
 * applied by each surface at its own boundary via `.omit` / `.extend` rather
 * than duplicated as a second schema here.
 */
export declare const TableFactorySchema: z.ZodObject<{
    _id: z.ZodOptional<z.ZodString>;
    description: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    displayName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    folder: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    isDynamic: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    isSystem: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    name: z.ZodString;
    ordinal: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    physicalName: z.ZodOptional<z.ZodString>;
    metadata: z.ZodOptional<z.ZodNullable<z.ZodOptional<z.ZodNullable<z.ZodObject<{
        allowDynamicColumns: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        displayFieldId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        hasComments: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        hasVersion: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        transient: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    }, z.core.$strip>>>>>;
    parent: z.ZodString;
    type: z.ZodPrefault<z.ZodLiteral<"table">>;
    constraints: z.ZodOptional<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        caseInsensitive: z.ZodOptional<z.ZodBoolean>;
        columns: z.ZodArray<z.ZodString>;
        constraintType: z.ZodLiteral<"unique">;
        name: z.ZodOptional<z.ZodString>;
        nullsNotDistinct: z.ZodOptional<z.ZodBoolean>;
        rowPredicate: z.ZodOptional<z.ZodObject<{
            anyOf: z.ZodArray<z.ZodObject<{
                column: z.ZodString;
                test: z.ZodEnum<{
                    isTrue: "isTrue";
                    notNull: "notNull";
                }>;
            }, z.core.$strip>>;
        }, z.core.$strip>>;
    }, z.core.$strip>], "constraintType">>>;
}, z.core.$strip>;
export type TableFactory = z.infer<typeof TableFactorySchema>;
