import { z } from 'zod';
import { type ModelBaseNode } from './model-base';
export declare const NQExposure: z.ZodEnum<{
    public: "public";
    service: "service";
    trusted: "trusted";
}>;
export type NQExposure = z.infer<typeof NQExposure>;
export declare const NamedQuerySchema: z.ZodObject<{
    _id: z.ZodOptional<z.ZodString>;
    description: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    displayName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    folder: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    isDynamic: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    isSystem: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    name: z.ZodString;
    ordinal: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    physicalName: z.ZodOptional<z.ZodString>;
    metadata: z.ZodObject<{
        elevated: z.ZodOptional<z.ZodBoolean>;
        exposure: z.ZodOptional<z.ZodEnum<{
            public: "public";
            service: "service";
            trusted: "trusted";
        }>>;
        query: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>;
    parent: z.ZodString;
    type: z.ZodPrefault<z.ZodLiteral<"namedQuery">>;
}, z.core.$strip>;
export type NamedQueryNode = ModelBaseNode & {
    type: 'namedQuery';
    metadata: {
        elevated?: boolean;
        exposure?: NQExposure;
        query?: string;
    };
};
export declare const isStrictNamedQueryNode: (node: unknown) => node is NamedQueryNode;
export declare const isNamedQueryNode: (node: unknown) => node is NamedQueryNode;
