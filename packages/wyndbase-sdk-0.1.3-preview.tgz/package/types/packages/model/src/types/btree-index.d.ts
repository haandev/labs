/** Metadata flags that compile to a plain (non-GIN) B-tree index. */
export declare const BTREE_INDEX_FLAGS: readonly ['allowFilter', 'optimizeSort'];
export type BtreeIndexFlag = (typeof BTREE_INDEX_FLAGS)[number];
/** Minimal metadata shape needed to judge B-tree indexability. */
export interface BtreeIndexFlagsLike {
    allowFilter?: boolean | null;
    optimizeSort?: boolean | null;
}
/** True when `CREATE INDEX ... (col)` is valid for a column of this pgType. */
export declare const supportsBtreeIndex: (pgType: string | null | undefined) => boolean;
/**
 * The enabled B-tree flags that `pgType` cannot support. Empty array means the
 * configuration is valid (either the pgType is indexable or no flag is on).
 */
export declare const unsupportedBtreeIndexFlags: (pgType: string | null | undefined, metadata: BtreeIndexFlagsLike | null | undefined) => BtreeIndexFlag[];
/**
 * User-facing rejection text. Echoes the raw PostgreSQL error the user used to
 * hit at DDL time, so the validation failure is recognisable.
 */
export declare const btreeIndexRejectionMessage: (pgType: string, flags: readonly BtreeIndexFlag[]) => string;
