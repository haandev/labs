import { z } from 'zod';
export declare const RowPredicateTestSchema: z.ZodEnum<{
    isTrue: "isTrue";
    notNull: "notNull";
}>;
export type RowPredicateTest = z.infer<typeof RowPredicateTestSchema>;
export declare const RowPredicateMetadataSchema: z.ZodObject<{
    anyOf: z.ZodArray<z.ZodObject<{
        columnId: z.ZodString;
        test: z.ZodEnum<{
            isTrue: "isTrue";
            notNull: "notNull";
        }>;
    }, z.core.$strip>>;
}, z.core.$strip>;
export type RowPredicateMetadata = z.infer<typeof RowPredicateMetadataSchema>;
export declare const RowPredicateInitSchema: z.ZodObject<{
    anyOf: z.ZodArray<z.ZodObject<{
        column: z.ZodString;
        test: z.ZodEnum<{
            isTrue: "isTrue";
            notNull: "notNull";
        }>;
    }, z.core.$strip>>;
}, z.core.$strip>;
export type RowPredicateInit = z.infer<typeof RowPredicateInitSchema>;
export type RowPredicateInitAlternative = RowPredicateInit['anyOf'][number];
export declare const UniqueConstraintMetadataSchema: z.ZodObject<{
    caseInsensitive: z.ZodOptional<z.ZodBoolean>;
    columnIds: z.ZodArray<z.ZodString>;
    constraintType: z.ZodLiteral<"unique">;
    nullsNotDistinct: z.ZodOptional<z.ZodBoolean>;
    rowPredicate: z.ZodOptional<z.ZodObject<{
        anyOf: z.ZodArray<z.ZodObject<{
            columnId: z.ZodString;
            test: z.ZodEnum<{
                isTrue: "isTrue";
                notNull: "notNull";
            }>;
        }, z.core.$strip>>;
    }, z.core.$strip>>;
}, z.core.$strip>;
export declare const ConstraintMetadataSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    caseInsensitive: z.ZodOptional<z.ZodBoolean>;
    columnIds: z.ZodArray<z.ZodString>;
    constraintType: z.ZodLiteral<"unique">;
    nullsNotDistinct: z.ZodOptional<z.ZodBoolean>;
    rowPredicate: z.ZodOptional<z.ZodObject<{
        anyOf: z.ZodArray<z.ZodObject<{
            columnId: z.ZodString;
            test: z.ZodEnum<{
                isTrue: "isTrue";
                notNull: "notNull";
            }>;
        }, z.core.$strip>>;
    }, z.core.$strip>>;
}, z.core.$strip>], "constraintType">;
export type ConstraintMetadata = z.infer<typeof ConstraintMetadataSchema>;
export type UniqueConstraintMetadata = z.infer<typeof UniqueConstraintMetadataSchema>;
export declare const UniqueConstraintInitSchema: z.ZodObject<{
    caseInsensitive: z.ZodOptional<z.ZodBoolean>;
    columns: z.ZodArray<z.ZodString>;
    constraintType: z.ZodLiteral<"unique">;
    name: z.ZodOptional<z.ZodString>;
    nullsNotDistinct: z.ZodOptional<z.ZodBoolean>;
    rowPredicate: z.ZodOptional<z.ZodObject<{
        anyOf: z.ZodArray<z.ZodObject<{
            column: z.ZodString;
            test: z.ZodEnum<{
                isTrue: "isTrue";
                notNull: "notNull";
            }>;
        }, z.core.$strip>>;
    }, z.core.$strip>>;
}, z.core.$strip>;
export declare const ConstraintInitSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    caseInsensitive: z.ZodOptional<z.ZodBoolean>;
    columns: z.ZodArray<z.ZodString>;
    constraintType: z.ZodLiteral<"unique">;
    name: z.ZodOptional<z.ZodString>;
    nullsNotDistinct: z.ZodOptional<z.ZodBoolean>;
    rowPredicate: z.ZodOptional<z.ZodObject<{
        anyOf: z.ZodArray<z.ZodObject<{
            column: z.ZodString;
            test: z.ZodEnum<{
                isTrue: "isTrue";
                notNull: "notNull";
            }>;
        }, z.core.$strip>>;
    }, z.core.$strip>>;
}, z.core.$strip>], "constraintType">;
export type ConstraintInit = z.infer<typeof ConstraintInitSchema>;
