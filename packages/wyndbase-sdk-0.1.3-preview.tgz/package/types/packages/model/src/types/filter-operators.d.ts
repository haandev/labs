export type FilterOperatorArity = 'none' | 'scalar' | 'list' | 'pair' | 'pattern';
export interface FilterOperatorSpec {
    arity: FilterOperatorArity;
    /** Hardcoded English menu text; runtime i18n was removed. */
    label: string;
    name: string;
}
/**
 * Declared `as const satisfies readonly FilterOperatorSpec[]`, never annotated
 * `: FilterOperatorSpec[]` — that would widen the operator union to `string`.
 */
export declare const FILTER_OPERATORS: readonly [{
    readonly arity: 'scalar';
    readonly label: 'is equal to';
    readonly name: 'equals';
}, {
    readonly arity: 'scalar';
    readonly label: 'is not equal to';
    readonly name: 'notEquals';
}, {
    readonly arity: 'scalar';
    readonly label: 'is greater than';
    readonly name: 'greaterThan';
}, {
    readonly arity: 'scalar';
    readonly label: 'is greater than or equal to';
    readonly name: 'greaterThanOrEquals';
}, {
    readonly arity: 'scalar';
    readonly label: 'is less than';
    readonly name: 'lessThan';
}, {
    readonly arity: 'scalar';
    readonly label: 'is less than or equal to';
    readonly name: 'lessThanOrEquals';
}, {
    readonly arity: 'pattern';
    readonly label: 'starts with';
    readonly name: 'startsWith';
}, {
    readonly arity: 'pattern';
    readonly label: 'contains';
    readonly name: 'contains';
}, {
    readonly arity: 'list';
    readonly label: 'is one of';
    readonly name: 'in';
}, {
    readonly arity: 'list';
    readonly label: 'is not one of';
    readonly name: 'notIn';
}, {
    readonly arity: 'pair';
    readonly label: 'is between';
    readonly name: 'between';
}, {
    readonly arity: 'pair';
    readonly label: 'is not between';
    readonly name: 'notBetween';
}, {
    readonly arity: 'pair';
    readonly label: 'is between (symmetric)';
    readonly name: 'betweenSymmetric';
}, {
    readonly arity: 'pair';
    readonly label: 'is not between (symmetric)';
    readonly name: 'notBetweenSymmetric';
}, {
    readonly arity: 'none';
    readonly label: 'is empty';
    readonly name: 'isNull';
}, {
    readonly arity: 'none';
    readonly label: 'is not empty';
    readonly name: 'isNotNull';
}];
/** Identity on a literal union; a named error tuple if it ever widens to `string`. */
type NarrowStringUnion<T extends string> = string extends T ? ['ERROR: the filter operator union widened to string', never] : T;
/** Canonical `availableOperations` names. */
export type FilterOperator = NarrowStringUnion<(typeof FILTER_OPERATORS)[number]['name']>;
/** Every canonical operator name, for exhaustive consumers and tests. */
export declare const FILTER_OPERATOR_NAMES: readonly FilterOperator[];
/** Canonical operator name -> value shape. */
export declare const FILTER_OPERATOR_ARITY: Record<FilterOperator, FilterOperatorArity>;
/** Canonical operator name -> English menu label. */
export declare const FILTER_OPERATOR_LABELS: Record<FilterOperator, string>;
/** English label for a canonical name, or undefined for unknown UI input. */
export declare const filterOperatorLabelFor: (name: string) => string | undefined;
/**
 * Operators that reveal only null-ness, which a masked projection already
 * discloses — gating them would be stricter than the read path for no gain.
 */
export declare const NO_VALUE_OPS: ReadonlySet<string>;
/** Operators whose value is a FRAGMENT of a column value, not a whole one — the `LIKE` family. */
export declare const PATTERN_OPS: ReadonlySet<string>;
/**
 * Escapes `LIKE` metacharacters so a fragment matches literally, using
 * PostgreSQL's default `\` escape character — unlike the shared
 * `escapeLikePattern`, which escapes with `!` for an explicit `ESCAPE '!'`.
 * `\` is escaped first so a user-typed backslash isn't consumed by a later
 * `%`/`_`.
 */
export declare const escapeLikePatternBackslash: (value: string) => string;
export {};
