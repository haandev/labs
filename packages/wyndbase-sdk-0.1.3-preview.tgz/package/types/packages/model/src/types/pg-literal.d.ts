/**
 * Whether PostgreSQL would parse a value as a bare input literal — a different
 * contract from the write schema, which arrives as a cast bound parameter.
 */
export type PgLiteralValue = string | number | boolean;
export declare const PG_LITERAL_TYPES: readonly string[];
/**
 * Reason `value` can't be rendered as an input literal for `pgType`, or
 * `undefined` when it can. Never includes the submitted value itself.
 */
export declare const pgLiteralRejection: (pgType: string | null | undefined, value: PgLiteralValue) => string | undefined;
