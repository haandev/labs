import type { WidgetProps } from '../../wyn-widget/src/index';
import type { z } from 'zod';
import type { ColumnGroup, ColumnType } from './metadata-unions';
import type { ContainerKind } from './types/disclosure';
import type { ColumnMetadataProperty, ColumnNode, MaskConfigType, SpaceNode, TableNode } from './types.ts';
export type * from './registry.ts';
export type * from './types.ts';
export type ColumnDescriptor = {
    group: ColumnGroup;
    columnType: ColumnType;
    metadataProperties: ColumnMetadataProperty[];
    widgetProps?: Record<string, WidgetProps>;
    dynamicWidgetProps?: Record<string, WidgetProps>;
    /**
     * Keys the column editor strips from the payload on save — a stale value
     * behind a no-longer-rendered field fails the form resolver invisibly.
     */
    nonDynamicMetadataKeys?: string[];
    availableRules?: string[];
    availableOperations?: string[];
    availableSummaryTypes?: string[];
    allowArray?: boolean;
};
export type JoinType = 'inner' | 'left' | 'right' | 'outer' | 'cross';
export type DataMask = MaskConfigType;
export type WynModel = SpaceNode[];
export interface ResolvedTable {
    space: SpaceNode;
    table: TableNode;
    qualifiedName: string;
}
export interface ResolvedColumn {
    column: ColumnNode | undefined;
    dbName: string;
}
export interface ResolvedNode {
    type: 'space' | 'table' | 'column';
    node: SpaceNode | TableNode | ColumnNode;
    space?: SpaceNode;
    table?: TableNode;
}
/**
 * Nominal markers. A `unique symbol` key cannot be acquired structurally, so a
 * contract carrying one is satisfied only by a class that declares it — which
 * is what stops the whole compilation context standing in for a column surface.
 */
export declare const resolutionBrandKey: unique symbol;
export declare const policyBrandKey: unique symbol;
export declare const linkBrandKey: unique symbol;
export declare const formulaBrandKey: unique symbol;
/**
 * Alias/table resolution — what every column type needs to place itself in
 * the query, whether or not it also navigates a link.
 */
export interface ColumnResolutionContext {
    readonly [resolutionBrandKey]: 'resolution';
    model: WynModelTree | undefined;
    getBaseTableAlias(): string | undefined;
    getAliasRegistry(): {
        uniqueAlias: (base: string) => string;
    };
    getBaseTableRef(): string;
    getCurrentResolved(): ResolvedTable | undefined;
}
/** Row-level and cell-level policy a column's bound SQL must honour. */
export interface ColumnPolicyContext {
    readonly [policyBrandKey]: 'policy';
    /**
     * Active-version soft-filter (`endAt IS NULL`), or null when the target is
     * not versioned. Required: omitting it silently leaks historical rows.
     */
    buildActiveVersionFilter(target: ResolvedTable, alias: string): string | null;
    /**
     * Wrap a navigated terminal in its own column's `cell.<column>.read` rule.
     * Required: omitting it emits the protected column raw into a predicate.
     */
    applyNavigatedCellReadPolicy(target: ResolvedTable, columnName: string, rowAlias: string | undefined, sql: string): string;
    /**
     * Declared here so a column strategy can resolve a cell policy for a row
     * alias only IT knows — an aggregate's body row is visible nowhere else.
     */
    policy?(): {
        resolveCellPolicyForColumn(col: ColumnNode | undefined, resolvedTable: ResolvedTable | undefined, operation: 'read' | 'update' | 'decrypt' | 'unmask' | 'filter', joinAlias?: string): string | null;
    };
}
/** Link navigation — joins, hop retargeting and synthetic/NQ targets. */
export interface ColumnLinkContext {
    readonly [linkBrandKey]: 'link';
    addJoinFromLink(linkCol: ColumnNode, sourceTable: ResolvedTable, targetTable: ResolvedTable, type: JoinType, sourceAlias?: string): string;
    /**
     * Run `fn` with the base table retargeted to one hop of a link chain, so an
     * expression correlating through `getBaseTableRef()` reads the right row.
     */
    withHopBase<T>(hop: ResolvedTable, sourceRef: string, fn: () => T): T;
    /**
     * A link's foreign key on its source row — the join's left-hand side without
     * the join. `undefined` when there is no source row (a create); keep the join.
     */
    linkFkRef(linkCol: ColumnNode, sourceAlias?: string): string | undefined;
    /**
     * Emit a bulk x:M array as a pre-aggregated CTE + LEFT JOIN and return the
     * projection expression reading it. `bodyFilters` sit inside, before GROUP BY.
     */
    emitPreAggregatedLinkArray(cfg: {
        selectExpr: string;
        fromClause: string;
        groupKeyExpr: string;
        sourceKeyExpr: string;
        bodyFilters: string[];
        /**
         * A cell read policy governing the aggregated value as a whole, evaluated
         * INSIDE the CTE under the same GROUP BY.
         */
        wholeArrayGate?: string | null;
    }): string;
    /**
     * True while projecting a non-selective bulk top-level read, so x:M array
     * projections can pre-aggregate instead of a per-row correlated subquery.
     */
    isBulkOuterRead(): boolean;
    getTableAliasForName(tableName: string): string | undefined;
    getSyntheticTarget(targetRef: string): ResolvedTable | undefined;
    /**
     * Registered named-query CTEs. A targetRef present here was emitted as a
     * re-selectable static CTE; absence means a LATERAL join.
     */
    getNamedQueryCTEs(): {
        name: string;
        sql: string;
    }[];
    /**
     * SQL for a link's inlined LATERAL join, keyed by column name — what a
     * correlated ad-hoc NQ-target MULTI link inlines, having no CTE to name.
     */
    getLateralJoinSql(linkName: string): string | undefined;
}
/** Formula expansion — a declared column standing in for a formula body. */
export interface ColumnFormulaContext {
    readonly [formulaBrandKey]: 'formula';
    tryExpandFormula(columnName: string): string | null;
}
/** Whether a write creates the row or rewrites one that already has a state. */
export type WriteMode = 'insert' | 'update';
/**
 * How a column type asks for the access-decision keys a write to it spends.
 *
 * The column names what it needs; the SQL layer owns the key FORMAT and
 * supplies the implementation bound to one statement's collector, table and
 * column. Keeping the format on that side is what lets this package request a
 * key without knowing how one is spelled.
 */
export interface WriteDecisionKeyEmitter {
    /** Target-state validity for `stateId`. */
    state(stateId: string): void;
    /** The `(from, to)` transition guard. */
    transition(fromState: string, toState: string): void;
}
/** The four column surfaces a column type's `bind()` is handed, by name. */
export interface ColumnBindContext {
    readonly resolution: ColumnResolutionContext;
    readonly policy: ColumnPolicyContext;
    readonly links: ColumnLinkContext;
    readonly formula: ColumnFormulaContext;
}
export interface EncryptInfo {
    isEncrypted: boolean;
    container: ContainerKind;
    pgType: string;
}
export interface NestedQueryConfig {
    tableSql: string;
    correlation: string | null;
    targetResolved?: ResolvedTable;
    aggregate: boolean;
    wrap(subquerySql: string): string;
    junctionSql?: string;
    junctionCorrelation?: string;
}
import type { WynModelTree } from './model-tree.ts';
export interface NestedResolution {
    tableSql: string;
    correlation: string;
    targetResolved?: ResolvedTable;
    junctionSql?: string;
    junctionCorrelation?: string;
}
/**
 * Answers "the SQL for `physicalColumn` of the row this expression is about" —
 * a relation while there is one, and the values being written during a create.
 */
export type BaseColumnRef = (physicalColumn: string) => string;
export interface BoundColumnContract {
    project(alias: string): string;
    starEntry(prefix: string): string;
    projectField?(targetField: string): string;
    /**
     * Bare projection-mode SQL (no `AS alias`) where the projected form differs
     * from the stored value. `undefined` = plain column ref.
     */
    projectionExpr?(): string | undefined;
    /**
     * `ORDER BY` terms for a bare `SORT` on this column; `undefined` = no
     * opinion. Not used in FILTER or WHERE — a predicate keeps raw semantics.
     */
    sortExpr?(): string[] | undefined;
    resolveNested?(nestedAlias: string, baseColumn: BaseColumnRef): NestedResolution | undefined;
    resolveNavigation?(joinType: JoinType, nextSegmentName?: string): ResolvedTable | undefined;
    resolveTerminal?(joinType: JoinType): string | undefined;
    getNestedConfig(nestedAlias: string, baseRef: string, useFirst: boolean): NestedQueryConfig | null;
    wrapDecrypted?(sql: string): string;
}
export interface BoundLinkColumnContract extends BoundColumnContract {
    getSourceRef(fallbackRef?: string): string;
    polyArrayRef?(): string | undefined;
}
export interface BoundStrategyContract {
    project(alias: string): string;
    projectField(targetField: string): string;
    /**
     * Bare projection-mode SQL (no `AS alias`) where the projected form differs
     * from the stored value. `undefined` = plain column ref — mirrors
     * `BoundColumnContract.projectionExpr?()`; `LinkBoundColumn` forwards this
     * the same way it already forwards `polyArrayRef`/`sortExpr`.
     */
    projectionExpr?(): string | undefined;
    /**
     * The bare `poly_ref[]` of a MULTI polymorphic link on the source row —
     * `project`/`projectField` answer aggregated jsonb, wrong for `unnest`.
     */
    polyArrayRef?(): string | undefined;
    /**
     * `ORDER BY` terms this link strategy wants, `undefined` for no opinion —
     * so a strategy with no meaningful key answers by not implementing it.
     */
    sortExpr?(): string[] | undefined;
    resolveNested(nestedAlias: string, baseColumn: BaseColumnRef): NestedResolution | undefined;
    resolveNavigation(joinType: JoinType, nextSegmentName?: string): ResolvedTable | undefined;
    resolveTerminal(joinType: JoinType): string | undefined;
}
export interface ColumnIdentity {
    readonly col: ColumnNode;
    readonly outputSchema: z.ZodType;
    readonly inputSchema: z.ZodType;
    readonly finalPgType: string | null;
    /**
     * PG type a PROJECTION of this column yields — different from
     * `finalPgType` wherever `project()` rewrites the reference (to_char,
     * a label, a jsonb build). `null` means unknown: do not cast. A column the
     * disclosure layer wraps answers `null`; the wrapper picks the type.
     */
    readonly projectedPgType: string | null;
    readonly isPseudo: boolean;
    readonly isArray: boolean;
    readonly usesJsonbAgg: boolean;
    readonly dataMask: DataMask | undefined;
    readonly encryptInfo: EncryptInfo | undefined;
    getFieldSchema?(targetField: string): z.ZodType | undefined;
    /** Pure: resolution only, no joins and no side effects. */
    resolveNavigationTarget?(): ResolvedTable | undefined;
    /** Pure: resolution only, no joins and no side effects. */
    resolveNestedTarget?(): ResolvedTable | undefined;
    bind(ctx: ColumnBindContext): BoundColumnContract;
}
export interface LinkStrategySchema {
    readonly outputSchema: z.ZodType;
    readonly finalPgType: string | null;
    /** @see ColumnIdentity.projectedPgType */
    readonly projectedPgType: string | null;
    getFieldSchema?(targetField: string): z.ZodType | undefined;
    /**
     * Narrower than `ColumnIdentity.bind`'s parameter: this is exactly what
     * `LinkColumn.bind` has in hand to pass through — a strategy needing more
     * (policy, for the x:M/M:N read gate) declares that on its own `bind`,
     * which a caller reaching it only through this interface never sees.
     */
    bind(ctx: Pick<ColumnBindContext, 'resolution' | 'links'>, boundLink: BoundLinkColumnContract): BoundStrategyContract;
}
/** Type inference only — no SQL generation, no side effects. */
export interface ColumnSchemaProvider {
    readonly outputSchema: z.ZodType;
    readonly isPseudo: boolean;
    readonly isArray: boolean;
    readonly usesJsonbAgg: boolean;
    readonly encryptInfo: EncryptInfo | undefined;
    readonly dataMask: DataMask | undefined;
    readonly container: ContainerKind;
    /**
     * Whether a value reached THROUGH this column arrives as a collection —
     * unlike `isArray` (own arrayness) or `container` (`scalar` for a multi link).
     */
    readonly isMultiValued: boolean;
    /**
     * Whether reading this column's value passes through a cell READ gate — what
     * makes a `COALESCE(..., '[]')` aggregate nullable after all.
     */
    readonly hasCellReadGate: boolean;
    getFieldSchema?(targetField: string): z.ZodType | undefined;
    /**
     * Zod schema of an arbitrary-depth sub-path. `undefined` means unresolvable
     * and the caller degrades to `z.unknown()`; empty `path` = the own schema.
     */
    getFieldPathSchema?(path: readonly import('./utils/json-schema-walk').JsonSchemaPathStep[]): z.ZodType | undefined;
    /** Pure: resolution only, no joins and no side effects. */
    resolveNavigationTarget?(): ResolvedTable | undefined;
    /** Pure: resolution only, no joins and no side effects. */
    resolveNestedTarget?(): ResolvedTable | undefined;
}
export interface SchemaProviderFactory {
    getProvider(table: TableNode, columnName: string, resolved?: ResolvedTable): ColumnSchemaProvider | null;
    getProviderFromNode(col: ColumnNode, resolved?: ResolvedTable): ColumnSchemaProvider;
}
