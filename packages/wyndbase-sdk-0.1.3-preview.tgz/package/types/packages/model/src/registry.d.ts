export * from './columns';
export { resolveColumnDefault } from './columns/default-value';
export type { ColumnDescriptor } from './internal-types';
export declare const columns: {
    readonly BinaryColumn: typeof import("./columns").BinaryColumn;
    readonly BooleanColumn: typeof import("./columns").BooleanColumn;
    readonly ChoiceColumn: typeof import("./columns").ChoiceColumn;
    readonly CountryColumn: typeof import("./columns").CountryColumn;
    readonly DateOnlyColumn: typeof import("./columns").DateOnlyColumn;
    readonly DateRangeColumn: typeof import("./columns").DateRangeColumn;
    readonly DatetimeColumn: typeof import("./columns").DatetimeColumn;
    readonly DatetimeZonedColumn: typeof import("./columns").DatetimeZonedColumn;
    readonly DecimalColumn: typeof import("./columns").DecimalColumn;
    readonly EmailColumn: typeof import("./columns").EmailColumn;
    readonly FileColumn: typeof import("./columns").FileColumn;
    readonly FormulaColumn: typeof import("./columns").FormulaColumn;
    readonly FSMColumn: typeof import("./columns").FSMColumn;
    readonly IntegerColumn: typeof import("./columns").IntegerColumn;
    readonly JsonbColumn: typeof import("./columns").JsonbColumn;
    readonly JsonColumn: typeof import("./columns").JsonColumn;
    readonly LinkColumn: typeof import("./columns").LinkColumn;
    readonly LongTextColumn: typeof import("./columns").LongTextColumn;
    readonly MarkdownColumn: typeof import("./columns").MarkdownColumn;
    readonly MonthYearColumn: typeof import("./columns").MonthYearColumn;
    readonly MonthYearZonedColumn: typeof import("./columns").MonthYearZonedColumn;
    readonly NumberColumn: typeof import("./columns").NumberColumn;
    readonly NumberRangeColumn: typeof import("./columns").NumberRangeColumn;
    readonly PGBigserialColumn: typeof import("./columns").PGBigserialColumn;
    readonly PGBooleanColumn: typeof import("./columns").PGBooleanColumn;
    readonly PGByteaColumn: typeof import("./columns").PGByteaColumn;
    readonly PGDateColumn: typeof import("./columns").PGDateColumn;
    readonly PGDaterangeColumn: typeof import("./columns").PGDaterangeColumn;
    readonly PGFloatColumn: typeof import("./columns").PGFloatColumn;
    readonly PGIntegerColumn: typeof import("./columns").PGIntegerColumn;
    readonly PGJsonColumn: typeof import("./columns").PGJsonColumn;
    readonly PGNumrangeColumn: typeof import("./columns").PGNumrangeColumn;
    readonly PGTextColumn: typeof import("./columns").PGTextColumn;
    readonly PGTimeColumn: typeof import("./columns").PGTimeColumn;
    readonly PGTimestampColumn: typeof import("./columns").PGTimestampColumn;
    readonly PGTimestamptzColumn: typeof import("./columns").PGTimestamptzColumn;
    readonly PGTsrangeColumn: typeof import("./columns").PGTsrangeColumn;
    readonly PGTstzrangeColumn: typeof import("./columns").PGTstzrangeColumn;
    readonly PGUuidColumn: typeof import("./columns").PGUuidColumn;
    readonly PhoneColumn: typeof import("./columns").PhoneColumn;
    readonly PolyLinkColumn: typeof import("./columns").PolyLinkColumn;
    readonly TextColumn: typeof import("./columns").TextColumn;
    readonly TimeOnlyColumn: typeof import("./columns").TimeOnlyColumn;
    readonly TimeRangeColumn: typeof import("./columns").TimeRangeColumn;
    readonly ZonedTimeRangeColumn: typeof import("./columns").ZonedTimeRangeColumn;
};
export type { RuleContext, RuleEnforcement } from './rules/defineRule';
export * from './rules/descriptors';
export { NO_SPECIAL_CHAR_MESSAGE, NO_SPECIAL_CHAR_PATTERN, } from './rules/noSpecialChar.rule';
export * from './rules/rule-factory';
export declare const rules: {
    readonly allowedTimeWindow: {
        enforcement: import("./registry").RuleEnforcement;
        expressionArg: number | undefined;
        name: "allowedTimeWindow";
        predicate: ((ctx: import("./registry").RuleContext, ...params: NoInfer<[string, string]> & {
            length: number;
        }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodUnion<readonly [import("zod").ZodISODateTime, import("zod").ZodISOTime]>, import("zod").ZodUnion<readonly [import("zod").ZodISODateTime, import("zod").ZodISOTime]>], null>;
            name: import("zod").ZodLiteral<"allowedTimeWindow">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[string, string]>) => import("zod").ZodType;
    };
    readonly alphanumericOnly: {
        enforcement: import("./registry").RuleEnforcement;
        expressionArg: number | undefined;
        name: "alphanumericOnly";
        predicate: ((ctx: import("./registry").RuleContext, ...params: NoInfer<[]> & {
            length: number;
        }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[], null>;
            name: import("zod").ZodLiteral<"alphanumericOnly">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[]>) => import("zod").ZodType;
    };
    readonly alphanumericWithSpaceOnly: {
        enforcement: import("./registry").RuleEnforcement;
        expressionArg: number | undefined;
        name: "alphanumericWithSpaceOnly";
        predicate: ((ctx: import("./registry").RuleContext, ...params: NoInfer<[]> & {
            length: number;
        }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[], null>;
            name: import("zod").ZodLiteral<"alphanumericWithSpaceOnly">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[]>) => import("zod").ZodType;
    };
    readonly alphaOnly: {
        enforcement: import("./registry").RuleEnforcement;
        expressionArg: number | undefined;
        name: "alphaOnly";
        predicate: ((ctx: import("./registry").RuleContext, ...params: NoInfer<[]> & {
            length: number;
        }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[], null>;
            name: import("zod").ZodLiteral<"alphaOnly">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[]>) => import("zod").ZodType;
    };
    readonly alphaWithSpaceOnly: {
        enforcement: import("./registry").RuleEnforcement;
        expressionArg: number | undefined;
        name: "alphaWithSpaceOnly";
        predicate: ((ctx: import("./registry").RuleContext, ...params: NoInfer<[]> & {
            length: number;
        }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[], null>;
            name: import("zod").ZodLiteral<"alphaWithSpaceOnly">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[]>) => import("zod").ZodType;
    };
    readonly cannotStartWith: {
        enforcement: import("./registry").RuleEnforcement;
        expressionArg: number | undefined;
        name: "cannotStartWith";
        predicate: ((ctx: import("./registry").RuleContext, ...params: NoInfer<[string]> & {
            length: number;
        }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodString], null>;
            name: import("zod").ZodLiteral<"cannotStartWith">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[string]>) => import("zod").ZodType;
    };
    readonly dateformula: {
        enforcement: import("./registry").RuleEnforcement;
        expressionArg: number | undefined;
        name: "dateformula";
        predicate: ((ctx: import("./registry").RuleContext, ...params: NoInfer<[string]> & {
            length: number;
        }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodString], null>;
            name: import("zod").ZodLiteral<"dateformula">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[string]>) => import("zod").ZodType;
    };
    readonly disallowFuture: {
        enforcement: import("./registry").RuleEnforcement;
        expressionArg: number | undefined;
        name: "disallowFuture";
        predicate: ((ctx: import("./registry").RuleContext, ...params: NoInfer<[]> & {
            length: number;
        }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[], null>;
            name: import("zod").ZodLiteral<"disallowFuture">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[]>) => import("zod").ZodType;
    };
    readonly disallowPast: {
        enforcement: import("./registry").RuleEnforcement;
        expressionArg: number | undefined;
        name: "disallowPast";
        predicate: ((ctx: import("./registry").RuleContext, ...params: NoInfer<[]> & {
            length: number;
        }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[], null>;
            name: import("zod").ZodLiteral<"disallowPast">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[]>) => import("zod").ZodType;
    };
    readonly enforceDomain: {
        enforcement: import("./registry").RuleEnforcement;
        expressionArg: number | undefined;
        name: "enforceDomain";
        predicate: ((ctx: import("./registry").RuleContext, ...params: NoInfer<[string[]]> & {
            length: number;
        }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodArray<import("zod").ZodString>], null>;
            name: import("zod").ZodLiteral<"enforceDomain">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[string[]]>) => import("zod").ZodType;
    };
    readonly exclude: {
        enforcement: import("./registry").RuleEnforcement;
        expressionArg: number | undefined;
        name: "exclude";
        predicate: ((ctx: import("./registry").RuleContext, ...params: NoInfer<[string]> & {
            length: number;
        }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodString], null>;
            name: import("zod").ZodLiteral<"exclude">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[string]>) => import("zod").ZodType;
    };
    readonly excludeDomain: {
        enforcement: import("./registry").RuleEnforcement;
        expressionArg: number | undefined;
        name: "excludeDomain";
        predicate: ((ctx: import("./registry").RuleContext, ...params: NoInfer<[string[]]> & {
            length: number;
        }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodArray<import("zod").ZodString>], null>;
            name: import("zod").ZodLiteral<"excludeDomain">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[string[]]>) => import("zod").ZodType;
    };
    readonly intBetween: {
        enforcement: import("./registry").RuleEnforcement;
        expressionArg: number | undefined;
        name: "intBetween";
        predicate: ((ctx: import("./registry").RuleContext, ...params: NoInfer<[number, number]> & {
            length: number;
        }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodInt, import("zod").ZodInt], null>;
            name: import("zod").ZodLiteral<"intBetween">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[number, number]>) => import("zod").ZodType;
    };
    readonly intMax: {
        enforcement: import("./registry").RuleEnforcement;
        expressionArg: number | undefined;
        name: "intMax";
        predicate: ((ctx: import("./registry").RuleContext, ...params: NoInfer<[number]> & {
            length: number;
        }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodNumber], null>;
            name: import("zod").ZodLiteral<"intMax">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[number]>) => import("zod").ZodType;
    };
    readonly intMin: {
        enforcement: import("./registry").RuleEnforcement;
        expressionArg: number | undefined;
        name: "intMin";
        predicate: ((ctx: import("./registry").RuleContext, ...params: NoInfer<[number]> & {
            length: number;
        }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodInt], null>;
            name: import("zod").ZodLiteral<"intMin">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[number]>) => import("zod").ZodType;
    };
    readonly lengthBetween: {
        enforcement: import("./registry").RuleEnforcement;
        expressionArg: number | undefined;
        name: "lengthBetween";
        predicate: ((ctx: import("./registry").RuleContext, ...params: NoInfer<[number, number]> & {
            length: number;
        }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodInt, import("zod").ZodInt], null>;
            name: import("zod").ZodLiteral<"lengthBetween">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[number, number]>) => import("zod").ZodType;
    };
    readonly maxDate: {
        enforcement: import("./registry").RuleEnforcement;
        expressionArg: number | undefined;
        name: "maxDate";
        predicate: ((ctx: import("./registry").RuleContext, ...params: NoInfer<[string]> & {
            length: number;
        }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodString], null>;
            name: import("zod").ZodLiteral<"maxDate">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[string]>) => import("zod").ZodType;
    };
    readonly maxDateTime: {
        enforcement: import("./registry").RuleEnforcement;
        expressionArg: number | undefined;
        name: "maxDateTime";
        predicate: ((ctx: import("./registry").RuleContext, ...params: NoInfer<[string]> & {
            length: number;
        }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodString], null>;
            name: import("zod").ZodLiteral<"maxDateTime">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[string]>) => import("zod").ZodType;
    };
    readonly maxDuration: {
        enforcement: import("./registry").RuleEnforcement;
        expressionArg: number | undefined;
        name: "maxDuration";
        predicate: ((ctx: import("./registry").RuleContext, ...params: NoInfer<[number, string]> & {
            length: number;
        }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodNumber, import("zod").ZodString], null>;
            name: import("zod").ZodLiteral<"maxDuration">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[number, string]>) => import("zod").ZodType;
    };
    readonly maxDurationDays: {
        enforcement: import("./registry").RuleEnforcement;
        expressionArg: number | undefined;
        name: "maxDurationDays";
        predicate: ((ctx: import("./registry").RuleContext, ...params: NoInfer<[number]> & {
            length: number;
        }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodNumber], null>;
            name: import("zod").ZodLiteral<"maxDurationDays">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[number]>) => import("zod").ZodType;
    };
    readonly maxDurationTime: {
        enforcement: import("./registry").RuleEnforcement;
        expressionArg: number | undefined;
        name: "maxDurationTime";
        predicate: ((ctx: import("./registry").RuleContext, ...params: NoInfer<[number, string]> & {
            length: number;
        }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodNumber, import("zod").ZodString], null>;
            name: import("zod").ZodLiteral<"maxDurationTime">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[number, string]>) => import("zod").ZodType;
    };
    readonly maxEndDate: {
        enforcement: import("./registry").RuleEnforcement;
        expressionArg: number | undefined;
        name: "maxEndDate";
        predicate: ((ctx: import("./registry").RuleContext, ...params: NoInfer<[string]> & {
            length: number;
        }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodString], null>;
            name: import("zod").ZodLiteral<"maxEndDate">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[string]>) => import("zod").ZodType;
    };
    readonly maxEndDateTime: {
        enforcement: import("./registry").RuleEnforcement;
        expressionArg: number | undefined;
        name: "maxEndDateTime";
        predicate: ((ctx: import("./registry").RuleContext, ...params: NoInfer<[string]> & {
            length: number;
        }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodString], null>;
            name: import("zod").ZodLiteral<"maxEndDateTime">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[string]>) => import("zod").ZodType;
    };
    readonly maxLength: {
        enforcement: import("./registry").RuleEnforcement;
        expressionArg: number | undefined;
        name: "maxLength";
        predicate: ((ctx: import("./registry").RuleContext, ...params: NoInfer<[number]> & {
            length: number;
        }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodInt], null>;
            name: import("zod").ZodLiteral<"maxLength">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[number]>) => import("zod").ZodType;
    };
    readonly maxMonth: {
        enforcement: import("./registry").RuleEnforcement;
        expressionArg: number | undefined;
        name: "maxMonth";
        predicate: ((ctx: import("./registry").RuleContext, ...params: NoInfer<[string]> & {
            length: number;
        }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodUnion<readonly [import("zod").ZodString, import("zod").ZodISODateTime]>], null>;
            name: import("zod").ZodLiteral<"maxMonth">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[string]>) => import("zod").ZodType;
    };
    readonly maxTime: {
        enforcement: import("./registry").RuleEnforcement;
        expressionArg: number | undefined;
        name: "maxTime";
        predicate: ((ctx: import("./registry").RuleContext, ...params: NoInfer<[string]> & {
            length: number;
        }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodUnion<readonly [import("zod").ZodISODateTime, import("zod").ZodISOTime]>], null>;
            name: import("zod").ZodLiteral<"maxTime">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[string]>) => import("zod").ZodType;
    };
    readonly minDate: {
        enforcement: import("./registry").RuleEnforcement;
        expressionArg: number | undefined;
        name: "minDate";
        predicate: ((ctx: import("./registry").RuleContext, ...params: NoInfer<[string]> & {
            length: number;
        }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodString], null>;
            name: import("zod").ZodLiteral<"minDate">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[string]>) => import("zod").ZodType;
    };
    readonly minDateTime: {
        enforcement: import("./registry").RuleEnforcement;
        expressionArg: number | undefined;
        name: "minDateTime";
        predicate: ((ctx: import("./registry").RuleContext, ...params: NoInfer<[string]> & {
            length: number;
        }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodString], null>;
            name: import("zod").ZodLiteral<"minDateTime">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[string]>) => import("zod").ZodType;
    };
    readonly minLength: {
        enforcement: import("./registry").RuleEnforcement;
        expressionArg: number | undefined;
        name: "minLength";
        predicate: ((ctx: import("./registry").RuleContext, ...params: NoInfer<[number]> & {
            length: number;
        }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodInt], null>;
            name: import("zod").ZodLiteral<"minLength">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[number]>) => import("zod").ZodType;
    };
    readonly minMonth: {
        enforcement: import("./registry").RuleEnforcement;
        expressionArg: number | undefined;
        name: "minMonth";
        predicate: ((ctx: import("./registry").RuleContext, ...params: NoInfer<[string]> & {
            length: number;
        }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodUnion<readonly [import("zod").ZodString, import("zod").ZodISODateTime]>], null>;
            name: import("zod").ZodLiteral<"minMonth">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[string]>) => import("zod").ZodType;
    };
    readonly minStartDate: {
        enforcement: import("./registry").RuleEnforcement;
        expressionArg: number | undefined;
        name: "minStartDate";
        predicate: ((ctx: import("./registry").RuleContext, ...params: NoInfer<[string]> & {
            length: number;
        }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodString], null>;
            name: import("zod").ZodLiteral<"minStartDate">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[string]>) => import("zod").ZodType;
    };
    readonly minStartDateTime: {
        enforcement: import("./registry").RuleEnforcement;
        expressionArg: number | undefined;
        name: "minStartDateTime";
        predicate: ((ctx: import("./registry").RuleContext, ...params: NoInfer<[string]> & {
            length: number;
        }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodString], null>;
            name: import("zod").ZodLiteral<"minStartDateTime">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[string]>) => import("zod").ZodType;
    };
    readonly minTime: {
        enforcement: import("./registry").RuleEnforcement;
        expressionArg: number | undefined;
        name: "minTime";
        predicate: ((ctx: import("./registry").RuleContext, ...params: NoInfer<[string]> & {
            length: number;
        }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodUnion<readonly [import("zod").ZodISODateTime, import("zod").ZodISOTime]>], null>;
            name: import("zod").ZodLiteral<"minTime">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[string]>) => import("zod").ZodType;
    };
    readonly mustInclude: {
        enforcement: import("./registry").RuleEnforcement;
        expressionArg: number | undefined;
        name: "mustInclude";
        predicate: ((ctx: import("./registry").RuleContext, ...params: NoInfer<[string]> & {
            length: number;
        }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodString], null>;
            name: import("zod").ZodLiteral<"mustInclude">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[string]>) => import("zod").ZodType;
    };
    readonly mustStartWith: {
        enforcement: import("./registry").RuleEnforcement;
        expressionArg: number | undefined;
        name: "mustStartWith";
        predicate: ((ctx: import("./registry").RuleContext, ...params: NoInfer<[string]> & {
            length: number;
        }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodString], null>;
            name: import("zod").ZodLiteral<"mustStartWith">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[string]>) => import("zod").ZodType;
    };
    readonly noSpecialChar: {
        enforcement: import("./registry").RuleEnforcement;
        expressionArg: number | undefined;
        name: "noSpecialChar";
        predicate: ((ctx: import("./registry").RuleContext, ...params: NoInfer<[]> & {
            length: number;
        }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[], null>;
            name: import("zod").ZodLiteral<"noSpecialChar">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[]>) => import("zod").ZodType;
    };
    readonly noWhitespace: {
        enforcement: import("./registry").RuleEnforcement;
        expressionArg: number | undefined;
        name: "noWhitespace";
        predicate: ((ctx: import("./registry").RuleContext, ...params: NoInfer<[]> & {
            length: number;
        }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[], null>;
            name: import("zod").ZodLiteral<"noWhitespace">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[]>) => import("zod").ZodType;
    };
    readonly numberBetween: {
        enforcement: import("./registry").RuleEnforcement;
        expressionArg: number | undefined;
        name: "numberBetween";
        predicate: ((ctx: import("./registry").RuleContext, ...params: NoInfer<[number, number]> & {
            length: number;
        }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodNumber, import("zod").ZodNumber], null>;
            name: import("zod").ZodLiteral<"numberBetween">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[number, number]>) => import("zod").ZodType;
    };
    readonly numberMax: {
        enforcement: import("./registry").RuleEnforcement;
        expressionArg: number | undefined;
        name: "numberMax";
        predicate: ((ctx: import("./registry").RuleContext, ...params: NoInfer<[number]> & {
            length: number;
        }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodNumber], null>;
            name: import("zod").ZodLiteral<"numberMax">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[number]>) => import("zod").ZodType;
    };
    readonly numberMin: {
        enforcement: import("./registry").RuleEnforcement;
        expressionArg: number | undefined;
        name: "numberMin";
        predicate: ((ctx: import("./registry").RuleContext, ...params: NoInfer<[number]> & {
            length: number;
        }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodNumber], null>;
            name: import("zod").ZodLiteral<"numberMin">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[number]>) => import("zod").ZodType;
    };
    readonly regex: {
        enforcement: import("./registry").RuleEnforcement;
        expressionArg: number | undefined;
        name: "regex";
        predicate: ((ctx: import("./registry").RuleContext, ...params: NoInfer<[string, (string | null | undefined)?]> & {
            length: number;
        }) => import("../../shared/src/index").TaggedLiteral | undefined | Promise<import("../../shared/src/index").TaggedLiteral | undefined>) | undefined;
        schema: import("zod").ZodObject<{
            args: import("zod").ZodTuple<[import("zod").ZodString, import("zod").ZodOptional<import("zod").ZodNullable<import("zod").ZodString>>], null>;
            name: import("zod").ZodLiteral<"regex">;
        }, import("zod/v4/core").$strip>;
        validator: (...params: NoInfer<[string, (string | null | undefined)?]>) => import("zod").ZodType;
    };
};
