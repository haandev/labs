/**
 * Zod-first WidgetProps schemas.
 *
 * All WidgetProps TypeScript types are derived via `z.infer<>` from these schemas.
 * This is the single source of truth for both runtime validation and static types.
 */
import { z } from 'zod';
export declare const WidgetOptionSchema: z.ZodObject<{
    label: z.ZodString;
    value: z.ZodString;
}, z.core.$strip>;
export declare const WidgetDataSourceSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    type: z.ZodLiteral<"fetch">;
    url: z.ZodString;
}, z.core.$strip>], "type">;
export declare const WidgetFetchSchema: z.ZodString;
export declare const WidgetPropsBaseSchema: z.ZodObject<{
    defaultValue: z.ZodOptional<z.ZodUnknown>;
    description: z.ZodOptional<z.ZodString>;
    extras: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
    fetch: z.ZodOptional<z.ZodString>;
    hidden: z.ZodOptional<z.ZodBoolean>;
    name: z.ZodOptional<z.ZodString>;
    nullable: z.ZodOptional<z.ZodBoolean>;
    required: z.ZodOptional<z.ZodBoolean>;
    size: z.ZodOptional<z.ZodEnum<{
        1: "1";
        "1/2": "1/2";
        "1/3": "1/3";
        "1/4": "1/4";
    }>>;
    sort: z.ZodOptional<z.ZodNumber>;
    title: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
export declare const TextWidgetPropsSchema: z.ZodObject<{
    defaultValue: z.ZodOptional<z.ZodUnknown>;
    description: z.ZodOptional<z.ZodString>;
    extras: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
    fetch: z.ZodOptional<z.ZodString>;
    hidden: z.ZodOptional<z.ZodBoolean>;
    name: z.ZodOptional<z.ZodString>;
    nullable: z.ZodOptional<z.ZodBoolean>;
    required: z.ZodOptional<z.ZodBoolean>;
    size: z.ZodOptional<z.ZodEnum<{
        1: "1";
        "1/2": "1/2";
        "1/3": "1/3";
        "1/4": "1/4";
    }>>;
    sort: z.ZodOptional<z.ZodNumber>;
    title: z.ZodOptional<z.ZodString>;
    inputMask: z.ZodOptional<z.ZodString>;
    maxLength: z.ZodOptional<z.ZodNumber>;
    minLength: z.ZodOptional<z.ZodNumber>;
    regex: z.ZodOptional<z.ZodString>;
    type: z.ZodLiteral<"text">;
}, z.core.$strip>;
export declare const NumberWidgetPropsSchema: z.ZodObject<{
    defaultValue: z.ZodOptional<z.ZodUnknown>;
    description: z.ZodOptional<z.ZodString>;
    extras: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
    fetch: z.ZodOptional<z.ZodString>;
    hidden: z.ZodOptional<z.ZodBoolean>;
    name: z.ZodOptional<z.ZodString>;
    nullable: z.ZodOptional<z.ZodBoolean>;
    required: z.ZodOptional<z.ZodBoolean>;
    size: z.ZodOptional<z.ZodEnum<{
        1: "1";
        "1/2": "1/2";
        "1/3": "1/3";
        "1/4": "1/4";
    }>>;
    sort: z.ZodOptional<z.ZodNumber>;
    title: z.ZodOptional<z.ZodString>;
    max: z.ZodOptional<z.ZodNumber>;
    min: z.ZodOptional<z.ZodNumber>;
    step: z.ZodOptional<z.ZodNumber>;
    type: z.ZodLiteral<"number">;
}, z.core.$strip>;
export declare const BytesWidgetPropsSchema: z.ZodObject<{
    defaultValue: z.ZodOptional<z.ZodUnknown>;
    description: z.ZodOptional<z.ZodString>;
    extras: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
    fetch: z.ZodOptional<z.ZodString>;
    hidden: z.ZodOptional<z.ZodBoolean>;
    name: z.ZodOptional<z.ZodString>;
    nullable: z.ZodOptional<z.ZodBoolean>;
    required: z.ZodOptional<z.ZodBoolean>;
    size: z.ZodOptional<z.ZodEnum<{
        1: "1";
        "1/2": "1/2";
        "1/3": "1/3";
        "1/4": "1/4";
    }>>;
    sort: z.ZodOptional<z.ZodNumber>;
    title: z.ZodOptional<z.ZodString>;
    max: z.ZodOptional<z.ZodNumber>;
    min: z.ZodOptional<z.ZodNumber>;
    type: z.ZodLiteral<"bytes">;
}, z.core.$strip>;
export declare const ToggleWidgetPropsSchema: z.ZodObject<{
    defaultValue: z.ZodOptional<z.ZodUnknown>;
    description: z.ZodOptional<z.ZodString>;
    extras: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
    fetch: z.ZodOptional<z.ZodString>;
    hidden: z.ZodOptional<z.ZodBoolean>;
    name: z.ZodOptional<z.ZodString>;
    nullable: z.ZodOptional<z.ZodBoolean>;
    required: z.ZodOptional<z.ZodBoolean>;
    size: z.ZodOptional<z.ZodEnum<{
        1: "1";
        "1/2": "1/2";
        "1/3": "1/3";
        "1/4": "1/4";
    }>>;
    sort: z.ZodOptional<z.ZodNumber>;
    title: z.ZodOptional<z.ZodString>;
    type: z.ZodLiteral<"toggle">;
}, z.core.$strip>;
export declare const SelectWidgetPropsSchema: z.ZodObject<{
    defaultValue: z.ZodOptional<z.ZodUnknown>;
    description: z.ZodOptional<z.ZodString>;
    extras: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
    fetch: z.ZodOptional<z.ZodString>;
    hidden: z.ZodOptional<z.ZodBoolean>;
    name: z.ZodOptional<z.ZodString>;
    nullable: z.ZodOptional<z.ZodBoolean>;
    required: z.ZodOptional<z.ZodBoolean>;
    size: z.ZodOptional<z.ZodEnum<{
        1: "1";
        "1/2": "1/2";
        "1/3": "1/3";
        "1/4": "1/4";
    }>>;
    sort: z.ZodOptional<z.ZodNumber>;
    title: z.ZodOptional<z.ZodString>;
    create: z.ZodOptional<z.ZodString>;
    customString: z.ZodOptional<z.ZodBoolean>;
    multiple: z.ZodOptional<z.ZodBoolean>;
    options: z.ZodOptional<z.ZodArray<z.ZodObject<{
        label: z.ZodString;
        value: z.ZodString;
    }, z.core.$strip>>>;
    type: z.ZodLiteral<"select">;
}, z.core.$strip>;
export declare const RadioWidgetPropsSchema: z.ZodObject<{
    defaultValue: z.ZodOptional<z.ZodUnknown>;
    description: z.ZodOptional<z.ZodString>;
    extras: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
    fetch: z.ZodOptional<z.ZodString>;
    hidden: z.ZodOptional<z.ZodBoolean>;
    name: z.ZodOptional<z.ZodString>;
    nullable: z.ZodOptional<z.ZodBoolean>;
    required: z.ZodOptional<z.ZodBoolean>;
    size: z.ZodOptional<z.ZodEnum<{
        1: "1";
        "1/2": "1/2";
        "1/3": "1/3";
        "1/4": "1/4";
    }>>;
    sort: z.ZodOptional<z.ZodNumber>;
    title: z.ZodOptional<z.ZodString>;
    options: z.ZodArray<z.ZodObject<{
        label: z.ZodString;
        value: z.ZodString;
    }, z.core.$strip>>;
    type: z.ZodLiteral<"radio">;
}, z.core.$strip>;
export declare const DatetimeWidgetPropsSchema: z.ZodObject<{
    defaultValue: z.ZodOptional<z.ZodUnknown>;
    description: z.ZodOptional<z.ZodString>;
    extras: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
    fetch: z.ZodOptional<z.ZodString>;
    hidden: z.ZodOptional<z.ZodBoolean>;
    name: z.ZodOptional<z.ZodString>;
    nullable: z.ZodOptional<z.ZodBoolean>;
    required: z.ZodOptional<z.ZodBoolean>;
    size: z.ZodOptional<z.ZodEnum<{
        1: "1";
        "1/2": "1/2";
        "1/3": "1/3";
        "1/4": "1/4";
    }>>;
    sort: z.ZodOptional<z.ZodNumber>;
    title: z.ZodOptional<z.ZodString>;
    type: z.ZodUnion<readonly [z.ZodLiteral<"datetime">, z.ZodLiteral<"date">, z.ZodLiteral<"time">, z.ZodLiteral<"month">]>;
}, z.core.$strip>;
export declare const CodeWidgetPropsSchema: z.ZodObject<{
    defaultValue: z.ZodOptional<z.ZodUnknown>;
    description: z.ZodOptional<z.ZodString>;
    extras: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
    fetch: z.ZodOptional<z.ZodString>;
    hidden: z.ZodOptional<z.ZodBoolean>;
    name: z.ZodOptional<z.ZodString>;
    nullable: z.ZodOptional<z.ZodBoolean>;
    required: z.ZodOptional<z.ZodBoolean>;
    size: z.ZodOptional<z.ZodEnum<{
        1: "1";
        "1/2": "1/2";
        "1/3": "1/3";
        "1/4": "1/4";
    }>>;
    sort: z.ZodOptional<z.ZodNumber>;
    title: z.ZodOptional<z.ZodString>;
    completions: z.ZodOptional<z.ZodArray<z.ZodObject<{
        detail: z.ZodOptional<z.ZodString>;
        label: z.ZodString;
        type: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>>;
    language: z.ZodOptional<z.ZodString>;
    type: z.ZodLiteral<"code">;
}, z.core.$strip>;
export type GroupWidgetProps = z.infer<typeof WidgetPropsBaseSchema> & {
    type: 'group';
    properties: Record<string, WidgetProps>;
    /** Key of a boolean child that gates the rest of the group. */
    gate?: string;
};
export declare const GroupWidgetPropsSchema: z.ZodType<GroupWidgetProps>;
export type WidgetProps = z.infer<typeof TextWidgetPropsSchema> | z.infer<typeof NumberWidgetPropsSchema> | z.infer<typeof BytesWidgetPropsSchema> | z.infer<typeof ToggleWidgetPropsSchema> | z.infer<typeof SelectWidgetPropsSchema> | z.infer<typeof RadioWidgetPropsSchema> | z.infer<typeof DatetimeWidgetPropsSchema> | z.infer<typeof CodeWidgetPropsSchema> | GroupWidgetProps;
export declare const WidgetPropsSchema: z.ZodType<WidgetProps>;
export declare const WidgetPropsMapSchema: z.ZodReadonly<z.ZodRecord<z.ZodString, z.ZodType<WidgetProps, unknown, z.core.$ZodTypeInternals<WidgetProps, unknown>>>>;
export declare const DataMaskSchema: z.ZodObject<{
    defaultValue: z.ZodOptional<z.ZodUnknown>;
    description: z.ZodOptional<z.ZodString>;
    extras: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
    fetch: z.ZodOptional<z.ZodString>;
    hidden: z.ZodOptional<z.ZodBoolean>;
    name: z.ZodOptional<z.ZodString>;
    nullable: z.ZodOptional<z.ZodBoolean>;
    required: z.ZodOptional<z.ZodBoolean>;
    size: z.ZodOptional<z.ZodEnum<{
        1: "1";
        "1/2": "1/2";
        "1/3": "1/3";
        "1/4": "1/4";
    }>>;
    sort: z.ZodOptional<z.ZodNumber>;
    title: z.ZodOptional<z.ZodString>;
    applyTo: z.ZodOptional<z.ZodLiteral<"all" | "export" | "ui-only">>;
    enabled: z.ZodOptional<z.ZodBoolean>;
    innerText: z.ZodOptional<z.ZodString>;
    maskChar: z.ZodOptional<z.ZodString>;
    patternType: z.ZodOptional<z.ZodLiteral<"simple">>;
    preserveSeparators: z.ZodOptional<z.ZodBoolean>;
    type: z.ZodLiteral<"dataMask">;
    visibleLeading: z.ZodOptional<z.ZodNumber>;
    visibleTrailing: z.ZodOptional<z.ZodNumber>;
}, z.core.$strip>;
export type WidgetOption = z.infer<typeof WidgetOptionSchema>;
export type WidgetDataSource = z.infer<typeof WidgetDataSourceSchema>;
export type WidgetFetch = z.infer<typeof WidgetFetchSchema>;
export type WidgetPropsBase = z.infer<typeof WidgetPropsBaseSchema>;
export type TextWidgetProps = z.infer<typeof TextWidgetPropsSchema>;
export type NumberWidgetProps = z.infer<typeof NumberWidgetPropsSchema>;
export type BytesWidgetProps = z.infer<typeof BytesWidgetPropsSchema>;
export type ToggleWidgetProps = z.infer<typeof ToggleWidgetPropsSchema>;
export type SelectWidgetProps = z.infer<typeof SelectWidgetPropsSchema>;
export type RadioWidgetProps = z.infer<typeof RadioWidgetPropsSchema>;
export type DatetimeWidgetProps = z.infer<typeof DatetimeWidgetPropsSchema>;
export type CodeWidgetProps = z.infer<typeof CodeWidgetPropsSchema>;
export type WidgetPropsMap = z.infer<typeof WidgetPropsMapSchema>;
export type DataMaskProps = z.infer<typeof DataMaskSchema>;
