/**
 * Converter functions between WidgetMeta (JSON Schema meta) and WidgetProps (runtime).
 *
 * A `widget:*` key always wins. When one is absent the equivalent standard
 * JSON Schema keyword is read instead, so a schema that already states a
 * constraint does not have to repeat it.
 */
import type { GroupWidgetProps, WidgetProps } from './schema';
export interface JsonSchemaProperty {
    type?: string | string[];
    anyOf?: Array<{
        type?: string;
        [k: string]: unknown;
    }>;
    oneOf?: Array<{
        type?: string;
        [k: string]: unknown;
    }>;
    items?: JsonSchemaProperty;
    properties?: Record<string, JsonSchemaProperty>;
    required?: string[];
    format?: string;
    pattern?: string;
    minLength?: number;
    maxLength?: number;
    minimum?: number;
    maximum?: number;
    exclusiveMinimum?: number;
    exclusiveMaximum?: number;
    multipleOf?: number;
    title?: string;
    description?: string;
    default?: unknown;
    const?: unknown;
    enum?: unknown[];
    meta?: Record<string, unknown>;
    [k: string]: unknown;
}
/**
 * Convert a single JSON Schema property (with `widget:*` meta) to WidgetProps.
 * A hidden property is returned marked `hidden` rather than dropped, so callers
 * that rewrite the schema cannot lose it; renderers skip it themselves.
 */
export declare function toWidgetProps(name: string, schema: JsonSchemaProperty, options?: {
    required?: boolean;
}): WidgetProps;
/**
 * Convert all properties in a JSON Schema object to a WidgetProps map.
 * Hidden properties are included, marked `hidden`. Results are sorted by `sort`.
 */
export declare function toWidgetPropsMap(jsonSchema: JsonSchemaProperty): Record<string, WidgetProps>;
/**
 * Convert a JSON Schema tuple's `prefixItems` to an ordered WidgetProps array.
 * Supports both `widget:*` prefixed meta keys and plain meta keys
 * (as used in rule configSchema `.meta({ title, options, ... })`).
 */
export declare function tupleSchemaToWidgetProps(prefixItems: JsonSchemaProperty[]): WidgetProps[];
/**
 * Convert WidgetProps back to `widget:*` prefixed meta keys
 * suitable for JSON Schema / OpenAPI spec generation.
 */
export declare function widgetPropsToWidgetMeta(props: WidgetProps): Record<string, unknown>;
/**
 * Convert WidgetProps to a complete JSON Schema property: the standard
 * keywords carry every constraint they can express, and only what JSON Schema
 * has no word for stays behind as a `widget:*` key.
 */
export declare function widgetPropsToJsonSchema(props: WidgetProps): JsonSchemaProperty;
/**
 * Convert a WidgetProps map to a JSON Schema object with a `required` list.
 * `rootExtras` (from `rootExtrasOf`) carries the root's own non-modelled
 * keywords — `$schema`, `$defs`, root `title`, and so on — through the
 * builder's field-map-only representation. Modelled keys still win.
 */
export declare function widgetPropsMapToJsonSchema(widgets: Record<string, WidgetProps>, rootExtras?: Record<string, unknown>): JsonSchemaProperty & {
    type: 'object';
    properties: Record<string, JsonSchemaProperty>;
    required?: string[];
};
export declare function rootExtrasOf(schema: JsonSchemaProperty): Record<string, unknown> | undefined;
export type { GroupWidgetProps };
