/** Type-safe definitions for `widget:*` prefixed keys used in Zod/JSON Schema `meta` objects. */
import type { WidgetFetch, WidgetOption } from './schema';
export type { WidgetFetch, WidgetOption };
export interface WidgetMetaBase {
    'widget:hidden'?: boolean;
    'widget:fetch'?: WidgetFetch;
    'widget:size'?: '1' | '1/2' | '1/3' | '1/4';
    'widget:sort'?: number;
    /**
     * Group widgets only: the key of a boolean child that gates the group. While
     * that child is falsy only it renders; the other fields stay in the value and
     * come back untouched when it is switched on again.
     */
    'widget:gate'?: string;
    /** Allow standard JSON Schema / Zod meta fields (title, description, etc.) alongside widget:* keys */
    [key: string]: unknown;
}
export interface WidgetMetaText extends WidgetMetaBase {
    'widget:type'?: 'text';
    'widget:inputMask'?: string;
    'widget:regex'?: string;
}
export interface WidgetMetaNumber extends WidgetMetaBase {
    'widget:type'?: 'number';
    'widget:min'?: number;
    'widget:max'?: number;
    'widget:step'?: number;
}
export interface WidgetMetaBytes extends WidgetMetaBase {
    'widget:type'?: 'bytes';
    'widget:min'?: number;
    'widget:max'?: number;
}
export interface WidgetMetaToggle extends WidgetMetaBase {
    'widget:type'?: 'toggle';
}
export interface WidgetMetaSelect extends WidgetMetaBase {
    'widget:type'?: 'select';
    /**
     * Host-provided creator name; selecting it creates the typed value instead
     * of only choosing from fetched options, and the host returns the id to store.
     */
    'widget:create'?: string;
    'widget:customString'?: boolean;
    'widget:multiple'?: boolean;
    'widget:options'?: WidgetOption[];
}
export interface WidgetMetaRadio extends WidgetMetaBase {
    'widget:type'?: 'radio';
    'widget:options'?: WidgetOption[];
}
export interface WidgetMetaDatetime extends WidgetMetaBase {
    'widget:type'?: 'datetime' | 'date' | 'time' | 'month';
}
export interface WidgetMetaCode extends WidgetMetaBase {
    'widget:type'?: 'code';
    'widget:language'?: string;
    'widget:completions'?: Array<{
        label: string;
        detail?: string;
        type?: string;
    }>;
}
export interface WidgetMetaMap {
    text: WidgetMetaText;
    number: WidgetMetaNumber;
    bytes: WidgetMetaBytes;
    toggle: WidgetMetaToggle;
    select: WidgetMetaSelect;
    radio: WidgetMetaRadio;
    datetime: WidgetMetaDatetime;
    date: WidgetMetaDatetime;
    time: WidgetMetaDatetime;
    month: WidgetMetaDatetime;
    code: WidgetMetaCode;
}
export type WidgetType = keyof WidgetMetaMap;
export type WidgetMeta<T extends WidgetType = WidgetType> = WidgetMetaMap[T];
