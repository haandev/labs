/**
 * A named list passes through; an unnamed list (`'[unnamed]'`, empty, nullish)
 * collapses to `$<spaceId>.<tableId>.<columnId>`.
 */
export declare function effectiveChoiceListName(spaceId: string, tableId: string, columnId: string, rawListName: string | null | undefined): string;
/**
 * True when the list is synthesized for this column rather than a shared,
 * user-named list — compares against the name this column would synthesize.
 */
export declare function isColumnOwnedChoiceList(rawListName: string | null | undefined, spaceRef: string, tableId: string, columnId: string): boolean;
