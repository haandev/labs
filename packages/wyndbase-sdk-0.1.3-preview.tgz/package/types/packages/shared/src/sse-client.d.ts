import { EventListener, type Events } from './event';
/**
 * ±50% jitter with a 100ms floor, shared by SSE reconnect and retry backoff
 * — spreads a post-restart retry storm instead of a synchronized retry.
 */
export declare function computeJitteredDelay(baseDelay: number): number;
export type SSEReconnectPolicy = {
    initialDelayMs?: number;
    maxDelayMs?: number;
};
export type SSEClientOptions = {
    /** Full `Authorization` header value, e.g. `Bearer <token>`. */
    authorization?: string;
    /**
     * Reopen a lost stream with jittered exponential backoff. Off by default:
     * a privileged GET must not replay. Every failure retries — there is no
     * permanent refusal on a reconnecting stream.
     */
    reconnect?: SSEReconnectPolicy;
    /** Treat a stream with no bytes for this long as lost. Catches half-open
     *  connections the transport layer never reports. */
    idleTimeoutMs?: number;
};
/** Client-side lifecycle events, reserved alongside whatever `E` carries:
 *  `fail` is terminal, `drop` announces a lost stream about to be retried. */
export type SSEClientEvents = {
    fail: (message: string) => void;
    drop: (message: string) => void;
};
/**
 * Uses `fetch`, not `EventSource`, so the auth token travels in a header
 * instead of the URL. Without a `reconnect` policy it never reconnects —
 * that would replay a privileged GET.
 */
export declare class SSEClient<E extends Events> extends EventListener<E & SSEClientEvents> {
    private url;
    private options;
    private attempt;
    private closed;
    private retryTimer;
    private idleTimer;
    private wake;
    constructor(url: string, options?: SSEClientOptions);
    close(): void;
    private emitLifecycle;
    private dispatch;
    private run;
    private sleep;
    /** Watchdog for half-open connections: TCP can die without the fetch body
     *  ever erroring, and heartbeats guarantee a live stream has bytes. */
    private armIdleWatchdog;
    private disarmIdleWatchdog;
    private connectOnce;
}
export type EventToStepArgs<T extends Record<string, (...args: any[]) => any>> = {
    [K in keyof T]: T[K] extends (...args: infer Args) => any ? [action: K, ...args: Args] : never;
}[keyof T];
export type EventToStepHandler<T extends Record<string, (...args: any[]) => any>> = (...args: EventToStepArgs<T>) => Promise<void> | void;
