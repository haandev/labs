/**
 * Extracts the lower bound as a Date from a PostgreSQL tsrange string.
 * Accepts formats like '[2025-01-01T00:00:00Z,2025-02-01T00:00:00Z)'
 * or '[2025-01-01 00:00:00,2025-02-01 00:00:00)'.
 */
export declare function parseTsrangeLower(value: string): Date | null;
