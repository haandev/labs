/**
 * Converts a date-like value to a PostgreSQL TSRANGE literal
 * covering the full calendar month.
 *
 * Accepts: ISO datetime, ISO date (YYYY-MM-DD), YYYY-MM, or Date object.
 * Returns: `[YYYY-MM-01 00:00:00,YYYY-{MM+1}-01 00:00:00)`
 */
export declare function toTsrange(value: string | Date): string;
