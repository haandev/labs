export declare const nanoid: (size?: number) => string;
export declare function createDeterministicIdGenerator(alphabet: string, length: number): {
    next: () => string;
    reset: () => void;
};
export declare const nextId: () => string, resetDeterministicId: () => void;
