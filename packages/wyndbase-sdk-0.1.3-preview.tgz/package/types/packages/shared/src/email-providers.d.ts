/**
 * The admin-form half of a provider spec — no send-time behaviour, so this
 * module imports nothing. It lives here rather than in the driver because the
 * browser reads it as a value to build the provider form, and only a type may
 * cross the driver boundary; importing it from there would drag a provider's
 * own transport (nodemailer for SMTP, an HTTP client for the next one) into
 * the bundle. The driver's registry composes its send behaviour onto these
 * same keys.
 */
/** What the admin form renders for one secret-free setting. */
export type ConfigFieldDescriptor = {
    name: string;
    label: string;
    kind: 'text' | 'number' | 'boolean';
    required: boolean;
    placeholder?: string;
};
export type EmailProviderDescriptor = {
    /** Drives the admin form, so a new provider touches no front-end file. */
    configFields: readonly ConfigFieldDescriptor[];
    credentialLabel: string;
    /** False drops the inline logo and sends anyway; the frame falls back to the
     *  base name on its own. */
    supportsAttachments: boolean;
};
declare const EMAIL_PROVIDER_DESCRIPTOR_MAP: {
    mailgun: {
        configFields: ({
            kind: "text";
            label: string;
            name: string;
            placeholder: string;
            required: true;
        } | {
            kind: "text";
            label: string;
            name: string;
            placeholder: string;
            required: false;
        })[];
        credentialLabel: string;
        supportsAttachments: true;
    };
    plunk: {
        configFields: never[];
        credentialLabel: string;
        supportsAttachments: true;
    };
    postmark: {
        configFields: {
            kind: "text";
            label: string;
            name: string;
            placeholder: string;
            required: false;
        }[];
        credentialLabel: string;
        supportsAttachments: true;
    };
    resend: {
        configFields: never[];
        credentialLabel: string;
        supportsAttachments: true;
    };
    sendgrid: {
        configFields: {
            kind: "text";
            label: string;
            name: string;
            placeholder: string;
            required: false;
        }[];
        credentialLabel: string;
        supportsAttachments: true;
    };
    smtp: {
        configFields: ({
            kind: "text";
            label: string;
            name: string;
            placeholder: string;
            required: true;
        } | {
            kind: "number";
            label: string;
            name: string;
            placeholder: string;
            required: true;
        } | {
            placeholder?: undefined;
            kind: "boolean";
            label: string;
            name: string;
            required: false;
        } | {
            placeholder?: undefined;
            kind: "text";
            label: string;
            name: string;
            required: false;
        })[];
        credentialLabel: string;
        supportsAttachments: true;
    };
    zeptomail: {
        configFields: {
            kind: "text";
            label: string;
            name: string;
            placeholder: string;
            required: false;
        }[];
        credentialLabel: string;
        supportsAttachments: true;
    };
};
export type EmailProviderTypeName = keyof typeof EMAIL_PROVIDER_DESCRIPTOR_MAP;
export declare const EMAIL_PROVIDER_DESCRIPTORS: Readonly<Record<EmailProviderTypeName, EmailProviderDescriptor>>;
export {};
