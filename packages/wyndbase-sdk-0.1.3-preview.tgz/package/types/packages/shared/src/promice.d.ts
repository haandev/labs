import { type PromiseFactory, Queue, type QueueConfig, type TaskOptions } from './queue';
/** Executor function for Promice. */
type Executor<T> = (resolve: (value: T | PromiseLike<T>) => void, reject: (reason?: any) => void) => void;
type OnRejected<T> = ((reason: any) => T | PromiseLike<T>) | undefined | null;
type OnFulfilled<R, T> = ((value: T) => R | PromiseLike<R>) | undefined | null;
declare const ensure: unique symbol;
export declare class Promice<T> implements Promise<T> {
    [Symbol.toStringTag]: string;
    static queues: Map<string, Queue>;
    static unnamedqueues: Queue[];
    static get allQueues(): Queue<any>[];
    private executor;
    private inner;
    private [ensure];
    /**
     * Creates a new Promice instance.
     *
     * @param exec - Executor function receiving resolve and reject callbacks.
     */
    constructor(exec: Executor<T>);
    /**
     * Executes the Promice. If you dont need any chaining, use this method
     * instead of then.
     *
     * @returns A Promise resolving with the Promice's result.
     * @public
     */
    exec(): Promise<T>;
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promice.
     *
     * @param onfulfilled - Called when the Promice is resolved.
     * @param onrejected - Called when the Promice is rejected.
     * @returns A new Promise for chaining.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: OnFulfilled<TResult1, T>, onrejected?: OnRejected<TResult2>): Promise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promice.
     *
     * @param onrejected - Called when the Promice is rejected.
     * @returns A new Promise for chaining.
     */
    catch<TResult = never>(onrejected?: OnRejected<TResult>): Promise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promice is settled (fulfilled
     * or rejected).
     *
     * @param onfinally - Callback invoked when settled.
     * @returns A new Promise for chaining.
     */
    finally(onfinally?: (() => void) | undefined | null): Promise<T>;
    /**
     * Returns a Promice that is resolved with the given value.
     *
     * @param value - The value to resolve with.
     */
    static resolve<T>(value: T | PromiseLike<T>): Promice<T>;
    /**
     * Returns a Promice that is rejected with the given reason.
     *
     * @param reason - The rejection reason.
     */
    static reject<T = never>(reason?: any): Promice<T>;
    /**
     * Runs multiple tasks in parallel and resolves with an array of their
     * results.
     *
     * @param tasks - Array of tasks to run.
     * @param config - Queue configuration.
     * @returns A Promice resolving to an array of results.
     */
    static all<T>(tasks: Array<PromiseFactory<T>>, config?: QueueConfig): Promice<T[]>;
    /**
     * Runs multiple tasks in parallel and resolves with their settled results.
     *
     * @param tasks - Array of tasks to run.
     * @param config - Queue configuration.
     * @returns A Promice resolving to an array of settled results.
     */
    static allSettled<T>(tasks: Array<PromiseFactory<T>>, config?: QueueConfig): Promice<PromiseSettledResult<T>[]>;
    /**
     * Returns a Promice that fulfills as soon as any of the provided tasks
     * fulfills.
     *
     * @param tasks - Array of tasks to run.
     * @param config - Queue configuration and keepRunning option.
     * @returns A Promice resolving with the first fulfilled task's result.
     */
    static any<T>(tasks: Array<PromiseFactory<T>>, config?: QueueConfig & {
        keepRunning?: boolean;
    }): Promice<T>;
    /**
     * Returns a Promice that settles as soon as any of the provided tasks
     * settles.
     *
     * @param tasks - Array of tasks to run.
     * @param config - Queue configuration and keepRunning option.
     * @returns A Promice resolving or rejecting with the first settled task.
     */
    static race<T>(tasks: Array<PromiseFactory<T>>, config?: QueueConfig & {
        keepRunning?: boolean;
    }): Promice<T>;
    /**
     * Creates a Promice along with its resolve and reject functions.
     *
     * @returns Object containing the promice, resolve and reject callbacks.
     */
    static withResolvers<T>(): {
        promice: Promice<T>;
        reject: (reason?: any) => void;
        resolve: (value: T | PromiseLike<T>) => void;
    };
    /**
     * Executes a synchronous or asynchronous function and wraps its result in a
     * Promice.
     *
     * @param func - Function to execute.
     * @param args - Arguments to pass to the function.
     * @returns A Promice resolving with the function's result.
     */
    static try<T>(func: (...args: any[]) => T | Promise<T> | Promice<T>, ...args: any[]): Promice<T>;
    /**
     * Returns the status of a named queue.
     *
     * @param name - Name of the queue.
     */
    static status(name: string): {
        concurrency: number | undefined;
        length: number;
        respectPriority: boolean | undefined;
        running: number;
        signal: AbortSignal | undefined;
        timeout: number | undefined;
    } | undefined;
    /**
     * Creates a new queue with the given name and configuration.
     *
     * @param name - Queue name.
     * @param config - Queue configuration options.
     * @returns The created queue.
     */
    static createQueue(name: string, config: QueueConfig): Queue<any>;
    /**
     * Runs a task on a named queue.
     *
     * @param promiseFactory - Task to run.
     * @param queueName - Name of the queue.
     * @param options - Task execution options.
     * @returns A Promise resolving with the task result.
     */
    static run<T>(promiseFactory: PromiseFactory<T>, queueName: string, options?: TaskOptions): Promise<T>;
    /**
     * Clears all tasks in the named queue.
     *
     * @param name - Queue name.
     */
    static clearQueue(name: string): void;
    /**
     * Deletes a named queue, freeing its memory.
     *
     * @param name - Queue name.
     */
    static deleteQueue(name: string): void;
    /**
     * Pauses task execution in the named queue.
     *
     * @param name - Queue name.
     */
    static pauseQueue(name: string): void;
    /**
     * Resumes task execution in the named queue.
     *
     * @param name - Queue name.
     */
    static resumeQueue(name: string): void;
    /** Pauses all queues managed by Promice. */
    static pauseAll(): void;
    /** Resumes all queues managed by Promice. */
    static resumeAll(): void;
    /** Clears all queues managed by Promice. */
    static clearAll(): void;
}
/**
 * Converts a Promise-returning function into a lazy Promice.
 *
 * Unlike regular Promises which execute immediately upon creation, Promice instances
 * created with `lazify` won't execute until they are consumed (via `.then()`, `.catch()`,
 * `.exec()`, or `await`). This is useful for deferring expensive operations until they're
 * actually needed.
 *
 * @template T - The type of value the Promise resolves to.
 * @param fn - A function that returns a Promise. This function won't be called until
 *             the resulting Promice is consumed.
 * @returns A Promice that lazily executes the provided function.
 *
 * @example
 * ```typescript
 * // This API call won't execute immediately
 * const lazyUser = lazify(() => fetchUser(123))
 *
 * // Still not executed...
 * if (needsUser) {
 *   // Only now does the API call happen
 *   const user = await lazyUser
 * }
 * ```
 *
 * @example
 * ```typescript
 * // Expensive computation that we might not need
 * const lazyResult = lazify(async () => {
 *   console.log('Computing...') // Won't log until consumed
 *   return expensiveCalculation()
 * })
 *
 * // Computation hasn't started yet
 * conditionallyUse(lazyResult) // Only runs if actually awaited inside
 * ```
 *
 * @see {@link Promice} for more information about lazy promise execution.
 */
export declare const lazify: <T>(fn: () => Promise<T>) => Promice<T>;
export {};
