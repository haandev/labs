/**
 * A result set encoded as one column header plus one array of values per row,
 * in header order. The object-per-row form repeats every column name once per
 * row; this form names them once.
 */
export interface HeaderAndRows {
    columns: string[];
    rows: unknown[][];
}
/**
 * Encodes object rows as a header and value arrays. Cells are carried by
 * reference — never cloned, stringified or inspected — so an already
 * serialized cell reaches the response serializer intact.
 *
 * The header is the first row's keys, and the contract is a result set whose
 * rows all share it: a key only a later row carries is not in the header and
 * does not survive. A cell that is `undefined` becomes `null` on the wire,
 * where the object form would have omitted the key.
 */
export declare function toHeaderAndRows(rows: readonly unknown[]): HeaderAndRows;
/**
 * The inverse of {@link toHeaderAndRows}. Rows come back on a null prototype,
 * so a consumer calling `row.hasOwnProperty(…)` must reach for
 * `Object.hasOwn` instead.
 */
export declare function fromHeaderAndRows(encoded: HeaderAndRows): Record<string, unknown>[];
