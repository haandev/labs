/**
 * Wall-clock helper for the `timerange` column wire format.
 *
 * Wire format encodes wall-clock h:m as UTC: the digits the user typed
 * are tagged with a `Z` marker on a `2100-01-0[12]` sentinel date.
 * PostgreSQL may return the value without the TZ marker — this helper
 * normalizes to UTC parsing (heuristic Z-append, `space → T` swap) and
 * reads h:m back, isolating that quirk in one place so call sites (codec,
 * grid formatter, editor materialization) all agree.
 *
 * @returns UTC h:m, or `null` if the input cannot be parsed.
 */
export declare const readWallClockHm: (s: string) => {
    h: number;
    m: number;
} | null;
/**
 * Materialize a local `Date` whose local h:m mirror the wire-format's
 * wall-clock UTC h:m, so a time picker renders the same digits the user
 * typed regardless of FE timezone.
 *
 * Form state may oscillate between wire-format strings (initial / server-
 * sourced) and `Date` objects (fresh picker output) — pass `Date` through
 * unchanged so an active edit keeps its already-correct local time.
 */
export declare const wireToLocalDate: (v: string | Date | null) => Date | null;
