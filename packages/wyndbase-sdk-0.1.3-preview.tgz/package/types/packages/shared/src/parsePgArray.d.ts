/**
 * Parses a PostgreSQL array literal Bun's client doesn't decode natively
 * (e.g. `uuid[]`), since PG only quotes elements when it has to.
 */
export declare function parsePgArray(value: unknown): unknown[];
