import type { SessionMeta } from './session';
export type ClientConfig = {
    _id: string;
    shortName: string;
    allowRawWql: boolean | null;
    isIdp: boolean | null;
    accessTokenTtl: number | null;
    refreshTokenTtl: number | null;
    sessionDuration: number | null;
    inactivityTimeout: number | null;
    rateLimitRpm: number | null;
    rateLimitBurst: number | null;
    allowedOrigins: string[] | null;
};
export type TransactionContext = SessionMeta & {
    requestId: string;
    userId?: string;
    /** Current session assurance level (NIST AAL), parsed from the JWT `acr`. */
    aal?: number;
    /** Authentication methods used (RFC 8176 `amr`), from the JWT. */
    amr?: string[];
    /** OAuth2 scopes the session's access token carries, from the JWT
     *  `scope` claim. Capability scopes (`wql:raw`) ride here into WQL
     *  admission. */
    scopes?: string[];
    baseId?: string;
    /** The base the caller authenticated against, from the access token's
     *  `baseId` claim — never the base the request targets. */
    callerHomeBaseId?: string;
    clientId?: string;
    clientShortName?: string;
    clientConfig?: ClientConfig;
    sessionMeta?: SessionMeta;
};
