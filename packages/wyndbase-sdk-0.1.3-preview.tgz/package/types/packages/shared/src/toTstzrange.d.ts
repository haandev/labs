/**
 * Unlike {@link toTsrange} (wall-clock `tsrange`), the bounds carry the `+00`
 * designator, so the cast anchors them in UTC instead of the DB session zone.
 */
export declare function toTstzrange(value: string | Date): string;
