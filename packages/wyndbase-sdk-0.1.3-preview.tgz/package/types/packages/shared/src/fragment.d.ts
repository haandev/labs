export type TaggedLiteral = [TemplateStringsArray, ...any[]];
export type Stringify = (value: any) => string;
export type Mergeable = TaggedLiteral | any;
export declare const isTemplateStringsArray: (value: unknown) => value is TemplateStringsArray;
export declare const isTaggedLiteral: (arg: any) => arg is TaggedLiteral;
export declare const isEmptyTaggedLiteral: (arg: TaggedLiteral) => boolean;
export declare const isEmpty: (arg?: null | undefined | string | TaggedLiteral) => boolean;
declare const joinfragments: (templates: Mergeable[], delimiter?: string) => TaggedLiteral;
declare const fragment: fragment;
export interface fragment {
    /**
     * Creates a tagged template string representation from a plain string.
     *
     * This is useful for injecting raw SQL/text directly without any interpolated
     * values.
     *
     * @example
     *   ```ts
     *   fragment('SELECT * FROM users')
     *   fragment(`${NON_PORTAL_VALUE} NON PORTAL VALUE`)
     *   ```
     *
     * @param str - A plain string to be treated as a tagged string.
     * @returns A `TaggedLiteral` containing the input string.
     */
    (str: string): TaggedLiteral;
    /**
     * Creates a `TaggedLiteral` from a tagged template literal.
     *
     * Supports interpolated values including nested `TaggedLiteral`s, which will
     * be automatically flattened and merged.
     *
     * This is the primary and most powerful way to construct reusable tagged
     * fragments.
     *
     * @example
     *   Basic usage:
     *   ```ts
     *   const id = 42
     *   fragment`SELECT * FROM users WHERE id = ${id}`
     *   ```
     *
     * @example
     *   Nested `TaggedLiteral`s:
     *   ```ts
     *   const condition1 = fragment`age > ${18}`
     *   const condition2 = fragment`status = ${'active'}`
     *   const where = fragment`WHERE ${condition1} AND ${condition2}`
     *   // Result: [ ["WHERE age > ", " AND status = ", ""], 18, "active" ]
     *   ```
     *
     * @param strings - The template strings array (automatically provided by JS
     *   engine).
     * @param values - The interpolated values, which may include nested
     *   `TaggedLiteral`s.
     * @returns A flattened and merged `TaggedLiteral`.
     */
    (strings: TemplateStringsArray, ...values: any[]): TaggedLiteral;
    /**
     * Combines multiple `TaggedLiteral` or `string` fragments into a single
     * `TaggedLiteral`.
     *
     * This is used to concatenate parts, useful for composing complex queries or
     * nested tagged strings.
     *
     * Automatically flattens nested `TaggedLiteral` values and merges string
     * fragments.
     *
     * @example
     *   ```ts
     *   const condition = fragment`age > ${18}`
     *   const clause = fragment('WHERE ', condition)
     *   ```
     *
     * @param args - A list of `TaggedLiteral` or plain strings.
     * @returns A single flattened and merged `TaggedLiteral`.
     */
    (...args: Mergeable[]): TaggedLiteral;
    /**
     * Joins multiple `TaggedLiteral` fragments with a specified delimiter.
     *
     * `joinfragments` is useful when you have several tagged template parts
     * (e.g., SQL conditions, string fragments) that need to be combined into a
     * single `TaggedLiteral`, with a custom delimiter (such as `" AND "` or `",
     * "`).
     *
     * The resulting `TaggedLiteral` is flattened and normalized so that the
     * structure remains valid (i.e., `strings.length === values.length + 1`).
     *
     * @example
     *   Basic usage:
     *   ```ts
     *   const cond1 = fragment`age > ${18}`
     *   const cond2 = fragment`status = ${'active'}`
     *   const joined = fragment.join([cond1, cond2], ' AND ')
     *   // Result generates same as fragment`age > ${18} AND status = ${'active'}`
     *   ```
     *
     * @example
     *   Deeply nested composition:
     *   ```ts
     *   const conds = [
     *   fragment`a = ${1}`,
     *   fragment`b = ${2}`,
     *   fragment`c = ${3}`,
     *   ]
     *   const complex = fragment.join(conds, ' OR ')
     *   // Result generates same as fragment`a = ${1} OR b = ${2} OR c = ${3}`
     *   ```
     *
     * @param taggedStrings - An array of `TaggedLiteral` fragments to join.
     * @param delimiter - The string inserted between each fragment.
     * @returns A normalized and flattened `TaggedLiteral` combining all parts
     *   with the given delimiter.
     */
    join: typeof joinfragments;
    /**
     * Converts a TaggedLiteral ([TemplateStringsArray, ...any[]]) into a single
     * flat string by interpolating all values in order.
     *
     * @example
     *   ```ts
     *   dump(fragment`SELECT * FROM users WHERE id = ${42}`)
     *   // "SELECT * FROM users WHERE id = 42"
     *   // or it accepts literal syntax too
     *   dump`SELECT * FROM users WHERE id = ${42}`
     *   // "SELECT * FROM users WHERE id = 42"
     *   ```
     */
    dump: fragmentDump;
    /**
     * Logs the fragment to the console.
     *
     * @example
     *   ```ts
     *   dumpLog(fragment`SELECT * FROM users WHERE id = ${42}`)
     *   // "SELECT * FROM users WHERE id = 42"
     *   ```
     */
    dumpLog: fragmentDump;
    /**
     * Creates a dump function with a custom stringify function. Useful for using
     * tools like bun.sql or postgresjs
     *
     * @example
     *   ```ts
     *   const dump = fragment.createDump((value) => {
     *   return typeof value === 'string' ? value : String(value)
     *   })
     *   dump(fragment`SELECT * FROM users WHERE id = ${42}`)
     *   // "SELECT * FROM users WHERE id = 42"
     *   ```
     */
    createDump: (stringify: Stringify) => {
        dump: fragmentDump;
        dumpLog: fragmentDump;
    };
}
interface fragmentDump {
    (...args: TaggedLiteral): string;
    (fragment: TaggedLiteral): string;
}
export default fragment;
