/**
 * RealtimeFilterNode Visitor Utilities
 *
 * Single source of truth for `RealtimeFilterNode` tree shape — mirrors the
 * `walkExpression` / `mapExpression` / `collectFromExpression` family that
 * exists for `Expression` AST in `@wyndb/wql/ast/expression-visitor.ts`.
 *
 * Use these helpers instead of writing manual switch-based filter tree walks.
 * If a new node variant is added to `RealtimeFilterNode`, only this file needs
 * updating — every consumer using the helpers picks up the change for free.
 */
import type { RealtimeFilterNode } from './realtime';
/**
 * Get all child filter nodes of a node. Single source of truth for filter
 * tree structure.
 */
export declare function getChildFilterNodes(node: RealtimeFilterNode): RealtimeFilterNode[];
/**
 * Walk every node in a filter tree, calling the callback on each.
 * Depth-first, pre-order traversal — matches the recursion order of the
 * hand-written walkers it replaces.
 */
export declare function walkFilter(node: RealtimeFilterNode, callback: (n: RealtimeFilterNode) => void): void;
/**
 * Returns true if any node in the filter tree satisfies the predicate.
 * Short-circuits on first match.
 */
export declare function someFilter(node: RealtimeFilterNode, predicate: (n: RealtimeFilterNode) => boolean): boolean;
/**
 * Returns true if every node in the filter tree satisfies the predicate.
 */
export declare function everyFilter(node: RealtimeFilterNode, predicate: (n: RealtimeFilterNode) => boolean): boolean;
/**
 * Collect typed values from each node, dropping any `undefined` results.
 * Identical depth-first pre-order to `walkFilter`.
 */
export declare function collectFromFilter<T>(node: RealtimeFilterNode, collector: (n: RealtimeFilterNode) => T | undefined): T[];
/**
 * Bottom-up transform of a filter tree. Children are transformed first, then
 * the parent. Returning `null` from the transform keeps the original node
 * (with its children replaced); returning a node substitutes that node.
 *
 * Note: NOT-inversion semantics in `filter-comparator` need to abort traversal
 * on un-invertible descendants. For that specific case, callers should keep
 * their bespoke walker — `mapFilter` is for total transforms only.
 */
export declare function mapFilter(node: RealtimeFilterNode, transform: (n: RealtimeFilterNode) => RealtimeFilterNode | null): RealtimeFilterNode;
