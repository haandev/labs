import { z } from 'zod';
export declare const jsonString: <T extends z.ZodTypeAny>(schema: T) => z.ZodPipe<z.ZodTransform<any, unknown>, T>;
