import type { z } from 'zod';
import type { TaggedLiteral } from './fragment';
import type { TransactionContext } from './transaction';
export type From = string | QueryFrom;
export type QueryFrom = QueryOptionals & {
    from: From;
    forUpdateSkipLocked?: boolean;
};
export type QueryOptionals = {
    alias?: string;
    limit?: number;
    offset?: number;
    count?: boolean | 'withData';
    select?: Selectable[] | Selectable;
    filter?: Condition;
    hashed?: boolean;
    decrypt?: boolean | null | string;
};
export type QueryColumn = QueryOptionals & ColumnCommons;
export type NamedQuery = string;
export type Query = QueryFrom | QueryColumn;
export type ColumnCommons = {
    column: string;
    arrayAgg?: boolean;
    alias?: string;
};
export type Column = ColumnCommons | QueryColumn;
export type Selectable = string | Query | Column;
type DotPrefix<T extends string, P extends string> = P extends '' ? T : `${P}.${T}`;
type DotNestedKeys<T, Prefix extends string = ''> = T extends Primitive ? Prefix extends '' ? never : Prefix : T extends (infer U)[] ? DotNestedKeys<U, Prefix> : T extends object ? {
    [K in keyof T]: DotNestedKeys<T[K], DotPrefix<Extract<K, string>, Prefix>>;
}[keyof T] : never;
type DefineOperation<Operator extends string, Value> = {
    [P in Operator]: {
        [Q in P]: Value;
    };
}[Operator];
export type Primitive = string | number | boolean | null | undefined | symbol | bigint;
type Context = DotNestedKeys<TransactionContext>;
export type ContextParameter = {
    type: 'context';
    context: Context;
};
export type Parameter = {
    type: 'parameter';
    parameter: string;
};
export type Reference = {
    type: 'reference';
    reference: string;
};
export type Expression = {
    type: 'expression';
    expression: string | TaggedLiteral;
};
export type Returning = {
    type: 'returning';
    returning: string;
    source: string;
};
export type QuotedValue = `'${string}'`;
export type Value = {
    type: 'value';
    value: Primitive;
};
type LeftOperand = string;
export type TypedOperand = Value | Reference | Returning | Expression | ContextParameter | Parameter | FunctionCall;
export type NormalOperand = TypedOperand | Query | Condition;
export type Operand = NormalOperand | Primitive;
type FunctionCall = {
    type: 'function';
    function: 'concat' | 'max' | 'min' | 'subtract' | 'add';
    parameters: Operand[];
};
type EqualsConditionValue = Operand;
export type BinaryOperation = 'equals' | 'notEquals' | 'lessThan' | 'greaterThan' | 'lessThanOrEqual' | 'greaterThanOrEqual' | 'like' | 'ilike' | 'notLike' | 'notILike';
type BinaryConditionValue = DefineOperation<BinaryOperation, Operand>;
export type NormalBinaryCondition = {
    left: NormalOperand;
    right: NormalOperand;
    operator: BinaryOperation;
};
export type RangeOperations = 'between' | 'notBetween' | 'betweenSymmetric' | 'notBetweenSymmetric';
type RangeConditionValue = DefineOperation<RangeOperations, [
    Operand,
    Operand
] | Reference>;
export interface NormalRangeCondition {
    left: NormalOperand;
    right: [NormalOperand, NormalOperand] | Reference;
    operator: RangeOperations;
}
export type InOperation = 'in' | 'notIn';
type InConditionValue = DefineOperation<InOperation, Operand[] | Reference>;
export interface NormalInCondition {
    left: NormalOperand;
    right: NormalOperand[] | Query;
    operator: InOperation;
}
type HasOperation = 'has';
export type HasValue = Condition;
export type NormalHasValue = NormalGroupCondition;
type HasConditionValue = DefineOperation<HasOperation, HasValue>;
export interface NormalHasCondition {
    left: NormalOperand;
    right: NormalHasValue;
    operator: HasOperation;
}
export interface AndGroupWithConditions {
    and: Condition[] | QuickCondition;
}
type GroupOperation = 'and' | 'or';
export interface OrGroupWithConditions {
    or: Condition[] | QuickCondition;
}
export interface NormalGroupCondition {
    operator: GroupOperation;
    conditions: NormalCondition[];
}
type GroupWithConditions = AndGroupWithConditions | OrGroupWithConditions;
export type FieldOperation = BinaryOperation | RangeOperations | InOperation | HasOperation;
export type ValueWithOperation = EqualsConditionValue | BinaryConditionValue | RangeConditionValue | InConditionValue | HasConditionValue;
type QuickSingleCondition = {
    [key in LeftOperand]: ValueWithOperation | ValueWithOperation[];
};
type QuickCondition = QuickSingleCondition | GroupWithConditions | QuickSingleCondition[];
export type NormalSingleCondition = NormalBinaryCondition | NormalRangeCondition | NormalInCondition | NormalHasCondition;
export type NormalCondition = NormalSingleCondition | NormalGroupCondition;
export type SingleCondition = QuickSingleCondition | NormalSingleCondition;
export type Condition = QuickCondition | NormalCondition;
type SingleSet = Record<string, Operand>;
type MultipleSet = SingleSet[];
export type SetObject = SingleSet | MultipleSet;
type TableName = string;
type MutationCondition = Condition | QueryFrom | NamedQuery;
interface MutationCommons {
    id?: string;
    if?: MutationCondition;
    failure?: Statement;
    save?: string;
}
interface SingleMutainCommons extends MutationCommons {
    returning?: Selectable[];
}
export interface UpdateMutation extends SingleMutainCommons {
    filter: Condition;
    set: SingleSet;
    update: TableName;
    limit?: number;
}
export interface InsertMutation extends SingleMutainCommons {
    insert: TableName;
    set: SetObject;
}
export interface DeleteMutation extends SingleMutainCommons {
    delete: TableName;
    filter: Condition;
    limit?: number;
}
export type SingleMutation = UpdateMutation | InsertMutation | DeleteMutation;
export interface ConditionalStep {
    if?: MutationCondition;
    then?: Statement;
    else?: Statement;
}
type TransactionItemKey = string;
type ThenOrElseStatement = {
    exception?: string;
    rollback?: TransactionItemKey;
};
type FatalThenOrElseStatement = {
    fatal?: boolean;
    exception?: string;
};
type Statement = ThenOrElseStatement | FatalThenOrElseStatement;
export type CompositeMutationItem = SingleMutation | CompositeMutation | ConditionalStep;
export interface CompositeMutation extends MutationCommons {
    mutations: CompositeMutationItem[];
    finalQuery?: QueryFrom | NamedQuery;
}
export type Mutation = SingleMutation | CompositeMutation;
export type MutationItem = Mutation | ConditionalStep;
export type NormalCompositeMutation = Omit<CompositeMutation, 'mutations' | 'id'> & {
    id: string;
    mutations: (NormalSingleMutation | NormalCompositeMutation | ConditionalStep)[];
};
export type NormalSingleMutation = Omit<SingleMutation, 'id'> & {
    id: string;
};
export type NormalMutation = NormalSingleMutation | NormalCompositeMutation;
export type QueryConfig = {
    skipResult?: boolean;
    jsonSchema?: boolean;
    sqlString?: boolean;
    typescriptInterface?: boolean;
    totalCount?: boolean;
};
export type QueryEnvelope<Row, Config extends QueryConfig = Record<string, unknown>> = (Config['skipResult'] extends true ? Record<string, unknown> : {
    result: Row[];
}) & (Config['sqlString'] extends true ? {
    sqlString: string;
} : Record<string, unknown>) & (Config['jsonSchema'] extends true ? {
    jsonSchema: z.core.JSONSchema.JSONSchema;
} : Record<string, unknown>) & (Config['typescriptInterface'] extends true ? {
    typescriptInterface: string;
} : Record<string, unknown>) & (Config['totalCount'] extends true ? {
    totalCount: number;
} : Record<string, unknown>);
export declare const isFromQuery: (selectable: unknown) => selectable is QueryFrom;
export declare const isColumnQuery: (selectable: unknown) => selectable is QueryColumn;
export declare const isQuery: (selectable: any) => selectable is Query;
export declare const isColumn: (selectable: Selectable) => selectable is Column | string;
export declare const asColumnObject: (column: string | Column) => Column;
export declare const isWrappedSingleQuote: (str: string) => str is QuotedValue;
export declare const unwrapSingleQuote: (str: QuotedValue) => string;
export declare const isValue: (operand: ValueWithOperation | Operand) => operand is Value;
export declare const isValueWithOperation: (operand: ValueWithOperation | Operand) => operand is ValueWithOperation;
export declare const castValue: (value: Primitive) => Value;
export declare const isReference: (operand: Operand) => operand is Reference;
export declare const castReference: (reference: string) => Reference;
export declare const isExpression: (operand: Operand) => operand is Expression;
export declare const isContextParameter: (operand: Operand) => operand is ContextParameter;
export declare const isParameter: (operand: Operand) => operand is Parameter;
export declare const isHasValue: (value: any) => value is HasValue;
export declare const isNormalHasValue: (value: any) => value is NormalHasValue;
export declare const isNormalGroupCondition: (condition: Condition) => condition is NormalGroupCondition;
export declare const normalizeOperand: (operand: Operand) => NormalOperand;
export declare const normalizeCondition: (condition: Condition) => NormalGroupCondition;
export declare const denormalizeCondition: (normalized: NormalCondition) => Condition;
export declare const normalizeColumn: (selection: Selectable) => QueryColumn;
export {};
