import { z } from 'zod';
export declare const FACTOR_TIERS: readonly ['T0', 'T1', 'T2', 'T3'];
export type FactorTier = (typeof FACTOR_TIERS)[number];
export declare const FACTOR_STATUSES: readonly ['SETUP', 'PENDING', 'ACTIVE', 'DISABLED', 'RECOVERY', 'REVOKED'];
export type FactorStatus = (typeof FACTOR_STATUSES)[number];
/**
 * Method key -> assurance tier. A method is anything a step can offer, but
 * `password_reset` is a method nobody enrols or holds — not a factor.
 */
export declare const FACTOR_TYPE_TIERS: {
    readonly email_otp: 'T2';
    readonly hardware_key: 'T3';
    readonly magic_link: 'T2';
    readonly oidc_external: 'T0';
    readonly passkey_device_bound: 'T3';
    readonly passkey_synced: 'T3';
    readonly password: 'T1';
    readonly password_reset: 'T2';
    readonly pin: 'T1';
    readonly push_notification: 'T2';
    readonly recovery_codes: 'T2';
    readonly security_question: 'T1';
    readonly sms_otp: 'T2';
    readonly social_apple: 'T0';
    readonly social_github: 'T0';
    readonly social_google: 'T0';
    readonly totp: 'T2';
};
export type FactorType = keyof typeof FACTOR_TYPE_TIERS;
/** Cryptographic types whose key is non-exportable (AAL3 candidates). */
export declare const DEVICE_BOUND_TYPES: ReadonlySet<string>;
export declare function tierForType(type: string): FactorTier | undefined;
export declare function isDeviceBound(type: string): boolean;
/**
 * T2 possession types NIST accepts as AAL2-qualifying; phishable channels
 * (email-based) are excluded per NIST SP 800-63B 5.1.3.1.
 */
export declare const AAL2_QUALIFYING_TYPES: ReadonlySet<string>;
export declare function isAal2Qualifying(type: string): boolean;
export declare const FactorTypeSchema: z.ZodEnum<{
    email_otp: "email_otp";
    hardware_key: "hardware_key";
    magic_link: "magic_link";
    oidc_external: "oidc_external";
    passkey_device_bound: "passkey_device_bound";
    passkey_synced: "passkey_synced";
    password: "password";
    password_reset: "password_reset";
    pin: "pin";
    push_notification: "push_notification";
    recovery_codes: "recovery_codes";
    security_question: "security_question";
    sms_otp: "sms_otp";
    social_apple: "social_apple";
    social_github: "social_github";
    social_google: "social_google";
    totp: "totp";
}>;
export declare const FactorStatusSchema: z.ZodEnum<{
    ACTIVE: "ACTIVE";
    DISABLED: "DISABLED";
    PENDING: "PENDING";
    RECOVERY: "RECOVERY";
    REVOKED: "REVOKED";
    SETUP: "SETUP";
}>;
export declare const FactorTierSchema: z.ZodEnum<{
    T0: "T0";
    T1: "T1";
    T2: "T2";
    T3: "T3";
}>;
