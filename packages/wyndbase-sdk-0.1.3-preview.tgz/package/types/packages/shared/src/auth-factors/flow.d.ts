import { z } from 'zod';
import type { FactorType } from './types';
/**
 * Capability keys the model describes but no factor verifies yet — withheld
 * from `FLOW_FIRST_FACTORS` so no admin can offer a route that never completes.
 */
export declare const NOT_YET_VERIFIABLE: ReadonlySet<FactorType>;
/**
 * Factor types valid as a configured first factor: `canBeStep1`, not
 * redirect-answered, granting a session, and verifiable today.
 */
export declare const FLOW_FIRST_FACTORS: readonly ['password', 'passkey_synced', 'passkey_device_bound'];
/**
 * The normalized "what next" for both first factor and step-up.
 * `update_password` is a required action run before any token is issued.
 */
export type FlowNext = {
    factors: FactorType[];
    required: boolean;
    mode: 'verify' | 'enroll' | 'update_password';
    autoSelect?: FactorType;
    escapes: FactorType[];
};
/**
 * Flow configuration stored on `clients.idpSettings`. `.passthrough()` keeps
 * unrelated keys such as `consentPageUrl` and `trustedProviders`.
 */
export declare const FlowConfigSchema: z.ZodObject<{
    allowedFirstFactors: z.ZodDefault<z.ZodArray<z.ZodEnum<{
        passkey_device_bound: "passkey_device_bound";
        passkey_synced: "passkey_synced";
        password: "password";
    }>>>;
    excludedProviderIds: z.ZodDefault<z.ZodArray<z.ZodString>>;
    federatedSignIn: z.ZodDefault<z.ZodBoolean>;
    minimumAAL: z.ZodDefault<z.ZodUnion<readonly [z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>]>>;
    userAdditiveFactors: z.ZodDefault<z.ZodBoolean>;
}, z.core.$loose>;
/** A flow config with every knob resolved — the shape stored on a client. */
export declare function normalizeFlowConfig(provided: unknown): z.output<typeof FlowConfigSchema>;
export type FlowConfig = z.output<typeof FlowConfigSchema>;
/**
 * Absent means ON, matching the schema default. The sign-in ladder and factor
 * removal both ask this, so neither can drift onto its own default.
 */
export declare function additiveOnlyEnabled(cfg: Partial<FlowConfig> | null | undefined): boolean;
/**
 * The home-screen entry list: the `'credentials'` identifier input when any
 * non-discoverable first factor exists, plus every discoverable one.
 */
export declare function deriveEntryList(cfg: {
    allowedFirstFactors?: string[];
} | null | undefined): string[];
/**
 * Both discovery and the round trip ask this one function, so a request that
 * skips the sign-in screen is refused rather than merely undrawn.
 */
export declare function federatedAllowedFor(cfg: {
    federatedSignIn?: boolean;
    excludedProviderIds?: string[];
} | null | undefined, providerId: string): boolean;
