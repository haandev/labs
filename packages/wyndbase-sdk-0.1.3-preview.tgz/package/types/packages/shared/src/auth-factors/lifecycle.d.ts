import type { FactorStatus } from './types';
export declare function canTransition(from: FactorStatus, to: FactorStatus): boolean;
export declare function assertTransition(from: FactorStatus, to: FactorStatus): void;
