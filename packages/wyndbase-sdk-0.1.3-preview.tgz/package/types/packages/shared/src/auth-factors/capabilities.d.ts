export type FactorAnswerMode = 'typed' | 'ceremony' | 'redirect';
/**
 * Where the subject — which account this is — comes from. An upper bound on
 * what a method can do; a `'flow'` method can never be the first step.
 */
export declare const FACTOR_SUBJECT_FROM: readonly ['credential', 'identifier', 'flow'];
export type FactorSubjectFrom = (typeof FACTOR_SUBJECT_FROM)[number];
/**
 * `'credential-reset'` mints no session — the assurance bar the person was held
 * to still stands afterwards.
 */
export declare const FACTOR_GRANTS: readonly ['session', 'credential-reset'];
export type FactorGrant = (typeof FACTOR_GRANTS)[number];
/**
 * Closed rather than `string` so a typo — `'passkeys'` on one tier — cannot
 * silently split a group that two capability keys are meant to share.
 */
export declare const FACTOR_CREDENTIALS: readonly ['password', 'passkey', 'totp', 'recovery_codes', 'email', 'oidc_external', 'social_apple', 'social_github', 'social_google'];
export type FactorCredential = (typeof FACTOR_CREDENTIALS)[number];
export type FactorCapabilities = {
    answerMode: FactorAnswerMode;
    /**
     * What the person holds — not the step key: two steps can stand on one secret
     * (both passkey tiers; `magic_link` and `password_reset` are one inbox).
     */
    credential: FactorCredential;
    subjectFrom: FactorSubjectFrom;
    grants: FactorGrant;
    /** Which credential a `grants: 'credential-reset'` method re-establishes. */
    resets?: FactorCredential;
    /** Offered as a way out, as its own control, rather than among the options. */
    escape: boolean;
    supportsEnroll: boolean;
};
/**
 * A row describes what a method *is*, not that anything can answer it —
 * `magic_link` has one precisely because no server factor verifies it yet.
 */
export declare const FACTOR_CAPABILITIES: {
    magic_link: {
        answerMode: "typed";
        credential: "email";
        escape: false;
        grants: "session";
        subjectFrom: "identifier";
        supportsEnroll: false;
    };
    oidc_external: {
        answerMode: "redirect";
        credential: "oidc_external";
        escape: false;
        grants: "session";
        subjectFrom: "credential";
        supportsEnroll: false;
    };
    passkey_device_bound: {
        answerMode: "ceremony";
        credential: "passkey";
        escape: false;
        grants: "session";
        subjectFrom: "credential";
        supportsEnroll: true;
    };
    passkey_synced: {
        answerMode: "ceremony";
        credential: "passkey";
        escape: false;
        grants: "session";
        subjectFrom: "credential";
        supportsEnroll: true;
    };
    password: {
        answerMode: "typed";
        credential: "password";
        escape: false;
        grants: "session";
        subjectFrom: "identifier";
        supportsEnroll: false;
    };
    password_reset: {
        answerMode: "typed";
        credential: "email";
        escape: true;
        grants: "credential-reset";
        resets: "password";
        subjectFrom: "identifier";
        supportsEnroll: false;
    };
    recovery_codes: {
        answerMode: "typed";
        credential: "recovery_codes";
        escape: true;
        grants: "session";
        subjectFrom: "flow";
        supportsEnroll: false;
    };
    social_apple: {
        answerMode: "redirect";
        credential: "social_apple";
        escape: false;
        grants: "session";
        subjectFrom: "credential";
        supportsEnroll: false;
    };
    social_github: {
        answerMode: "redirect";
        credential: "social_github";
        escape: false;
        grants: "session";
        subjectFrom: "credential";
        supportsEnroll: false;
    };
    social_google: {
        answerMode: "redirect";
        credential: "social_google";
        escape: false;
        grants: "session";
        subjectFrom: "credential";
        supportsEnroll: false;
    };
    totp: {
        answerMode: "typed";
        credential: "totp";
        escape: false;
        grants: "session";
        subjectFrom: "flow";
        supportsEnroll: true;
    };
};
/**
 * Stated as an inclusion, not `!== 'flow'`: a newly added `subjectFrom` must be
 * named here to be offered rather than becoming step-1-capable by default.
 */
export declare function canBeStep1(type: string): boolean;
/** Usernameless entry — the credential itself names the account. */
export declare function isDiscoverable(type: string): boolean;
/**
 * Falls back to the type's own key when nobody has declared one, so an unknown
 * type groups only with itself rather than collapsing into a neighbour's row.
 */
export declare function credentialFor(type: string): string;
/**
 * Deliberately permissive for an unknown type: `'credential-reset'` is the
 * narrow grant and would quietly demote it to "cannot finish a login".
 */
export declare function grantsFor(type: string): FactorGrant;
/**
 * `undefined` means "not a reset" rather than "a reset with no target", so a
 * defined answer is also the test for "this method resets something".
 */
export declare function resetTargetOf(type: string): string | undefined;
/**
 * An undeclared type is not an escape: that would draw its own control for a
 * method with no described way to answer it.
 */
export declare function isEscape(type: string): boolean;
export declare function answerModeFor(type: string): FactorAnswerMode;
/**
 * Unknown types fall back to the typed form deliberately: a wrong text field is
 * recoverable; calling `navigator.credentials` for a non-credential is not.
 */
export declare function needsCeremony(type: string): boolean;
/**
 * An undeclared type cannot: a permissive fallback would put a factor class
 * registered before its row into an enrol offering nobody has described.
 */
export declare function supportsEnroll(type: string): boolean;
export type ClientCapabilities = {
    webauthn: boolean;
};
type EnrollOffering = {
    factors: string[];
    mode: 'enroll' | 'unsatisfiable' | 'verify';
};
/**
 * Applied by the route, never by `AuthService`: the capability is
 * client-asserted, so it may only narrow an offering, never a permission.
 */
export declare function narrowEnrollOffering(offering: EnrollOffering, client: ClientCapabilities): EnrollOffering;
export {};
