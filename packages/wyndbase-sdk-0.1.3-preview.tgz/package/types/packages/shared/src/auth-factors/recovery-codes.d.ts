export declare const RECOVERY_CODE_COUNT = 10;
/**
 * A batch has no id of its own; this constant gives the driver and the
 * browser the same stable key to render and delete by.
 */
export declare const RECOVERY_BATCH_ID = "recovery-codes-batch";
/** Generate a batch of distinct recovery codes (formatted for display). */
export declare function generateRecoveryCodes(count?: number): string[];
/**
 * Canonical form for hashing/comparison: strip everything but [a-z0-9] and
 * lowercase, so a user typing the dash, spaces, or uppercase still matches.
 */
export declare function normalizeRecoveryCode(input: string): string;
/**
 * HMAC-SHA256 (not a raw hash) so a DB leak alone can't be brute-forced
 * offline; deterministic so verification is an indexed lookup, not a loop.
 */
export declare function hashRecoveryCode(code: string, secret: string): string;
