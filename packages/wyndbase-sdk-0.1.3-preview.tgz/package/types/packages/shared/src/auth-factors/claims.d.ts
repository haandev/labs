import type { Aal } from './aal';
/** The IANA Authentication Method Reference Values registry. */
export declare const AMR_VALUES: readonly ['face', 'fpt', 'geo', 'hwk', 'iris', 'kba', 'mca', 'mfa', 'otp', 'pin', 'pop', 'pwd', 'rba', 'retina', 'sc', 'sms', 'swk', 'tel', 'user', 'vbm', 'wia'];
export type AmrValue = (typeof AMR_VALUES)[number];
/**
 * `null` where the person authenticated at another provider: the registry has
 * no value for that, and inventing one asserts something no relying party can
 * resolve. Declared rather than left out, so a new method still has to answer.
 */
export declare const AMR_BY_TYPE: {
    readonly email_otp: 'otp';
    readonly hardware_key: 'hwk';
    readonly magic_link: 'otp';
    readonly oidc_external: null;
    readonly passkey_device_bound: 'hwk';
    readonly passkey_synced: 'swk';
    readonly password: 'pwd';
    readonly password_reset: 'otp';
    readonly pin: 'pin';
    readonly push_notification: 'mfa';
    readonly recovery_codes: 'otp';
    readonly security_question: 'kba';
    readonly sms_otp: 'sms';
    readonly social_apple: null;
    readonly social_github: null;
    readonly social_google: null;
    readonly totp: 'otp';
};
/**
 * Nothing, rather than the key itself: a method name is not a reference value,
 * and a token carrying one asserts something no relying party can read. A
 * method declared `null` answers the same way as one nobody declared.
 */
export declare function amrForFactor(type: string): AmrValue | undefined;
/** Distinct `amr` values for the factor types used, in input order. */
export declare function amrForFactors(types: readonly string[]): AmrValue[];
/**
 * Registered values only, in order and deduplicated. For an `amr` list read
 * back rather than built — a stored session row — so a value the registry does
 * not define cannot reach a token however it came to be stored.
 */
export declare function registeredAmrValues(values: readonly string[]): AmrValue[];
/** `acr` value mapped from the achieved AAL. */
export declare function acrForAal(aal: Aal): string;
/**
 * Inverse of `acrForAal`: parse an `acr` claim ("aal2") back to an AAL number.
 * Missing/unknown values fall back to AAL1 (least privilege).
 */
export declare function aalFromAcr(acr?: string | null): Aal;
/** What a session row or a verified token says about how somebody signed in. */
export type ResolvedAssurance = {
    aal: Aal;
    amr: AmrValue[];
};
/** The level nothing may sit below, wherever an assurance is defaulted. */
export declare const FLOOR_AAL: Aal;
/**
 * The assurance a session holds when nothing stronger can be read off it.
 * A fresh object per call, because `amr` is a list callers replace in place.
 */
export declare function floorAssurance(): ResolvedAssurance;
/**
 * Read in exactly one place, from the row and from the token alike. `aal`
 * accepts the row's number and the token's `aal2` spelling.
 *
 * An `amr` that is present but carries no registered value stays empty: a
 * person who signed in only at another provider has no reference value, and
 * substituting one would have the token claim a method nobody used. Only an
 * absent `amr` falls back — that is a row or a token written before the field
 * existed, where the floor is the best that can be said.
 *
 * `amr` is read from a list or from the space-delimited spelling a text column
 * stores, so a column read cannot route around the registry filter.
 */
export declare function resolveAssurance(source: {
    aal?: unknown;
    amr?: unknown;
}): ResolvedAssurance;
