/** How long a newly enrolled factor waits before it can stand alone. */
export declare const FACTOR_GRACE_MS: number;
type GracedFactor = {
    createdAt: string;
    type: string;
};
/**
 * A newly enrolled factor can't authorize sensitive ops within its grace
 * window — unless it's the only one, so a bare account isn't locked out.
 */
export declare function factorsOutOfGrace<T extends GracedFactor>(factors: readonly T[], now?: number): T[];
export {};
