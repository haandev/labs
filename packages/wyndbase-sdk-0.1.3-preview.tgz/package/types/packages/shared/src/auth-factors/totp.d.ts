export interface TotpOptions {
    /** step length in seconds (default 30) */
    period?: number;
    /** number of digits (default 6) */
    digits?: number;
    /** unix time in SECONDS (default Date.now()/1000) */
    time?: number;
}
export declare function generateTotpSecret(byteLength?: number): string;
export declare function generateTotp(secretBase32: string, opts?: TotpOptions): string;
/**
 * The matched time step, or `null`. Callers must persist the last accepted
 * step and reject anything at or below it to stay replay-resistant.
 */
export declare function verifyTotpStep(secretBase32: string, token: string, opts?: TotpOptions & {
    window?: number;
}): number | null;
export declare function verifyTotp(secretBase32: string, token: string, opts?: TotpOptions & {
    window?: number;
}): boolean;
export declare function buildOtpauthUri(params: {
    secret: string;
    /** account label, e.g. "alice@example.com" */
    account: string;
    /** issuer shown in the authenticator app */
    issuer: string;
    digits?: number;
    period?: number;
}): string;
