/** Query parameter marking a completed round trip. */
export declare const FEDERATED_DONE_PARAM = "federated";
/** Query parameter marking a round trip that produced no session. */
export declare const FEDERATED_ERROR_PARAM = "federated_error";
/** Fragment key holding the flow token when the base wants a climb. */
export declare const FEDERATED_FLOW_KEY = "federated_flow";
/** Fragment key holding the step that flow token belongs to. */
export declare const FEDERATED_NEXT_KEY = "federated_next";
/** The two shapes a *completed* round trip takes. */
export declare const FEDERATED_DONE: {
    /** A session was issued, as an HttpOnly cookie. */
    readonly COMPLETE: 'complete';
    /** The base wants a further factor; the fragment carries the flow token. */
    readonly FLOW: 'flow';
};
export type FederatedDoneMarker = (typeof FEDERATED_DONE)[keyof typeof FEDERATED_DONE];
/**
 * Three rather than one because each calls for a different action from the
 * person; none of them discloses which identities a base admits.
 */
export declare const FEDERATED_ERROR: {
    /** Sign in another way first, then attach this provider from settings. */
    readonly LINK_REQUIRED: 'link_required';
    /** The base will not accept this identity. */
    readonly REFUSED: 'refused';
    /** The round trip did not finish. Nothing was decided about anybody. */
    readonly UNAVAILABLE: 'unavailable';
};
export type FederatedErrorMarker = (typeof FEDERATED_ERROR)[keyof typeof FEDERATED_ERROR];
/**
 * A value off an address bar is a bookmark or hand-edited link as often as our
 * own redirect, so an unrecognised one is no marker rather than the nearest.
 */
export declare function isFederatedErrorMarker(value: unknown): value is FederatedErrorMarker;
/**
 * The names and nothing else: what each type *is* stays server-side, because a
 * mis-specified identity endpoint is a silent authentication bypass.
 */
export declare const FEDERATED_PROVIDER_TYPES: readonly ['github', 'google', 'microsoft', 'oidc'];
export type FederatedProviderType = (typeof FEDERATED_PROVIDER_TYPES)[number];
export declare function isFederatedProviderType(value: unknown): value is FederatedProviderType;
