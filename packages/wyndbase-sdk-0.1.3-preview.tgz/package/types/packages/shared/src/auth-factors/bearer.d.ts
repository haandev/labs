export type BearerClaims = {
    userId: string;
    /**
     * Session this access token was minted for. Absent on tokens minted before
     * `sid` existed and on hand-signed tokens in tests.
     */
    sid?: string;
    /** The base the token names, never the base the request happens to target. */
    baseId?: string;
    /**
     * The client the session was minted through — the only client identity a
     * request can prove, since the declared `client_id` is unauthenticated text.
     */
    clientId?: string;
};
/**
 * Reads an *already signature-verified* payload. Only `typ === 'access'`: the
 * session token shares the secret but lives for days with no `sid` to revoke.
 */
export declare function readBearerClaims(payload: unknown): BearerClaims | null;
export type BearerSessionRow = {
    revokedAt?: unknown;
    expires?: unknown;
    userId?: unknown;
};
/**
 * A row with no `expires` is not expired here: an absent TTL is a data question.
 */
export declare function isSessionRowExpired(session: {
    expires?: unknown;
}, now?: Date): boolean;
/**
 * A missing row is a refusal: a revocation check that cannot see its store must
 * not wave the request through.
 */
export declare function isSessionRowAcceptable(session: BearerSessionRow | undefined, userId: string, now?: Date): boolean;
export declare const TOKEN_AUDIENCE_ERROR_DESCRIPTION = "token audience does not match this base";
export declare const CHALLENGE_VALUE_PATTERN: RegExp;
/** Read this marker with {@link isTokenAudienceChallenge}, never by matching it. */
export declare function tokenAudienceChallenge(baseId: string): string;
/**
 * `true` means the 401 is permanent — do not refresh, replay or sign out.
 * Matches the whole marker: a bare `resource=` elsewhere must not match.
 */
export declare function isTokenAudienceChallenge(challenge: string | null | undefined): boolean;
/**
 * A production base is its own audience. Ask only AFTER the signature and
 * revocation checks — earlier it is an oracle for which bases are immutable.
 */
export declare function assertTokenAudience(claims: {
    baseId?: string;
}, base: {
    id: string;
    immutable?: unknown;
} | null | undefined): string | null;
/**
 * Bare on purpose: an error code here tells a client its credential was
 * rejected, and over a request that carried none that is a logout for a typo.
 */
export declare const BEARER_CHALLENGE = "Bearer";
/**
 * For a credential that WAS presented and did not survive; the client's correct
 * response is to refresh. Not {@link tokenAudienceChallenge}, which is permanent.
 */
export declare function invalidTokenChallenge(): string;
/**
 * For a valid session that is not assured strongly enough. The level is floored
 * to an integer >= 1 — a non-finite one would serialise as `acr_values="aalNaN"`.
 */
export declare function stepUpChallenge(requiredAal: number): string;
