export declare function base32Encode(bytes: Uint8Array): string;
export declare function base32Decode(input: string): Uint8Array;
