/**
 * The one list. The write-time admission on the provider named queries and the
 * provider editor both import it — an operator missing here fails a `reject`
 * rule closed for everyone.
 */
export declare const FEDERATED_RULE_OPERATORS: readonly ['equals', 'one_of', 'email_domain_in'];
export type FederatedRuleOperator = (typeof FEDERATED_RULE_OPERATORS)[number];
export declare function isListRuleOperator(operator: string): boolean;
/**
 * Verification is asserted only for `email` (OIDC has no per-claim
 * equivalent), so it is the only claim `email_domain_in` may read.
 */
export declare const FEDERATED_EMAIL_CLAIM = "email";
/** One entry in a provider's ordered accept/reject list. */
export type FederatedRule = {
    claim: string;
    decision: 'accept' | 'reject';
    operator: FederatedRuleOperator;
    /** A single value for `equals`, a list for `one_of` / `email_domain_in`. */
    value: string | string[];
};
/** What the provider asserted about the person, after signature verification. */
export type ProviderIdentity = {
    claims: Record<string, unknown>;
    emailVerified: boolean;
    subject: string;
};
/**
 * Means a rule could not run at all, not that it failed to match — an
 * unevaluable `reject` rule still denies, which is worth showing the admin.
 */
export type RuleRefusalReason = 
/** The rules container itself is not a list; reported with `index: -1`. */
'unreadable_rules'
/** Not a rule: a `null` entry, or one missing `claim` / `decision`. */
 | 'malformed_rule'
/** `value` is not a string or a list of strings. */
 | 'malformed_value' | 'unknown_operator'
/** `email_domain_in` on a claim other than `email`. */
 | 'claim_not_email'
/** The claim is an array or an object, not a scalar. */
 | 'non_scalar_claim'
/** The claim is a scalar but not an address with a usable domain. */
 | 'unparsable_email'
/** A rule reads `email`, which the provider does not assert as verified. */
 | 'email_unverified';
export type RuleRefusal = {
    /** `-1` when the refusal isn't about one rule (`unreadable_rules`). */
    index: number;
    reason: RuleRefusalReason;
};
export type RuleOutcome = {
    accepted: boolean;
    /** Index of the rule that decided it, or `null` when the default decided. */
    matchedIndex: number | null;
    refusals: RuleRefusal[];
};
/**
 * A whole address in canonical form (`null` if not one); the local part is
 * case-folded so a denylist entry also catches `BANNED@…`.
 */
export declare function canonicalEmail(value: string): string | null;
/**
 * Evaluates a provider's ordered rules against an identity; first match
 * wins. `defaultDecision` is required so no caller can leave it implicit.
 */
export declare function evaluateRules(rules: readonly FederatedRule[], defaultDecision: 'accept' | 'reject', identity: ProviderIdentity): RuleOutcome;
