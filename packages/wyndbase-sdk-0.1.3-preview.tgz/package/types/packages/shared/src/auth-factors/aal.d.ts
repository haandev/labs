import { type FactorType } from './types';
export type Aal = 1 | 2 | 3;
export declare function calculateAAL(types: readonly string[]): Aal;
/** Whether the `current` AAL satisfies a `required` minimum (for step-up gates). */
export declare function meetsAAL(current: number, required: number): boolean;
export declare function aalForFactor(type: string): Aal;
export declare function factorTypesForAal(required: number): FactorType[];
export declare function maxAAL(types: readonly string[]): number;
export declare function verifiableFactorsFrom(input: {
    mode: 'verify' | 'enroll' | 'unsatisfiable';
    factors: readonly string[];
    escapes: readonly string[];
}): string[];
export declare function keepsRecoveryBatch(type: string): boolean;
