/**
 * A method granting `'credential-reset'` re-establishes a credential rather
 * than minting a session, so it can never settle a challenge on its own.
 */
export declare function usableFor<T extends string>(enrolled: readonly T[]): T[];
/** The ordinary options at `target`: usable, not an escape, strong enough. */
export declare function rungsFor<T extends string>(enrolled: readonly T[], target: number): T[];
/**
 * Methods a person could enrol to reach `target`, over every declared method.
 * Delegates to `rungsFor` so an escape can't drift back into the list.
 */
export declare function enrollableFor<T extends string>(candidates: readonly T[], target: number): T[];
/**
 * The ways out at `target`. An escape may re-establish credentials only up to
 * the assurance it carries: AAL2 recovery codes rescue a lost app, AAL1 reset can't.
 */
export declare function escapesFor<T extends string>(enrolled: readonly T[], target: number): T[];
/**
 * Everything a step offers at `target`, as its two halves. `rungs` and
 * `escapes` are disjoint by construction — `isEscape` splits one filtered list.
 */
export declare function offeredFor<T extends string>(enrolled: readonly T[], target: number): {
    escapes: T[];
    rungs: T[];
};
/**
 * Methods that may raise a person's own assurance bar. Escapes are excluded:
 * holding recovery codes must not put someone on AAL2 and refuse them as the climb.
 */
export declare function barRaisersIn<T extends string>(enrolled: readonly T[]): T[];
