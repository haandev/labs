/**
 * A user may remove a factor only if it does not lower their achievable AAL.
 * Compares factor *types*, not the tier, since assurance is qualifying-factor based.
 *
 * Emptying the account is refused before the setting is consulted: additive-only
 * off means no assurance floor, never a way out of every credential.
 */
export declare function canRemoveFactor(params: {
    currentTypes: readonly string[];
    remainingTypes: readonly string[];
    additiveOnly: boolean;
}): boolean;
