export declare const LOCKOUT_THRESHOLD = 5;
/** Cost of the first lockout trip; the unit each further cycle doubles. */
export declare const LOCKOUT_BASE_DURATION_MS: number;
/**
 * Ceiling on an escalated lockout, and the span of attempts a caller must
 * read for `isLockedOut` to see its own cause.
 */
export declare const LOCKOUT_MAX_DURATION_MS: number;
export declare function failuresSinceLastSuccess(attempts: readonly {
    success: boolean;
}[]): number;
/**
 * Complete failure runs since the last success; each run of `threshold`
 * failures is one trip, priced by the escalation of the next trip.
 */
export declare function lockoutCycles(failures: number, threshold?: number): number;
/**
 * Base window doubling per cycle, capped at `LOCKOUT_MAX_DURATION_MS`, per
 * NIST SP 800-63B §5.2.2's escalating-wait guidance.
 */
export declare function lockoutDurationMs(cycles: number): number;
/**
 * Locked until the escalated duration elapses since the tripping attempt —
 * measuring from the newest attempt instead lets fresh noise lock forever.
 */
export declare function isLockedOut(attempts: readonly {
    success: boolean;
    createdAt?: string | number;
}[], threshold?: number, now?: number): boolean;
declare const lockoutBucketBrand: unique symbol;
/**
 * A lockout bucket key. Branded so a raw identifier cannot reach a lockout
 * read, an attempt record or the attempt lock without a namespace below.
 */
export type LockoutBucket = string & {
    readonly [lockoutBucketBrand]: true;
};
/** The bucket for a string the caller typed, which may name no account. */
export declare function typedIdentifierBucket(identifier: string): LockoutBucket;
/** The bucket for a resolved account. */
export declare function accountBucket(userId: string): LockoutBucket;
/** The bucket for a credential the caller presented, which may name no account. */
export declare function credentialBucket(credentialId: string): LockoutBucket;
export {};
