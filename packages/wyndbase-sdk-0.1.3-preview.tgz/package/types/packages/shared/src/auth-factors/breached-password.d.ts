/**
 * NIST SP 800-63B §5.1.1.2 requires verifiers to reject a memorized secret
 * found in a breach corpus; it does not require sending the secret anywhere.
 */
/**
 * k-anonymity: only `prefix` leaves the process, so the service learns which
 * of 2^20 buckets the password falls in, never the password itself.
 */
export declare function breachRangeKey(password: string): Promise<{
    prefix: string;
    suffix: string;
}>;
/**
 * A padded response includes filler rows shaped like real ones but with count
 * 0, so returning the count (not a boolean) lets callers treat them as absent.
 */
export declare function breachCountFromRange(body: string, suffix: string): number;
