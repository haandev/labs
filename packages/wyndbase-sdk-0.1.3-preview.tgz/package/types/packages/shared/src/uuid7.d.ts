export declare const randomUUIDv7: () => string;
