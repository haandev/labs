/**
 * A `datetime` column comes back naive, and a date-time with no offset parses as
 * *local* time — wrong by the server's UTC offset in whichever direction it sits.
 */
export declare function asUtcIso(value: unknown): string;
