/**
 * A value the database already serialized, carried to the response without
 * being decoded. Produced by the WQL compiler's report, consumed by the
 * driver and the response serializer, so it lives here rather than in either.
 */
export type JsonPassthroughReport = {
    kind: 'none';
} | {
    kind: 'columns';
    columns: string[];
}
/** The outer projection could not be resolved; nothing is passed through. */
 | {
    kind: 'unknown';
};
export declare const JSON_PASSTHROUGH_NONE: JsonPassthroughReport;
export declare const JSON_PASSTHROUGH_UNKNOWN: JsonPassthroughReport;
export declare function jsonPassthroughColumns(columns: readonly string[]): JsonPassthroughReport;
/** `unknown` absorbs; otherwise the column sets merge and an empty merge is `none`. */
export declare function mergeJsonPassthroughReports(reports: readonly JsonPassthroughReport[]): JsonPassthroughReport;
/**
 * JSON text the database produced. A marker rather than a bare string so a
 * consumer that ignores the report cannot mistake it for a text value and ship
 * a quoted document.
 */
export declare class RawJson {
    readonly json: string;
    constructor(json: string);
    toJSON(): unknown;
}
export declare function rawJson(json: string): RawJson;
export declare function isRawJson(value: unknown): value is RawJson;
/**
 * `JSON.stringify` with `RawJson` spliced in verbatim. `JSON.rawJSON` cannot
 * carry an object or an array — the language restricts it to JSON primitives —
 * so the splice is done here.
 *
 * Only containers are walked by hand; every leaf goes through `JSON.stringify`
 * whole, so a subtree holding no `RawJson` costs one native call.
 */
export declare function stringifyWithRawJson(value: unknown): string;
