import { EventListener } from '@wyndb/shared/event';
/** A PromiseLike or function that creates a PromiseLike. */
export type PromiseFactory<T> = (() => PromiseLike<T>) | PromiseLike<T>;
/** Options for a task. */
export type TaskOptions<M = any> = {
    /** Task priority, higher numbers indicate higher priority. */
    priority?: number;
    /** Timeout in milliseconds for the task. */
    timeout?: number;
    /** AbortSignal to allow task cancellation. */
    signal?: AbortSignal;
    /** Maximum number of retries for the task. */
    maxRetries?: number;
    /** Delay in milliseconds between retries. */
    retryDelay?: number;
    /** Metadata of the task, notes, information, caller etc. */
    metadata?: M;
};
/** Configuration for a queue. */
export type QueueConfig = {
    /** Maximum number of concurrent tasks. */
    concurrency?: number;
    /** Whether to prioritize tasks. */
    respectPriority?: boolean;
    /** Timeout in milliseconds for the queue. */
    timeout?: number;
    /** AbortSignal to allow queue cancellation. */
    signal?: AbortSignal;
};
type QueueTask<T, M = any> = {
    fn: () => void;
    priority: number;
    createdAt: number;
    resolve: (value: T) => void;
    reject: (reason?: any) => void;
    timeout?: number;
    signal?: AbortSignal;
    metadata?: M;
    currentRetry: number;
};
export type SerializedTask<T, M = any> = Pick<QueueTask<T, M>, 'currentRetry' | 'metadata' | 'priority' | 'createdAt' | 'timeout'> & {
    running: boolean;
};
export type QueueEventsMap<M = any> = {
    taskDequeued: (task: SerializedTask<any, M>) => void;
    taskFailed: (task: SerializedTask<any, M>) => void;
    taskFinally: (task: SerializedTask<any, M>) => void;
    taskStarted: (task: SerializedTask<any, M>) => void;
    taskSuccess: (task: SerializedTask<any, M>) => void;
    queueChanged: (tasks: SerializedTask<any, M>[]) => void;
};
export declare class Queue<M = any> {
    protected _events: EventListener<QueueEventsMap<M>>;
    private paused;
    private running;
    _tasks: QueueTask<any, M>[];
    _runningTasks: QueueTask<any, M>[];
    private config;
    constructor(conf: QueueConfig);
    /**
     * Enqueues and runs a task with optional task options.
     *
     * @param promiseFactory - Function or Promice producing the task Promise.
     * @param options - Options to control priority, timeout, retries, and
     *   cancellation.
     * @returns A Promise resolving or rejecting based on the task result.
     */
    run<T>(promiseFactory: PromiseFactory<T>, options?: TaskOptions<M>): Promise<T>;
    /** Clears the queue and rejects all pending tasks with an error. */
    clear(): void;
    /**
     * Returns the current status of the queue, including running and queued tasks
     * count.
     */
    get status(): {
        concurrency: number | undefined;
        length: number;
        respectPriority: boolean | undefined;
        running: number;
        signal: AbortSignal | undefined;
        timeout: number | undefined;
    };
    /** Returns a shallow copy of the current task queue. */
    get tasks(): QueueTask<any, M>[];
    get tasksSerialized(): SerializedTask<any, M>[];
    set tasks(_tasks: QueueTask<any, M>[]);
    /** Pauses task execution in the queue. */
    pause(): void;
    /** Resumes task execution if the queue was paused. */
    resume(): void;
    private dequeue;
    /** Full access to the events via EventHandler instance */
    get events(): EventListener<QueueEventsMap<M>>;
}
export {};
