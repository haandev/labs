export type SessionMeta = {
    device: string;
    os: string;
    browser: string;
    ipAddress: string;
};
