/**
 * Parses and validates a date string or Date object in one call.
 * Returns the Date object if valid, null otherwise.
 * Avoids creating the Date object twice (once for validation, once for usage).
 *
 * @param value - Date string (ISO format) or Date object
 * @returns Parsed Date object if valid, null if invalid
 */
export declare const parseValidDate: (value: string | Date | null | undefined) => Date | null;
