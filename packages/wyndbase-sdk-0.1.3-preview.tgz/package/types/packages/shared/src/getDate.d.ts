export declare const getDate: (date: Date | string) => string;
