/**
 * Fixed sign-in button variants — one route per size, so every consumer of a
 * given size renders the identical shape and the designs cannot drift apart.
 */
export declare const SIGNIN_BUTTON_SIZES: {
    readonly lg: {
        readonly height: 48;
        readonly width: 400;
    };
    readonly md: {
        readonly height: 40;
        readonly width: 320;
    };
    readonly sm: {
        readonly height: 36;
        readonly width: 280;
    };
    readonly xs: {
        readonly height: 32;
        readonly width: 240;
    };
};
export type SignInButtonSize = keyof typeof SIGNIN_BUTTON_SIZES;
/** What `getSignInButton()` fetches when the caller names no size. */
export declare const DEFAULT_SIGNIN_BUTTON_SIZE = "md";
