/**
 * Derive a collision-free choice key from a label. Keys are snake_case slugs,
 * unique within a single choice list; a numeric suffix (`_2`, `_3`, ...) is
 * appended when the base slug is already taken.
 */
export declare function deriveChoiceKey(label: string, taken: Iterable<string>): string;
