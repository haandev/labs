export type Events = Record<string, (...args: any[]) => any>;
type AllListener<E extends Events, K extends keyof E> = (event: K, ...args: Parameters<E[K]>) => any;
export type EventProps<T> = {
    [K in keyof T as `on${Capitalize<string & K>}`]?: T[K];
};
export declare class EventListener<E extends Events> {
    private listeners;
    private allListeners;
    constructor(initials?: Partial<EventProps<E>>);
    on<K extends keyof E>(event: K, callback: E[K]): () => void;
    off<K extends keyof E>(event: K, callback: E[K]): void;
    onAll(callback: AllListener<E, keyof E>): () => void;
    offAll(callback: AllListener<E, keyof E>): void;
    once<K extends keyof E>(event: K, callback: E[K]): void;
    emit<K extends keyof E>(event: K, ...args: [...Parameters<E[K]>, (AbortSignal | null)?]): Promise<{
        results: ReturnType<E[K]>[];
        errors: any[];
    }>;
    emitSync<K extends keyof E>(event: K, ...args: [...Parameters<E[K]>, AbortSignal?]): {
        results: ReturnType<E[K]>[];
        errors: any[];
    };
    hasListeners<K extends keyof E>(event: K): boolean;
    clear(event?: keyof E): void;
    listeningEvents(): (keyof E)[];
    addListener<K extends keyof E>(event: K, callback: E[K]): void;
    removeListener<K extends keyof E>(event: K, callback: E[K]): void;
}
export type EventTupleToHandler<T extends Record<string, any[]>> = {
    [K in keyof T]: (...args: T[K]) => void;
};
export type Streamable<T extends Record<string, (...args: any[]) => any>> = {
    [K in keyof T]: T[K] extends (...args: infer A) => any ? [K, ...A] : never;
}[keyof T];
export type StreamableFromEventTuples<T extends Record<string, any[]>> = Streamable<EventTupleToHandler<T>>;
export {};
