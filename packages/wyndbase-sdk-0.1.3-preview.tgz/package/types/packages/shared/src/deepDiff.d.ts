export type DiffMap = Record<string, {
    old: any;
    new: any;
}>;
export declare const isNullish: (value: any) => boolean;
export declare const isDeepNullish: (value: any) => boolean;
export declare const deepDiff: (a: any, b: any, options?: {
    weakNullish?: boolean;
}) => DiffMap;
