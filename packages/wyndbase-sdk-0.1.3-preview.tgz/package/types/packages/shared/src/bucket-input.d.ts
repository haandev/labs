import { z } from 'zod';
/**
 * What a client may name a bucket. Shared because the create form validates it
 * before sending and the server validates it again on arrival.
 */
export declare const bucketNameSchema: z.ZodString;
export declare const CreateBucketInputSchema: z.ZodObject<{
    name: z.ZodString;
}, z.core.$strip>;
export type TCreateBucketInput = z.infer<typeof CreateBucketInputSchema>;
