/**
 * The main ("maintenance") base answers to two spellings, and both reach code
 * that has to recognise it: the frontend addresses it by the URL sentinel,
 * while the server carries its pinned uuid. One predicate for both, because a
 * second spelling of this question is how the two halves drifted apart.
 *
 * `wyndbase` is reserved: a create or rename that would put that name on any
 * other base is refused as a name conflict, because this predicate would then
 * treat a tenant base as the platform.
 */
/** Pinned so a process restart produces the same id as the `system.bases` row.
 *  (UUID v7: version digit 7, variant digit a.) */
export declare const MAINTENANCE_BASE_ID = "00000000-0000-7000-a000-000000000001";
/** The default `POSTGRES_DB`, and the sentinel the frontend puts in URLs. */
export declare const MAIN_BASE_NAME = "wyndbase";
export declare function isMainBase(ref: string): boolean;
/**
 * True when `name` is the reserved main-base spelling and `holderId` is not
 * the main base itself. Create passes no holder.
 */
export declare function isReservedBaseName(name: string, holderId?: string): boolean;
/**
 * The same question asked of a handler, which carries both spellings at once.
 *
 * The id arm is pinned in `system/Main.base.ts`. The name arm is only reserved
 * while `wyndbase` is the deployment's own database name: under a different
 * `POSTGRES_DB` a customer base can take the name and match here.
 */
export declare function isMainBaseHandle(baseId: string, baseName: string): boolean;
/**
 * Platform identity is where a caller authenticated, not who they are. The
 * home base comes from the access token's `baseId` claim; an absent or empty
 * one is not a platform caller, so a credential that cannot say where it was
 * minted is refused rather than assumed.
 */
export declare function isPlatformCaller(callerHomeBaseId: string | null | undefined): boolean;
/**
 * Membership decided from the verified token claims: the caller's own base, or
 * the platform base, whose principals operate on every tenant. Asks where the
 * caller signed in, never who they are.
 */
export declare function callerBelongsToBase(baseId: string, callerHomeBaseId: string | undefined): boolean;
