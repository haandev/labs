/**
 * Pads a number with leading zeros to the specified size
 * @param num - The number to pad
 * @param size - The desired string length
 * @returns Zero-padded string representation
 * @example pad(5, 2) => "05"
 * @example pad(123, 5) => "00123"
 */
export declare const pad: (num: number, size: number) => string;
