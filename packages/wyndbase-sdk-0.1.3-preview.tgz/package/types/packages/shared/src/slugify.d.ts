type SlugCase = 'snake' | 'camel' | 'pascal' | 'kebab' | 'keep' | 'safe-keep';
export declare function slugify(input: string, targetCase?: SlugCase): string;
export {};
