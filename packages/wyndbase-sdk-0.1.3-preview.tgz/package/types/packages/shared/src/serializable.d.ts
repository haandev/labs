export type Serializable = null | boolean | number | string | Serializable[] | SerializableObject;
export type SerializableObject = {
    [key: string]: Serializable;
};
