/**
 * What a compiled statement can deliver in the way of polymorphic link cells.
 * Produced by the WQL compiler, consumed by the driver's display labeler, so it
 * lives here rather than in either.
 */
export type PolyDisplayReport = {
    kind: 'none';
} | {
    kind: 'columns';
    columns: string[];
}
/** The projection could not be resolved to model columns; inspect everything. */
 | {
    kind: 'unknown';
};
