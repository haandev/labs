/** The JWT signing + HMAC secret. Guaranteed present (fail-fast above in prod). */
export declare const secret: string;
