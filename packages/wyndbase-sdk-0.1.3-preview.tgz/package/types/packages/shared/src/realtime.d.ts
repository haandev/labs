/**
 * Realtime Query Invalidation — Shared Types
 *
 * Used by both server (driver/RealtimeHub) and client (sdk/RealtimeManager)
 * for subscription tracking and invalidation signaling.
 */
/** Tree-structured filter preserving AND/OR semantics from the WQL AST */
export type RealtimeFilterNode = RealtimeFilterAnd | RealtimeFilterOr | RealtimeFilterNot | RealtimeFilterComparison | RealtimeFilterUnknown;
export interface RealtimeFilterAnd {
    type: 'and';
    children: RealtimeFilterNode[];
}
export interface RealtimeFilterOr {
    type: 'or';
    children: RealtimeFilterNode[];
}
export interface RealtimeFilterNot {
    type: 'not';
    child: RealtimeFilterNode;
}
/**
 * Every operator `expressionToFilterTreeInner` can lower into a comparison
 * node. Closed against the producer: the WQL grammar admits only the six
 * relational operators, and the rest are written as literals by the lowering
 * itself. Range/containment/regex operators lower to an `unknown` node.
 */
export type RealtimeFilterOperator = '==' | '!=' | '<' | '>' | '<=' | '>=' | 'IS NULL' | 'IS NOT NULL' | 'IN' | 'NOT IN' | 'BETWEEN' | 'NOT BETWEEN' | 'LIKE' | 'NOT LIKE';
export interface RealtimeFilterComparison {
    type: 'comparison';
    /** Column name: 'age', 'status', '_id', 'user.name' */
    column: string;
    operator: RealtimeFilterOperator;
    /** Value summary: '${param}', "'literal'", '42', 'null', '' (for IS NULL) */
    value: string;
    /**
     * Elements of an `IN` / `NOT IN` list, each in the same summary form as
     * `value`. Authoritative for list reasoning; `value` is only a display and
     * size summary derived from it. Absent when the list is not a literal one.
     */
    values?: string[];
    /**
     * Qualified table name this comparison is **about** (`'shop.customers'`,
     * `'shop.orders'`, …). Primary query/mutation comparisons carry the
     * primary table; comparisons lowered from a HAS/EXISTS subquery carry
     * the subquery's target table.
     *
     * Lets the comparator distinguish `customers.status` from `orders.status`
     * when a query's filter mixes parent columns with HAS-inner columns:
     *
     *   SELECT customers { _id }
     *   FILTER tier == "gold" AND orders HAS (status == "pending")
     *
     * A mutation on `customers` writing `status` must not match the HAS-inner
     * `status` comparison (different table, different physical column), and
     * vice versa. Consumers (`membership-stability`, `literalPairIsDisjoint`)
     * filter by this tag to avoid cross-table column-name collisions.
     *
     * Undefined means "untagged" — kept optional so older producers and
     * fixtures still work. Comparing two comparisons where one is tagged
     * and the other is not is treated as a backward-compat match (the
     * consumer cannot prove a different-table distinction).
     */
    table?: string;
}
export interface RealtimeFilterUnknown {
    /** Expressions that can't be analyzed — conservative (never disjoint) */
    type: 'unknown';
    /**
     * Best-effort list of column names referenced inside the opaque expression.
     * Lets the comparator prove that an UPDATE writing none of these columns
     * cannot change any row's membership in the filter — even when the filter
     * itself is too complex to evaluate (column-to-column, function calls).
     */
    columns?: string[];
}
/** Compact summary of a statement's table access + filter tree, used for realtime matching */
export interface RealtimeTrackingEntry {
    /** 'SELECT' | 'SUMMARIZE' | 'INSERT' | 'UPDATE' | 'UPSERT' | 'DELETE' */
    operation: string;
    /** Accessed/mutated tables: ['users', 'hr.orders'] */
    tables: string[];
    /** Filter/guard tree preserving AND/OR structure. null = no filter */
    filter: RealtimeFilterNode | null;
    /** Column assignments from mutation SET clause. '*' column = spread (opaque). */
    setColumns?: Array<{
        column: string;
        value: string;
    }>;
    /**
     * Bare column names whose change this query's subscriber can observe: the
     * ones it projects, and the ones it sorts by. Lets the membership-stability
     * shortcut also account for snapshot drift: a SET that writes one of them
     * changes the visible result even when no row's filter membership flips —
     * for a sort column, by moving rows through a window's boundary.
     *
     * The name is narrower than the contents; it predates the sort columns.
     *
     * Undefined means the set is opaque and no narrowing is possible — a star,
     * computed expression, aggregate or link expansion in the projection, or a
     * sort key that is not a plain column of the primary table.
     *
     * Always scoped to the PRIMARY table (the first element of `tables`). For
     * mutations targeting a different table (e.g. a nested/linked child),
     * this list must not be consulted for snapshot-stability — see
     * {@link exposedNestedTables}.
     */
    projectedColumns?: string[];
    /**
     * Qualified names of tables a write can drift this query's visible result
     * through, without touching any column of the primary table. Two things put a
     * table here: a nested subquery projection, whose rows appear in the payload;
     * and a sort key that navigates a link, whose rows decide the ordering. The
     * membership-stability shortcut must be disabled for both, or such a write is
     * narrowed away and the subscriber keeps a result the tables no longer
     * support.
     *
     * The name is narrower than the contents; it predates the sort case.
     *
     * This is a separate list from `tables` because `tables` also includes
     * linked tables referenced only from a HAS/EXISTS filter — those do
     * NOT appear in the visible payload and DO participate in
     * membership-stability (via the filter-column union), so they must not
     * be lumped together with nested-projection tables.
     */
    exposedNestedTables?: string[];
}
export interface RealtimeSubscribeRequest {
    connId: string;
    /** One-time-use ID from server query response — maps to tracking data server-side */
    trackingId: string;
    /** Deterministic hash of queryKey — compact identifier for sub/unsub */
    keyHash: string;
    /** Optional per-subscription idle TTL override (ms). Server clamps to
     *  [30s, 6h]. Omitting falls back to the hub default. */
    ttlMs?: number;
}
export interface RealtimeUnsubscribeRequest {
    connId: string;
    keyHash: string;
}
export type RealtimeEvents = {
    connected: (connId: string) => Promise<void> | void;
    invalidate: (keyHash: string) => Promise<void> | void;
    /** Server dropped this subscription (idle TTL). Client should resubscribe if still interested. */
    expired: (keyHash: string) => Promise<void> | void;
    error: (message: string) => Promise<void> | void;
};
/** Wire-format tuple for SSE events emitted by the server. The first element
 *  is the action name; the rest are positional payload values. Used to
 *  type-check `createSSEStream` and `RealtimeHub` `send` callsites. */
export type RealtimeServerEvent = ['connected', string] | ['invalidate', string] | ['expired', string] | ['error', string, string?];
