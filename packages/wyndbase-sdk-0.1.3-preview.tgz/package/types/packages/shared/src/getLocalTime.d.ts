export declare const getLocalTime: (date: Date | string, precision?: boolean) => string;
