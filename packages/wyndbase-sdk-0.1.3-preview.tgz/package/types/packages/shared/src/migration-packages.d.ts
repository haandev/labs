/**
 * The migration package catalogue, read by the plan engine on the server and by
 * the preview screens in the browser. Here rather than beside the engine so the
 * browser reads one copy instead of keeping its own.
 */
/** A union with one member today; a new package is one entry in each keyed record. */
export type PackageKey = 'clientSettings';
export type DataTableKey = 'choices' | 'publishers' | 'clients' | 'settings';
/** Per-package physical tables in FK-safe apply order. */
export declare const PACKAGE_TABLES: Record<PackageKey, DataTableKey[]>;
/**
 * Fixed apply order for both the plan and execute paths, so SSE event
 * sequences and audit logs do not depend on caller input order.
 */
export declare const PACKAGE_ORDER: PackageKey[];
export declare const PACKAGE_LABELS: Record<PackageKey, string>;
