/**
 * Converts a Date to an ISO 8601 string that includes the local timezone offset
 * (e.g. "2026-05-06T14:30:00+03:00") instead of the UTC "Z" suffix.
 * Required for timestamptz columns which must carry timezone information.
 */
export declare const toOffsetISO: (date: Date) => string;
