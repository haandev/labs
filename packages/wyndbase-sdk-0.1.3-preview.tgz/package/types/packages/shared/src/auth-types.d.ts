import { z } from 'zod';
export declare const AuthorizeQuerySchema: z.ZodObject<{
    client_id: z.ZodString;
    code_challenge: z.ZodString;
    code_challenge_method: z.ZodOptional<z.ZodDefault<z.ZodString>>;
    confirmed: z.ZodOptional<z.ZodString>;
    redirect_uri: z.ZodString;
    redirected: z.ZodOptional<z.ZodString>;
    response_type: z.ZodOptional<z.ZodDefault<z.ZodString>>;
    scope: z.ZodOptional<z.ZodString>;
    state: z.ZodString;
}, z.core.$strip>;
export type AuthorizeQuerySchema = z.infer<typeof AuthorizeQuerySchema>;
export declare const OAuth2State: z.ZodObject<{
    csrf: z.ZodString;
    metadata: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
    nonce: z.ZodOptional<z.ZodString>;
    redirect: z.ZodOptional<z.ZodString>;
    timestamp: z.ZodOptional<z.ZodNumber>;
}, z.core.$strip>;
export type OAuth2State = z.infer<typeof OAuth2State>;
export declare const OAuth2StateCodec: z.ZodCodec<z.ZodString, z.ZodObject<{
    csrf: z.ZodString;
    metadata: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
    nonce: z.ZodOptional<z.ZodString>;
    redirect: z.ZodOptional<z.ZodString>;
    timestamp: z.ZodOptional<z.ZodNumber>;
}, z.core.$strip>>;
export declare const OAuth2TokenResponse: z.ZodObject<{
    access_token: z.ZodString;
    expires_in: z.ZodNumber;
    refresh_token: z.ZodOptional<z.ZodString>;
    scopes: z.ZodArray<z.ZodString>;
    token_type: z.ZodString;
}, z.core.$strip>;
export type OAuth2TokenResponse = z.infer<typeof OAuth2TokenResponse>;
declare const OAuth2RequestCommons: z.ZodObject<{
    client_id: z.ZodString;
    grant_type: z.ZodEnum<{
        authorization_code: "authorization_code";
        flow: "flow";
        flow_start: "flow_start";
        refresh_token: "refresh_token";
    }>;
}, z.core.$strip>;
export type OAuth2RequestCommons = z.output<typeof OAuth2RequestCommons>;
declare const OAuth2RequestGrantFlowStart: z.ZodObject<{
    client_id: z.ZodString;
    captcha_token: z.ZodOptional<z.ZodString>;
    grant_type: z.ZodLiteral<"flow_start">;
    identifier: z.ZodString;
}, z.core.$strip>;
export type OAuth2RequestGrantFlowStart = z.output<typeof OAuth2RequestGrantFlowStart>;
declare const OAuth2RequestGrantAuthorizationCode: z.ZodObject<{
    client_id: z.ZodString;
    code: z.ZodString;
    code_verifier: z.ZodString;
    grant_type: z.ZodLiteral<"authorization_code">;
    redirect_uri: z.ZodOptional<z.ZodString>;
    scope: z.ZodOptional<z.ZodString>;
    state: z.ZodOptional<z.ZodUnknown>;
}, z.core.$strip>;
export type OAuth2RequestGrantAuthorizationCode = z.output<typeof OAuth2RequestGrantAuthorizationCode>;
declare const OAuth2RequestGrantRefreshToken: z.ZodObject<{
    client_id: z.ZodString;
    grant_type: z.ZodLiteral<"refresh_token">;
    refresh_token: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
export type OAuth2RequestGrantRefreshToken = z.output<typeof OAuth2RequestGrantRefreshToken>;
declare const OAuth2RequestGrantFlow: z.ZodObject<{
    client_id: z.ZodString;
    captcha_token: z.ZodOptional<z.ZodString>;
    code: z.ZodString;
    factor_id: z.ZodOptional<z.ZodString>;
    factor_type: z.ZodString;
    flow_token: z.ZodString;
    grant_type: z.ZodLiteral<"flow">;
}, z.core.$strip>;
export type OAuth2RequestGrantFlow = z.output<typeof OAuth2RequestGrantFlow>;
export declare const OAuth2Request: z.ZodDiscriminatedUnion<[z.ZodObject<{
    client_id: z.ZodString;
    captcha_token: z.ZodOptional<z.ZodString>;
    grant_type: z.ZodLiteral<"flow_start">;
    identifier: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    client_id: z.ZodString;
    code: z.ZodString;
    code_verifier: z.ZodString;
    grant_type: z.ZodLiteral<"authorization_code">;
    redirect_uri: z.ZodOptional<z.ZodString>;
    scope: z.ZodOptional<z.ZodString>;
    state: z.ZodOptional<z.ZodUnknown>;
}, z.core.$strip>, z.ZodObject<{
    client_id: z.ZodString;
    grant_type: z.ZodLiteral<"refresh_token">;
    refresh_token: z.ZodOptional<z.ZodString>;
}, z.core.$strip>, z.ZodObject<{
    client_id: z.ZodString;
    captcha_token: z.ZodOptional<z.ZodString>;
    code: z.ZodString;
    factor_id: z.ZodOptional<z.ZodString>;
    factor_type: z.ZodString;
    flow_token: z.ZodString;
    grant_type: z.ZodLiteral<"flow">;
}, z.core.$strip>], "grant_type">;
export type OAuth2Request = OAuth2RequestGrantFlowStart | OAuth2RequestGrantAuthorizationCode | OAuth2RequestGrantRefreshToken | OAuth2RequestGrantFlow;
declare const JwtPayload: z.ZodObject<{
    acr: z.ZodOptional<z.ZodString>;
    amr: z.ZodOptional<z.ZodArray<z.ZodString>>;
    baseId: z.ZodString;
    clientId: z.ZodString;
    exp: z.ZodNumber;
    iss: z.ZodString;
    roles: z.ZodArray<z.ZodString>;
    scope: z.ZodString;
    sid: z.ZodOptional<z.ZodString>;
    sub: z.ZodString;
    typ: z.ZodEnum<{
        access: "access";
        session: "session";
    }>;
    userId: z.ZodString;
}, z.core.$strip>;
export type JwtPayload = z.infer<typeof JwtPayload>;
export type OAuth2ClientParams = {
    name: string;
    allowedUrls?: string[] | null;
    redirectUrls?: string[] | null;
    scopes?: string[] | null;
    isIdp?: boolean | null;
    idpSettings?: Record<string, any> | null;
    isActive?: boolean | null;
    idp?: string | null;
};
export type CreateOAuth2ClientParams = OAuth2ClientParams;
export type UpdateOAuth2ClientParams = Omit<OAuth2ClientParams, 'name'> & {
    id: string;
    name?: string | undefined | null;
};
export {};
