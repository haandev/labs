/**
 * True when `sql` holds more than one statement. Literals, quoted identifiers,
 * dollar-quoted bodies and comments are skipped, because generated SQL inlines
 * string constants that may themselves contain a separator.
 *
 * Every construct that never terminates is reported as multiple. A malformed
 * text is refused at no cost — the database would reject it anyway — whereas
 * failing open on a mis-lexed construct would let a real separator through.
 */
export declare function carriesMultipleStatements(sql: string): boolean;
