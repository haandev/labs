/**
 * Extracts { year, month } (0-indexed month) from a string or Date config value.
 * Handles YYYY-MM, YYYY-MM-DD, and full ISO strings.
 * Uses UTC getters for strings (avoids local-TZ drift) and local getters for Dates
 * (preserves the caller's intended month).
 */
export declare function normalizeMonthConfig(value: string | Date): {
    month: number;
    year: number;
};
