import { ErrorNode, ParseTreeListener, ParserRuleContext, TerminalNode } from "antlr4ng";
import { QueryContext } from "./WynQLParser.js";
import { DqlStatementContext } from "./WynQLParser.js";
import { BareQueryContext } from "./WynQLParser.js";
import { DmlStatementContext } from "./WynQLParser.js";
import { TclStatementContext } from "./WynQLParser.js";
import { DdlStatementContext } from "./WynQLParser.js";
import { DclStatementContext } from "./WynQLParser.js";
import { GrantStatementContext } from "./WynQLParser.js";
import { ModelTargetContext } from "./WynQLParser.js";
import { DecisionOperationContext } from "./WynQLParser.js";
import { PolicyStatementContext } from "./WynQLParser.js";
import { PolicyKeyContext } from "./WynQLParser.js";
import { AlterPolicyStatementContext } from "./WynQLParser.js";
import { DropPolicyStatementContext } from "./WynQLParser.js";
import { PolicyRefContext } from "./WynQLParser.js";
import { RoleClauseContext } from "./WynQLParser.js";
import { QualifiedNameContext } from "./WynQLParser.js";
import { DelegateStatementContext } from "./WynQLParser.js";
import { DelegableTargetContext } from "./WynQLParser.js";
import { RevokeDelegationStatementContext } from "./WynQLParser.js";
import { PeriodClauseContext } from "./WynQLParser.js";
import { UserRefContext } from "./WynQLParser.js";
import { DelegationRefContext } from "./WynQLParser.js";
import { StatementContext } from "./WynQLParser.js";
import { DefineStatementContext } from "./WynQLParser.js";
import { ConstDefineStatementContext } from "./WynQLParser.js";
import { ImportStatementContext } from "./WynQLParser.js";
import { DefinitionOptionContext } from "./WynQLParser.js";
import { DefinitionBodyContext } from "./WynQLParser.js";
import { DefinitionBodyStatementContext } from "./WynQLParser.js";
import { ExposeStatementContext } from "./WynQLParser.js";
import { DropStatementContext } from "./WynQLParser.js";
import { NamedQueryRefContext } from "./WynQLParser.js";
import { ExposureLevelContext } from "./WynQLParser.js";
import { QueryStatementContext } from "./WynQLParser.js";
import { CteDefinitionContext } from "./WynQLParser.js";
import { CteBodyContext } from "./WynQLParser.js";
import { QueryBodyContext } from "./WynQLParser.js";
import { InsertStatementContext } from "./WynQLParser.js";
import { EachSourceContext } from "./WynQLParser.js";
import { UpdateStatementContext } from "./WynQLParser.js";
import { UpsertStatementContext } from "./WynQLParser.js";
import { DeleteStatementContext } from "./WynQLParser.js";
import { GuardClauseContext } from "./WynQLParser.js";
import { TransactionBlockContext } from "./WynQLParser.js";
import { TransactionBodyStatementContext } from "./WynQLParser.js";
import { TransactionErrorHandlerContext } from "./WynQLParser.js";
import { TableNameContext } from "./WynQLParser.js";
import { MutationObjectContext } from "./WynQLParser.js";
import { MutationFieldContext } from "./WynQLParser.js";
import { MutationAssignContext } from "./WynQLParser.js";
import { MutationValueContext } from "./WynQLParser.js";
import { MutationArrayContext } from "./WynQLParser.js";
import { MutationArrayItemContext } from "./WynQLParser.js";
import { NestedInsertContext } from "./WynQLParser.js";
import { LinkLookupContext } from "./WynQLParser.js";
import { LinkLookupTargetContext } from "./WynQLParser.js";
import { LinkLookupOpContext } from "./WynQLParser.js";
import { LinkMessageContext } from "./WynQLParser.js";
import { LinkUpdateContext } from "./WynQLParser.js";
import { ChoiceRefContext } from "./WynQLParser.js";
import { ChoiceKeyArgContext } from "./WynQLParser.js";
import { OnConflictClauseContext } from "./WynQLParser.js";
import { ReturningClauseContext } from "./WynQLParser.js";
import { ReturningSpecContext } from "./WynQLParser.js";
import { SelectQueryContext } from "./WynQLParser.js";
import { AsOfClauseContext } from "./WynQLParser.js";
import { SelectLockClauseContext } from "./WynQLParser.js";
import { LinkDefinitionContext } from "./WynQLParser.js";
import { LinkArgContext } from "./WynQLParser.js";
import { LinkArgKeyContext } from "./WynQLParser.js";
import { LinkArgValueContext } from "./WynQLParser.js";
import { SummarizeQueryContext } from "./WynQLParser.js";
import { TableRefContext } from "./WynQLParser.js";
import { NqInvocationArgsContext } from "./WynQLParser.js";
import { NqInvocationArgContext } from "./WynQLParser.js";
import { SetOperationContext } from "./WynQLParser.js";
import { AliasContext } from "./WynQLParser.js";
import { ProjectionContext } from "./WynQLParser.js";
import { AnnotationContext } from "./WynQLParser.js";
import { AnnotationArgsContext } from "./WynQLParser.js";
import { AnnotationArgContext } from "./WynQLParser.js";
import { AnnotationArgValueContext } from "./WynQLParser.js";
import { ArrayAggSortContext } from "./WynQLParser.js";
import { AliasAssignmentContext } from "./WynQLParser.js";
import { NestedSubqueryContext } from "./WynQLParser.js";
import { LinkRefContext } from "./WynQLParser.js";
import { LeadingLinkOperatorContext } from "./WynQLParser.js";
import { GroupByClauseContext } from "./WynQLParser.js";
import { DeriveClauseContext } from "./WynQLParser.js";
import { DerivationContext } from "./WynQLParser.js";
import { AggregationContext } from "./WynQLParser.js";
import { DistinctModifierContext } from "./WynQLParser.js";
import { AggregateFunctionContext } from "./WynQLParser.js";
import { FilterSuffixContext } from "./WynQLParser.js";
import { OverClauseContext } from "./WynQLParser.js";
import { WindowDefinitionContext } from "./WynQLParser.js";
import { WindowSpecContext } from "./WynQLParser.js";
import { WindowPartContext } from "./WynQLParser.js";
import { WindowCallArgsContext } from "./WynQLParser.js";
import { FrameClauseContext } from "./WynQLParser.js";
import { FrameSpecContext } from "./WynQLParser.js";
import { FrameStartContext } from "./WynQLParser.js";
import { FrameEndContext } from "./WynQLParser.js";
import { SignedIntegerContext } from "./WynQLParser.js";
import { SortItemContext } from "./WynQLParser.js";
import { WindowRefContext } from "./WynQLParser.js";
import { WindowFunctionContext } from "./WynQLParser.js";
import { WindowCallContext } from "./WynQLParser.js";
import { FilterClauseContext } from "./WynQLParser.js";
import { SortClauseContext } from "./WynQLParser.js";
import { TakeClauseContext } from "./WynQLParser.js";
import { TakeValueContext } from "./WynQLParser.js";
import { RankQueryContext } from "./WynQLParser.js";
import { LoopQueryContext } from "./WynQLParser.js";
import { ExpressionContext } from "./WynQLParser.js";
import { OrExpressionContext } from "./WynQLParser.js";
import { AndExpressionContext } from "./WynQLParser.js";
import { NullishExpressionContext } from "./WynQLParser.js";
import { NotExpressionContext } from "./WynQLParser.js";
import { ComparisonExpressionContext } from "./WynQLParser.js";
import { TableSearchExprContext } from "./WynQLParser.js";
import { ComparisonTailContext } from "./WynQLParser.js";
import { NegatableTailContext } from "./WynQLParser.js";
import { InRhsContext } from "./WynQLParser.js";
import { JsonbPathExprContext } from "./WynQLParser.js";
import { InExpressionListContext } from "./WynQLParser.js";
import { LikeRhsContext } from "./WynQLParser.js";
import { RangeOpRhsContext } from "./WynQLParser.js";
import { RangeOpContext } from "./WynQLParser.js";
import { ComparisonOperatorContext } from "./WynQLParser.js";
import { AdditiveExpressionContext } from "./WynQLParser.js";
import { MultiplicativeExpressionContext } from "./WynQLParser.js";
import { ColumnRefContext } from "./WynQLParser.js";
import { AnnotatedColumnRefContext } from "./WynQLParser.js";
import { ColumnAccessorContext } from "./WynQLParser.js";
import { DatePartAccessContext } from "./WynQLParser.js";
import { LinkNavigationContext } from "./WynQLParser.js";
import { PostfixAccessContext } from "./WynQLParser.js";
import { IdentifierNameContext } from "./WynQLParser.js";
import { ParameterRefContext } from "./WynQLParser.js";
import { ParameterMetaContext } from "./WynQLParser.js";
import { ParameterMetaEntryContext } from "./WynQLParser.js";
import { ParameterDefaultValueContext } from "./WynQLParser.js";
import { ParameterTypeNameContext } from "./WynQLParser.js";
import { LinkOperatorContext } from "./WynQLParser.js";
import { LinkExpressionContext } from "./WynQLParser.js";
import { RangeBoundContext } from "./WynQLParser.js";
import { LeftBoundContext } from "./WynQLParser.js";
import { RightBoundContext } from "./WynQLParser.js";
import { FunctionCallContext } from "./WynQLParser.js";
import { NonReservedFunctionNameContext } from "./WynQLParser.js";
import { NiladicTemporalFunctionContext } from "./WynQLParser.js";
import { ExpressionOrStarContext } from "./WynQLParser.js";
import { ExpressionListContext } from "./WynQLParser.js";
import { CaseExpressionContext } from "./WynQLParser.js";
import { CaseArgsContext } from "./WynQLParser.js";
import { InlineSqlContext } from "./WynQLParser.js";
import { CastExpressionContext } from "./WynQLParser.js";
import { PolicyExpansionContext } from "./WynQLParser.js";
import { CapabilityCheckContext } from "./WynQLParser.js";
import { UnaryExpressionContext } from "./WynQLParser.js";
import { PostfixExpressionContext } from "./WynQLParser.js";
import { TypeNameContext } from "./WynQLParser.js";
import { TypeParamsContext } from "./WynQLParser.js";
import { PrimaryExpressionContext } from "./WynQLParser.js";
import { ArrayLiteralContext } from "./WynQLParser.js";
import { LiteralContext } from "./WynQLParser.js";
/**
 * This interface defines a complete listener for a parse tree produced by
 * `WynQLParser`.
 */
export declare class WynQLListener implements ParseTreeListener {
    /**
     * Enter a parse tree produced by `WynQLParser.query`.
     * @param ctx the parse tree
     */
    enterQuery?: (ctx: QueryContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.query`.
     * @param ctx the parse tree
     */
    exitQuery?: (ctx: QueryContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.dqlStatement`.
     * @param ctx the parse tree
     */
    enterDqlStatement?: (ctx: DqlStatementContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.dqlStatement`.
     * @param ctx the parse tree
     */
    exitDqlStatement?: (ctx: DqlStatementContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.bareQuery`.
     * @param ctx the parse tree
     */
    enterBareQuery?: (ctx: BareQueryContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.bareQuery`.
     * @param ctx the parse tree
     */
    exitBareQuery?: (ctx: BareQueryContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.dmlStatement`.
     * @param ctx the parse tree
     */
    enterDmlStatement?: (ctx: DmlStatementContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.dmlStatement`.
     * @param ctx the parse tree
     */
    exitDmlStatement?: (ctx: DmlStatementContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.tclStatement`.
     * @param ctx the parse tree
     */
    enterTclStatement?: (ctx: TclStatementContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.tclStatement`.
     * @param ctx the parse tree
     */
    exitTclStatement?: (ctx: TclStatementContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.ddlStatement`.
     * @param ctx the parse tree
     */
    enterDdlStatement?: (ctx: DdlStatementContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.ddlStatement`.
     * @param ctx the parse tree
     */
    exitDdlStatement?: (ctx: DdlStatementContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.dclStatement`.
     * @param ctx the parse tree
     */
    enterDclStatement?: (ctx: DclStatementContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.dclStatement`.
     * @param ctx the parse tree
     */
    exitDclStatement?: (ctx: DclStatementContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.grantStatement`.
     * @param ctx the parse tree
     */
    enterGrantStatement?: (ctx: GrantStatementContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.grantStatement`.
     * @param ctx the parse tree
     */
    exitGrantStatement?: (ctx: GrantStatementContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.modelTarget`.
     * @param ctx the parse tree
     */
    enterModelTarget?: (ctx: ModelTargetContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.modelTarget`.
     * @param ctx the parse tree
     */
    exitModelTarget?: (ctx: ModelTargetContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.decisionOperation`.
     * @param ctx the parse tree
     */
    enterDecisionOperation?: (ctx: DecisionOperationContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.decisionOperation`.
     * @param ctx the parse tree
     */
    exitDecisionOperation?: (ctx: DecisionOperationContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.policyStatement`.
     * @param ctx the parse tree
     */
    enterPolicyStatement?: (ctx: PolicyStatementContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.policyStatement`.
     * @param ctx the parse tree
     */
    exitPolicyStatement?: (ctx: PolicyStatementContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.policyKey`.
     * @param ctx the parse tree
     */
    enterPolicyKey?: (ctx: PolicyKeyContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.policyKey`.
     * @param ctx the parse tree
     */
    exitPolicyKey?: (ctx: PolicyKeyContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.alterPolicyStatement`.
     * @param ctx the parse tree
     */
    enterAlterPolicyStatement?: (ctx: AlterPolicyStatementContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.alterPolicyStatement`.
     * @param ctx the parse tree
     */
    exitAlterPolicyStatement?: (ctx: AlterPolicyStatementContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.dropPolicyStatement`.
     * @param ctx the parse tree
     */
    enterDropPolicyStatement?: (ctx: DropPolicyStatementContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.dropPolicyStatement`.
     * @param ctx the parse tree
     */
    exitDropPolicyStatement?: (ctx: DropPolicyStatementContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.policyRef`.
     * @param ctx the parse tree
     */
    enterPolicyRef?: (ctx: PolicyRefContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.policyRef`.
     * @param ctx the parse tree
     */
    exitPolicyRef?: (ctx: PolicyRefContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.roleClause`.
     * @param ctx the parse tree
     */
    enterRoleClause?: (ctx: RoleClauseContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.roleClause`.
     * @param ctx the parse tree
     */
    exitRoleClause?: (ctx: RoleClauseContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.qualifiedName`.
     * @param ctx the parse tree
     */
    enterQualifiedName?: (ctx: QualifiedNameContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.qualifiedName`.
     * @param ctx the parse tree
     */
    exitQualifiedName?: (ctx: QualifiedNameContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.delegateStatement`.
     * @param ctx the parse tree
     */
    enterDelegateStatement?: (ctx: DelegateStatementContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.delegateStatement`.
     * @param ctx the parse tree
     */
    exitDelegateStatement?: (ctx: DelegateStatementContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.delegableTarget`.
     * @param ctx the parse tree
     */
    enterDelegableTarget?: (ctx: DelegableTargetContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.delegableTarget`.
     * @param ctx the parse tree
     */
    exitDelegableTarget?: (ctx: DelegableTargetContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.revokeDelegationStatement`.
     * @param ctx the parse tree
     */
    enterRevokeDelegationStatement?: (ctx: RevokeDelegationStatementContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.revokeDelegationStatement`.
     * @param ctx the parse tree
     */
    exitRevokeDelegationStatement?: (ctx: RevokeDelegationStatementContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.periodClause`.
     * @param ctx the parse tree
     */
    enterPeriodClause?: (ctx: PeriodClauseContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.periodClause`.
     * @param ctx the parse tree
     */
    exitPeriodClause?: (ctx: PeriodClauseContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.userRef`.
     * @param ctx the parse tree
     */
    enterUserRef?: (ctx: UserRefContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.userRef`.
     * @param ctx the parse tree
     */
    exitUserRef?: (ctx: UserRefContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.delegationRef`.
     * @param ctx the parse tree
     */
    enterDelegationRef?: (ctx: DelegationRefContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.delegationRef`.
     * @param ctx the parse tree
     */
    exitDelegationRef?: (ctx: DelegationRefContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.statement`.
     * @param ctx the parse tree
     */
    enterStatement?: (ctx: StatementContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.statement`.
     * @param ctx the parse tree
     */
    exitStatement?: (ctx: StatementContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.defineStatement`.
     * @param ctx the parse tree
     */
    enterDefineStatement?: (ctx: DefineStatementContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.defineStatement`.
     * @param ctx the parse tree
     */
    exitDefineStatement?: (ctx: DefineStatementContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.constDefineStatement`.
     * @param ctx the parse tree
     */
    enterConstDefineStatement?: (ctx: ConstDefineStatementContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.constDefineStatement`.
     * @param ctx the parse tree
     */
    exitConstDefineStatement?: (ctx: ConstDefineStatementContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.importStatement`.
     * @param ctx the parse tree
     */
    enterImportStatement?: (ctx: ImportStatementContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.importStatement`.
     * @param ctx the parse tree
     */
    exitImportStatement?: (ctx: ImportStatementContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.definitionOption`.
     * @param ctx the parse tree
     */
    enterDefinitionOption?: (ctx: DefinitionOptionContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.definitionOption`.
     * @param ctx the parse tree
     */
    exitDefinitionOption?: (ctx: DefinitionOptionContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.definitionBody`.
     * @param ctx the parse tree
     */
    enterDefinitionBody?: (ctx: DefinitionBodyContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.definitionBody`.
     * @param ctx the parse tree
     */
    exitDefinitionBody?: (ctx: DefinitionBodyContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.definitionBodyStatement`.
     * @param ctx the parse tree
     */
    enterDefinitionBodyStatement?: (ctx: DefinitionBodyStatementContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.definitionBodyStatement`.
     * @param ctx the parse tree
     */
    exitDefinitionBodyStatement?: (ctx: DefinitionBodyStatementContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.exposeStatement`.
     * @param ctx the parse tree
     */
    enterExposeStatement?: (ctx: ExposeStatementContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.exposeStatement`.
     * @param ctx the parse tree
     */
    exitExposeStatement?: (ctx: ExposeStatementContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.dropStatement`.
     * @param ctx the parse tree
     */
    enterDropStatement?: (ctx: DropStatementContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.dropStatement`.
     * @param ctx the parse tree
     */
    exitDropStatement?: (ctx: DropStatementContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.namedQueryRef`.
     * @param ctx the parse tree
     */
    enterNamedQueryRef?: (ctx: NamedQueryRefContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.namedQueryRef`.
     * @param ctx the parse tree
     */
    exitNamedQueryRef?: (ctx: NamedQueryRefContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.exposureLevel`.
     * @param ctx the parse tree
     */
    enterExposureLevel?: (ctx: ExposureLevelContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.exposureLevel`.
     * @param ctx the parse tree
     */
    exitExposureLevel?: (ctx: ExposureLevelContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.queryStatement`.
     * @param ctx the parse tree
     */
    enterQueryStatement?: (ctx: QueryStatementContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.queryStatement`.
     * @param ctx the parse tree
     */
    exitQueryStatement?: (ctx: QueryStatementContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.cteDefinition`.
     * @param ctx the parse tree
     */
    enterCteDefinition?: (ctx: CteDefinitionContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.cteDefinition`.
     * @param ctx the parse tree
     */
    exitCteDefinition?: (ctx: CteDefinitionContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.cteBody`.
     * @param ctx the parse tree
     */
    enterCteBody?: (ctx: CteBodyContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.cteBody`.
     * @param ctx the parse tree
     */
    exitCteBody?: (ctx: CteBodyContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.queryBody`.
     * @param ctx the parse tree
     */
    enterQueryBody?: (ctx: QueryBodyContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.queryBody`.
     * @param ctx the parse tree
     */
    exitQueryBody?: (ctx: QueryBodyContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.insertStatement`.
     * @param ctx the parse tree
     */
    enterInsertStatement?: (ctx: InsertStatementContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.insertStatement`.
     * @param ctx the parse tree
     */
    exitInsertStatement?: (ctx: InsertStatementContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.eachSource`.
     * @param ctx the parse tree
     */
    enterEachSource?: (ctx: EachSourceContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.eachSource`.
     * @param ctx the parse tree
     */
    exitEachSource?: (ctx: EachSourceContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.updateStatement`.
     * @param ctx the parse tree
     */
    enterUpdateStatement?: (ctx: UpdateStatementContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.updateStatement`.
     * @param ctx the parse tree
     */
    exitUpdateStatement?: (ctx: UpdateStatementContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.upsertStatement`.
     * @param ctx the parse tree
     */
    enterUpsertStatement?: (ctx: UpsertStatementContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.upsertStatement`.
     * @param ctx the parse tree
     */
    exitUpsertStatement?: (ctx: UpsertStatementContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.deleteStatement`.
     * @param ctx the parse tree
     */
    enterDeleteStatement?: (ctx: DeleteStatementContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.deleteStatement`.
     * @param ctx the parse tree
     */
    exitDeleteStatement?: (ctx: DeleteStatementContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.guardClause`.
     * @param ctx the parse tree
     */
    enterGuardClause?: (ctx: GuardClauseContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.guardClause`.
     * @param ctx the parse tree
     */
    exitGuardClause?: (ctx: GuardClauseContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.transactionBlock`.
     * @param ctx the parse tree
     */
    enterTransactionBlock?: (ctx: TransactionBlockContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.transactionBlock`.
     * @param ctx the parse tree
     */
    exitTransactionBlock?: (ctx: TransactionBlockContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.transactionBodyStatement`.
     * @param ctx the parse tree
     */
    enterTransactionBodyStatement?: (ctx: TransactionBodyStatementContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.transactionBodyStatement`.
     * @param ctx the parse tree
     */
    exitTransactionBodyStatement?: (ctx: TransactionBodyStatementContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.transactionErrorHandler`.
     * @param ctx the parse tree
     */
    enterTransactionErrorHandler?: (ctx: TransactionErrorHandlerContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.transactionErrorHandler`.
     * @param ctx the parse tree
     */
    exitTransactionErrorHandler?: (ctx: TransactionErrorHandlerContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.tableName`.
     * @param ctx the parse tree
     */
    enterTableName?: (ctx: TableNameContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.tableName`.
     * @param ctx the parse tree
     */
    exitTableName?: (ctx: TableNameContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.mutationObject`.
     * @param ctx the parse tree
     */
    enterMutationObject?: (ctx: MutationObjectContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.mutationObject`.
     * @param ctx the parse tree
     */
    exitMutationObject?: (ctx: MutationObjectContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.mutationField`.
     * @param ctx the parse tree
     */
    enterMutationField?: (ctx: MutationFieldContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.mutationField`.
     * @param ctx the parse tree
     */
    exitMutationField?: (ctx: MutationFieldContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.mutationAssign`.
     * @param ctx the parse tree
     */
    enterMutationAssign?: (ctx: MutationAssignContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.mutationAssign`.
     * @param ctx the parse tree
     */
    exitMutationAssign?: (ctx: MutationAssignContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.mutationValue`.
     * @param ctx the parse tree
     */
    enterMutationValue?: (ctx: MutationValueContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.mutationValue`.
     * @param ctx the parse tree
     */
    exitMutationValue?: (ctx: MutationValueContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.mutationArray`.
     * @param ctx the parse tree
     */
    enterMutationArray?: (ctx: MutationArrayContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.mutationArray`.
     * @param ctx the parse tree
     */
    exitMutationArray?: (ctx: MutationArrayContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.mutationArrayItem`.
     * @param ctx the parse tree
     */
    enterMutationArrayItem?: (ctx: MutationArrayItemContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.mutationArrayItem`.
     * @param ctx the parse tree
     */
    exitMutationArrayItem?: (ctx: MutationArrayItemContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.nestedInsert`.
     * @param ctx the parse tree
     */
    enterNestedInsert?: (ctx: NestedInsertContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.nestedInsert`.
     * @param ctx the parse tree
     */
    exitNestedInsert?: (ctx: NestedInsertContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.linkLookup`.
     * @param ctx the parse tree
     */
    enterLinkLookup?: (ctx: LinkLookupContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.linkLookup`.
     * @param ctx the parse tree
     */
    exitLinkLookup?: (ctx: LinkLookupContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.linkLookupTarget`.
     * @param ctx the parse tree
     */
    enterLinkLookupTarget?: (ctx: LinkLookupTargetContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.linkLookupTarget`.
     * @param ctx the parse tree
     */
    exitLinkLookupTarget?: (ctx: LinkLookupTargetContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.linkLookupOp`.
     * @param ctx the parse tree
     */
    enterLinkLookupOp?: (ctx: LinkLookupOpContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.linkLookupOp`.
     * @param ctx the parse tree
     */
    exitLinkLookupOp?: (ctx: LinkLookupOpContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.linkMessage`.
     * @param ctx the parse tree
     */
    enterLinkMessage?: (ctx: LinkMessageContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.linkMessage`.
     * @param ctx the parse tree
     */
    exitLinkMessage?: (ctx: LinkMessageContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.linkUpdate`.
     * @param ctx the parse tree
     */
    enterLinkUpdate?: (ctx: LinkUpdateContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.linkUpdate`.
     * @param ctx the parse tree
     */
    exitLinkUpdate?: (ctx: LinkUpdateContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.choiceRef`.
     * @param ctx the parse tree
     */
    enterChoiceRef?: (ctx: ChoiceRefContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.choiceRef`.
     * @param ctx the parse tree
     */
    exitChoiceRef?: (ctx: ChoiceRefContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.choiceKeyArg`.
     * @param ctx the parse tree
     */
    enterChoiceKeyArg?: (ctx: ChoiceKeyArgContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.choiceKeyArg`.
     * @param ctx the parse tree
     */
    exitChoiceKeyArg?: (ctx: ChoiceKeyArgContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.onConflictClause`.
     * @param ctx the parse tree
     */
    enterOnConflictClause?: (ctx: OnConflictClauseContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.onConflictClause`.
     * @param ctx the parse tree
     */
    exitOnConflictClause?: (ctx: OnConflictClauseContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.returningClause`.
     * @param ctx the parse tree
     */
    enterReturningClause?: (ctx: ReturningClauseContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.returningClause`.
     * @param ctx the parse tree
     */
    exitReturningClause?: (ctx: ReturningClauseContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.returningSpec`.
     * @param ctx the parse tree
     */
    enterReturningSpec?: (ctx: ReturningSpecContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.returningSpec`.
     * @param ctx the parse tree
     */
    exitReturningSpec?: (ctx: ReturningSpecContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.selectQuery`.
     * @param ctx the parse tree
     */
    enterSelectQuery?: (ctx: SelectQueryContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.selectQuery`.
     * @param ctx the parse tree
     */
    exitSelectQuery?: (ctx: SelectQueryContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.asOfClause`.
     * @param ctx the parse tree
     */
    enterAsOfClause?: (ctx: AsOfClauseContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.asOfClause`.
     * @param ctx the parse tree
     */
    exitAsOfClause?: (ctx: AsOfClauseContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.selectLockClause`.
     * @param ctx the parse tree
     */
    enterSelectLockClause?: (ctx: SelectLockClauseContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.selectLockClause`.
     * @param ctx the parse tree
     */
    exitSelectLockClause?: (ctx: SelectLockClauseContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.linkDefinition`.
     * @param ctx the parse tree
     */
    enterLinkDefinition?: (ctx: LinkDefinitionContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.linkDefinition`.
     * @param ctx the parse tree
     */
    exitLinkDefinition?: (ctx: LinkDefinitionContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.linkArg`.
     * @param ctx the parse tree
     */
    enterLinkArg?: (ctx: LinkArgContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.linkArg`.
     * @param ctx the parse tree
     */
    exitLinkArg?: (ctx: LinkArgContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.linkArgKey`.
     * @param ctx the parse tree
     */
    enterLinkArgKey?: (ctx: LinkArgKeyContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.linkArgKey`.
     * @param ctx the parse tree
     */
    exitLinkArgKey?: (ctx: LinkArgKeyContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.linkArgValue`.
     * @param ctx the parse tree
     */
    enterLinkArgValue?: (ctx: LinkArgValueContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.linkArgValue`.
     * @param ctx the parse tree
     */
    exitLinkArgValue?: (ctx: LinkArgValueContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.summarizeQuery`.
     * @param ctx the parse tree
     */
    enterSummarizeQuery?: (ctx: SummarizeQueryContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.summarizeQuery`.
     * @param ctx the parse tree
     */
    exitSummarizeQuery?: (ctx: SummarizeQueryContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.tableRef`.
     * @param ctx the parse tree
     */
    enterTableRef?: (ctx: TableRefContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.tableRef`.
     * @param ctx the parse tree
     */
    exitTableRef?: (ctx: TableRefContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.nqInvocationArgs`.
     * @param ctx the parse tree
     */
    enterNqInvocationArgs?: (ctx: NqInvocationArgsContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.nqInvocationArgs`.
     * @param ctx the parse tree
     */
    exitNqInvocationArgs?: (ctx: NqInvocationArgsContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.nqInvocationArg`.
     * @param ctx the parse tree
     */
    enterNqInvocationArg?: (ctx: NqInvocationArgContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.nqInvocationArg`.
     * @param ctx the parse tree
     */
    exitNqInvocationArg?: (ctx: NqInvocationArgContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.setOperation`.
     * @param ctx the parse tree
     */
    enterSetOperation?: (ctx: SetOperationContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.setOperation`.
     * @param ctx the parse tree
     */
    exitSetOperation?: (ctx: SetOperationContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.alias`.
     * @param ctx the parse tree
     */
    enterAlias?: (ctx: AliasContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.alias`.
     * @param ctx the parse tree
     */
    exitAlias?: (ctx: AliasContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.projection`.
     * @param ctx the parse tree
     */
    enterProjection?: (ctx: ProjectionContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.projection`.
     * @param ctx the parse tree
     */
    exitProjection?: (ctx: ProjectionContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.annotation`.
     * @param ctx the parse tree
     */
    enterAnnotation?: (ctx: AnnotationContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.annotation`.
     * @param ctx the parse tree
     */
    exitAnnotation?: (ctx: AnnotationContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.annotationArgs`.
     * @param ctx the parse tree
     */
    enterAnnotationArgs?: (ctx: AnnotationArgsContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.annotationArgs`.
     * @param ctx the parse tree
     */
    exitAnnotationArgs?: (ctx: AnnotationArgsContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.annotationArg`.
     * @param ctx the parse tree
     */
    enterAnnotationArg?: (ctx: AnnotationArgContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.annotationArg`.
     * @param ctx the parse tree
     */
    exitAnnotationArg?: (ctx: AnnotationArgContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.annotationArgValue`.
     * @param ctx the parse tree
     */
    enterAnnotationArgValue?: (ctx: AnnotationArgValueContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.annotationArgValue`.
     * @param ctx the parse tree
     */
    exitAnnotationArgValue?: (ctx: AnnotationArgValueContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.arrayAggSort`.
     * @param ctx the parse tree
     */
    enterArrayAggSort?: (ctx: ArrayAggSortContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.arrayAggSort`.
     * @param ctx the parse tree
     */
    exitArrayAggSort?: (ctx: ArrayAggSortContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.aliasAssignment`.
     * @param ctx the parse tree
     */
    enterAliasAssignment?: (ctx: AliasAssignmentContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.aliasAssignment`.
     * @param ctx the parse tree
     */
    exitAliasAssignment?: (ctx: AliasAssignmentContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.nestedSubquery`.
     * @param ctx the parse tree
     */
    enterNestedSubquery?: (ctx: NestedSubqueryContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.nestedSubquery`.
     * @param ctx the parse tree
     */
    exitNestedSubquery?: (ctx: NestedSubqueryContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.linkRef`.
     * @param ctx the parse tree
     */
    enterLinkRef?: (ctx: LinkRefContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.linkRef`.
     * @param ctx the parse tree
     */
    exitLinkRef?: (ctx: LinkRefContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.leadingLinkOperator`.
     * @param ctx the parse tree
     */
    enterLeadingLinkOperator?: (ctx: LeadingLinkOperatorContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.leadingLinkOperator`.
     * @param ctx the parse tree
     */
    exitLeadingLinkOperator?: (ctx: LeadingLinkOperatorContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.groupByClause`.
     * @param ctx the parse tree
     */
    enterGroupByClause?: (ctx: GroupByClauseContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.groupByClause`.
     * @param ctx the parse tree
     */
    exitGroupByClause?: (ctx: GroupByClauseContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.deriveClause`.
     * @param ctx the parse tree
     */
    enterDeriveClause?: (ctx: DeriveClauseContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.deriveClause`.
     * @param ctx the parse tree
     */
    exitDeriveClause?: (ctx: DeriveClauseContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.derivation`.
     * @param ctx the parse tree
     */
    enterDerivation?: (ctx: DerivationContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.derivation`.
     * @param ctx the parse tree
     */
    exitDerivation?: (ctx: DerivationContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.aggregation`.
     * @param ctx the parse tree
     */
    enterAggregation?: (ctx: AggregationContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.aggregation`.
     * @param ctx the parse tree
     */
    exitAggregation?: (ctx: AggregationContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.distinctModifier`.
     * @param ctx the parse tree
     */
    enterDistinctModifier?: (ctx: DistinctModifierContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.distinctModifier`.
     * @param ctx the parse tree
     */
    exitDistinctModifier?: (ctx: DistinctModifierContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.aggregateFunction`.
     * @param ctx the parse tree
     */
    enterAggregateFunction?: (ctx: AggregateFunctionContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.aggregateFunction`.
     * @param ctx the parse tree
     */
    exitAggregateFunction?: (ctx: AggregateFunctionContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.filterSuffix`.
     * @param ctx the parse tree
     */
    enterFilterSuffix?: (ctx: FilterSuffixContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.filterSuffix`.
     * @param ctx the parse tree
     */
    exitFilterSuffix?: (ctx: FilterSuffixContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.overClause`.
     * @param ctx the parse tree
     */
    enterOverClause?: (ctx: OverClauseContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.overClause`.
     * @param ctx the parse tree
     */
    exitOverClause?: (ctx: OverClauseContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.windowDefinition`.
     * @param ctx the parse tree
     */
    enterWindowDefinition?: (ctx: WindowDefinitionContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.windowDefinition`.
     * @param ctx the parse tree
     */
    exitWindowDefinition?: (ctx: WindowDefinitionContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.windowSpec`.
     * @param ctx the parse tree
     */
    enterWindowSpec?: (ctx: WindowSpecContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.windowSpec`.
     * @param ctx the parse tree
     */
    exitWindowSpec?: (ctx: WindowSpecContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.windowPart`.
     * @param ctx the parse tree
     */
    enterWindowPart?: (ctx: WindowPartContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.windowPart`.
     * @param ctx the parse tree
     */
    exitWindowPart?: (ctx: WindowPartContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.windowCallArgs`.
     * @param ctx the parse tree
     */
    enterWindowCallArgs?: (ctx: WindowCallArgsContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.windowCallArgs`.
     * @param ctx the parse tree
     */
    exitWindowCallArgs?: (ctx: WindowCallArgsContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.frameClause`.
     * @param ctx the parse tree
     */
    enterFrameClause?: (ctx: FrameClauseContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.frameClause`.
     * @param ctx the parse tree
     */
    exitFrameClause?: (ctx: FrameClauseContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.frameSpec`.
     * @param ctx the parse tree
     */
    enterFrameSpec?: (ctx: FrameSpecContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.frameSpec`.
     * @param ctx the parse tree
     */
    exitFrameSpec?: (ctx: FrameSpecContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.frameStart`.
     * @param ctx the parse tree
     */
    enterFrameStart?: (ctx: FrameStartContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.frameStart`.
     * @param ctx the parse tree
     */
    exitFrameStart?: (ctx: FrameStartContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.frameEnd`.
     * @param ctx the parse tree
     */
    enterFrameEnd?: (ctx: FrameEndContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.frameEnd`.
     * @param ctx the parse tree
     */
    exitFrameEnd?: (ctx: FrameEndContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.signedInteger`.
     * @param ctx the parse tree
     */
    enterSignedInteger?: (ctx: SignedIntegerContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.signedInteger`.
     * @param ctx the parse tree
     */
    exitSignedInteger?: (ctx: SignedIntegerContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.sortItem`.
     * @param ctx the parse tree
     */
    enterSortItem?: (ctx: SortItemContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.sortItem`.
     * @param ctx the parse tree
     */
    exitSortItem?: (ctx: SortItemContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.windowRef`.
     * @param ctx the parse tree
     */
    enterWindowRef?: (ctx: WindowRefContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.windowRef`.
     * @param ctx the parse tree
     */
    exitWindowRef?: (ctx: WindowRefContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.windowFunction`.
     * @param ctx the parse tree
     */
    enterWindowFunction?: (ctx: WindowFunctionContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.windowFunction`.
     * @param ctx the parse tree
     */
    exitWindowFunction?: (ctx: WindowFunctionContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.windowCall`.
     * @param ctx the parse tree
     */
    enterWindowCall?: (ctx: WindowCallContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.windowCall`.
     * @param ctx the parse tree
     */
    exitWindowCall?: (ctx: WindowCallContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.filterClause`.
     * @param ctx the parse tree
     */
    enterFilterClause?: (ctx: FilterClauseContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.filterClause`.
     * @param ctx the parse tree
     */
    exitFilterClause?: (ctx: FilterClauseContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.sortClause`.
     * @param ctx the parse tree
     */
    enterSortClause?: (ctx: SortClauseContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.sortClause`.
     * @param ctx the parse tree
     */
    exitSortClause?: (ctx: SortClauseContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.takeClause`.
     * @param ctx the parse tree
     */
    enterTakeClause?: (ctx: TakeClauseContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.takeClause`.
     * @param ctx the parse tree
     */
    exitTakeClause?: (ctx: TakeClauseContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.takeValue`.
     * @param ctx the parse tree
     */
    enterTakeValue?: (ctx: TakeValueContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.takeValue`.
     * @param ctx the parse tree
     */
    exitTakeValue?: (ctx: TakeValueContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.rankQuery`.
     * @param ctx the parse tree
     */
    enterRankQuery?: (ctx: RankQueryContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.rankQuery`.
     * @param ctx the parse tree
     */
    exitRankQuery?: (ctx: RankQueryContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.loopQuery`.
     * @param ctx the parse tree
     */
    enterLoopQuery?: (ctx: LoopQueryContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.loopQuery`.
     * @param ctx the parse tree
     */
    exitLoopQuery?: (ctx: LoopQueryContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.expression`.
     * @param ctx the parse tree
     */
    enterExpression?: (ctx: ExpressionContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.expression`.
     * @param ctx the parse tree
     */
    exitExpression?: (ctx: ExpressionContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.orExpression`.
     * @param ctx the parse tree
     */
    enterOrExpression?: (ctx: OrExpressionContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.orExpression`.
     * @param ctx the parse tree
     */
    exitOrExpression?: (ctx: OrExpressionContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.andExpression`.
     * @param ctx the parse tree
     */
    enterAndExpression?: (ctx: AndExpressionContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.andExpression`.
     * @param ctx the parse tree
     */
    exitAndExpression?: (ctx: AndExpressionContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.nullishExpression`.
     * @param ctx the parse tree
     */
    enterNullishExpression?: (ctx: NullishExpressionContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.nullishExpression`.
     * @param ctx the parse tree
     */
    exitNullishExpression?: (ctx: NullishExpressionContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.notExpression`.
     * @param ctx the parse tree
     */
    enterNotExpression?: (ctx: NotExpressionContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.notExpression`.
     * @param ctx the parse tree
     */
    exitNotExpression?: (ctx: NotExpressionContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.comparisonExpression`.
     * @param ctx the parse tree
     */
    enterComparisonExpression?: (ctx: ComparisonExpressionContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.comparisonExpression`.
     * @param ctx the parse tree
     */
    exitComparisonExpression?: (ctx: ComparisonExpressionContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.tableSearchExpr`.
     * @param ctx the parse tree
     */
    enterTableSearchExpr?: (ctx: TableSearchExprContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.tableSearchExpr`.
     * @param ctx the parse tree
     */
    exitTableSearchExpr?: (ctx: TableSearchExprContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.comparisonTail`.
     * @param ctx the parse tree
     */
    enterComparisonTail?: (ctx: ComparisonTailContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.comparisonTail`.
     * @param ctx the parse tree
     */
    exitComparisonTail?: (ctx: ComparisonTailContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.negatableTail`.
     * @param ctx the parse tree
     */
    enterNegatableTail?: (ctx: NegatableTailContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.negatableTail`.
     * @param ctx the parse tree
     */
    exitNegatableTail?: (ctx: NegatableTailContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.inRhs`.
     * @param ctx the parse tree
     */
    enterInRhs?: (ctx: InRhsContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.inRhs`.
     * @param ctx the parse tree
     */
    exitInRhs?: (ctx: InRhsContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.jsonbPathExpr`.
     * @param ctx the parse tree
     */
    enterJsonbPathExpr?: (ctx: JsonbPathExprContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.jsonbPathExpr`.
     * @param ctx the parse tree
     */
    exitJsonbPathExpr?: (ctx: JsonbPathExprContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.inExpressionList`.
     * @param ctx the parse tree
     */
    enterInExpressionList?: (ctx: InExpressionListContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.inExpressionList`.
     * @param ctx the parse tree
     */
    exitInExpressionList?: (ctx: InExpressionListContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.likeRhs`.
     * @param ctx the parse tree
     */
    enterLikeRhs?: (ctx: LikeRhsContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.likeRhs`.
     * @param ctx the parse tree
     */
    exitLikeRhs?: (ctx: LikeRhsContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.rangeOpRhs`.
     * @param ctx the parse tree
     */
    enterRangeOpRhs?: (ctx: RangeOpRhsContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.rangeOpRhs`.
     * @param ctx the parse tree
     */
    exitRangeOpRhs?: (ctx: RangeOpRhsContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.rangeOp`.
     * @param ctx the parse tree
     */
    enterRangeOp?: (ctx: RangeOpContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.rangeOp`.
     * @param ctx the parse tree
     */
    exitRangeOp?: (ctx: RangeOpContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.comparisonOperator`.
     * @param ctx the parse tree
     */
    enterComparisonOperator?: (ctx: ComparisonOperatorContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.comparisonOperator`.
     * @param ctx the parse tree
     */
    exitComparisonOperator?: (ctx: ComparisonOperatorContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.additiveExpression`.
     * @param ctx the parse tree
     */
    enterAdditiveExpression?: (ctx: AdditiveExpressionContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.additiveExpression`.
     * @param ctx the parse tree
     */
    exitAdditiveExpression?: (ctx: AdditiveExpressionContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.multiplicativeExpression`.
     * @param ctx the parse tree
     */
    enterMultiplicativeExpression?: (ctx: MultiplicativeExpressionContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.multiplicativeExpression`.
     * @param ctx the parse tree
     */
    exitMultiplicativeExpression?: (ctx: MultiplicativeExpressionContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.columnRef`.
     * @param ctx the parse tree
     */
    enterColumnRef?: (ctx: ColumnRefContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.columnRef`.
     * @param ctx the parse tree
     */
    exitColumnRef?: (ctx: ColumnRefContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.annotatedColumnRef`.
     * @param ctx the parse tree
     */
    enterAnnotatedColumnRef?: (ctx: AnnotatedColumnRefContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.annotatedColumnRef`.
     * @param ctx the parse tree
     */
    exitAnnotatedColumnRef?: (ctx: AnnotatedColumnRefContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.columnAccessor`.
     * @param ctx the parse tree
     */
    enterColumnAccessor?: (ctx: ColumnAccessorContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.columnAccessor`.
     * @param ctx the parse tree
     */
    exitColumnAccessor?: (ctx: ColumnAccessorContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.datePartAccess`.
     * @param ctx the parse tree
     */
    enterDatePartAccess?: (ctx: DatePartAccessContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.datePartAccess`.
     * @param ctx the parse tree
     */
    exitDatePartAccess?: (ctx: DatePartAccessContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.linkNavigation`.
     * @param ctx the parse tree
     */
    enterLinkNavigation?: (ctx: LinkNavigationContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.linkNavigation`.
     * @param ctx the parse tree
     */
    exitLinkNavigation?: (ctx: LinkNavigationContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.postfixAccess`.
     * @param ctx the parse tree
     */
    enterPostfixAccess?: (ctx: PostfixAccessContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.postfixAccess`.
     * @param ctx the parse tree
     */
    exitPostfixAccess?: (ctx: PostfixAccessContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.identifierName`.
     * @param ctx the parse tree
     */
    enterIdentifierName?: (ctx: IdentifierNameContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.identifierName`.
     * @param ctx the parse tree
     */
    exitIdentifierName?: (ctx: IdentifierNameContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.parameterRef`.
     * @param ctx the parse tree
     */
    enterParameterRef?: (ctx: ParameterRefContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.parameterRef`.
     * @param ctx the parse tree
     */
    exitParameterRef?: (ctx: ParameterRefContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.parameterMeta`.
     * @param ctx the parse tree
     */
    enterParameterMeta?: (ctx: ParameterMetaContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.parameterMeta`.
     * @param ctx the parse tree
     */
    exitParameterMeta?: (ctx: ParameterMetaContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.parameterMetaEntry`.
     * @param ctx the parse tree
     */
    enterParameterMetaEntry?: (ctx: ParameterMetaEntryContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.parameterMetaEntry`.
     * @param ctx the parse tree
     */
    exitParameterMetaEntry?: (ctx: ParameterMetaEntryContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.parameterDefaultValue`.
     * @param ctx the parse tree
     */
    enterParameterDefaultValue?: (ctx: ParameterDefaultValueContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.parameterDefaultValue`.
     * @param ctx the parse tree
     */
    exitParameterDefaultValue?: (ctx: ParameterDefaultValueContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.parameterTypeName`.
     * @param ctx the parse tree
     */
    enterParameterTypeName?: (ctx: ParameterTypeNameContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.parameterTypeName`.
     * @param ctx the parse tree
     */
    exitParameterTypeName?: (ctx: ParameterTypeNameContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.linkOperator`.
     * @param ctx the parse tree
     */
    enterLinkOperator?: (ctx: LinkOperatorContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.linkOperator`.
     * @param ctx the parse tree
     */
    exitLinkOperator?: (ctx: LinkOperatorContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.linkExpression`.
     * @param ctx the parse tree
     */
    enterLinkExpression?: (ctx: LinkExpressionContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.linkExpression`.
     * @param ctx the parse tree
     */
    exitLinkExpression?: (ctx: LinkExpressionContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.rangeBound`.
     * @param ctx the parse tree
     */
    enterRangeBound?: (ctx: RangeBoundContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.rangeBound`.
     * @param ctx the parse tree
     */
    exitRangeBound?: (ctx: RangeBoundContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.leftBound`.
     * @param ctx the parse tree
     */
    enterLeftBound?: (ctx: LeftBoundContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.leftBound`.
     * @param ctx the parse tree
     */
    exitLeftBound?: (ctx: LeftBoundContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.rightBound`.
     * @param ctx the parse tree
     */
    enterRightBound?: (ctx: RightBoundContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.rightBound`.
     * @param ctx the parse tree
     */
    exitRightBound?: (ctx: RightBoundContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.functionCall`.
     * @param ctx the parse tree
     */
    enterFunctionCall?: (ctx: FunctionCallContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.functionCall`.
     * @param ctx the parse tree
     */
    exitFunctionCall?: (ctx: FunctionCallContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.nonReservedFunctionName`.
     * @param ctx the parse tree
     */
    enterNonReservedFunctionName?: (ctx: NonReservedFunctionNameContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.nonReservedFunctionName`.
     * @param ctx the parse tree
     */
    exitNonReservedFunctionName?: (ctx: NonReservedFunctionNameContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.niladicTemporalFunction`.
     * @param ctx the parse tree
     */
    enterNiladicTemporalFunction?: (ctx: NiladicTemporalFunctionContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.niladicTemporalFunction`.
     * @param ctx the parse tree
     */
    exitNiladicTemporalFunction?: (ctx: NiladicTemporalFunctionContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.expressionOrStar`.
     * @param ctx the parse tree
     */
    enterExpressionOrStar?: (ctx: ExpressionOrStarContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.expressionOrStar`.
     * @param ctx the parse tree
     */
    exitExpressionOrStar?: (ctx: ExpressionOrStarContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.expressionList`.
     * @param ctx the parse tree
     */
    enterExpressionList?: (ctx: ExpressionListContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.expressionList`.
     * @param ctx the parse tree
     */
    exitExpressionList?: (ctx: ExpressionListContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.caseExpression`.
     * @param ctx the parse tree
     */
    enterCaseExpression?: (ctx: CaseExpressionContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.caseExpression`.
     * @param ctx the parse tree
     */
    exitCaseExpression?: (ctx: CaseExpressionContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.caseArgs`.
     * @param ctx the parse tree
     */
    enterCaseArgs?: (ctx: CaseArgsContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.caseArgs`.
     * @param ctx the parse tree
     */
    exitCaseArgs?: (ctx: CaseArgsContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.inlineSql`.
     * @param ctx the parse tree
     */
    enterInlineSql?: (ctx: InlineSqlContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.inlineSql`.
     * @param ctx the parse tree
     */
    exitInlineSql?: (ctx: InlineSqlContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.castExpression`.
     * @param ctx the parse tree
     */
    enterCastExpression?: (ctx: CastExpressionContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.castExpression`.
     * @param ctx the parse tree
     */
    exitCastExpression?: (ctx: CastExpressionContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.policyExpansion`.
     * @param ctx the parse tree
     */
    enterPolicyExpansion?: (ctx: PolicyExpansionContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.policyExpansion`.
     * @param ctx the parse tree
     */
    exitPolicyExpansion?: (ctx: PolicyExpansionContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.capabilityCheck`.
     * @param ctx the parse tree
     */
    enterCapabilityCheck?: (ctx: CapabilityCheckContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.capabilityCheck`.
     * @param ctx the parse tree
     */
    exitCapabilityCheck?: (ctx: CapabilityCheckContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.unaryExpression`.
     * @param ctx the parse tree
     */
    enterUnaryExpression?: (ctx: UnaryExpressionContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.unaryExpression`.
     * @param ctx the parse tree
     */
    exitUnaryExpression?: (ctx: UnaryExpressionContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.postfixExpression`.
     * @param ctx the parse tree
     */
    enterPostfixExpression?: (ctx: PostfixExpressionContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.postfixExpression`.
     * @param ctx the parse tree
     */
    exitPostfixExpression?: (ctx: PostfixExpressionContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.typeName`.
     * @param ctx the parse tree
     */
    enterTypeName?: (ctx: TypeNameContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.typeName`.
     * @param ctx the parse tree
     */
    exitTypeName?: (ctx: TypeNameContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.typeParams`.
     * @param ctx the parse tree
     */
    enterTypeParams?: (ctx: TypeParamsContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.typeParams`.
     * @param ctx the parse tree
     */
    exitTypeParams?: (ctx: TypeParamsContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.primaryExpression`.
     * @param ctx the parse tree
     */
    enterPrimaryExpression?: (ctx: PrimaryExpressionContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.primaryExpression`.
     * @param ctx the parse tree
     */
    exitPrimaryExpression?: (ctx: PrimaryExpressionContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.arrayLiteral`.
     * @param ctx the parse tree
     */
    enterArrayLiteral?: (ctx: ArrayLiteralContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.arrayLiteral`.
     * @param ctx the parse tree
     */
    exitArrayLiteral?: (ctx: ArrayLiteralContext) => void;
    /**
     * Enter a parse tree produced by `WynQLParser.literal`.
     * @param ctx the parse tree
     */
    enterLiteral?: (ctx: LiteralContext) => void;
    /**
     * Exit a parse tree produced by `WynQLParser.literal`.
     * @param ctx the parse tree
     */
    exitLiteral?: (ctx: LiteralContext) => void;
    visitTerminal(node: TerminalNode): void;
    visitErrorNode(node: ErrorNode): void;
    enterEveryRule(node: ParserRuleContext): void;
    exitEveryRule(node: ParserRuleContext): void;
}
