import * as antlr from "antlr4ng";
import { WynQLListener } from "./WynQLListener.js";
import { WynQLVisitor } from "./WynQLVisitor.js";
export declare class WynQLParser extends antlr.Parser {
    static readonly BEGIN = 1;
    static readonly COMMIT = 2;
    static readonly ROLLBACK = 3;
    static readonly ON = 4;
    static readonly ERROR = 5;
    static readonly INSERT = 6;
    static readonly UPDATE = 7;
    static readonly UPSERT = 8;
    static readonly DELETE = 9;
    static readonly EACH = 10;
    static readonly SOFT = 11;
    static readonly HARD = 12;
    static readonly SELECT = 13;
    static readonly SUMMARIZE = 14;
    static readonly FILTER = 15;
    static readonly ORDER = 16;
    static readonly BY = 17;
    static readonly TAKE = 18;
    static readonly DISTINCT = 19;
    static readonly EXPAND = 20;
    static readonly FIRST = 21;
    static readonly UNION = 22;
    static readonly INTERSECT = 23;
    static readonly EXCEPT = 24;
    static readonly ALL = 25;
    static readonly AS = 26;
    static readonly OVER = 27;
    static readonly WINDOW = 28;
    static readonly LOOP = 29;
    static readonly USING = 30;
    static readonly CASE = 31;
    static readonly CAST = 32;
    static readonly AND = 33;
    static readonly OR = 34;
    static readonly NOT = 35;
    static readonly IF = 36;
    static readonly IN = 37;
    static readonly BETWEEN = 38;
    static readonly LIKE = 39;
    static readonly IS = 40;
    static readonly NULL_LITERAL = 41;
    static readonly TRUE = 42;
    static readonly FALSE = 43;
    static readonly ASC = 44;
    static readonly DESC = 45;
    static readonly ROWS = 46;
    static readonly RANGE = 47;
    static readonly PARTITION = 48;
    static readonly SORT = 49;
    static readonly SEARCH = 50;
    static readonly DERIVE = 51;
    static readonly REST = 52;
    static readonly ARRAY = 53;
    static readonly SKIPLOCK = 54;
    static readonly NOWAIT = 55;
    static readonly LINK = 56;
    static readonly SOURCE = 57;
    static readonly TARGET = 58;
    static readonly MULTI = 59;
    static readonly CONFLICT = 60;
    static readonly DO = 61;
    static readonly NOTHING = 62;
    static readonly HAS = 63;
    static readonly OF = 64;
    static readonly CURRENT_DATE = 65;
    static readonly CURRENT_TIME = 66;
    static readonly CURRENT_TIMESTAMP = 67;
    static readonly LOCALTIME = 68;
    static readonly LOCALTIMESTAMP = 69;
    static readonly DEFAULT = 70;
    static readonly REQUIRED = 71;
    static readonly DEFINE = 72;
    static readonly IMPORT = 73;
    static readonly EXPOSE = 74;
    static readonly DROP = 75;
    static readonly REPLACE = 76;
    static readonly END = 77;
    static readonly POLICY = 78;
    static readonly CAN = 79;
    static readonly GRANT = 80;
    static readonly PREVENT = 81;
    static readonly ALTER = 82;
    static readonly DELEGATE = 83;
    static readonly DELEGATION = 84;
    static readonly REVOKE = 85;
    static readonly TO = 86;
    static readonly STARTS = 87;
    static readonly UNTIL = 88;
    static readonly SERVICE = 89;
    static readonly TRUSTED = 90;
    static readonly PUBLIC = 91;
    static readonly ELEVATED = 92;
    static readonly ROW_NUMBER = 93;
    static readonly RANK = 94;
    static readonly DENSE_RANK = 95;
    static readonly PERCENT_RANK = 96;
    static readonly CUME_DIST = 97;
    static readonly NTILE = 98;
    static readonly LAG = 99;
    static readonly LEAD = 100;
    static readonly FIRST_VALUE = 101;
    static readonly LAST_VALUE = 102;
    static readonly NTH_VALUE = 103;
    static readonly ASSIGN = 104;
    static readonly CONDITIONAL_ASSIGN = 105;
    static readonly ARROW = 106;
    static readonly SPREAD = 107;
    static readonly EQ = 108;
    static readonly EQUALS = 109;
    static readonly NEQ = 110;
    static readonly BANG = 111;
    static readonly LINK_FWD = 112;
    static readonly LINK_BWD = 113;
    static readonly LT = 114;
    static readonly GT = 115;
    static readonly LTE = 116;
    static readonly GTE = 117;
    static readonly PLUS = 118;
    static readonly MINUS = 119;
    static readonly STAR = 120;
    static readonly SLASH = 121;
    static readonly PERCENT = 122;
    static readonly DOT = 123;
    static readonly HASH = 124;
    static readonly RANGE_OP = 125;
    static readonly CAST_OP = 126;
    static readonly PIPE = 127;
    static readonly COLON = 128;
    static readonly COMMA = 129;
    static readonly SEMICOLON = 130;
    static readonly LPAREN = 131;
    static readonly RPAREN = 132;
    static readonly LBRACKET = 133;
    static readonly RBRACKET = 134;
    static readonly LBRACE = 135;
    static readonly RBRACE = 136;
    static readonly FULLTEXT_MATCH = 137;
    static readonly REGEX_MATCH = 138;
    static readonly REGEX_MATCH_CI = 139;
    static readonly NOT_REGEX_MATCH = 140;
    static readonly NOT_REGEX_MATCH_CI = 141;
    static readonly RANGE_CONTAINS = 142;
    static readonly RANGE_CONTAINED_BY = 143;
    static readonly RANGE_OVERLAPS = 144;
    static readonly RANGE_ADJACENT = 145;
    static readonly RANGE_STRICTLY_LEFT = 146;
    static readonly RANGE_STRICTLY_RIGHT = 147;
    static readonly NULLISH_COALESCE = 148;
    static readonly JSONB_KEY_EXISTS = 149;
    static readonly JSONB_ALL_KEYS_EXIST = 150;
    static readonly JSONB_ANY_KEY_EXISTS = 151;
    static readonly JSONB_PATH = 152;
    static readonly JSONB_PATH_TEXT = 153;
    static readonly INLINE_SQL = 154;
    static readonly BACKTICK = 155;
    static readonly LINK_LOOKUP_STRICT = 156;
    static readonly LINK_LOOKUP_NULLABLE = 157;
    static readonly LOOKUP_STRICT = 158;
    static readonly LOOKUP_NULLABLE = 159;
    static readonly CONST_REF = 160;
    static readonly COLUMN_REF = 161;
    static readonly PARAM_REF = 162;
    static readonly DYNAMIC_TABLE_REF = 163;
    static readonly CHOICES_REF = 164;
    static readonly CHOICE_REF = 165;
    static readonly CTE_REF = 166;
    static readonly ANNOTATION = 167;
    static readonly IDENTIFIER = 168;
    static readonly QUOTED_IDENTIFIER = 169;
    static readonly INTEGER = 170;
    static readonly DECIMAL = 171;
    static readonly STRING = 172;
    static readonly WS = 173;
    static readonly LINE_COMMENT = 174;
    static readonly BLOCK_COMMENT = 175;
    static readonly RULE_query = 0;
    static readonly RULE_dqlStatement = 1;
    static readonly RULE_bareQuery = 2;
    static readonly RULE_dmlStatement = 3;
    static readonly RULE_tclStatement = 4;
    static readonly RULE_ddlStatement = 5;
    static readonly RULE_dclStatement = 6;
    static readonly RULE_grantStatement = 7;
    static readonly RULE_modelTarget = 8;
    static readonly RULE_decisionOperation = 9;
    static readonly RULE_policyStatement = 10;
    static readonly RULE_policyKey = 11;
    static readonly RULE_alterPolicyStatement = 12;
    static readonly RULE_dropPolicyStatement = 13;
    static readonly RULE_policyRef = 14;
    static readonly RULE_roleClause = 15;
    static readonly RULE_qualifiedName = 16;
    static readonly RULE_delegateStatement = 17;
    static readonly RULE_delegableTarget = 18;
    static readonly RULE_revokeDelegationStatement = 19;
    static readonly RULE_periodClause = 20;
    static readonly RULE_userRef = 21;
    static readonly RULE_delegationRef = 22;
    static readonly RULE_statement = 23;
    static readonly RULE_defineStatement = 24;
    static readonly RULE_constDefineStatement = 25;
    static readonly RULE_importStatement = 26;
    static readonly RULE_definitionOption = 27;
    static readonly RULE_definitionBody = 28;
    static readonly RULE_definitionBodyStatement = 29;
    static readonly RULE_exposeStatement = 30;
    static readonly RULE_dropStatement = 31;
    static readonly RULE_namedQueryRef = 32;
    static readonly RULE_exposureLevel = 33;
    static readonly RULE_queryStatement = 34;
    static readonly RULE_cteDefinition = 35;
    static readonly RULE_cteBody = 36;
    static readonly RULE_queryBody = 37;
    static readonly RULE_insertStatement = 38;
    static readonly RULE_eachSource = 39;
    static readonly RULE_updateStatement = 40;
    static readonly RULE_upsertStatement = 41;
    static readonly RULE_deleteStatement = 42;
    static readonly RULE_guardClause = 43;
    static readonly RULE_transactionBlock = 44;
    static readonly RULE_transactionBodyStatement = 45;
    static readonly RULE_transactionErrorHandler = 46;
    static readonly RULE_tableName = 47;
    static readonly RULE_mutationObject = 48;
    static readonly RULE_mutationField = 49;
    static readonly RULE_mutationAssign = 50;
    static readonly RULE_mutationValue = 51;
    static readonly RULE_mutationArray = 52;
    static readonly RULE_mutationArrayItem = 53;
    static readonly RULE_nestedInsert = 54;
    static readonly RULE_linkLookup = 55;
    static readonly RULE_linkLookupTarget = 56;
    static readonly RULE_linkLookupOp = 57;
    static readonly RULE_linkMessage = 58;
    static readonly RULE_linkUpdate = 59;
    static readonly RULE_choiceRef = 60;
    static readonly RULE_choiceKeyArg = 61;
    static readonly RULE_onConflictClause = 62;
    static readonly RULE_returningClause = 63;
    static readonly RULE_returningSpec = 64;
    static readonly RULE_selectQuery = 65;
    static readonly RULE_asOfClause = 66;
    static readonly RULE_selectLockClause = 67;
    static readonly RULE_linkDefinition = 68;
    static readonly RULE_linkArg = 69;
    static readonly RULE_linkArgKey = 70;
    static readonly RULE_linkArgValue = 71;
    static readonly RULE_summarizeQuery = 72;
    static readonly RULE_tableRef = 73;
    static readonly RULE_nqInvocationArgs = 74;
    static readonly RULE_nqInvocationArg = 75;
    static readonly RULE_setOperation = 76;
    static readonly RULE_alias = 77;
    static readonly RULE_projection = 78;
    static readonly RULE_annotation = 79;
    static readonly RULE_annotationArgs = 80;
    static readonly RULE_annotationArg = 81;
    static readonly RULE_annotationArgValue = 82;
    static readonly RULE_arrayAggSort = 83;
    static readonly RULE_aliasAssignment = 84;
    static readonly RULE_nestedSubquery = 85;
    static readonly RULE_linkRef = 86;
    static readonly RULE_leadingLinkOperator = 87;
    static readonly RULE_groupByClause = 88;
    static readonly RULE_deriveClause = 89;
    static readonly RULE_derivation = 90;
    static readonly RULE_aggregation = 91;
    static readonly RULE_distinctModifier = 92;
    static readonly RULE_aggregateFunction = 93;
    static readonly RULE_filterSuffix = 94;
    static readonly RULE_overClause = 95;
    static readonly RULE_windowDefinition = 96;
    static readonly RULE_windowSpec = 97;
    static readonly RULE_windowPart = 98;
    static readonly RULE_windowCallArgs = 99;
    static readonly RULE_frameClause = 100;
    static readonly RULE_frameSpec = 101;
    static readonly RULE_frameStart = 102;
    static readonly RULE_frameEnd = 103;
    static readonly RULE_signedInteger = 104;
    static readonly RULE_sortItem = 105;
    static readonly RULE_windowRef = 106;
    static readonly RULE_windowFunction = 107;
    static readonly RULE_windowCall = 108;
    static readonly RULE_filterClause = 109;
    static readonly RULE_sortClause = 110;
    static readonly RULE_takeClause = 111;
    static readonly RULE_takeValue = 112;
    static readonly RULE_rankQuery = 113;
    static readonly RULE_loopQuery = 114;
    static readonly RULE_expression = 115;
    static readonly RULE_orExpression = 116;
    static readonly RULE_andExpression = 117;
    static readonly RULE_nullishExpression = 118;
    static readonly RULE_notExpression = 119;
    static readonly RULE_comparisonExpression = 120;
    static readonly RULE_tableSearchExpr = 121;
    static readonly RULE_comparisonTail = 122;
    static readonly RULE_negatableTail = 123;
    static readonly RULE_inRhs = 124;
    static readonly RULE_jsonbPathExpr = 125;
    static readonly RULE_inExpressionList = 126;
    static readonly RULE_likeRhs = 127;
    static readonly RULE_rangeOpRhs = 128;
    static readonly RULE_rangeOp = 129;
    static readonly RULE_comparisonOperator = 130;
    static readonly RULE_additiveExpression = 131;
    static readonly RULE_multiplicativeExpression = 132;
    static readonly RULE_columnRef = 133;
    static readonly RULE_annotatedColumnRef = 134;
    static readonly RULE_columnAccessor = 135;
    static readonly RULE_datePartAccess = 136;
    static readonly RULE_linkNavigation = 137;
    static readonly RULE_postfixAccess = 138;
    static readonly RULE_identifierName = 139;
    static readonly RULE_parameterRef = 140;
    static readonly RULE_parameterMeta = 141;
    static readonly RULE_parameterMetaEntry = 142;
    static readonly RULE_parameterDefaultValue = 143;
    static readonly RULE_parameterTypeName = 144;
    static readonly RULE_linkOperator = 145;
    static readonly RULE_linkExpression = 146;
    static readonly RULE_rangeBound = 147;
    static readonly RULE_leftBound = 148;
    static readonly RULE_rightBound = 149;
    static readonly RULE_functionCall = 150;
    static readonly RULE_nonReservedFunctionName = 151;
    static readonly RULE_niladicTemporalFunction = 152;
    static readonly RULE_expressionOrStar = 153;
    static readonly RULE_expressionList = 154;
    static readonly RULE_caseExpression = 155;
    static readonly RULE_caseArgs = 156;
    static readonly RULE_inlineSql = 157;
    static readonly RULE_castExpression = 158;
    static readonly RULE_policyExpansion = 159;
    static readonly RULE_capabilityCheck = 160;
    static readonly RULE_unaryExpression = 161;
    static readonly RULE_postfixExpression = 162;
    static readonly RULE_typeName = 163;
    static readonly RULE_typeParams = 164;
    static readonly RULE_primaryExpression = 165;
    static readonly RULE_arrayLiteral = 166;
    static readonly RULE_literal = 167;
    static readonly literalNames: (string | null)[];
    static readonly symbolicNames: (string | null)[];
    static readonly ruleNames: string[];
    get grammarFileName(): string;
    get literalNames(): (string | null)[];
    get symbolicNames(): (string | null)[];
    get ruleNames(): string[];
    get serializedATN(): number[];
    protected createFailedPredicateException(predicate?: string, message?: string): antlr.FailedPredicateException;
    constructor(input: antlr.TokenStream);
    query(): QueryContext;
    dqlStatement(): DqlStatementContext;
    bareQuery(): BareQueryContext;
    dmlStatement(): DmlStatementContext;
    tclStatement(): TclStatementContext;
    ddlStatement(): DdlStatementContext;
    dclStatement(): DclStatementContext;
    grantStatement(): GrantStatementContext;
    modelTarget(): ModelTargetContext;
    decisionOperation(): DecisionOperationContext;
    policyStatement(): PolicyStatementContext;
    policyKey(): PolicyKeyContext;
    alterPolicyStatement(): AlterPolicyStatementContext;
    dropPolicyStatement(): DropPolicyStatementContext;
    policyRef(): PolicyRefContext;
    roleClause(): RoleClauseContext;
    qualifiedName(): QualifiedNameContext;
    delegateStatement(): DelegateStatementContext;
    delegableTarget(): DelegableTargetContext;
    revokeDelegationStatement(): RevokeDelegationStatementContext;
    periodClause(): PeriodClauseContext;
    userRef(): UserRefContext;
    delegationRef(): DelegationRefContext;
    statement(): StatementContext;
    defineStatement(): DefineStatementContext;
    constDefineStatement(): ConstDefineStatementContext;
    importStatement(): ImportStatementContext;
    definitionOption(): DefinitionOptionContext;
    definitionBody(): DefinitionBodyContext;
    definitionBodyStatement(): DefinitionBodyStatementContext;
    exposeStatement(): ExposeStatementContext;
    dropStatement(): DropStatementContext;
    namedQueryRef(): NamedQueryRefContext;
    exposureLevel(): ExposureLevelContext;
    queryStatement(): QueryStatementContext;
    cteDefinition(): CteDefinitionContext;
    cteBody(): CteBodyContext;
    queryBody(): QueryBodyContext;
    insertStatement(): InsertStatementContext;
    eachSource(): EachSourceContext;
    updateStatement(): UpdateStatementContext;
    upsertStatement(): UpsertStatementContext;
    deleteStatement(): DeleteStatementContext;
    guardClause(): GuardClauseContext;
    transactionBlock(): TransactionBlockContext;
    transactionBodyStatement(): TransactionBodyStatementContext;
    transactionErrorHandler(): TransactionErrorHandlerContext;
    tableName(): TableNameContext;
    mutationObject(): MutationObjectContext;
    mutationField(): MutationFieldContext;
    mutationAssign(): MutationAssignContext;
    mutationValue(): MutationValueContext;
    mutationArray(): MutationArrayContext;
    mutationArrayItem(): MutationArrayItemContext;
    nestedInsert(): NestedInsertContext;
    linkLookup(): LinkLookupContext;
    linkLookupTarget(): LinkLookupTargetContext;
    linkLookupOp(): LinkLookupOpContext;
    linkMessage(): LinkMessageContext;
    linkUpdate(): LinkUpdateContext;
    choiceRef(): ChoiceRefContext;
    choiceKeyArg(): ChoiceKeyArgContext;
    onConflictClause(): OnConflictClauseContext;
    returningClause(): ReturningClauseContext;
    returningSpec(): ReturningSpecContext;
    selectQuery(): SelectQueryContext;
    asOfClause(): AsOfClauseContext;
    selectLockClause(): SelectLockClauseContext;
    linkDefinition(): LinkDefinitionContext;
    linkArg(): LinkArgContext;
    linkArgKey(): LinkArgKeyContext;
    linkArgValue(): LinkArgValueContext;
    summarizeQuery(): SummarizeQueryContext;
    tableRef(): TableRefContext;
    nqInvocationArgs(): NqInvocationArgsContext;
    nqInvocationArg(): NqInvocationArgContext;
    setOperation(): SetOperationContext;
    alias(): AliasContext;
    projection(): ProjectionContext;
    annotation(): AnnotationContext;
    annotationArgs(): AnnotationArgsContext;
    annotationArg(): AnnotationArgContext;
    annotationArgValue(): AnnotationArgValueContext;
    arrayAggSort(): ArrayAggSortContext;
    aliasAssignment(): AliasAssignmentContext;
    nestedSubquery(): NestedSubqueryContext;
    linkRef(): LinkRefContext;
    leadingLinkOperator(): LeadingLinkOperatorContext;
    groupByClause(): GroupByClauseContext;
    deriveClause(): DeriveClauseContext;
    derivation(): DerivationContext;
    aggregation(): AggregationContext;
    distinctModifier(): DistinctModifierContext;
    aggregateFunction(): AggregateFunctionContext;
    filterSuffix(): FilterSuffixContext;
    overClause(): OverClauseContext;
    windowDefinition(): WindowDefinitionContext;
    windowSpec(): WindowSpecContext;
    windowPart(): WindowPartContext;
    windowCallArgs(): WindowCallArgsContext;
    frameClause(): FrameClauseContext;
    frameSpec(): FrameSpecContext;
    frameStart(): FrameStartContext;
    frameEnd(): FrameEndContext;
    signedInteger(): SignedIntegerContext;
    sortItem(): SortItemContext;
    windowRef(): WindowRefContext;
    windowFunction(): WindowFunctionContext;
    windowCall(): WindowCallContext;
    filterClause(): FilterClauseContext;
    sortClause(): SortClauseContext;
    takeClause(): TakeClauseContext;
    takeValue(): TakeValueContext;
    rankQuery(): RankQueryContext;
    loopQuery(): LoopQueryContext;
    expression(): ExpressionContext;
    orExpression(): OrExpressionContext;
    andExpression(): AndExpressionContext;
    nullishExpression(): NullishExpressionContext;
    notExpression(): NotExpressionContext;
    comparisonExpression(): ComparisonExpressionContext;
    tableSearchExpr(): TableSearchExprContext;
    comparisonTail(): ComparisonTailContext;
    negatableTail(): NegatableTailContext;
    inRhs(): InRhsContext;
    jsonbPathExpr(): JsonbPathExprContext;
    inExpressionList(): InExpressionListContext;
    likeRhs(): LikeRhsContext;
    rangeOpRhs(): RangeOpRhsContext;
    rangeOp(): RangeOpContext;
    comparisonOperator(): ComparisonOperatorContext;
    additiveExpression(): AdditiveExpressionContext;
    multiplicativeExpression(): MultiplicativeExpressionContext;
    columnRef(): ColumnRefContext;
    annotatedColumnRef(): AnnotatedColumnRefContext;
    columnAccessor(): ColumnAccessorContext;
    datePartAccess(): DatePartAccessContext;
    linkNavigation(): LinkNavigationContext;
    postfixAccess(): PostfixAccessContext;
    identifierName(): IdentifierNameContext;
    parameterRef(): ParameterRefContext;
    parameterMeta(): ParameterMetaContext;
    parameterMetaEntry(): ParameterMetaEntryContext;
    parameterDefaultValue(): ParameterDefaultValueContext;
    parameterTypeName(): ParameterTypeNameContext;
    linkOperator(): LinkOperatorContext;
    linkExpression(): LinkExpressionContext;
    rangeBound(): RangeBoundContext;
    leftBound(): LeftBoundContext;
    rightBound(): RightBoundContext;
    functionCall(): FunctionCallContext;
    nonReservedFunctionName(): NonReservedFunctionNameContext;
    niladicTemporalFunction(): NiladicTemporalFunctionContext;
    expressionOrStar(): ExpressionOrStarContext;
    expressionList(): ExpressionListContext;
    caseExpression(): CaseExpressionContext;
    caseArgs(): CaseArgsContext;
    inlineSql(): InlineSqlContext;
    castExpression(): CastExpressionContext;
    policyExpansion(): PolicyExpansionContext;
    capabilityCheck(): CapabilityCheckContext;
    unaryExpression(): UnaryExpressionContext;
    postfixExpression(): PostfixExpressionContext;
    typeName(): TypeNameContext;
    typeParams(): TypeParamsContext;
    primaryExpression(): PrimaryExpressionContext;
    arrayLiteral(): ArrayLiteralContext;
    literal(): LiteralContext;
    static readonly _serializedATN: number[];
    private static __ATN;
    static get _ATN(): antlr.ATN;
    private static readonly vocabulary;
    get vocabulary(): antlr.Vocabulary;
    private static readonly decisionsToDFA;
}
export declare class QueryContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    statement(): StatementContext[];
    statement(i: number): StatementContext | null;
    EOF(): antlr.TerminalNode;
    SEMICOLON(): antlr.TerminalNode[];
    SEMICOLON(i: number): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class DqlStatementContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    queryStatement(): QueryStatementContext;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class BareQueryContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    selectQuery(): SelectQueryContext | null;
    summarizeQuery(): SummarizeQueryContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class DmlStatementContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    insertStatement(): InsertStatementContext | null;
    updateStatement(): UpdateStatementContext | null;
    upsertStatement(): UpsertStatementContext | null;
    deleteStatement(): DeleteStatementContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class TclStatementContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    transactionBlock(): TransactionBlockContext;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class DdlStatementContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    constDefineStatement(): ConstDefineStatementContext | null;
    importStatement(): ImportStatementContext | null;
    defineStatement(): DefineStatementContext | null;
    exposeStatement(): ExposeStatementContext | null;
    dropStatement(): DropStatementContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class DclStatementContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    grantStatement(): GrantStatementContext | null;
    policyStatement(): PolicyStatementContext | null;
    alterPolicyStatement(): AlterPolicyStatementContext | null;
    dropPolicyStatement(): DropPolicyStatementContext | null;
    delegateStatement(): DelegateStatementContext | null;
    revokeDelegationStatement(): RevokeDelegationStatementContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class GrantStatementContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    modelTarget(): ModelTargetContext;
    roleClause(): RoleClauseContext;
    GRANT(): antlr.TerminalNode | null;
    PREVENT(): antlr.TerminalNode | null;
    mutationObject(): MutationObjectContext | null;
    filterClause(): FilterClauseContext | null;
    returningClause(): ReturningClauseContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class ModelTargetContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    decisionOperation(): DecisionOperationContext | null;
    ON(): antlr.TerminalNode;
    qualifiedName(): QualifiedNameContext;
    identifierName(): IdentifierNameContext[];
    identifierName(i: number): IdentifierNameContext | null;
    ARROW(): antlr.TerminalNode | null;
    IDENTIFIER(): antlr.TerminalNode | null;
    COLON(): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class DecisionOperationContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    IDENTIFIER(): antlr.TerminalNode | null;
    INSERT(): antlr.TerminalNode | null;
    UPDATE(): antlr.TerminalNode | null;
    DELETE(): antlr.TerminalNode | null;
    FILTER(): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class PolicyStatementContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    POLICY(): antlr.TerminalNode;
    policyKey(): PolicyKeyContext;
    roleClause(): RoleClauseContext | null;
    mutationObject(): MutationObjectContext | null;
    filterClause(): FilterClauseContext | null;
    returningClause(): ReturningClauseContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class PolicyKeyContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    STRING(): antlr.TerminalNode | null;
    IDENTIFIER(): antlr.TerminalNode | null;
    COLON(): antlr.TerminalNode | null;
    identifierName(): IdentifierNameContext | null;
    ON(): antlr.TerminalNode | null;
    qualifiedName(): QualifiedNameContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class AlterPolicyStatementContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    ALTER(): antlr.TerminalNode;
    POLICY(): antlr.TerminalNode;
    policyRef(): PolicyRefContext;
    mutationObject(): MutationObjectContext | null;
    filterClause(): FilterClauseContext | null;
    returningClause(): ReturningClauseContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class DropPolicyStatementContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    DROP(): antlr.TerminalNode;
    POLICY(): antlr.TerminalNode;
    policyRef(): PolicyRefContext;
    returningClause(): ReturningClauseContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class PolicyRefContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    STRING(): antlr.TerminalNode | null;
    parameterRef(): ParameterRefContext | null;
    guardClause(): GuardClauseContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class RoleClauseContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    TO(): antlr.TerminalNode;
    identifierName(): IdentifierNameContext | null;
    parameterRef(): ParameterRefContext | null;
    ALL(): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class QualifiedNameContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    identifierName(): IdentifierNameContext[];
    identifierName(i: number): IdentifierNameContext | null;
    DOT(): antlr.TerminalNode[];
    DOT(i: number): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class DelegateStatementContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    DELEGATE(): antlr.TerminalNode;
    delegableTarget(): DelegableTargetContext;
    TO(): antlr.TerminalNode;
    userRef(): UserRefContext[];
    userRef(i: number): UserRefContext | null;
    periodClause(): PeriodClauseContext;
    BY(): antlr.TerminalNode | null;
    returningClause(): ReturningClauseContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class DelegableTargetContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    modelTarget(): ModelTargetContext | null;
    STRING(): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class RevokeDelegationStatementContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    REVOKE(): antlr.TerminalNode;
    DELEGATION(): antlr.TerminalNode;
    delegationRef(): DelegationRefContext;
    returningClause(): ReturningClauseContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class PeriodClauseContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    UNTIL(): antlr.TerminalNode;
    expression(): ExpressionContext[];
    expression(i: number): ExpressionContext | null;
    STARTS(): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class UserRefContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    parameterRef(): ParameterRefContext | null;
    STRING(): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class DelegationRefContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    parameterRef(): ParameterRefContext | null;
    STRING(): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class StatementContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    ddlStatement(): DdlStatementContext | null;
    dclStatement(): DclStatementContext | null;
    dqlStatement(): DqlStatementContext | null;
    dmlStatement(): DmlStatementContext | null;
    tclStatement(): TclStatementContext | null;
    cteDefinition(): CteDefinitionContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class DefineStatementContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    DEFINE(): antlr.TerminalNode;
    namedQueryRef(): NamedQueryRefContext;
    AS(): antlr.TerminalNode;
    definitionBody(): DefinitionBodyContext;
    END(): antlr.TerminalNode;
    OR(): antlr.TerminalNode | null;
    REPLACE(): antlr.TerminalNode | null;
    ELEVATED(): antlr.TerminalNode | null;
    exposureLevel(): ExposureLevelContext | null;
    definitionOption(): DefinitionOptionContext[];
    definitionOption(i: number): DefinitionOptionContext | null;
    COMMA(): antlr.TerminalNode[];
    COMMA(i: number): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class ConstDefineStatementContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    DEFINE(): antlr.TerminalNode;
    identifierName(): IdentifierNameContext;
    EQUALS(): antlr.TerminalNode;
    literal(): LiteralContext;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class ImportStatementContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    IMPORT(): antlr.TerminalNode;
    STRING(): antlr.TerminalNode;
    AS(): antlr.TerminalNode | null;
    identifierName(): IdentifierNameContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class DefinitionOptionContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    IDENTIFIER(): antlr.TerminalNode;
    COLON(): antlr.TerminalNode;
    STRING(): antlr.TerminalNode;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class DefinitionBodyContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    definitionBodyStatement(): DefinitionBodyStatementContext[];
    definitionBodyStatement(i: number): DefinitionBodyStatementContext | null;
    SEMICOLON(): antlr.TerminalNode[];
    SEMICOLON(i: number): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class DefinitionBodyStatementContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    dqlStatement(): DqlStatementContext | null;
    dmlStatement(): DmlStatementContext | null;
    tclStatement(): TclStatementContext | null;
    cteDefinition(): CteDefinitionContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class ExposeStatementContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    EXPOSE(): antlr.TerminalNode;
    namedQueryRef(): NamedQueryRefContext;
    AS(): antlr.TerminalNode;
    exposureLevel(): ExposureLevelContext;
    ELEVATED(): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class DropStatementContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    DROP(): antlr.TerminalNode;
    namedQueryRef(): NamedQueryRefContext;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class NamedQueryRefContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    identifierName(): IdentifierNameContext[];
    identifierName(i: number): IdentifierNameContext | null;
    DOT(): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class ExposureLevelContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    SERVICE(): antlr.TerminalNode | null;
    TRUSTED(): antlr.TerminalNode | null;
    PUBLIC(): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class QueryStatementContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    queryBody(): QueryBodyContext[];
    queryBody(i: number): QueryBodyContext | null;
    windowDefinition(): WindowDefinitionContext[];
    windowDefinition(i: number): WindowDefinitionContext | null;
    cteDefinition(): CteDefinitionContext[];
    cteDefinition(i: number): CteDefinitionContext | null;
    setOperation(): SetOperationContext[];
    setOperation(i: number): SetOperationContext | null;
    COMMA(): antlr.TerminalNode[];
    COMMA(i: number): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class CteDefinitionContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    CTE_REF(): antlr.TerminalNode;
    ASSIGN(): antlr.TerminalNode;
    cteBody(): CteBodyContext;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class CteBodyContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    bareQuery(): BareQueryContext | null;
    dmlStatement(): DmlStatementContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class QueryBodyContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    selectQuery(): SelectQueryContext | null;
    summarizeQuery(): SummarizeQueryContext | null;
    rankQuery(): RankQueryContext | null;
    loopQuery(): LoopQueryContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class InsertStatementContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    INSERT(): antlr.TerminalNode;
    tableName(): TableNameContext;
    mutationObject(): MutationObjectContext;
    onConflictClause(): OnConflictClauseContext | null;
    returningClause(): ReturningClauseContext | null;
    EACH(): antlr.TerminalNode | null;
    eachSource(): EachSourceContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class EachSourceContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    parameterRef(): ParameterRefContext | null;
    LPAREN(): antlr.TerminalNode | null;
    selectQuery(): SelectQueryContext | null;
    RPAREN(): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class UpdateStatementContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    UPDATE(): antlr.TerminalNode;
    tableName(): TableNameContext;
    guardClause(): GuardClauseContext;
    mutationObject(): MutationObjectContext;
    REQUIRED(): antlr.TerminalNode | null;
    HARD(): antlr.TerminalNode | null;
    returningClause(): ReturningClauseContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class UpsertStatementContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    UPSERT(): antlr.TerminalNode;
    tableName(): TableNameContext;
    guardClause(): GuardClauseContext;
    mutationObject(): MutationObjectContext;
    HARD(): antlr.TerminalNode | null;
    returningClause(): ReturningClauseContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class DeleteStatementContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    DELETE(): antlr.TerminalNode;
    tableName(): TableNameContext;
    guardClause(): GuardClauseContext;
    REQUIRED(): antlr.TerminalNode | null;
    HARD(): antlr.TerminalNode | null;
    returningClause(): ReturningClauseContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class GuardClauseContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    LBRACKET(): antlr.TerminalNode;
    expression(): ExpressionContext;
    RBRACKET(): antlr.TerminalNode;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class TransactionBlockContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    BEGIN(): antlr.TerminalNode;
    SEMICOLON(): antlr.TerminalNode[];
    SEMICOLON(i: number): antlr.TerminalNode | null;
    COMMIT(): antlr.TerminalNode | null;
    ROLLBACK(): antlr.TerminalNode | null;
    transactionErrorHandler(): TransactionErrorHandlerContext | null;
    transactionBodyStatement(): TransactionBodyStatementContext[];
    transactionBodyStatement(i: number): TransactionBodyStatementContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class TransactionBodyStatementContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    dclStatement(): DclStatementContext | null;
    dqlStatement(): DqlStatementContext | null;
    dmlStatement(): DmlStatementContext | null;
    tclStatement(): TclStatementContext | null;
    cteDefinition(): CteDefinitionContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class TransactionErrorHandlerContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    ON(): antlr.TerminalNode;
    ERROR(): antlr.TerminalNode;
    ROLLBACK(): antlr.TerminalNode;
    expression(): ExpressionContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class TableNameContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    identifierName(): IdentifierNameContext[];
    identifierName(i: number): IdentifierNameContext | null;
    DOT(): antlr.TerminalNode | null;
    DYNAMIC_TABLE_REF(): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class MutationObjectContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    LBRACE(): antlr.TerminalNode;
    mutationField(): MutationFieldContext[];
    mutationField(i: number): MutationFieldContext | null;
    RBRACE(): antlr.TerminalNode;
    COMMA(): antlr.TerminalNode[];
    COMMA(i: number): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class MutationFieldContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    identifierName(): IdentifierNameContext | null;
    mutationAssign(): MutationAssignContext | null;
    mutationValue(): MutationValueContext | null;
    SPREAD(): antlr.TerminalNode | null;
    parameterRef(): ParameterRefContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class MutationAssignContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    ASSIGN(): antlr.TerminalNode | null;
    COLON(): antlr.TerminalNode | null;
    CONDITIONAL_ASSIGN(): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class MutationValueContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    linkLookup(): LinkLookupContext | null;
    linkUpdate(): LinkUpdateContext | null;
    choiceRef(): ChoiceRefContext | null;
    mutationArray(): MutationArrayContext | null;
    expression(): ExpressionContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class MutationArrayContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    LBRACKET(): antlr.TerminalNode;
    mutationArrayItem(): MutationArrayItemContext[];
    mutationArrayItem(i: number): MutationArrayItemContext | null;
    RBRACKET(): antlr.TerminalNode;
    COMMA(): antlr.TerminalNode[];
    COMMA(i: number): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class MutationArrayItemContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    nestedInsert(): NestedInsertContext | null;
    expression(): ExpressionContext | null;
    linkLookup(): LinkLookupContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class NestedInsertContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    INSERT(): antlr.TerminalNode;
    mutationObject(): MutationObjectContext;
    returningClause(): ReturningClauseContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class LinkLookupContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    linkLookupOp(): LinkLookupOpContext;
    linkLookupTarget(): LinkLookupTargetContext;
    LPAREN(): antlr.TerminalNode;
    expression(): ExpressionContext;
    RPAREN(): antlr.TerminalNode;
    linkMessage(): LinkMessageContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class LinkLookupTargetContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    tableName(): TableNameContext | null;
    COLUMN_REF(): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class LinkLookupOpContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    LINK_LOOKUP_STRICT(): antlr.TerminalNode | null;
    LINK_LOOKUP_NULLABLE(): antlr.TerminalNode | null;
    LOOKUP_STRICT(): antlr.TerminalNode | null;
    LOOKUP_NULLABLE(): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class LinkMessageContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    LPAREN(): antlr.TerminalNode;
    expression(): ExpressionContext;
    RPAREN(): antlr.TerminalNode;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class LinkUpdateContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    UPDATE(): antlr.TerminalNode;
    mutationObject(): MutationObjectContext;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class ChoiceRefContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    LPAREN(): antlr.TerminalNode;
    choiceKeyArg(): ChoiceKeyArgContext[];
    choiceKeyArg(i: number): ChoiceKeyArgContext | null;
    RPAREN(): antlr.TerminalNode;
    CHOICE_REF(): antlr.TerminalNode | null;
    CHOICES_REF(): antlr.TerminalNode | null;
    COMMA(): antlr.TerminalNode[];
    COMMA(i: number): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class ChoiceKeyArgContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    identifierName(): IdentifierNameContext[];
    identifierName(i: number): IdentifierNameContext | null;
    DOT(): antlr.TerminalNode | null;
    parameterRef(): ParameterRefContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class OnConflictClauseContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    ON(): antlr.TerminalNode;
    CONFLICT(): antlr.TerminalNode;
    LPAREN(): antlr.TerminalNode;
    identifierName(): IdentifierNameContext[];
    identifierName(i: number): IdentifierNameContext | null;
    RPAREN(): antlr.TerminalNode;
    DO(): antlr.TerminalNode;
    UPDATE(): antlr.TerminalNode | null;
    mutationObject(): MutationObjectContext | null;
    COMMA(): antlr.TerminalNode[];
    COMMA(i: number): antlr.TerminalNode | null;
    NOTHING(): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class ReturningClauseContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    ARROW(): antlr.TerminalNode;
    returningSpec(): ReturningSpecContext;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class ReturningSpecContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    expression(): ExpressionContext[];
    expression(i: number): ExpressionContext | null;
    LBRACE(): antlr.TerminalNode | null;
    RBRACE(): antlr.TerminalNode | null;
    COMMA(): antlr.TerminalNode[];
    COMMA(i: number): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class SelectQueryContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    SELECT(): antlr.TerminalNode;
    tableRef(): TableRefContext;
    LBRACE(): antlr.TerminalNode;
    projection(): ProjectionContext[];
    projection(i: number): ProjectionContext | null;
    RBRACE(): antlr.TerminalNode;
    REQUIRED(): antlr.TerminalNode | null;
    selectLockClause(): SelectLockClauseContext | null;
    HARD(): antlr.TerminalNode | null;
    DISTINCT(): antlr.TerminalNode | null;
    asOfClause(): AsOfClauseContext | null;
    linkDefinition(): LinkDefinitionContext[];
    linkDefinition(i: number): LinkDefinitionContext | null;
    COMMA(): antlr.TerminalNode[];
    COMMA(i: number): antlr.TerminalNode | null;
    filterClause(): FilterClauseContext | null;
    sortClause(): SortClauseContext | null;
    takeClause(): TakeClauseContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class AsOfClauseContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    AS(): antlr.TerminalNode;
    OF(): antlr.TerminalNode;
    expression(): ExpressionContext;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class SelectLockClauseContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    UPDATE(): antlr.TerminalNode;
    SKIPLOCK(): antlr.TerminalNode | null;
    NOWAIT(): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class LinkDefinitionContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    LINK(): antlr.TerminalNode;
    identifierName(): IdentifierNameContext;
    LPAREN(): antlr.TerminalNode;
    RPAREN(): antlr.TerminalNode;
    linkArg(): LinkArgContext[];
    linkArg(i: number): LinkArgContext | null;
    MULTI(): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class LinkArgContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    linkArgKey(): LinkArgKeyContext;
    linkArgValue(): LinkArgValueContext;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class LinkArgKeyContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    SOURCE(): antlr.TerminalNode | null;
    TARGET(): antlr.TerminalNode | null;
    ON(): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class LinkArgValueContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    identifierName(): IdentifierNameContext[];
    identifierName(i: number): IdentifierNameContext | null;
    DOT(): antlr.TerminalNode | null;
    nqInvocationArgs(): NqInvocationArgsContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class SummarizeQueryContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    SUMMARIZE(): antlr.TerminalNode;
    tableRef(): TableRefContext;
    LBRACE(): antlr.TerminalNode;
    aggregation(): AggregationContext[];
    aggregation(i: number): AggregationContext | null;
    RBRACE(): antlr.TerminalNode;
    HARD(): antlr.TerminalNode | null;
    asOfClause(): AsOfClauseContext | null;
    linkDefinition(): LinkDefinitionContext[];
    linkDefinition(i: number): LinkDefinitionContext | null;
    COMMA(): antlr.TerminalNode[];
    COMMA(i: number): antlr.TerminalNode | null;
    groupByClause(): GroupByClauseContext | null;
    deriveClause(): DeriveClauseContext | null;
    filterClause(): FilterClauseContext | null;
    sortClause(): SortClauseContext | null;
    takeClause(): TakeClauseContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class TableRefContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    CTE_REF(): antlr.TerminalNode | null;
    DYNAMIC_TABLE_REF(): antlr.TerminalNode | null;
    alias(): AliasContext | null;
    ASSIGN(): antlr.TerminalNode | null;
    identifierName(): IdentifierNameContext[];
    identifierName(i: number): IdentifierNameContext | null;
    DOT(): antlr.TerminalNode | null;
    nqInvocationArgs(): NqInvocationArgsContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class NqInvocationArgsContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    LPAREN(): antlr.TerminalNode;
    nqInvocationArg(): NqInvocationArgContext[];
    nqInvocationArg(i: number): NqInvocationArgContext | null;
    RPAREN(): antlr.TerminalNode;
    COMMA(): antlr.TerminalNode[];
    COMMA(i: number): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class NqInvocationArgContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    identifierName(): IdentifierNameContext;
    COLON(): antlr.TerminalNode;
    expression(): ExpressionContext;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class SetOperationContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    UNION(): antlr.TerminalNode | null;
    ALL(): antlr.TerminalNode | null;
    INTERSECT(): antlr.TerminalNode | null;
    EXCEPT(): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class AliasContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    identifierName(): IdentifierNameContext;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class ProjectionContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    STAR(): antlr.TerminalNode | null;
    nestedSubquery(): NestedSubqueryContext | null;
    expression(): ExpressionContext | null;
    aliasAssignment(): AliasAssignmentContext | null;
    annotation(): AnnotationContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class AnnotationContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    ANNOTATION(): antlr.TerminalNode;
    annotationArgs(): AnnotationArgsContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class AnnotationArgsContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    LPAREN(): antlr.TerminalNode;
    annotationArg(): AnnotationArgContext[];
    annotationArg(i: number): AnnotationArgContext | null;
    RPAREN(): antlr.TerminalNode;
    COMMA(): antlr.TerminalNode[];
    COMMA(i: number): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class AnnotationArgContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    IDENTIFIER(): antlr.TerminalNode;
    COLON(): antlr.TerminalNode;
    annotationArgValue(): AnnotationArgValueContext;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class AnnotationArgValueContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    INTEGER(): antlr.TerminalNode | null;
    TRUE(): antlr.TerminalNode | null;
    FALSE(): antlr.TerminalNode | null;
    IDENTIFIER(): antlr.TerminalNode | null;
    STAR(): antlr.TerminalNode | null;
    HASH(): antlr.TerminalNode | null;
    MINUS(): antlr.TerminalNode | null;
    PLUS(): antlr.TerminalNode | null;
    DOT(): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class ArrayAggSortContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    SORT(): antlr.TerminalNode;
    sortItem(): SortItemContext[];
    sortItem(i: number): SortItemContext | null;
    COMMA(): antlr.TerminalNode[];
    COMMA(i: number): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class AliasAssignmentContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    alias(): AliasContext;
    ASSIGN(): antlr.TerminalNode;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class NestedSubqueryContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    LPAREN(): antlr.TerminalNode;
    SELECT(): antlr.TerminalNode | null;
    linkRef(): LinkRefContext;
    LBRACE(): antlr.TerminalNode;
    projection(): ProjectionContext[];
    projection(i: number): ProjectionContext | null;
    RBRACE(): antlr.TerminalNode;
    RPAREN(): antlr.TerminalNode;
    HARD(): antlr.TerminalNode | null;
    FIRST(): antlr.TerminalNode | null;
    EXPAND(): antlr.TerminalNode | null;
    linkDefinition(): LinkDefinitionContext[];
    linkDefinition(i: number): LinkDefinitionContext | null;
    COMMA(): antlr.TerminalNode[];
    COMMA(i: number): antlr.TerminalNode | null;
    filterClause(): FilterClauseContext | null;
    sortClause(): SortClauseContext | null;
    takeClause(): TakeClauseContext | null;
    SUMMARIZE(): antlr.TerminalNode | null;
    aggregation(): AggregationContext[];
    aggregation(i: number): AggregationContext | null;
    groupByClause(): GroupByClauseContext | null;
    deriveClause(): DeriveClauseContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class LinkRefContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    identifierName(): IdentifierNameContext[];
    identifierName(i: number): IdentifierNameContext | null;
    leadingLinkOperator(): LeadingLinkOperatorContext | null;
    DOT(): antlr.TerminalNode[];
    DOT(i: number): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class LeadingLinkOperatorContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    linkOperator(): LinkOperatorContext | null;
    GT(): antlr.TerminalNode | null;
    LT(): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class GroupByClauseContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    BY(): antlr.TerminalNode;
    expression(): ExpressionContext[];
    expression(i: number): ExpressionContext | null;
    COMMA(): antlr.TerminalNode[];
    COMMA(i: number): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class DeriveClauseContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    DERIVE(): antlr.TerminalNode;
    derivation(): DerivationContext[];
    derivation(i: number): DerivationContext | null;
    COMMA(): antlr.TerminalNode[];
    COMMA(i: number): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class DerivationContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    expression(): ExpressionContext;
    alias(): AliasContext | null;
    ASSIGN(): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class AggregationContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    expression(): ExpressionContext;
    alias(): AliasContext | null;
    ASSIGN(): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class DistinctModifierContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    DISTINCT(): antlr.TerminalNode;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class AggregateFunctionContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    IDENTIFIER(): antlr.TerminalNode;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class FilterSuffixContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    IF(): antlr.TerminalNode;
    expression(): ExpressionContext;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class OverClauseContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    OVER(): antlr.TerminalNode;
    windowRef(): WindowRefContext;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class WindowDefinitionContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    WINDOW(): antlr.TerminalNode;
    identifierName(): IdentifierNameContext | null;
    LBRACE(): antlr.TerminalNode | null;
    windowSpec(): WindowSpecContext | null;
    RBRACE(): antlr.TerminalNode | null;
    LPAREN(): antlr.TerminalNode | null;
    windowCallArgs(): WindowCallArgsContext | null;
    RPAREN(): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class WindowSpecContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    windowPart(): WindowPartContext[];
    windowPart(i: number): WindowPartContext | null;
    COMMA(): antlr.TerminalNode[];
    COMMA(i: number): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class WindowPartContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    PARTITION(): antlr.TerminalNode | null;
    COLON(): antlr.TerminalNode;
    expression(): ExpressionContext[];
    expression(i: number): ExpressionContext | null;
    COMMA(): antlr.TerminalNode[];
    COMMA(i: number): antlr.TerminalNode | null;
    SORT(): antlr.TerminalNode | null;
    sortItem(): SortItemContext[];
    sortItem(i: number): SortItemContext | null;
    ROWS(): antlr.TerminalNode | null;
    frameSpec(): FrameSpecContext | null;
    RANGE(): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class WindowCallArgsContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    windowFunction(): WindowFunctionContext;
    LPAREN(): antlr.TerminalNode[];
    LPAREN(i: number): antlr.TerminalNode | null;
    RPAREN(): antlr.TerminalNode[];
    RPAREN(i: number): antlr.TerminalNode | null;
    COMMA(): antlr.TerminalNode[];
    COMMA(i: number): antlr.TerminalNode | null;
    expression(): ExpressionContext[];
    expression(i: number): ExpressionContext | null;
    sortItem(): SortItemContext[];
    sortItem(i: number): SortItemContext | null;
    expressionList(): ExpressionListContext | null;
    frameClause(): FrameClauseContext | null;
    STRING(): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class FrameClauseContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    ROWS(): antlr.TerminalNode | null;
    LPAREN(): antlr.TerminalNode;
    frameSpec(): FrameSpecContext;
    RPAREN(): antlr.TerminalNode;
    RANGE(): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class FrameSpecContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    frameStart(): FrameStartContext;
    RANGE_OP(): antlr.TerminalNode;
    frameEnd(): FrameEndContext;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class FrameStartContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    signedInteger(): SignedIntegerContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class FrameEndContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    signedInteger(): SignedIntegerContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class SignedIntegerContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    INTEGER(): antlr.TerminalNode;
    PLUS(): antlr.TerminalNode | null;
    MINUS(): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class SortItemContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    expression(): ExpressionContext;
    PLUS(): antlr.TerminalNode | null;
    MINUS(): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class WindowRefContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    identifierName(): IdentifierNameContext | null;
    LBRACE(): antlr.TerminalNode | null;
    windowSpec(): WindowSpecContext | null;
    RBRACE(): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class WindowFunctionContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    ROW_NUMBER(): antlr.TerminalNode | null;
    RANK(): antlr.TerminalNode | null;
    DENSE_RANK(): antlr.TerminalNode | null;
    PERCENT_RANK(): antlr.TerminalNode | null;
    CUME_DIST(): antlr.TerminalNode | null;
    NTILE(): antlr.TerminalNode | null;
    LAG(): antlr.TerminalNode | null;
    LEAD(): antlr.TerminalNode | null;
    FIRST_VALUE(): antlr.TerminalNode | null;
    LAST_VALUE(): antlr.TerminalNode | null;
    NTH_VALUE(): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class WindowCallContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    windowFunction(): WindowFunctionContext;
    LPAREN(): antlr.TerminalNode;
    RPAREN(): antlr.TerminalNode;
    OVER(): antlr.TerminalNode;
    windowRef(): WindowRefContext;
    expressionList(): ExpressionListContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class FilterClauseContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    FILTER(): antlr.TerminalNode;
    expression(): ExpressionContext;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class SortClauseContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    SORT(): antlr.TerminalNode;
    sortItem(): SortItemContext[];
    sortItem(i: number): SortItemContext | null;
    COMMA(): antlr.TerminalNode[];
    COMMA(i: number): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class TakeClauseContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    TAKE(): antlr.TerminalNode;
    takeValue(): TakeValueContext[];
    takeValue(i: number): TakeValueContext | null;
    RANGE_OP(): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class TakeValueContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    INTEGER(): antlr.TerminalNode | null;
    parameterRef(): ParameterRefContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class RankQueryContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    RANK(): antlr.TerminalNode;
    signedInteger(): SignedIntegerContext;
    tableRef(): TableRefContext;
    LBRACE(): antlr.TerminalNode;
    projection(): ProjectionContext[];
    projection(i: number): ProjectionContext | null;
    RBRACE(): antlr.TerminalNode;
    BY(): antlr.TerminalNode;
    identifierName(): IdentifierNameContext[];
    identifierName(i: number): IdentifierNameContext | null;
    REST(): antlr.TerminalNode | null;
    COMMA(): antlr.TerminalNode[];
    COMMA(i: number): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class LoopQueryContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    LOOP(): antlr.TerminalNode;
    LPAREN(): antlr.TerminalNode[];
    LPAREN(i: number): antlr.TerminalNode | null;
    expression(): ExpressionContext;
    RPAREN(): antlr.TerminalNode[];
    RPAREN(i: number): antlr.TerminalNode | null;
    USING(): antlr.TerminalNode;
    identifierName(): IdentifierNameContext[];
    identifierName(i: number): IdentifierNameContext | null;
    ARROW(): antlr.TerminalNode;
    queryBody(): QueryBodyContext;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class ExpressionContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    orExpression(): OrExpressionContext;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class OrExpressionContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    andExpression(): AndExpressionContext[];
    andExpression(i: number): AndExpressionContext | null;
    OR(): antlr.TerminalNode[];
    OR(i: number): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class AndExpressionContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    nullishExpression(): NullishExpressionContext[];
    nullishExpression(i: number): NullishExpressionContext | null;
    AND(): antlr.TerminalNode[];
    AND(i: number): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class NullishExpressionContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    notExpression(): NotExpressionContext[];
    notExpression(i: number): NotExpressionContext | null;
    NULLISH_COALESCE(): antlr.TerminalNode[];
    NULLISH_COALESCE(i: number): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class NotExpressionContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    comparisonExpression(): ComparisonExpressionContext;
    NOT(): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class ComparisonExpressionContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    additiveExpression(): AdditiveExpressionContext | null;
    comparisonTail(): ComparisonTailContext | null;
    tableSearchExpr(): TableSearchExprContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class TableSearchExprContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    SEARCH(): antlr.TerminalNode;
    additiveExpression(): AdditiveExpressionContext;
    ON(): antlr.TerminalNode | null;
    identifierName(): IdentifierNameContext[];
    identifierName(i: number): IdentifierNameContext | null;
    COMMA(): antlr.TerminalNode[];
    COMMA(i: number): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class ComparisonTailContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    comparisonOperator(): ComparisonOperatorContext | null;
    additiveExpression(): AdditiveExpressionContext[];
    additiveExpression(i: number): AdditiveExpressionContext | null;
    IS(): antlr.TerminalNode | null;
    NULL_LITERAL(): antlr.TerminalNode | null;
    NOT(): antlr.TerminalNode | null;
    HAS(): antlr.TerminalNode | null;
    LPAREN(): antlr.TerminalNode | null;
    expression(): ExpressionContext | null;
    RPAREN(): antlr.TerminalNode | null;
    annotation(): AnnotationContext | null;
    FULLTEXT_MATCH(): antlr.TerminalNode | null;
    REGEX_MATCH(): antlr.TerminalNode | null;
    REGEX_MATCH_CI(): antlr.TerminalNode | null;
    NOT_REGEX_MATCH(): antlr.TerminalNode | null;
    NOT_REGEX_MATCH_CI(): antlr.TerminalNode | null;
    JSONB_KEY_EXISTS(): antlr.TerminalNode | null;
    JSONB_ALL_KEYS_EXIST(): antlr.TerminalNode | null;
    JSONB_ANY_KEY_EXISTS(): antlr.TerminalNode | null;
    JSONB_PATH(): antlr.TerminalNode | null;
    JSONB_PATH_TEXT(): antlr.TerminalNode | null;
    BETWEEN(): antlr.TerminalNode | null;
    AND(): antlr.TerminalNode | null;
    negatableTail(): NegatableTailContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class NegatableTailContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    inRhs(): InRhsContext | null;
    likeRhs(): LikeRhsContext | null;
    rangeOpRhs(): RangeOpRhsContext | null;
    NOT(): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class InRhsContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    IN(): antlr.TerminalNode;
    LPAREN(): antlr.TerminalNode | null;
    inExpressionList(): InExpressionListContext | null;
    RPAREN(): antlr.TerminalNode | null;
    LBRACKET(): antlr.TerminalNode | null;
    RBRACKET(): antlr.TerminalNode | null;
    rangeBound(): RangeBoundContext | null;
    functionCall(): FunctionCallContext | null;
    jsonbPathExpr(): JsonbPathExprContext | null;
    columnRef(): ColumnRefContext | null;
    parameterRef(): ParameterRefContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class JsonbPathExprContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    columnRef(): ColumnRefContext;
    primaryExpression(): PrimaryExpressionContext;
    JSONB_PATH(): antlr.TerminalNode | null;
    JSONB_PATH_TEXT(): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class InExpressionListContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    expressionOrStar(): ExpressionOrStarContext[];
    expressionOrStar(i: number): ExpressionOrStarContext | null;
    COMMA(): antlr.TerminalNode[];
    COMMA(i: number): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class LikeRhsContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    LIKE(): antlr.TerminalNode;
    additiveExpression(): AdditiveExpressionContext;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class RangeOpRhsContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    rangeOp(): RangeOpContext;
    additiveExpression(): AdditiveExpressionContext;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class RangeOpContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    RANGE_CONTAINS(): antlr.TerminalNode | null;
    RANGE_CONTAINED_BY(): antlr.TerminalNode | null;
    RANGE_OVERLAPS(): antlr.TerminalNode | null;
    RANGE_ADJACENT(): antlr.TerminalNode | null;
    RANGE_STRICTLY_LEFT(): antlr.TerminalNode | null;
    RANGE_STRICTLY_RIGHT(): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class ComparisonOperatorContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    EQ(): antlr.TerminalNode | null;
    NEQ(): antlr.TerminalNode | null;
    LT(): antlr.TerminalNode | null;
    GT(): antlr.TerminalNode | null;
    LTE(): antlr.TerminalNode | null;
    GTE(): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class AdditiveExpressionContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    multiplicativeExpression(): MultiplicativeExpressionContext[];
    multiplicativeExpression(i: number): MultiplicativeExpressionContext | null;
    PLUS(): antlr.TerminalNode[];
    PLUS(i: number): antlr.TerminalNode | null;
    MINUS(): antlr.TerminalNode[];
    MINUS(i: number): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class MultiplicativeExpressionContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    unaryExpression(): UnaryExpressionContext[];
    unaryExpression(i: number): UnaryExpressionContext | null;
    STAR(): antlr.TerminalNode[];
    STAR(i: number): antlr.TerminalNode | null;
    SLASH(): antlr.TerminalNode[];
    SLASH(i: number): antlr.TerminalNode | null;
    PERCENT(): antlr.TerminalNode[];
    PERCENT(i: number): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class ColumnRefContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    identifierName(): IdentifierNameContext[];
    identifierName(i: number): IdentifierNameContext | null;
    DOT(): antlr.TerminalNode | null;
    columnAccessor(): ColumnAccessorContext[];
    columnAccessor(i: number): ColumnAccessorContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class AnnotatedColumnRefContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    annotation(): AnnotationContext;
    columnRef(): ColumnRefContext;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class ColumnAccessorContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    datePartAccess(): DatePartAccessContext | null;
    linkNavigation(): LinkNavigationContext | null;
    postfixAccess(): PostfixAccessContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class DatePartAccessContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    COLON(): antlr.TerminalNode;
    identifierName(): IdentifierNameContext;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class LinkNavigationContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    linkOperator(): LinkOperatorContext;
    identifierName(): IdentifierNameContext[];
    identifierName(i: number): IdentifierNameContext | null;
    DOT(): antlr.TerminalNode[];
    DOT(i: number): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class PostfixAccessContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    LBRACKET(): antlr.TerminalNode | null;
    expression(): ExpressionContext | null;
    RBRACKET(): antlr.TerminalNode | null;
    distinctModifier(): DistinctModifierContext | null;
    filterClause(): FilterClauseContext | null;
    arrayAggSort(): ArrayAggSortContext | null;
    DOT(): antlr.TerminalNode | null;
    identifierName(): IdentifierNameContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class IdentifierNameContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    IDENTIFIER(): antlr.TerminalNode | null;
    QUOTED_IDENTIFIER(): antlr.TerminalNode | null;
    CONST_REF(): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class ParameterRefContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    PARAM_REF(): antlr.TerminalNode | null;
    DOT(): antlr.TerminalNode[];
    DOT(i: number): antlr.TerminalNode | null;
    identifierName(): IdentifierNameContext[];
    identifierName(i: number): IdentifierNameContext | null;
    parameterMeta(): ParameterMetaContext | null;
    CTE_REF(): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class ParameterMetaContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    LPAREN(): antlr.TerminalNode;
    parameterMetaEntry(): ParameterMetaEntryContext[];
    parameterMetaEntry(i: number): ParameterMetaEntryContext | null;
    RPAREN(): antlr.TerminalNode;
    COMMA(): antlr.TerminalNode[];
    COMMA(i: number): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class ParameterMetaEntryContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    DEFAULT(): antlr.TerminalNode | null;
    COLON(): antlr.TerminalNode | null;
    parameterDefaultValue(): ParameterDefaultValueContext | null;
    IDENTIFIER(): antlr.TerminalNode | null;
    parameterTypeName(): ParameterTypeNameContext | null;
    REQUIRED(): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class ParameterDefaultValueContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    literal(): LiteralContext;
    MINUS(): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class ParameterTypeNameContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    IDENTIFIER(): antlr.TerminalNode | null;
    niladicTemporalFunction(): NiladicTemporalFunctionContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class LinkOperatorContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    LINK_FWD(): antlr.TerminalNode | null;
    LINK_BWD(): antlr.TerminalNode | null;
    HASH(): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class LinkExpressionContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    leadingLinkOperator(): LeadingLinkOperatorContext;
    identifierName(): IdentifierNameContext[];
    identifierName(i: number): IdentifierNameContext | null;
    DOT(): antlr.TerminalNode[];
    DOT(i: number): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class RangeBoundContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    leftBound(): LeftBoundContext;
    RANGE_OP(): antlr.TerminalNode;
    rightBound(): RightBoundContext;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class LeftBoundContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    LBRACKET(): antlr.TerminalNode | null;
    LPAREN(): antlr.TerminalNode | null;
    expression(): ExpressionContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class RightBoundContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    RBRACKET(): antlr.TerminalNode | null;
    RPAREN(): antlr.TerminalNode | null;
    expression(): ExpressionContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class FunctionCallContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    LPAREN(): antlr.TerminalNode;
    RPAREN(): antlr.TerminalNode;
    IDENTIFIER(): antlr.TerminalNode | null;
    nonReservedFunctionName(): NonReservedFunctionNameContext | null;
    aggregateFunction(): AggregateFunctionContext | null;
    distinctModifier(): DistinctModifierContext | null;
    expressionList(): ExpressionListContext | null;
    filterSuffix(): FilterSuffixContext | null;
    overClause(): OverClauseContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class NonReservedFunctionNameContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    REPLACE(): antlr.TerminalNode;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class NiladicTemporalFunctionContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    CURRENT_DATE(): antlr.TerminalNode | null;
    CURRENT_TIME(): antlr.TerminalNode | null;
    CURRENT_TIMESTAMP(): antlr.TerminalNode | null;
    LOCALTIME(): antlr.TerminalNode | null;
    LOCALTIMESTAMP(): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class ExpressionOrStarContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    expression(): ExpressionContext | null;
    STAR(): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class ExpressionListContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    expressionOrStar(): ExpressionOrStarContext[];
    expressionOrStar(i: number): ExpressionOrStarContext | null;
    COMMA(): antlr.TerminalNode[];
    COMMA(i: number): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class CaseExpressionContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    CASE(): antlr.TerminalNode;
    LPAREN(): antlr.TerminalNode;
    caseArgs(): CaseArgsContext;
    RPAREN(): antlr.TerminalNode;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class CaseArgsContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    expression(): ExpressionContext[];
    expression(i: number): ExpressionContext | null;
    COMMA(): antlr.TerminalNode[];
    COMMA(i: number): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class InlineSqlContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    INLINE_SQL(): antlr.TerminalNode;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class CastExpressionContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    CAST(): antlr.TerminalNode;
    LPAREN(): antlr.TerminalNode;
    expression(): ExpressionContext;
    AS(): antlr.TerminalNode;
    typeName(): TypeNameContext;
    RPAREN(): antlr.TerminalNode;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class PolicyExpansionContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    POLICY(): antlr.TerminalNode;
    LPAREN(): antlr.TerminalNode;
    STRING(): antlr.TerminalNode;
    RPAREN(): antlr.TerminalNode;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class CapabilityCheckContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    CAN(): antlr.TerminalNode;
    LPAREN(): antlr.TerminalNode;
    STRING(): antlr.TerminalNode;
    RPAREN(): antlr.TerminalNode;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class UnaryExpressionContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    postfixExpression(): PostfixExpressionContext;
    MINUS(): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class PostfixExpressionContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    primaryExpression(): PrimaryExpressionContext;
    CAST_OP(): antlr.TerminalNode[];
    CAST_OP(i: number): antlr.TerminalNode | null;
    typeName(): TypeNameContext[];
    typeName(i: number): TypeNameContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class TypeNameContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    IDENTIFIER(): antlr.TerminalNode;
    typeParams(): TypeParamsContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class TypeParamsContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    LPAREN(): antlr.TerminalNode;
    RPAREN(): antlr.TerminalNode;
    expressionList(): ExpressionListContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class PrimaryExpressionContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    literal(): LiteralContext | null;
    arrayLiteral(): ArrayLiteralContext | null;
    linkLookup(): LinkLookupContext | null;
    choiceRef(): ChoiceRefContext | null;
    policyExpansion(): PolicyExpansionContext | null;
    capabilityCheck(): CapabilityCheckContext | null;
    linkExpression(): LinkExpressionContext | null;
    niladicTemporalFunction(): NiladicTemporalFunctionContext | null;
    annotatedColumnRef(): AnnotatedColumnRefContext | null;
    columnRef(): ColumnRefContext | null;
    parameterRef(): ParameterRefContext | null;
    functionCall(): FunctionCallContext | null;
    windowCall(): WindowCallContext | null;
    caseExpression(): CaseExpressionContext | null;
    inlineSql(): InlineSqlContext | null;
    castExpression(): CastExpressionContext | null;
    LPAREN(): antlr.TerminalNode | null;
    expression(): ExpressionContext | null;
    RPAREN(): antlr.TerminalNode | null;
    STAR(): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class ArrayLiteralContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    ARRAY(): antlr.TerminalNode;
    LBRACKET(): antlr.TerminalNode;
    RBRACKET(): antlr.TerminalNode;
    expressionList(): ExpressionListContext | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
export declare class LiteralContext extends antlr.ParserRuleContext {
    constructor(parent: antlr.ParserRuleContext | null, invokingState: number);
    INTEGER(): antlr.TerminalNode | null;
    DECIMAL(): antlr.TerminalNode | null;
    STRING(): antlr.TerminalNode | null;
    TRUE(): antlr.TerminalNode | null;
    FALSE(): antlr.TerminalNode | null;
    NULL_LITERAL(): antlr.TerminalNode | null;
    CONST_REF(): antlr.TerminalNode | null;
    get ruleIndex(): number;
    enterRule(listener: WynQLListener): void;
    exitRule(listener: WynQLListener): void;
    accept<Result>(visitor: WynQLVisitor<Result>): Result | null;
}
