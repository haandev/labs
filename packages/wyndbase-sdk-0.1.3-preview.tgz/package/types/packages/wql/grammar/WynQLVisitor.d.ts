import { AbstractParseTreeVisitor } from "antlr4ng";
import { QueryContext } from "./WynQLParser.js";
import { DqlStatementContext } from "./WynQLParser.js";
import { BareQueryContext } from "./WynQLParser.js";
import { DmlStatementContext } from "./WynQLParser.js";
import { TclStatementContext } from "./WynQLParser.js";
import { DdlStatementContext } from "./WynQLParser.js";
import { DclStatementContext } from "./WynQLParser.js";
import { GrantStatementContext } from "./WynQLParser.js";
import { ModelTargetContext } from "./WynQLParser.js";
import { DecisionOperationContext } from "./WynQLParser.js";
import { PolicyStatementContext } from "./WynQLParser.js";
import { PolicyKeyContext } from "./WynQLParser.js";
import { AlterPolicyStatementContext } from "./WynQLParser.js";
import { DropPolicyStatementContext } from "./WynQLParser.js";
import { PolicyRefContext } from "./WynQLParser.js";
import { RoleClauseContext } from "./WynQLParser.js";
import { QualifiedNameContext } from "./WynQLParser.js";
import { DelegateStatementContext } from "./WynQLParser.js";
import { DelegableTargetContext } from "./WynQLParser.js";
import { RevokeDelegationStatementContext } from "./WynQLParser.js";
import { PeriodClauseContext } from "./WynQLParser.js";
import { UserRefContext } from "./WynQLParser.js";
import { DelegationRefContext } from "./WynQLParser.js";
import { StatementContext } from "./WynQLParser.js";
import { DefineStatementContext } from "./WynQLParser.js";
import { ConstDefineStatementContext } from "./WynQLParser.js";
import { ImportStatementContext } from "./WynQLParser.js";
import { DefinitionOptionContext } from "./WynQLParser.js";
import { DefinitionBodyContext } from "./WynQLParser.js";
import { DefinitionBodyStatementContext } from "./WynQLParser.js";
import { ExposeStatementContext } from "./WynQLParser.js";
import { DropStatementContext } from "./WynQLParser.js";
import { NamedQueryRefContext } from "./WynQLParser.js";
import { ExposureLevelContext } from "./WynQLParser.js";
import { QueryStatementContext } from "./WynQLParser.js";
import { CteDefinitionContext } from "./WynQLParser.js";
import { CteBodyContext } from "./WynQLParser.js";
import { QueryBodyContext } from "./WynQLParser.js";
import { InsertStatementContext } from "./WynQLParser.js";
import { EachSourceContext } from "./WynQLParser.js";
import { UpdateStatementContext } from "./WynQLParser.js";
import { UpsertStatementContext } from "./WynQLParser.js";
import { DeleteStatementContext } from "./WynQLParser.js";
import { GuardClauseContext } from "./WynQLParser.js";
import { TransactionBlockContext } from "./WynQLParser.js";
import { TransactionBodyStatementContext } from "./WynQLParser.js";
import { TransactionErrorHandlerContext } from "./WynQLParser.js";
import { TableNameContext } from "./WynQLParser.js";
import { MutationObjectContext } from "./WynQLParser.js";
import { MutationFieldContext } from "./WynQLParser.js";
import { MutationAssignContext } from "./WynQLParser.js";
import { MutationValueContext } from "./WynQLParser.js";
import { MutationArrayContext } from "./WynQLParser.js";
import { MutationArrayItemContext } from "./WynQLParser.js";
import { NestedInsertContext } from "./WynQLParser.js";
import { LinkLookupContext } from "./WynQLParser.js";
import { LinkLookupTargetContext } from "./WynQLParser.js";
import { LinkLookupOpContext } from "./WynQLParser.js";
import { LinkMessageContext } from "./WynQLParser.js";
import { LinkUpdateContext } from "./WynQLParser.js";
import { ChoiceRefContext } from "./WynQLParser.js";
import { ChoiceKeyArgContext } from "./WynQLParser.js";
import { OnConflictClauseContext } from "./WynQLParser.js";
import { ReturningClauseContext } from "./WynQLParser.js";
import { ReturningSpecContext } from "./WynQLParser.js";
import { SelectQueryContext } from "./WynQLParser.js";
import { AsOfClauseContext } from "./WynQLParser.js";
import { SelectLockClauseContext } from "./WynQLParser.js";
import { LinkDefinitionContext } from "./WynQLParser.js";
import { LinkArgContext } from "./WynQLParser.js";
import { LinkArgKeyContext } from "./WynQLParser.js";
import { LinkArgValueContext } from "./WynQLParser.js";
import { SummarizeQueryContext } from "./WynQLParser.js";
import { TableRefContext } from "./WynQLParser.js";
import { NqInvocationArgsContext } from "./WynQLParser.js";
import { NqInvocationArgContext } from "./WynQLParser.js";
import { SetOperationContext } from "./WynQLParser.js";
import { AliasContext } from "./WynQLParser.js";
import { ProjectionContext } from "./WynQLParser.js";
import { AnnotationContext } from "./WynQLParser.js";
import { AnnotationArgsContext } from "./WynQLParser.js";
import { AnnotationArgContext } from "./WynQLParser.js";
import { AnnotationArgValueContext } from "./WynQLParser.js";
import { ArrayAggSortContext } from "./WynQLParser.js";
import { AliasAssignmentContext } from "./WynQLParser.js";
import { NestedSubqueryContext } from "./WynQLParser.js";
import { LinkRefContext } from "./WynQLParser.js";
import { LeadingLinkOperatorContext } from "./WynQLParser.js";
import { GroupByClauseContext } from "./WynQLParser.js";
import { DeriveClauseContext } from "./WynQLParser.js";
import { DerivationContext } from "./WynQLParser.js";
import { AggregationContext } from "./WynQLParser.js";
import { DistinctModifierContext } from "./WynQLParser.js";
import { AggregateFunctionContext } from "./WynQLParser.js";
import { FilterSuffixContext } from "./WynQLParser.js";
import { OverClauseContext } from "./WynQLParser.js";
import { WindowDefinitionContext } from "./WynQLParser.js";
import { WindowSpecContext } from "./WynQLParser.js";
import { WindowPartContext } from "./WynQLParser.js";
import { WindowCallArgsContext } from "./WynQLParser.js";
import { FrameClauseContext } from "./WynQLParser.js";
import { FrameSpecContext } from "./WynQLParser.js";
import { FrameStartContext } from "./WynQLParser.js";
import { FrameEndContext } from "./WynQLParser.js";
import { SignedIntegerContext } from "./WynQLParser.js";
import { SortItemContext } from "./WynQLParser.js";
import { WindowRefContext } from "./WynQLParser.js";
import { WindowFunctionContext } from "./WynQLParser.js";
import { WindowCallContext } from "./WynQLParser.js";
import { FilterClauseContext } from "./WynQLParser.js";
import { SortClauseContext } from "./WynQLParser.js";
import { TakeClauseContext } from "./WynQLParser.js";
import { TakeValueContext } from "./WynQLParser.js";
import { RankQueryContext } from "./WynQLParser.js";
import { LoopQueryContext } from "./WynQLParser.js";
import { ExpressionContext } from "./WynQLParser.js";
import { OrExpressionContext } from "./WynQLParser.js";
import { AndExpressionContext } from "./WynQLParser.js";
import { NullishExpressionContext } from "./WynQLParser.js";
import { NotExpressionContext } from "./WynQLParser.js";
import { ComparisonExpressionContext } from "./WynQLParser.js";
import { TableSearchExprContext } from "./WynQLParser.js";
import { ComparisonTailContext } from "./WynQLParser.js";
import { NegatableTailContext } from "./WynQLParser.js";
import { InRhsContext } from "./WynQLParser.js";
import { JsonbPathExprContext } from "./WynQLParser.js";
import { InExpressionListContext } from "./WynQLParser.js";
import { LikeRhsContext } from "./WynQLParser.js";
import { RangeOpRhsContext } from "./WynQLParser.js";
import { RangeOpContext } from "./WynQLParser.js";
import { ComparisonOperatorContext } from "./WynQLParser.js";
import { AdditiveExpressionContext } from "./WynQLParser.js";
import { MultiplicativeExpressionContext } from "./WynQLParser.js";
import { ColumnRefContext } from "./WynQLParser.js";
import { AnnotatedColumnRefContext } from "./WynQLParser.js";
import { ColumnAccessorContext } from "./WynQLParser.js";
import { DatePartAccessContext } from "./WynQLParser.js";
import { LinkNavigationContext } from "./WynQLParser.js";
import { PostfixAccessContext } from "./WynQLParser.js";
import { IdentifierNameContext } from "./WynQLParser.js";
import { ParameterRefContext } from "./WynQLParser.js";
import { ParameterMetaContext } from "./WynQLParser.js";
import { ParameterMetaEntryContext } from "./WynQLParser.js";
import { ParameterDefaultValueContext } from "./WynQLParser.js";
import { ParameterTypeNameContext } from "./WynQLParser.js";
import { LinkOperatorContext } from "./WynQLParser.js";
import { LinkExpressionContext } from "./WynQLParser.js";
import { RangeBoundContext } from "./WynQLParser.js";
import { LeftBoundContext } from "./WynQLParser.js";
import { RightBoundContext } from "./WynQLParser.js";
import { FunctionCallContext } from "./WynQLParser.js";
import { NonReservedFunctionNameContext } from "./WynQLParser.js";
import { NiladicTemporalFunctionContext } from "./WynQLParser.js";
import { ExpressionOrStarContext } from "./WynQLParser.js";
import { ExpressionListContext } from "./WynQLParser.js";
import { CaseExpressionContext } from "./WynQLParser.js";
import { CaseArgsContext } from "./WynQLParser.js";
import { InlineSqlContext } from "./WynQLParser.js";
import { CastExpressionContext } from "./WynQLParser.js";
import { PolicyExpansionContext } from "./WynQLParser.js";
import { CapabilityCheckContext } from "./WynQLParser.js";
import { UnaryExpressionContext } from "./WynQLParser.js";
import { PostfixExpressionContext } from "./WynQLParser.js";
import { TypeNameContext } from "./WynQLParser.js";
import { TypeParamsContext } from "./WynQLParser.js";
import { PrimaryExpressionContext } from "./WynQLParser.js";
import { ArrayLiteralContext } from "./WynQLParser.js";
import { LiteralContext } from "./WynQLParser.js";
/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by `WynQLParser`.
 *
 * @param <Result> The return type of the visit operation. Use `void` for
 * operations with no return type.
 */
export declare class WynQLVisitor<Result> extends AbstractParseTreeVisitor<Result> {
    /**
     * Visit a parse tree produced by `WynQLParser.query`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitQuery?: (ctx: QueryContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.dqlStatement`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitDqlStatement?: (ctx: DqlStatementContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.bareQuery`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitBareQuery?: (ctx: BareQueryContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.dmlStatement`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitDmlStatement?: (ctx: DmlStatementContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.tclStatement`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitTclStatement?: (ctx: TclStatementContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.ddlStatement`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitDdlStatement?: (ctx: DdlStatementContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.dclStatement`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitDclStatement?: (ctx: DclStatementContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.grantStatement`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitGrantStatement?: (ctx: GrantStatementContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.modelTarget`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitModelTarget?: (ctx: ModelTargetContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.decisionOperation`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitDecisionOperation?: (ctx: DecisionOperationContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.policyStatement`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitPolicyStatement?: (ctx: PolicyStatementContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.policyKey`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitPolicyKey?: (ctx: PolicyKeyContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.alterPolicyStatement`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitAlterPolicyStatement?: (ctx: AlterPolicyStatementContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.dropPolicyStatement`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitDropPolicyStatement?: (ctx: DropPolicyStatementContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.policyRef`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitPolicyRef?: (ctx: PolicyRefContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.roleClause`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitRoleClause?: (ctx: RoleClauseContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.qualifiedName`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitQualifiedName?: (ctx: QualifiedNameContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.delegateStatement`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitDelegateStatement?: (ctx: DelegateStatementContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.delegableTarget`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitDelegableTarget?: (ctx: DelegableTargetContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.revokeDelegationStatement`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitRevokeDelegationStatement?: (ctx: RevokeDelegationStatementContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.periodClause`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitPeriodClause?: (ctx: PeriodClauseContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.userRef`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitUserRef?: (ctx: UserRefContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.delegationRef`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitDelegationRef?: (ctx: DelegationRefContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.statement`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitStatement?: (ctx: StatementContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.defineStatement`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitDefineStatement?: (ctx: DefineStatementContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.constDefineStatement`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitConstDefineStatement?: (ctx: ConstDefineStatementContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.importStatement`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitImportStatement?: (ctx: ImportStatementContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.definitionOption`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitDefinitionOption?: (ctx: DefinitionOptionContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.definitionBody`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitDefinitionBody?: (ctx: DefinitionBodyContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.definitionBodyStatement`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitDefinitionBodyStatement?: (ctx: DefinitionBodyStatementContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.exposeStatement`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitExposeStatement?: (ctx: ExposeStatementContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.dropStatement`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitDropStatement?: (ctx: DropStatementContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.namedQueryRef`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitNamedQueryRef?: (ctx: NamedQueryRefContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.exposureLevel`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitExposureLevel?: (ctx: ExposureLevelContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.queryStatement`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitQueryStatement?: (ctx: QueryStatementContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.cteDefinition`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitCteDefinition?: (ctx: CteDefinitionContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.cteBody`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitCteBody?: (ctx: CteBodyContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.queryBody`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitQueryBody?: (ctx: QueryBodyContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.insertStatement`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitInsertStatement?: (ctx: InsertStatementContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.eachSource`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitEachSource?: (ctx: EachSourceContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.updateStatement`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitUpdateStatement?: (ctx: UpdateStatementContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.upsertStatement`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitUpsertStatement?: (ctx: UpsertStatementContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.deleteStatement`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitDeleteStatement?: (ctx: DeleteStatementContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.guardClause`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitGuardClause?: (ctx: GuardClauseContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.transactionBlock`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitTransactionBlock?: (ctx: TransactionBlockContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.transactionBodyStatement`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitTransactionBodyStatement?: (ctx: TransactionBodyStatementContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.transactionErrorHandler`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitTransactionErrorHandler?: (ctx: TransactionErrorHandlerContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.tableName`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitTableName?: (ctx: TableNameContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.mutationObject`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitMutationObject?: (ctx: MutationObjectContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.mutationField`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitMutationField?: (ctx: MutationFieldContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.mutationAssign`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitMutationAssign?: (ctx: MutationAssignContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.mutationValue`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitMutationValue?: (ctx: MutationValueContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.mutationArray`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitMutationArray?: (ctx: MutationArrayContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.mutationArrayItem`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitMutationArrayItem?: (ctx: MutationArrayItemContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.nestedInsert`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitNestedInsert?: (ctx: NestedInsertContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.linkLookup`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitLinkLookup?: (ctx: LinkLookupContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.linkLookupTarget`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitLinkLookupTarget?: (ctx: LinkLookupTargetContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.linkLookupOp`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitLinkLookupOp?: (ctx: LinkLookupOpContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.linkMessage`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitLinkMessage?: (ctx: LinkMessageContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.linkUpdate`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitLinkUpdate?: (ctx: LinkUpdateContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.choiceRef`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitChoiceRef?: (ctx: ChoiceRefContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.choiceKeyArg`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitChoiceKeyArg?: (ctx: ChoiceKeyArgContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.onConflictClause`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitOnConflictClause?: (ctx: OnConflictClauseContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.returningClause`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitReturningClause?: (ctx: ReturningClauseContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.returningSpec`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitReturningSpec?: (ctx: ReturningSpecContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.selectQuery`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitSelectQuery?: (ctx: SelectQueryContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.asOfClause`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitAsOfClause?: (ctx: AsOfClauseContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.selectLockClause`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitSelectLockClause?: (ctx: SelectLockClauseContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.linkDefinition`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitLinkDefinition?: (ctx: LinkDefinitionContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.linkArg`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitLinkArg?: (ctx: LinkArgContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.linkArgKey`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitLinkArgKey?: (ctx: LinkArgKeyContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.linkArgValue`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitLinkArgValue?: (ctx: LinkArgValueContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.summarizeQuery`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitSummarizeQuery?: (ctx: SummarizeQueryContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.tableRef`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitTableRef?: (ctx: TableRefContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.nqInvocationArgs`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitNqInvocationArgs?: (ctx: NqInvocationArgsContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.nqInvocationArg`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitNqInvocationArg?: (ctx: NqInvocationArgContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.setOperation`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitSetOperation?: (ctx: SetOperationContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.alias`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitAlias?: (ctx: AliasContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.projection`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitProjection?: (ctx: ProjectionContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.annotation`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitAnnotation?: (ctx: AnnotationContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.annotationArgs`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitAnnotationArgs?: (ctx: AnnotationArgsContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.annotationArg`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitAnnotationArg?: (ctx: AnnotationArgContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.annotationArgValue`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitAnnotationArgValue?: (ctx: AnnotationArgValueContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.arrayAggSort`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitArrayAggSort?: (ctx: ArrayAggSortContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.aliasAssignment`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitAliasAssignment?: (ctx: AliasAssignmentContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.nestedSubquery`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitNestedSubquery?: (ctx: NestedSubqueryContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.linkRef`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitLinkRef?: (ctx: LinkRefContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.leadingLinkOperator`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitLeadingLinkOperator?: (ctx: LeadingLinkOperatorContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.groupByClause`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitGroupByClause?: (ctx: GroupByClauseContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.deriveClause`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitDeriveClause?: (ctx: DeriveClauseContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.derivation`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitDerivation?: (ctx: DerivationContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.aggregation`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitAggregation?: (ctx: AggregationContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.distinctModifier`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitDistinctModifier?: (ctx: DistinctModifierContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.aggregateFunction`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitAggregateFunction?: (ctx: AggregateFunctionContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.filterSuffix`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitFilterSuffix?: (ctx: FilterSuffixContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.overClause`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitOverClause?: (ctx: OverClauseContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.windowDefinition`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitWindowDefinition?: (ctx: WindowDefinitionContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.windowSpec`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitWindowSpec?: (ctx: WindowSpecContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.windowPart`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitWindowPart?: (ctx: WindowPartContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.windowCallArgs`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitWindowCallArgs?: (ctx: WindowCallArgsContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.frameClause`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitFrameClause?: (ctx: FrameClauseContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.frameSpec`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitFrameSpec?: (ctx: FrameSpecContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.frameStart`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitFrameStart?: (ctx: FrameStartContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.frameEnd`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitFrameEnd?: (ctx: FrameEndContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.signedInteger`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitSignedInteger?: (ctx: SignedIntegerContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.sortItem`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitSortItem?: (ctx: SortItemContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.windowRef`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitWindowRef?: (ctx: WindowRefContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.windowFunction`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitWindowFunction?: (ctx: WindowFunctionContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.windowCall`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitWindowCall?: (ctx: WindowCallContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.filterClause`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitFilterClause?: (ctx: FilterClauseContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.sortClause`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitSortClause?: (ctx: SortClauseContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.takeClause`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitTakeClause?: (ctx: TakeClauseContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.takeValue`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitTakeValue?: (ctx: TakeValueContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.rankQuery`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitRankQuery?: (ctx: RankQueryContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.loopQuery`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitLoopQuery?: (ctx: LoopQueryContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.expression`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitExpression?: (ctx: ExpressionContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.orExpression`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitOrExpression?: (ctx: OrExpressionContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.andExpression`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitAndExpression?: (ctx: AndExpressionContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.nullishExpression`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitNullishExpression?: (ctx: NullishExpressionContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.notExpression`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitNotExpression?: (ctx: NotExpressionContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.comparisonExpression`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitComparisonExpression?: (ctx: ComparisonExpressionContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.tableSearchExpr`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitTableSearchExpr?: (ctx: TableSearchExprContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.comparisonTail`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitComparisonTail?: (ctx: ComparisonTailContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.negatableTail`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitNegatableTail?: (ctx: NegatableTailContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.inRhs`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitInRhs?: (ctx: InRhsContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.jsonbPathExpr`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitJsonbPathExpr?: (ctx: JsonbPathExprContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.inExpressionList`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitInExpressionList?: (ctx: InExpressionListContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.likeRhs`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitLikeRhs?: (ctx: LikeRhsContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.rangeOpRhs`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitRangeOpRhs?: (ctx: RangeOpRhsContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.rangeOp`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitRangeOp?: (ctx: RangeOpContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.comparisonOperator`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitComparisonOperator?: (ctx: ComparisonOperatorContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.additiveExpression`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitAdditiveExpression?: (ctx: AdditiveExpressionContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.multiplicativeExpression`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitMultiplicativeExpression?: (ctx: MultiplicativeExpressionContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.columnRef`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitColumnRef?: (ctx: ColumnRefContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.annotatedColumnRef`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitAnnotatedColumnRef?: (ctx: AnnotatedColumnRefContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.columnAccessor`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitColumnAccessor?: (ctx: ColumnAccessorContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.datePartAccess`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitDatePartAccess?: (ctx: DatePartAccessContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.linkNavigation`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitLinkNavigation?: (ctx: LinkNavigationContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.postfixAccess`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitPostfixAccess?: (ctx: PostfixAccessContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.identifierName`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitIdentifierName?: (ctx: IdentifierNameContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.parameterRef`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitParameterRef?: (ctx: ParameterRefContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.parameterMeta`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitParameterMeta?: (ctx: ParameterMetaContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.parameterMetaEntry`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitParameterMetaEntry?: (ctx: ParameterMetaEntryContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.parameterDefaultValue`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitParameterDefaultValue?: (ctx: ParameterDefaultValueContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.parameterTypeName`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitParameterTypeName?: (ctx: ParameterTypeNameContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.linkOperator`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitLinkOperator?: (ctx: LinkOperatorContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.linkExpression`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitLinkExpression?: (ctx: LinkExpressionContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.rangeBound`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitRangeBound?: (ctx: RangeBoundContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.leftBound`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitLeftBound?: (ctx: LeftBoundContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.rightBound`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitRightBound?: (ctx: RightBoundContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.functionCall`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitFunctionCall?: (ctx: FunctionCallContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.nonReservedFunctionName`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitNonReservedFunctionName?: (ctx: NonReservedFunctionNameContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.niladicTemporalFunction`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitNiladicTemporalFunction?: (ctx: NiladicTemporalFunctionContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.expressionOrStar`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitExpressionOrStar?: (ctx: ExpressionOrStarContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.expressionList`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitExpressionList?: (ctx: ExpressionListContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.caseExpression`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitCaseExpression?: (ctx: CaseExpressionContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.caseArgs`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitCaseArgs?: (ctx: CaseArgsContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.inlineSql`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitInlineSql?: (ctx: InlineSqlContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.castExpression`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitCastExpression?: (ctx: CastExpressionContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.policyExpansion`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitPolicyExpansion?: (ctx: PolicyExpansionContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.capabilityCheck`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitCapabilityCheck?: (ctx: CapabilityCheckContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.unaryExpression`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitUnaryExpression?: (ctx: UnaryExpressionContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.postfixExpression`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitPostfixExpression?: (ctx: PostfixExpressionContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.typeName`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitTypeName?: (ctx: TypeNameContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.typeParams`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitTypeParams?: (ctx: TypeParamsContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.primaryExpression`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitPrimaryExpression?: (ctx: PrimaryExpressionContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.arrayLiteral`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitArrayLiteral?: (ctx: ArrayLiteralContext) => Result;
    /**
     * Visit a parse tree produced by `WynQLParser.literal`.
     * @param ctx the parse tree
     * @return the visitor result
     */
    visitLiteral?: (ctx: LiteralContext) => Result;
}
