/**
 * WQL Built-in Linter for CodeMirror
 * Uses the ANTLR parser for syntax validation. Diagnostics flow through the
 * shared DiagnosticErrorListener so editor squiggles carry the same
 * actionable hints (CTE pitfalls, INTERVAL/EXTRACT, …) as the parse() path —
 * a single source for hint detection, no drift between the two surfaces.
 */
export interface WQLLintDiagnostic {
    message: string;
    line: number;
    column: number;
    severity?: 'error' | 'warning' | 'info';
}
/** Built-in WQL linter using the ANTLR parser. */
export declare function lintWQL(source: string): WQLLintDiagnostic[];
