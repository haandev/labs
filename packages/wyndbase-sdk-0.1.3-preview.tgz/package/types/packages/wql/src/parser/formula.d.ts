import type { Expression, NestedSubquery } from '../ast/nodes';
export type FormulaBody = Expression | NestedSubquery;
export declare class FormulaShapeError extends Error {
    readonly shape: 'star' | 'alias';
    name: string;
    constructor(shape: 'star' | 'alias', message: string);
}
/**
 * The one place deciding what a formula column's stored text may be. Enters at
 * the field rule rather than the expression rule, so a formula reaches the
 * subquery and linked-collection shapes a query's field list already accepts.
 */
export declare function parseFormula(source: string): FormulaBody;
/**
 * For the readers that must keep working on a formula they cannot parse — the
 * reported type, the policy-key walk, the dependency collector, the cycle walk.
 * Named so the choice to degrade is visible at the call site.
 */
export declare function tryParseFormula(source: string): FormulaBody | null;
export interface FormulaParseFailure {
    message: string;
    line?: number;
    column?: number;
}
export type FormulaParseOutcome = {
    ok: true;
    body: FormulaBody;
} | ({
    ok: false;
} & FormulaParseFailure);
/**
 * `parseFormula`'s outcome as data. For a caller reporting the parser's own
 * line and column, a local `catch` around `parseFormula` reads as a swallow
 * indistinguishable from the sites that discard the reason entirely — this
 * is the one place that inspects `ParserDiagnosticsError` / `FormulaShapeError`
 * on a caller's behalf, so no reader duck-types `err.diagnostics` itself.
 */
export declare function parseFormulaOutcome(source: string): FormulaParseOutcome;
