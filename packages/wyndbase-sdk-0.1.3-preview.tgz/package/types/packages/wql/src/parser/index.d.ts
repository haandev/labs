import type { Expression, Query } from '../ast/nodes';
interface QuerySource {
    source: string;
}
/**
 * Parse WynQL source code into AST
 */
export declare function parse(source?: string | null): Query[];
export declare function getParseStats(): {
    sllHits: number;
    llHits: number;
};
export declare function resetParseStats(): void;
export declare function splitQueries(source?: string | null): QuerySource[];
/**
 * Parse a WQL expression string into an Expression AST node. Used by formula
 * columns to convert their expression definitions into AST.
 */
export declare function parseExpression(source: string): Expression;
export type { FormulaBody, FormulaParseFailure, FormulaParseOutcome, } from './formula';
export { FormulaShapeError, parseFormula, parseFormulaOutcome, tryParseFormula, } from './formula';
export type { Expression, Query };
