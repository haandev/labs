import type { Expression } from '../ast/nodes';
export interface DelegatorContext {
    userId: string;
    roles: string[];
}
export type RewriteResult = {
    status: 'unchanged';
    expression: Expression;
}
/** `text` is the rule text the read is compiled against. It is produced here
 * so a caller cannot reach a tree the printer would refuse. */
 | {
    status: 'rewritten';
    expression: Expression;
    text: string;
} | {
    status: 'unrewritable';
    reason: string;
};
/** Rewrite a delegated rule's expression so it names the delegator. Skips the
 *  walk entirely when nothing is rewritable (`containsRewritable` short-
 *  circuits on the first hit), and fails CLOSED on `unrewritable` — the
 *  delegate reads what they could read without the delegation. */
export declare function rewriteForDelegator(expr: Expression, delegator: DelegatorContext): RewriteResult;
