import type { ColumnNode, ResolvedTable, WynModel } from '../../../model/src/types';
/** Find a table by name (id, physicalName, or name, in that priority). */
export declare function findTable(model: WynModel, name: string): ResolvedTable | undefined;
/** Find a column in a table by name (id, physicalName, or name, in that priority). */
export declare function findColumn(model: WynModel, tableName: string, columnName: string): ColumnNode | undefined;
/** Find a link column in a table by name; returns undefined if not a link. */
export declare function findLink(model: WynModel, tableName: string, linkName: string): ColumnNode | undefined;
