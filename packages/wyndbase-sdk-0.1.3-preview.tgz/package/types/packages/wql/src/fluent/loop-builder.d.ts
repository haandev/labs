import type { QueryBody } from '../ast/nodes';
import type { QueryBuilder } from './query-builder';
import type { Expr } from './types';
/**
 * Fluent builder for LOOP (recursive / hierarchical) queries.
 *
 * Usage:
 * ```ts
 * loop('employees')
 *   .anchorCondition(eq('managerId', null))
 *   .childColumn('managerId')
 *   .parentColumn('id')
 *   .queryBody(from('employees').select('*'))
 *   .buildBody()
 * ```
 */
export declare class LoopBuilder {
    private tableName;
    private anchorExpr?;
    private child?;
    private parent?;
    private innerBody?;
    constructor(table: string);
    /** Set the anchor (root) condition, e.g. `eq('managerId', null)` */
    anchorCondition(condition: Expr): LoopBuilder;
    /** Set the child column used for the recursive join (e.g. `'managerId'`) */
    childColumn(column: string): LoopBuilder;
    /** Set the parent column used for the recursive join (e.g. `'id'`) */
    parentColumn(column: string): LoopBuilder;
    /** Set the inner query body that defines projections, filters, etc. */
    queryBody(body: QueryBuilder | QueryBody): LoopBuilder;
    /** Build the QueryBody containing a LoopExpr */
    buildBody(): QueryBody;
}
/** Start building a LOOP query from a table */
export declare function loop(table: string): LoopBuilder;
