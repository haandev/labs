import type { Aggregation, CTEBody, Derivation, Expression, Query, QueryBody, QueryStatement, WindowSpec } from '../ast/nodes';
import { type ExpressionBuilder } from './helpers';
import { QueryStatementBuilder } from './statement-builder';
import { SummarizeBuilder } from './summarize-builder';
import type { Expr, ProjectionInput, SortInput } from './types';
/** Date part extraction: `datePart('year', col('orderDate'))` → `date_part('year', "orderDate")` */
export declare function datePart(part: string, expr: Expr): ExpressionBuilder;
/** Start a query from a table */
export declare function from(table: string): QueryBuilder;
/** Start a query from a CTE */
export declare function fromCte(cteName: string): QueryBuilder;
export declare class QueryBuilder {
    private tableName;
    private alias?;
    private isCte;
    private projections;
    private isDistinct;
    private isHard;
    private summarizing;
    private groupByExprs;
    private groupByAliases;
    private aggregations;
    private derivations;
    private filterExpr?;
    private sortItems;
    private takeLimit?;
    private takeOffset?;
    private selectLock?;
    private windows;
    private ctes;
    private linkDefs;
    constructor(tableName: string, isCte?: boolean);
    as(alias: string): QueryBuilder;
    select(...columns: ProjectionInput[]): QueryBuilder;
    distinct(): QueryBuilder;
    /** Mark query as HARD — bypass auto soft-filter (endAt IS NULL) */
    hardQuery(): QueryBuilder;
    lockUpdate(opts?: {
        skipLocked?: boolean;
        nowait?: boolean;
    }): QueryBuilder;
    summarize(): SummarizeBuilder;
    withWindow(name: string, spec: WindowSpec): QueryBuilder;
    withCte(name: string, body: CTEBody): QueryBuilder;
    withLink(name: string, opts: {
        source: string;
        target: string;
        on?: string;
        multi?: boolean;
    }): QueryBuilder;
    filter(condition: Expr): QueryBuilder;
    orderBy(...items: SortInput[]): QueryBuilder;
    take(limit?: number, offset?: number): QueryBuilder;
    /** Internal: set group by from SummarizeBuilder */
    _setGroupBy(exprs: Expression[], aliases?: (string | undefined)[]): void;
    /** Internal: add aggregation from SummarizeBuilder */
    _addAggregation(agg: Aggregation): void;
    /** Internal: add derivation from SummarizeBuilder */
    _addDerivation(derivation: Derivation): void;
    buildBody(): QueryBody;
    buildStatement(): QueryStatement;
    build(): Query;
    asStatement(): QueryStatementBuilder;
    union(next: QueryBuilder | QueryBody): QueryStatementBuilder;
    unionAll(next: QueryBuilder | QueryBody): QueryStatementBuilder;
    intersect(next: QueryBuilder | QueryBody): QueryStatementBuilder;
    except(next: QueryBuilder | QueryBody): QueryStatementBuilder;
    exceptAll(next: QueryBuilder | QueryBody): QueryStatementBuilder;
}
