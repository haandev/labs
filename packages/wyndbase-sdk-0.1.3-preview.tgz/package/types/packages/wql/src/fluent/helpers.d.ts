import type { Derivation, Expression, FrameBound, LinkArrayAggExpr, NestedSubquery, Projection, QueryBody, SortItem, TableRef, WindowSpec } from '../ast/nodes';
import type { Expr, ProjectionInput, SortInput } from './types';
import type { WindowSpecOptions } from './windows';
export declare class ExpressionBuilder {
    private expr;
    constructor(expr: Expression);
    getExpression(): Expression;
}
export declare function col(name: string): ExpressionBuilder;
export declare function lit(value: string | number | boolean | null): ExpressionBuilder;
export declare function toExpression(expr: Expr): Expression;
export declare function toExprBuilder(expr: Expr): ExpressionBuilder;
export declare function binary(op: string, left: Expr, right: Expr): ExpressionBuilder;
export declare function isExpression(value: unknown): value is Expression;
export declare function normalizeProjections(input: ProjectionInput): Projection[];
export declare function toSortItem(item: SortInput): SortItem;
export declare function resolveBody(body: QueryBody | {
    buildBody(): QueryBody;
}): QueryBody;
export declare function toTableRef(name: string): TableRef;
export declare function emptyBody(): QueryBody;
export declare function parseLinkRef(linkRef: string): {
    linkColumn: string;
    joinType: NestedSubquery['joinType'];
    hasOperator: boolean;
};
export declare function toFrameBound(value?: NonNullable<WindowSpecOptions['frame']>['start']): FrameBound;
export declare function isDerivation(item: {
    alias?: string;
    expr: Expr;
} | Derivation): item is Derivation;
export declare function isNestedSubquery(value: unknown): value is NestedSubquery;
export declare function isLinkArrayAggExpr(value: unknown): value is LinkArrayAggExpr;
export declare function isWindowSpec(spec: WindowSpecOptions | WindowSpec): spec is WindowSpec;
export declare function splitTableName(name: string): {
    schema?: string;
    name: string;
};
