import type { CTEBody, CTEDefinition, Query, QueryBody, QueryStatement, WindowSpec } from '../ast/nodes';
import type { QueryBuilder } from './query-builder';
/** Build a query statement from a body */
export declare function statement(body: QueryBuilder | QueryBody): QueryStatementBuilder;
export declare function cteDefinition(name: string, body: CTEBody): CTEDefinition;
export declare class QueryStatementBuilder {
    private windows;
    private ctes;
    private bodies;
    private setOps;
    constructor(firstBody: QueryBody);
    withWindow(name: string, spec: WindowSpec): QueryStatementBuilder;
    withCte(name: string, body: CTEBody): QueryStatementBuilder;
    union(body: QueryBuilder | QueryBody): QueryStatementBuilder;
    unionAll(body: QueryBuilder | QueryBody): QueryStatementBuilder;
    intersect(body: QueryBuilder | QueryBody): QueryStatementBuilder;
    except(body: QueryBuilder | QueryBody): QueryStatementBuilder;
    exceptAll(body: QueryBuilder | QueryBody): QueryStatementBuilder;
    buildStatement(): QueryStatement;
    build(): Query;
    private addSetOp;
}
