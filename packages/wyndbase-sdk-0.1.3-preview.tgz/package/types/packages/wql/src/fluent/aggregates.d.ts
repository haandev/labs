import type { Aggregation, Expression, WindowSpec } from '../ast/nodes';
import type { Expr } from './types';
export declare class AggregateBuilder {
    private func;
    private arg;
    private filterExpr?;
    private windowRef?;
    constructor(func: string, arg: Expression | '*');
    filter(condition: Expr): AggregateBuilder;
    over(win: string | WindowSpec): AggregateBuilder;
    as(alias: string): Aggregation;
    build(alias?: string): Aggregation;
    private buildExpression;
}
export declare function sum(expr: Expr): AggregateBuilder;
export declare function avg(expr: Expr): AggregateBuilder;
export declare function count(expr?: Expr | '*'): AggregateBuilder;
export declare function min(expr: Expr): AggregateBuilder;
export declare function max(expr: Expr): AggregateBuilder;
export declare function median(expr: Expr): AggregateBuilder;
export declare function stdev(expr: Expr): AggregateBuilder;
export declare function variance(expr: Expr): AggregateBuilder;
export declare function arrayAgg(expr: Expr): AggregateBuilder;
export declare function jsonAgg(expr: Expr): AggregateBuilder;
export declare function list(expr: Expr): AggregateBuilder;
