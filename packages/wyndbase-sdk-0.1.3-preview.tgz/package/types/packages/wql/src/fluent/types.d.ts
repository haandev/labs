import type { Expression, LinkArrayAggExpr, NestedSubquery, Projection, SortItem } from '../ast/nodes';
import type { ExpressionBuilder } from './helpers';
export type Expr = string | number | boolean | null | Expression | ExpressionBuilder;
export type ProjectionInput = '*' | string | Expr | Projection | NestedSubquery | LinkArrayAggExpr | {
    [alias: string]: Expr | NestedSubquery | LinkArrayAggExpr;
};
export type SortInput = string | {
    col: string;
    dir?: 'ASC' | 'DESC';
    nulls?: 'FIRST' | 'LAST';
} | SortItem;
