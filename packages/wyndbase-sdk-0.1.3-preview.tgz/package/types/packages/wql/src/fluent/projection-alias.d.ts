import type { Projection } from '../ast/nodes';
import type { ProjectionInput } from './types';
/**
 * Names a projection's result column. Prefer this over `{ [alias]: expr }` —
 * that form silently mishandles an annotated projection (e.g. `decrypt()`).
 */
export declare function aliased(name: string, projection: ProjectionInput): Projection;
