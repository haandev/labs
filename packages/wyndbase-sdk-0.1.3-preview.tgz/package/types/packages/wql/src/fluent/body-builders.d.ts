import type { Aggregation, Derivation, LinkDefinition, NestedSubquery, QueryBody } from '../ast/nodes';
import { AggregateBuilder } from './aggregates';
import type { QueryBuilder } from './query-builder';
import type { SummarizeBuilder } from './summarize-builder';
import type { Expr, ProjectionInput, SortInput } from './types';
/** Build a SELECT query body */
export declare function selectBody(table: string, builder?: (q: QueryBuilder) => QueryBuilder): QueryBody;
/** Build a SUMMARIZE query body */
export declare function summarizeBody(table: string, builder: (s: SummarizeBuilder) => QueryBuilder): QueryBody;
/** Build a RANK query body */
export declare function rankBody(opts: {
    table: string;
    projections: ProjectionInput[];
    rankColumns: string[];
    limit: number;
    direction: 'top' | 'bottom';
    includeRest?: boolean;
}): QueryBody;
/** Build a LOOP query body */
export declare function loopBody(opts: {
    anchorCondition: Expr;
    childColumn: string;
    parentColumn: string;
    queryBody: QueryBody;
}): QueryBody;
/** Nested SELECT subquery */
export declare function nestedSelect(linkRef: string, projections: ProjectionInput[], opts?: {
    filter?: Expr;
    orderBy?: SortInput[];
    take?: {
        limit: number;
        offset?: number;
    };
    links?: LinkDefinition[];
    first?: boolean;
    expand?: boolean;
    hard?: boolean;
}): NestedSubquery;
/** Nested SUMMARIZE subquery */
export declare function nestedSummarize(linkRef: string, aggregations: (AggregateBuilder | Aggregation)[], opts?: {
    groupBy?: (string | Expr)[];
    derive?: ({
        alias?: string;
        expr: Expr;
    } | Derivation)[];
    filter?: Expr;
    orderBy?: SortInput[];
    take?: {
        limit: number;
        offset?: number;
    };
    links?: LinkDefinition[];
    first?: boolean;
    expand?: boolean;
    hard?: boolean;
}): NestedSubquery;
