import type { Aggregation, Derivation } from '../ast/nodes';
import { AggregateBuilder } from './aggregates';
import type { QueryBuilder } from './query-builder';
import type { Expr } from './types';
export declare class SummarizeBuilder {
    private query;
    constructor(query: QueryBuilder);
    /** A key given as `{ alias, expr }` is projected under `alias`; `GROUP BY`
     *  still keys on the expression itself. Without one, the key keeps the name
     *  derived from its expression. */
    groupBy(...columns: (string | Expr | {
        alias: string;
        expr: string | Expr;
    })[]): SummarizeBuilder;
    derive(...items: ({
        alias?: string;
        expr: Expr;
    } | Derivation)[]): SummarizeBuilder;
    aggregate(...aggs: (AggregateBuilder | Aggregation)[]): QueryBuilder;
}
