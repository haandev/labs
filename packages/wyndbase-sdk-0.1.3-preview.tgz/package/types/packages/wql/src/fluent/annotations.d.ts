import type { Projection } from '../ast/nodes';
import type { ProjectionInput } from './types';
/** Attach an annotation to a projection */
export declare function annotate(name: string, projection: ProjectionInput, args?: Record<string, string | number | boolean>): Projection;
/** @mask annotation — masks sensitive data in output */
export declare function mask(projection: ProjectionInput): Projection;
/** @unmask annotation — reveals masked data */
export declare function unmask(projection: ProjectionInput): Projection;
/** @encrypt annotation — encrypts data before storage */
export declare function encrypt(projection: ProjectionInput): Projection;
/** @decrypt annotation — decrypts encrypted data */
export declare function decrypt(projection: ProjectionInput): Projection;
/** @hard annotation — bypasses auto soft-filter on nested subqueries and EXISTS */
export declare function hard(projection: ProjectionInput): Projection;
