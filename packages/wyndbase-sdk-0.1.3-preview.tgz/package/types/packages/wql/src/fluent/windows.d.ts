import type { Expression, WindowDefinition, WindowSpec } from '../ast/nodes';
import type { AggregateBuilder } from './aggregates';
import { ExpressionBuilder } from './helpers';
import type { Expr } from './types';
export interface WindowSpecOptions {
    group?: string | string[];
    sort?: string | {
        col: string;
        dir?: 'ASC' | 'DESC';
    }[];
    expanding?: boolean;
    rolling?: number;
    frame?: {
        mode: 'ROWS' | 'RANGE';
        start?: 'UNBOUNDED_PRECEDING' | 'UNBOUNDED_FOLLOWING' | 'CURRENT' | number;
        end?: 'UNBOUNDED_PRECEDING' | 'UNBOUNDED_FOLLOWING' | 'CURRENT' | number;
    };
}
export declare class WindowBuilder {
    private func;
    private args;
    constructor(func: string, args?: Expression[]);
    over(spec: WindowSpecOptions | string): ExpressionBuilder;
}
export declare function buildWindowSpec(opts: WindowSpecOptions): WindowSpec;
/** Create a window definition */
export declare function windowDef(name: string, spec: WindowSpecOptions | WindowSpec): WindowDefinition;
export declare function rowNumber(): WindowBuilder;
export declare function rank(): WindowBuilder;
export declare function denseRank(): WindowBuilder;
export declare function lag(expr: Expr, offset?: number): WindowBuilder;
export declare function lead(expr: Expr, offset?: number): WindowBuilder;
export declare function firstValue(expr: Expr): WindowBuilder;
export declare function lastValue(expr: Expr): WindowBuilder;
export declare function window(_name: string, agg: AggregateBuilder, spec: WindowSpecOptions): AggregateBuilder;
