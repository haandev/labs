import { ExpressionBuilder } from './helpers';
import type { Expr } from './types';
/** JSONB key exists: `metadata ? 'key'` */
export declare function jsonHasKey(expr: Expr, key: Expr): ExpressionBuilder;
/** JSONB all keys exist: `metadata ?& array['k1','k2']` */
export declare function jsonHasAllKeys(expr: Expr, keys: Expr): ExpressionBuilder;
/** JSONB any key exists: `metadata ?| array['k1','k2']` */
export declare function jsonHasAnyKey(expr: Expr, keys: Expr): ExpressionBuilder;
/** JSONB path extract: `metadata #> '{path}'` */
export declare function jsonPath(expr: Expr, path: Expr): ExpressionBuilder;
/** JSONB path extract as text: `metadata #>> '{path}'` */
export declare function jsonPathText(expr: Expr, path: Expr): ExpressionBuilder;
/** Range contains: `range @> element` */
export declare function rangeContains(expr: Expr, value: Expr): ExpressionBuilder;
/** Range contained by: `element <@ range` */
export declare function rangeContainedBy(expr: Expr, range: Expr): ExpressionBuilder;
/** Range overlap: `range1 && range2` */
export declare function rangeOverlaps(expr: Expr, other: Expr): ExpressionBuilder;
/** Range adjacent: `range1 -|- range2` */
export declare function rangeAdjacent(expr: Expr, other: Expr): ExpressionBuilder;
/** Full-text match: `doc @@ query` */
export declare function fullTextMatch(expr: Expr, query: Expr): ExpressionBuilder;
/** Regex match (case sensitive): `text ~ pattern` */
export declare function regexMatch(expr: Expr, pattern: Expr): ExpressionBuilder;
/** Regex match (case insensitive): `text ~* pattern` */
export declare function regexMatchCI(expr: Expr, pattern: Expr): ExpressionBuilder;
