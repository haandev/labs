import type { Expression, LinkArrayAggExpr, LinkOperator, ParameterMeta, RangeExpr, SortItem, TableRef, WindowRef } from '../ast/nodes';
import { ExpressionBuilder } from './helpers';
import type { Expr } from './types';
export { col, ExpressionBuilder, lit } from './helpers';
export declare function sql(sqlExpr: string): ExpressionBuilder;
export declare function expr(expression: Expression): ExpressionBuilder;
/** Generic parameter reference: paramRef("context.userId"), paramRef("myParam") */
export declare function paramRef(name: string, metadata?: ParameterMeta): ExpressionBuilder;
export declare function arrayLiteral(...values: Expr[]): ExpressionBuilder;
export declare function range(start?: Expr, end?: Expr, opts?: {
    startInclusive?: boolean;
    endInclusive?: boolean;
}): ExpressionBuilder;
export declare function inList(expr: Expr, values: Expr[], negated?: boolean): ExpressionBuilder;
export declare function inRange(expr: Expr, rangeExpr: RangeExpr, negated?: boolean): ExpressionBuilder;
export declare function between(expr: Expr, low: Expr, high: Expr, negated?: boolean): ExpressionBuilder;
export declare function like(expr: Expr, pattern: Expr, negated?: boolean): ExpressionBuilder;
export declare function isNull(expr: Expr, negated?: boolean): ExpressionBuilder;
/**
 * Full-text match against `column`'s search vector. `column` must be
 * single-segment — a link-navigated path resolves differently than generation reads it, letting a masked column's search leak past its permission check.
 */
export declare function search(column: Expr, term: Expr): ExpressionBuilder;
/**
 * Full-text match against a table's searchable columns. With no `columns`,
 * resolves to every searchable column minus encrypted/masked ones; each named column must be single-segment for the same reason `search()` enforces it.
 */
export declare function tableSearch(term: Expr, columns?: readonly (Expr | string)[]): ExpressionBuilder;
export declare function exists(source: TableRef | string, predicate: Expr, negated?: boolean): ExpressionBuilder;
export declare function cast(expr: Expr, target: string): ExpressionBuilder;
export declare function caseExpr(branches: {
    when: Expr;
    then: Expr;
}[], elseResult?: Expr): ExpressionBuilder;
export declare function linkExpr(operator: LinkOperator, column: string, ...path: string[]): ExpressionBuilder;
/** Column reference with link navigation (e.g., >customer.companyName) */
export declare function linkCol(operator: LinkOperator, column: string, ...path: string[]): ExpressionBuilder;
export declare function fn(name: string, args?: Expr[], opts?: {
    filter?: Expr;
    over?: WindowRef;
}): ExpressionBuilder;
export declare function linkArrayAgg(source: string, column: string, opts?: {
    distinct?: boolean;
    orderBy?: SortItem[];
}): LinkArrayAggExpr;
export declare function eq(left: Expr, right: Expr): ExpressionBuilder;
export declare function neq(left: Expr, right: Expr): ExpressionBuilder;
export declare function gt(left: Expr, right: Expr): ExpressionBuilder;
export declare function gte(left: Expr, right: Expr): ExpressionBuilder;
export declare function lt(left: Expr, right: Expr): ExpressionBuilder;
export declare function lte(left: Expr, right: Expr): ExpressionBuilder;
export declare function and(...conditions: Expr[]): ExpressionBuilder;
export declare function or(...conditions: Expr[]): ExpressionBuilder;
export declare function not(expr: Expr): ExpressionBuilder;
export declare function add(left: Expr, right: Expr): ExpressionBuilder;
export declare function sub(left: Expr, right: Expr): ExpressionBuilder;
export declare function mul(left: Expr, right: Expr): ExpressionBuilder;
export declare function div(left: Expr, right: Expr): ExpressionBuilder;
