import type { DeleteStatement, InsertStatement, LinkDefinition, LinkLookup, MutationArray, MutationArrayItem, MutationField, MutationObject, MutationSpread, MutationValue, NestedInsert, OnConflictClause, Query, ReturningSpec, TableName, TableRef, TransactionBlock, UpdateStatement, UpsertStatement } from '../ast/nodes';
import type { Expr } from './types';
export declare function table(name: string): TableName;
export declare function tableRef(name: string): TableRef;
export declare function returning(...exprs: Expr[]): ReturningSpec;
export declare function mutationField(name: string, value: MutationValue): MutationField;
export declare function mutationObject(...fields: (MutationField | MutationSpread)[]): MutationObject;
export declare function mutationArray(...items: MutationArrayItem[]): MutationArray;
export declare function nestedInsert(object: MutationObject, opts?: {
    returning?: ReturningSpec;
}): NestedInsert;
export declare function linkLookup(opts: {
    mode?: 'strict' | 'nullable';
    message?: Expr;
    table: string;
    predicate: Expr;
    update?: MutationObject;
}): LinkLookup;
export declare function onConflict(columns: string[], action: 'DO UPDATE' | 'DO NOTHING', updateObject?: MutationObject): OnConflictClause;
export declare function insertStatement(tableName: string, object: MutationObject, opts?: {
    onConflict?: OnConflictClause;
    returning?: ReturningSpec;
}): InsertStatement;
export declare function updateStatement(tableName: string, guard: Expr, object: MutationObject, opts?: {
    hard?: boolean;
    returning?: ReturningSpec;
}): UpdateStatement;
export declare function upsertStatement(tableName: string, guard: Expr, object: MutationObject, opts?: {
    hard?: boolean;
    returning?: ReturningSpec;
}): UpsertStatement;
export declare function deleteStatement(tableName: string, guard: Expr, opts?: {
    hard?: boolean;
    returning?: ReturningSpec;
}): DeleteStatement;
export declare function transactionBlock(statements: Query['statements'], opts?: {
    errorMessage?: Expr;
    endAction?: 'COMMIT' | 'ROLLBACK';
}): TransactionBlock;
/** Create an ad-hoc LINK definition for query-level JOINs */
export declare function linkDef(name: string, opts: {
    source: string;
    target: string;
    on?: string;
    multi?: boolean;
}): LinkDefinition;
