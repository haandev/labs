/**
 * Schema Inference
 *
 * Infers the expected result row schema from a WQL AST and WynModel.
 * Runs as a lightweight second pass over the AST — does NOT produce SQL,
 * only determines the shape of each result column.
 *
 * Internally uses Zod types throughout the pipeline.
 * Conversion to JSON Schema (FieldSchema) happens once at the generateSQL boundary.
 */
export type { RowSchema } from '../types';
export type { SummarizeOutputName } from './helpers';
export { allocateOutputName, deriveAlias, summarizeOutputNames, } from './helpers';
export { inferSchema, inferSchemaWithIssues } from './infer-schema';
export { containsMutationStatement } from './mutation-inference';
export type { ResolutionIssue } from './resolution-issues';
export { decimalUnionSchema, getZodBaseType, isDecimalUnion, unwrapNullable, zodBaseToRegistryType, } from './zod-utils';
