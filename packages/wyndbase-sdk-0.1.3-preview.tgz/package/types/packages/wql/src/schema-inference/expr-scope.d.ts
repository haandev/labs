import type { z } from 'zod';
export type ExprScope = ReadonlyMap<string, z.ZodType>;
