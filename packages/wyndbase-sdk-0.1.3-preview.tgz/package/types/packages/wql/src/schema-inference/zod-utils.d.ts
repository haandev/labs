import { z } from 'zod';
/**
 * Runtime shape of an exact numeric (`numeric`/`decimal`) expression: the
 * driver returns PG `numeric` cells as strings to preserve precision, while
 * historical float-typed expressions still produce JS numbers.
 */
export declare const decimalUnionSchema: z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>;
/**
 * True when the (nullable-unwrapped) schema is THE decimal union — the
 * shared instance or a schema carrying its marker. A bare structural check
 * would misclassify ad-hoc string∣number unions (e.g. `text ?? float`
 * COALESCE results) as decimal.
 */
export declare function isDecimalUnion(zod: z.ZodType): boolean;
/**
 * Wrap a Zod type with nullable if not already nullable.
 * Strips optional wrapper if present — ensureNullable is for expression-level
 * nullable semantics (e.g. link path traversal), not field-level optional.
 */
export declare function ensureNullable(zod: z.ZodType): z.ZodType;
/**
 * Unwrap optional and nullable wrappers, returning the inner base type.
 * Handles both `nullable(T)` and `optional(nullable(T))` patterns.
 */
export declare function unwrapNullable(zod: z.ZodType): z.ZodType;
/**
 * Check whether a Zod type is nullable (wrapped in `z.nullable(...)` or
 * `z.optional(z.nullable(...))`). Mirrors the unwrap pattern used by
 * `unwrapNullable` + `getZodBaseType` so callers agree on nullability
 * semantics.
 */
export declare function isNullableSchema(zod: z.ZodType): boolean;
/**
 * Extract the base type string from a Zod type (unwraps optional + nullable).
 * Returns JSON Schema type names: 'string', 'integer', 'number', 'boolean', 'array', 'object'.
 * Returns undefined for unknown types.
 */
export declare function getZodBaseType(zod: z.ZodType): string | undefined;
/**
 * Map a Zod base type (as returned by {@link getZodBaseType}) to a value
 * registered in `@wyndb/models`'s `columnRegistry` so that synthetic
 * ColumnNodes (built from CTE/NQ result schemas) survive validation when
 * passed through `getColumnConstructor`.
 *
 * The Zod base names (`'string'`, `'object'`, …) are JSON-Schema-flavored
 * and don't line up with PG type names. This mapping is the single point
 * of translation; both CTE and NQ synthetic-column construction route
 * through it.
 */
export declare function zodBaseToRegistryType(zodBase: string | undefined): string;
