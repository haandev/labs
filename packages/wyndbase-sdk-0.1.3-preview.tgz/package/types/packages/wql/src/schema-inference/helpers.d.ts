import type { Expression, Projection, SummarizeClause } from '../ast/nodes';
/** `*` in either spelling — the literal the parser keeps and the `StarExpr` node. */
export declare function isStarProjection(proj: Projection): boolean;
/**
 * Output key for an expression with no explicit alias. Undelimits exactly
 * once here — a caller with an explicit alias picks between it and this.
 */
export declare function deriveAlias(expr: Expression): string;
/** First free name in `base`, `base_2`, `base_3`, … */
export declare function allocateOutputName(base: string, taken: {
    has(name: string): boolean;
}): string;
/** Where a SUMMARIZE result column takes its value from. */
export interface SummarizeOutputName {
    name: string;
    from: 'groupBy' | 'aggregation';
    index: number;
}
/** Ordered, de-duplicated result columns of a SUMMARIZE. */
export declare function summarizeOutputNames(summarize: SummarizeClause): SummarizeOutputName[];
