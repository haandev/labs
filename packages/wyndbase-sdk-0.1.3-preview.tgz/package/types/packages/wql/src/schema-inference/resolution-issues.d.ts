import type { Position } from '../ast/nodes';
/**
 * A name inference could not resolve against the model. Inference answers
 * `z.unknown()` in that case, which is indistinguishable from a legitimately
 * open type; this is the channel that says which of the two happened.
 */
export interface ResolutionIssue {
    kind: 'table' | 'column';
    name: string;
    /** Qualified table a column issue was raised against; unset for a table. */
    table?: string;
    /**
     * Whatever the offending AST node carried. The parser does not populate
     * `ASTNode.position` today, so this is undefined in practice — a diagnostic
     * built on it can name the query but not a line within it.
     */
    position?: Position;
}
/** No-op unless a `collectResolutionIssues` scope is open. */
export declare function reportResolutionIssue(issue: ResolutionIssue): void;
export declare function collectResolutionIssues<T>(run: () => T): {
    value: T;
    issues: ResolutionIssue[];
};
