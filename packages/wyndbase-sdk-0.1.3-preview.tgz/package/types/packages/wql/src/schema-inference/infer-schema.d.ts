import type { SchemaProviderFactory } from '../../../model/src/types';
import type { WynModelTree } from '../../../model/src/utils/index';
import type { z } from 'zod';
import type { CTEDefinition, Query, Statement, TransactionBlock } from '../ast/nodes';
import { type ResolutionIssue } from './resolution-issues';
/**
 * Infer the result row schema for a set of parsed WQL queries.
 *
 * Returns a z.ZodObject (created via z.strictObject) or undefined when:
 * - No model is provided (column types cannot be resolved)
 * - No SELECT-type statement is found (mutations without RETURNING)
 *
 * Nullable fields are already wrapped with z.optional(z.nullable(...)) at the
 * get outputSchema() source, so they are automatically excluded from `required` when
 * toJSONSchema() is called.
 */
export declare function inferSchema(queries: Query[], model?: WynModelTree, factory?: SchemaProviderFactory): z.ZodObject | undefined;
/**
 * `inferSchema` plus the names it could not resolve. The schema is the one
 * `inferSchema` returns — collecting issues observes inference, it does not
 * steer it.
 */
export declare function inferSchemaWithIssues(queries: Query[], model?: WynModelTree, factory?: SchemaProviderFactory): {
    schema: z.ZodObject | undefined;
    issues: ResolutionIssue[];
};
export declare function inferSchemaInternal(queries: Query[], model?: WynModelTree, visitedNQs?: Set<string>, factory?: SchemaProviderFactory): z.ZodObject | undefined;
/** Collect CTEDefinition statements into a name→definition map */
export declare function collectCTEDefinitions(statements: Statement[]): Map<string, CTEDefinition>;
/**
 * Infer schema from a TransactionBlock by walking its nested statements backwards.
 * The last result-producing statement (SELECT or mutation with RETURNING) determines the schema.
 */
export declare function inferTransactionBlockSchema(block: TransactionBlock, model: WynModelTree, f: SchemaProviderFactory, visitedNQs?: Set<string>): z.ZodObject | undefined;
