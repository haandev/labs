import type { SchemaProviderFactory } from '../../../model/src/types';
import type { WynModelTree } from '../../../model/src/utils/index';
import { z } from 'zod';
import type { Query, ReturningSpec, Statement } from '../ast/nodes';
/** Check if a statement is any mutation type, with or without RETURNING */
export declare function isMutationStatement(stmt: Statement): boolean;
/**
 * Whether the parsed program contains any mutation statement at all —
 * directly, inside a transaction block, or as a CTE body in a mutation
 * chain. Used by typegen to tell a RETURNING-less mutation (a real query
 * whose result is simply untyped) apart from a program with no result.
 */
export declare function containsMutationStatement(queries: Query[]): boolean;
/** Check if a statement is a mutation type that has a RETURNING clause */
export declare function isMutationWithReturning(stmt: Statement): boolean;
/** Extract the RETURNING spec from any mutation statement */
export declare function getMutationReturning(stmt: Statement): ReturningSpec | undefined;
/** Extract the table name from any mutation statement */
export declare function getMutationTableName(stmt: Statement): {
    schema?: string;
    name: string;
} | undefined;
/**
 * Infer schema from a mutation statement's RETURNING clause.
 * Works like inferSelectSchema but uses the mutation's target table as the resolved table.
 */
export declare function inferMutationReturningSchema(stmt: Statement, model: WynModelTree, f: SchemaProviderFactory, visitStack?: readonly string[]): z.ZodObject | undefined;
