/**
 * A DCL target as written, mapped onto the one `DecisionTarget` union
 * `@wyndb/models/decision-key` owns. Deriving a key anywhere else would be a
 * second formatter, and a mismatched key silently denies or grants nothing.
 */
import { type DecisionTarget } from '../../../model/src/decision-key';
/** Raised while desugaring, so a caller can tell a DCL refusal from a parse error. */
export declare class DclError extends Error {
    constructor(message: string);
}
/** Two parts name a table, three a column or a link on one. */
export declare function readModelTarget(operation: string, path: string[]): DecisionTarget;
/** `GRANT draft -> sent ON shop.invoice.status`. The column is mandatory. */
export declare function readTransitionTarget(from: string, to: string, path: string[]): DecisionTarget;
/** `POLICY state:approved ON shop.invoice.status`. The column is mandatory. */
export declare function readStateTarget(stateId: string, path: string[]): DecisionTarget;
/**
 * `parseDecisionKey` is the one formatter/parser pair in the repository, so
 * "a key it can parse is not a policy key" is an exact test. Without it,
 * `POLICY 'shop.invoice.row.read'` would be an unconditional grant in policy
 * clothing.
 *
 * The right remediation differs by statement: a fresh `POLICY`/`GRANT`/
 * `PREVENT` can just be rewritten as a target, but `ALTER POLICY`/
 * `DROP POLICY` are addressing an EXISTING row, and the Addressing table's
 * own answer for a model decision key there is the guard form —
 * `ALTER POLICY [key == '...']` / `DROP POLICY [key == '...']` — not a
 * target GRANT/PREVENT, which creates or narrows a grant rather than
 * addressing one.
 */
export declare function assertPolicyKey(key: string, verb: 'POLICY' | 'ALTER POLICY' | 'DROP POLICY'): string;
