/**
 * The inverse of `desugar.ts`: a stored `system.decision_matrix` row printed
 * back as the DCL statement that would write it. The console's matrix editor
 * is the authoring surface for non-seed rules; a SEED rule edited there would
 * be overwritten at the next instance install, so the main base's matrix is
 * exported through here and pasted into
 * `packages/driver/src/features/policy/system-rules.wql` by hand.
 *
 * Paste-compatibility is the whole contract, and `dcl-print.test.ts` holds it
 * by round-tripping every shape through `parse` and comparing the desugared
 * INSERT's fields against the row that produced the text.
 */
import { DclError } from './targets';
/**
 * One matrix row, with its link columns already resolved to names. `key` gives
 * the SHAPE (row / cell / link / transition / state); the identity columns and
 * the resolved names give the CONTENT, because they are what the row actually
 * stores — a key is derived at write time and a later rename leaves it stale.
 */
export interface DecisionMatrixExportRow {
    key: string;
    effect: 'permit' | 'prevent' | string | null;
    /** Resolved through `tableId.parent.name`. Falls back to the key. */
    spaceName?: string | null;
    /** Resolved through `tableId.name`. Falls back to the key. */
    tableName?: string | null;
    /** Resolved through `columnId.name`. Falls back to the key. */
    columnName?: string | null;
    /** `role.name`; NULL is the universal rule, written `TO ALL`. */
    roleName?: string | null;
    expression?: string | null;
    minAal?: number | null;
    isDelegatable?: boolean | null;
    enabled?: boolean | null;
    lock?: boolean | null;
    description?: string | null;
    fsmFrom?: string | null;
    fsmTo?: string | null;
    fsmStateId?: string | null;
}
/** A row no DCL statement can spell. Raised rather than printed wrong. */
export declare class DclPrintError extends DclError {
    constructor(message: string);
}
/** One matrix row as the DCL statement that would write it, `;` included. */
export declare function printDecisionRule(row: DecisionMatrixExportRow): string;
/**
 * The whole matrix as one `system.wql`-shaped document: the named policies in
 * dependency order, then the rules grouped by the table they govern.
 */
export declare function printSystemRules(rows: DecisionMatrixExportRow[]): string;
