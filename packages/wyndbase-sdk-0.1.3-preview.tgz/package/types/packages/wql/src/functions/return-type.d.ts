import { z } from 'zod';
import type { FunctionCall } from '../ast/nodes';
import type { InferenceContext, ReturnResolver } from './types';
export declare function resolveFunctionReturnType(fn: FunctionCall, ctx: InferenceContext): z.ZodType;
/** sum — preserves input type. */
export declare const sumReturns: ReturnResolver;
/** avg — exact numeric input keeps its string-preserving shape. */
export declare const avgReturns: ReturnResolver;
/**
 * First-argument type, unmodified — shared verbatim by min/max, the window
 * value functions (lag/lead/first_value/last_value/nth_value) and
 * greatest/least, all of which had this identical case body in the switch.
 */
export declare const firstArgTypeReturns: ReturnResolver;
/** COALESCE: first argument type, non-nullable. */
export declare const coalesceReturns: ReturnResolver;
/** NULLIF: first arg type, nullable. */
export declare const nullifReturns: ReturnResolver;
