import type { FunctionSpec } from './types';
export { FUNCTIONS } from './registry';
export { resolveFunctionReturnType } from './return-type';
export type { FunctionKind, FunctionSpec, InferenceContext, ReturnResolver, } from './types';
export declare function lookupFunction(name: string): FunctionSpec | undefined;
/**
 * Trims before lookup, unlike the other accessors here — this mirrors the
 * old `isBlocked` gate it stands in for, which trimmed. The parser never
 * hands a padded name through, so the difference is unreachable in practice.
 */
export declare function isPermittedFunction(name: string): boolean;
export declare function isAggregateFunction(name: string): boolean;
