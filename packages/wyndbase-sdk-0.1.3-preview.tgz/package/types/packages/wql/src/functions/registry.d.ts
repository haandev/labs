import type { FunctionSpec } from './types';
export declare const FUNCTIONS: ReadonlyMap<string, FunctionSpec>;
