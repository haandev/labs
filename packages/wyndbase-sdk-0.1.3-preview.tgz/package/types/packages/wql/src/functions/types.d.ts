import type { ResolvedTable, SchemaProviderFactory } from '../../../model/src/types';
import type { WynModelTree } from '../../../model/src/utils/index';
import type { z } from 'zod';
import type { FunctionCall } from '../ast/nodes';
import type { ExprScope } from '../schema-inference/expr-scope';
export type FunctionKind = 'aggregate' | 'window' | 'scalar';
/** What return-type inference needs to resolve an argument-dependent type. */
export interface InferenceContext {
    resolved: ResolvedTable | undefined;
    model: WynModelTree;
    f: SchemaProviderFactory;
    visitStack: readonly string[];
    scope?: ExprScope;
}
export type ReturnResolver = (fn: FunctionCall, ctx: InferenceContext) => z.ZodType;
export interface FunctionSpec {
    kind: FunctionKind;
    category: string;
    /** Explicit and required — a forgotten field must fail to compile, never default to callable. */
    permitted: boolean;
    /** Absent means the return type is unknown, the same answer the engine gives today. */
    returns?: z.ZodType | ReturnResolver;
}
