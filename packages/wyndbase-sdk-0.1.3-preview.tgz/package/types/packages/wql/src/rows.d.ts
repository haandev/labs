import type { WQLOptions, WQLResult } from './types';
/**
 * A result whose rows ARE the value. Everything the compiler and the run
 * reported about the statement — `isMutation`, `rowCount`, `tracking`, and the
 * compile-only members when they were asked for — rides on the same value as
 * properties, so nothing is lost by the rows being the answer.
 *
 * The annotations are optional because they annotate: a value derived from the
 * rows — filtered, mapped, spread — is still rows, and carries none of them.
 */
export type WqlRows<Row extends Record<string | number | symbol, unknown> = Record<string, unknown>, C extends WQLOptions = WQLOptions> = Row[] & Partial<Omit<WQLResult<Row, C>, 'result'>>;
/**
 * Enumerable on purpose. A consumer spreading the metadata, and
 * `structuredClone`, both need to see them; the identity cost that normally
 * follows is paid back by the caller's own structural sharing where one
 * applies.
 */
export declare function tagWqlRows<Row extends Record<string | number | symbol, unknown> = Record<string, unknown>, C extends WQLOptions = WQLOptions>(payload: unknown): WqlRows<Row, C>;
/** The own keys a tagged value carries besides its rows. */
export declare function wqlRowsMeta(value: readonly unknown[]): Record<string, unknown>;
/** True for a rows value carrying metadata — an array with own keys of its own. */
export declare function isTaggedWqlRows(value: unknown): value is unknown[];
