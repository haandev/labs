/**
 * Canonical `Expression` → WQL text — the same expression always reprints the
 * same string and reparses to the same tree (spec D2); never a best-effort guess.
 */
import type { Expression } from '../ast/nodes';
/** A node the filter-clause dialect has no text for. */
export declare class UnprintableExpressionError extends Error {
    readonly nodeType: string;
    constructor(nodeType: string, reason: string);
}
/**
 * Prints an expression as canonical WQL text that `parseExpression` maps
 * back to the same tree — throws rather than emit unparseable text.
 */
export declare function printExpression(expr: Expression): string;
