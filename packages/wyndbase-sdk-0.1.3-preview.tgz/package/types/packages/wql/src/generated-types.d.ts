/**
 * The hook type generation fills in. `wyndbase typegen` writes one entry per
 * query literal into this interface; before it has run the interface is
 * empty, and the helpers below fall back to their open shapes.
 */
declare global {
    interface WQLGenerated {
    }
}
/** The rows a query returns, by the literal the generator keyed it under. */
export type WqlInfer<Q> = Q extends keyof WQLGenerated ? WQLGenerated[Q]['result'] : unknown;
/** The parameters a query accepts, by the same key. */
export type WqlParams<Q> = Q extends keyof WQLGenerated ? WQLGenerated[Q]['params'] : Record<string, unknown>;
