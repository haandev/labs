import type { JsonPassthroughReport, PolyDisplayReport, RealtimeTrackingEntry } from '../../shared/src/index';
import type { WidgetProps } from '../../wyn-widget/src/index';
import type { DefinitionStatement, ParameterMeta } from './ast/nodes';
export type WQLExecutionMode = 'dry' | 'run' | 'explain' | 'explain-analyze';
/** A decision matrix expression — always a WQL expression string.
 *  Role-based compound expressions are pre-built by the policyResolver. */
export type DecisionExpression = string;
export interface DelegationAuditMeta {
    delegationId: string;
}
export interface PolicyResolverResult {
    expressions: Record<string, DecisionExpression>;
    /** POLICY(…) — the OR-folded text. Caller-independent. */
    policies?: Record<string, DecisionExpression>;
    /** CAN(…) — present means held; `null` means held unconditionally. */
    capabilities?: Record<string, DecisionExpression | null>;
    delegationMeta?: DelegationAuditMeta[];
}
/** Full JSON Schema object returned by toJSONSchema() (without $schema) */
export type RowSchema = Record<string, unknown> & {
    type: 'object';
    properties: Record<string, any>;
    additionalProperties: boolean;
};
/**
 * Non-fatal diagnostic from WQL → SQL compilation — surfaces UX traps (e.g.
 * a no-op annotation) without blocking compilation.
 */
export interface WQLDiagnostic {
    code: string;
    message: string;
    column?: string;
    table?: string;
}
export interface WQLResult<Row extends Record<string | number | symbol, unknown> = Record<string, unknown>, C extends WQLOptions = WQLOptions> {
    statement: C['statement'] extends true ? {
        sql: string;
        statements: string[];
        parameterMap: Record<string, number>;
        parameterMaps: Record<string, number>[];
        parameterMeta: Record<string, WidgetProps>;
        parameterRawMeta?: Record<string, ParameterMeta>;
        /**
         * REQUIRED result contracts, index-aligned with `statements`: a label
         * means that statement must yield/affect at least one row or the
         * driver aborts the batch with RowRequiredError (404). Absent when no
         * statement carries the contract.
         */
        requiredChecks?: (string | null)[];
    } : never;
    schema: C['schema'] extends true ? RowSchema : never;
    typescript: C['typescript'] extends true ? string : never;
    result: C['as'] extends 'dry' | 'explain' | 'explain-analyze' ? never : Row[];
    explainReport: C['as'] extends 'explain' ? unknown[] : never;
    explainAnalyzeReport: C['as'] extends 'explain-analyze' ? unknown[] : never;
    error?: string;
    errorMessage?: string;
    rollsBack?: boolean;
    /**
     * Indices, into `statement.statements`, of statements the engine emitted
     * for transaction control (the SAVEPOINT/ROLLBACK TO SAVEPOINT pair
     * bracketing a rolling-back block) — not statements the caller wrote.
     * Absent when none were emitted.
     */
    controlStatementIndices?: number[];
    /**
     * Indices, into `statement.statements`, of statements the engine emitted to
     * finish a caller statement whose answer an earlier statement already gave
     * (the successor versions of a delete that versions linking rows). They run,
     * but never supply the result. Absent when none were emitted.
     */
    continuationStatementIndices?: number[];
    isMutation: boolean;
    /** SELECT/read statements — tables read + their filter conditions (for realtime) */
    tracking: RealtimeTrackingEntry[];
    /** Mutation statements — tables written + their guard conditions (for realtime) */
    mutating: RealtimeTrackingEntry[];
    /**
     * How many entries the realtime size cap had to narrow to whole-table
     * entries, per side. Absent when none were. A non-zero count means the
     * corresponding entries are unfiltered: correct, but over-notifying.
     */
    realtimeWidened?: {
        tracking: number;
        mutating: number;
    };
    /**
     * Result columns that can carry a polymorphic link reference. `none` means no
     * cell of this result can, so the display scan is skipped whole; `unknown`
     * means the projection could not be resolved and every cell is inspected.
     */
    polyDisplay: PolyDisplayReport;
    /**
     * Result columns the database itself serialized, so the value can cross into
     * the response without a decode. `none` means there are none; `unknown` means
     * the outer projection could not be resolved and nothing is passed through.
     */
    jsonPassthrough: JsonPassthroughReport;
    /**
     * Tables the statement WRITES, per the compiler itself — not derived from
     * `mutating`, whose entries may have been narrowed to their tables and must
     * not gate security.
     */
    mutatedTables: string[];
    /**
     * Rows affected/returned, from PG's command tag — correct without
     * RETURNING, unlike `result.length`. Undefined for dry/explain compiles.
     */
    rowCount?: number;
    /**
     * Non-fatal compile diagnostics (e.g. `@unmask`/`@decrypt` without a
     * matching cellPolicy). Undefined when none were reported.
     */
    warnings?: WQLDiagnostic[];
    /**
     * Parsed DEFINE/EXPOSE/DROP statements of a definition-only submission —
     * one or many, never mixed with row statements. Present means no SQL was
     * generated — never send `statement.sql` here; driver applies them.
     */
    definitions?: DefinitionStatement[];
}
/**
 * Client trust tier: `undefined` is the server itself (admitted by every
 * named query), `trusted` has raw-WQL permission, `public` is the rest.
 */
export type ClientLevel = 'trusted' | 'public';
export interface WQLOptions<SchemaExpected extends boolean = boolean, StatementExpected extends boolean = boolean, TypescriptExpected extends boolean = boolean, ExecutionMode extends WQLExecutionMode = WQLExecutionMode> {
    /**
     * Refuse names the model does not define.
     * `true` — tables and columns.
     * `'columns'` — columns (and link terminals) on a table that resolved;
     * unresolved tables still pass through.
     */
    strict?: boolean | 'columns';
    schema?: SchemaExpected;
    statement?: StatementExpected;
    typescript?: TypescriptExpected;
    /** Execution mode: 'dry' (no execution), 'run' (execute), 'explain' (EXPLAIN), 'explain-analyze' (EXPLAIN ANALYZE) */
    as?: ExecutionMode;
    /** Default namespace (space id, physicalName, or name) for unscoped table resolution */
    namespace?: string;
    /** User query flag — enables security policies (row/cell filtering, raw SQL blocking) */
    user?: boolean;
    /** Force policy injection without user flag (system queries that still need policies + $s blocking) */
    forcePolicies?: boolean;
    /** Context values injected into policy expressions (e.g. $context.organizationId) */
    context?: Record<string, unknown>;
    /** Must be explicitly true to execute mutation queries (INSERT/UPDATE/UPSERT/DELETE) */
    allowMutation?: boolean;
    /** Client trust level for NQ access: undefined = driver/internal call
     *  (highest privilege); otherwise the external client's tier. */
    clientLevel?: ClientLevel;
    /** Fetches policy expressions from the decision matrix; called once by generateSQL. */
    policyResolver?: (keys: string[], context?: Record<string, unknown>, 
    /** The subset of `keys` the statement writes as `POLICY(…)`. `CAN(…)` shares
     *  the key space but not the step-up accounting, so the two must be told apart. */
    expandedPolicies?: string[]) => Promise<PolicyResolverResult>;
    /** Runtime parameter values for EACH iteration and dynamic table references */
    runtimeParams?: Record<string, unknown>;
    /** Actor identity for audit column auto-injection (createdBy/updatedBy/deletedBy).
     *  null means anonymous (unauthenticated) request. undefined means not set. */
    actor?: {
        userId: string | null;
    };
    /** Maximum rows any one top-level statement may return, compiled in as a
     *  LIMIT. Absent means unbounded. Subqueries, CTEs and inlined named-query
     *  bodies are never bounded — a LIMIT there changes the answer. */
    rowBound?: number;
    /** Emit result columns the database already serialized as `text`, so the
     *  response can carry them through undecoded. Only a caller that sends the
     *  rows straight to the wire may set it — every in-process reader of a cell
     *  needs the decoded value. */
    jsonPassthrough?: boolean;
}
