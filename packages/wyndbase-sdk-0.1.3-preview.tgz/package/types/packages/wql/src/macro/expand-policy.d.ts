/**
 * `POLICY('x')` is replaced by the named policy's text, never evaluated, so
 * expansion is a WQL → WQL rewrite and needs nothing from the SQL generator.
 */
import type { Expression } from '../ast/nodes';
export type PolicyLookup = (name: string) => string | undefined;
export interface ExpandOptions {
    lookup: PolicyLookup;
    /** Shared with formula expansion in the compiler; the driver passes its own. */
    stack: Set<string>;
    maxDepth: number;
}
/** `policyName` is its own field: `name` is `Error`'s own, and a caller
 *  reporting which rule broke must not have to regex the message. */
export declare class UnknownPolicyError extends Error {
    readonly policyName: string;
    constructor(policyName: string);
}
/**
 * A locked rule naming a policy that IS defined, but only in the unlocked
 * tier. Distinct from {@link UnknownPolicyError} on purpose: "unknown" sends
 * an operator hunting for a definition that exists and is right in front of
 * them, when the real answer is that a locked rule may not read it.
 */
export declare class NoLockedPolicyDefinitionError extends Error {
    readonly policyName: string;
    constructor(policyName: string);
}
/** A stored policy text that will not parse. Named, because the parser's own
 *  diagnostic says which characters failed and not whose text they were. */
export declare class UnparseablePolicyError extends Error {
    readonly policyName: string;
    readonly cause: unknown;
    constructor(policyName: string, cause: unknown);
}
/** One type for the shared depth cap, so a caller can branch on it instead of
 *  matching the message wherever expansion runs. */
export declare class MacroDepthExceededError extends Error {
    readonly maxDepth: number;
    constructor(maxDepth: number);
}
/** `mapExpression` reaches the macros already in `expr`; the recursive call
 *  below reaches those inside a replacement text, which it has never seen. */
export declare function expandPolicyMacros(expr: Expression, options: ExpandOptions): Expression;
/** Shared with the compiler's own expansion, so a broken stored policy names
 *  its owner wherever it is parsed. */
export declare function parsePolicyText(name: string, text: string): Expression;
export declare const collectPolicyNames: (expr: Expression) => string[];
/** `CAN('x')` reaches a rule the caller may hold, so a resolver has to answer
 *  every name a stored expression can name — not only the requested ones. */
export declare const collectCapabilityNames: (expr: Expression) => string[];
