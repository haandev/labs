/** biome-ignore-all lint/style/noNonNullAssertion: TODO: remove this once we have a better way to handle this */
import type { AdditiveExpressionContext, AggregationContext, AlterPolicyStatementContext, AndExpressionContext, AnnotationContext, ArrayLiteralContext, BareQueryContext, CapabilityCheckContext, CaseExpressionContext, CastExpressionContext, ChoiceRefContext, ColumnRefContext, ComparisonExpressionContext, CteBodyContext, CteDefinitionContext, DclStatementContext, DdlStatementContext, DefineStatementContext, DelegateStatementContext, DeleteStatementContext, DerivationContext, DmlStatementContext, DqlStatementContext, DropPolicyStatementContext, DropStatementContext, ExposeStatementContext, ExpressionContext, ExpressionListContext, ExpressionOrStarContext, FrameEndContext, FrameSpecContext, FrameStartContext, FunctionCallContext, GrantStatementContext, InlineSqlContext, InsertStatementContext, LinkDefinitionContext, LinkExpressionContext, LinkLookupContext, LiteralContext, LoopQueryContext, MultiplicativeExpressionContext, MutationArrayContext, MutationArrayItemContext, MutationFieldContext, MutationObjectContext, MutationValueContext, NestedInsertContext, NestedSubqueryContext, NotExpressionContext, NullishExpressionContext, OnConflictClauseContext, OrExpressionContext, ParameterRefContext, PolicyExpansionContext, PolicyStatementContext, PostfixExpressionContext, PrimaryExpressionContext, ProjectionContext, QueryBodyContext, QueryContext, QueryStatementContext, RangeBoundContext, RankQueryContext, ReturningClauseContext, ReturningSpecContext, RevokeDelegationStatementContext, SelectQueryContext, SignedIntegerContext, SortClauseContext, SortItemContext, StatementContext, SummarizeQueryContext, TableNameContext, TableRefContext, TableSearchExprContext, TakeClauseContext, TclStatementContext, TransactionBlockContext, TransactionBodyStatementContext, TransactionErrorHandlerContext, UnaryExpressionContext, UpdateStatementContext, UpsertStatementContext, WindowCallContext, WindowPartContext, WindowRefContext, WindowSpecContext } from '../../grammar/WynQLParser';
import { WynQLVisitor } from '../../grammar/WynQLVisitor';
import type { Aggregation, AnnotationNode, ArrayLiteralExpr, CapabilityCheck, CaseExpr, CastExpr, ChoiceRef, ColumnRef, CTEBody, CTEDefinition, DefineStatement, DeleteStatement, Derivation, DropStatement, ExposeStatement, Expression, FrameBound, FrameSpec, FunctionCall, InlineSqlExpr, InsertStatement, LinkArrayAggExpr, LinkDefinition, LinkExpr, LinkLookup, LiteralExpr, LoopExpr, MutationArray, MutationArrayItem, MutationField, MutationObject, MutationSpread, MutationStatement, MutationValue, NestedInsert, NestedSubquery, OnConflictClause, ParameterRef, PolicyMacro, Position, Projection, Query, QueryBody, QueryStatement, RangeExpr, RankExpr, ReturningSpec, SortItem, Statement, TableName, TableRef, TakeClause, TransactionBlock, TransactionErrorHandler, UpdateStatement, UpsertStatement, WindowSpec } from '../ast/nodes';
/**
 * `annotatedColumnRef` sits in front of whatever `columnRef` builds, and
 * `columnRef` builds three different node shapes: a date-part accessor comes
 * back as a `FunctionCall`, a link bracket as a `LinkArrayAggExpr`, and only
 * a plain reference as the `ColumnRef` that alone has an `annotation` field.
 * Binding the annotation to either of the other two would have nowhere to
 * live that a reader — or `printColumnRef`, the only printer that reads
 * one — would ever look, so that binding is refused rather than dropped.
 */
export declare class AnnotationTargetError extends Error {
    readonly annotationName: string;
    readonly targetKind: string;
    readonly position?: Position | undefined;
    constructor(annotationName: string, targetKind: string, position?: Position | undefined);
}
export declare class ASTBuilder extends WynQLVisitor<unknown> {
    protected defaultResult(): unknown;
    visitQuery: (ctx: QueryContext) => Query;
    visitStatement: (ctx: StatementContext) => Statement;
    visitTransactionBodyStatement: (ctx: TransactionBodyStatementContext) => Statement;
    private visitRowStatement;
    visitDqlStatement: (ctx: DqlStatementContext) => QueryStatement;
    visitTclStatement: (ctx: TclStatementContext) => TransactionBlock;
    visitDmlStatement: (ctx: DmlStatementContext) => MutationStatement | null;
    private createEmptyQueryStatement;
    visitDdlStatement: (ctx: DdlStatementContext) => Statement;
    /**
     * DCL is sugar: each branch returns a node the generator already compiles.
     * Nothing here authorizes — the seeded self-protection rules do.
     */
    visitDclStatement: (ctx: DclStatementContext) => Statement;
    visitGrantStatement: (ctx: GrantStatementContext) => Statement;
    visitPolicyStatement: (ctx: PolicyStatementContext) => Statement;
    visitAlterPolicyStatement: (ctx: AlterPolicyStatementContext) => Statement;
    visitDropPolicyStatement: (ctx: DropPolicyStatementContext) => Statement;
    visitDelegateStatement: (ctx: DelegateStatementContext) => Statement;
    visitRevokeDelegationStatement: (ctx: RevokeDelegationStatementContext) => Statement;
    /** Written as a target or given literally; either way it reaches the query as one key. */
    private readDelegableKey;
    private readUserRef;
    private readPolicyRef;
    /** `space.table` or `space.table.column`; delimiters come off, as everywhere. */
    private readQualifiedName;
    private readModelTargetCtx;
    /** `TO` is mandatory on a rule; universality is written `TO ALL`. */
    private readRoleClause;
    visitDefineStatement: (ctx: DefineStatementContext) => DefineStatement;
    visitExposeStatement: (ctx: ExposeStatementContext) => ExposeStatement;
    visitDropStatement: (ctx: DropStatementContext) => DropStatement;
    /** One part is the name alone, two are space then name. Undelimited, since a
     *  `QUOTED_IDENTIFIER` would otherwise carry backticks nothing can resolve. */
    private readNamedQueryRef;
    visitQueryStatement: (ctx: QueryStatementContext) => QueryStatement;
    visitCteDefinition: (ctx: CteDefinitionContext) => CTEDefinition;
    visitCteBody: (ctx: CteBodyContext) => CTEBody;
    visitBareQuery: (ctx: BareQueryContext) => CTEBody;
    visitQueryBody: (ctx: QueryBodyContext) => QueryBody;
    visitInsertStatement: (ctx: InsertStatementContext) => InsertStatement;
    visitOnConflictClause: (ctx: OnConflictClauseContext) => OnConflictClause;
    visitUpdateStatement: (ctx: UpdateStatementContext) => UpdateStatement;
    visitUpsertStatement: (ctx: UpsertStatementContext) => UpsertStatement;
    visitDeleteStatement: (ctx: DeleteStatementContext) => DeleteStatement;
    visitTransactionBlock: (ctx: TransactionBlockContext) => TransactionBlock;
    visitTransactionErrorHandler: (ctx: TransactionErrorHandlerContext) => TransactionErrorHandler;
    visitTableName: (ctx: TableNameContext) => TableName;
    visitMutationObject: (ctx: MutationObjectContext) => MutationObject;
    visitMutationField: (ctx: MutationFieldContext) => MutationField | MutationSpread;
    visitMutationValue: (ctx: MutationValueContext) => MutationValue;
    visitMutationArray: (ctx: MutationArrayContext) => MutationArray;
    visitMutationArrayItem: (ctx: MutationArrayItemContext) => MutationArrayItem;
    visitNestedInsert: (ctx: NestedInsertContext) => NestedInsert;
    visitLinkLookup: (ctx: LinkLookupContext) => LinkLookup;
    visitChoiceRef: (ctx: ChoiceRefContext) => ChoiceRef;
    visitPolicyExpansion: (ctx: PolicyExpansionContext) => PolicyMacro;
    visitCapabilityCheck: (ctx: CapabilityCheckContext) => CapabilityCheck;
    visitReturningClause: (ctx: ReturningClauseContext) => ReturningSpec;
    visitReturningSpec: (ctx: ReturningSpecContext) => ReturningSpec;
    visitLinkDefinition: (ctx: LinkDefinitionContext) => LinkDefinition;
    visitSelectQuery: (ctx: SelectQueryContext) => QueryBody;
    visitSummarizeQuery: (ctx: SummarizeQueryContext) => QueryBody;
    visitLoopQuery: (ctx: LoopQueryContext) => LoopExpr;
    visitRankQuery: (ctx: RankQueryContext) => RankExpr;
    private parseNqInvocationArgs;
    visitTableRef: (ctx: TableRefContext) => TableRef;
    visitProjection: (ctx: ProjectionContext) => Projection;
    visitAnnotation: (ctx: AnnotationContext) => AnnotationNode;
    visitNestedSubquery: (ctx: NestedSubqueryContext) => NestedSubquery;
    private buildSummarizeFromNestedSubquery;
    visitDerivation: (ctx: DerivationContext) => Derivation;
    visitAggregation: (ctx: AggregationContext) => Aggregation;
    visitSortClause: (ctx: SortClauseContext) => SortItem[];
    visitSortItem: (ctx: SortItemContext) => SortItem;
    visitTakeClause: (ctx: TakeClauseContext) => TakeClause;
    visitExpression: (ctx: ExpressionContext) => Expression;
    visitOrExpression: (ctx: OrExpressionContext) => Expression;
    visitAndExpression: (ctx: AndExpressionContext) => Expression;
    /** Nullish-coalesce chain `a ?? b ?? c` emits a left-associative `BinaryExpr`
     *  tree; the SQL generator flattens it into one `COALESCE(a, b, c)` at emit. */
    visitNullishExpression: (ctx: NullishExpressionContext) => Expression;
    visitNotExpression: (ctx: NotExpressionContext) => Expression;
    visitComparisonExpression: (ctx: ComparisonExpressionContext) => Expression;
    /** `SEARCH term [ON a,b]`: the column set isn't resolved here (no model) —
     *  it's resolved at SQL-gen via `resolveSearchColumns`. Whether `ON` was
     *  written is preserved too, since `printExpression` must reproduce it. */
    visitTableSearchExpr: (ctx: TableSearchExprContext) => Expression;
    private applyComparisonTail;
    private resolveComparisonPgOperator;
    private applyNegatableTail;
    private buildInExpr;
    /** For `HAS` — a 2-segment ColumnRef becomes a schema.table source AND a
     *  linkPath (a link navigation); a ParameterRef becomes a CTE source. */
    private extractTableRefFromExpression;
    visitRangeBound: (ctx: RangeBoundContext) => RangeExpr;
    /** Operand `i`'s operator is child `2i-1` (children alternate operand,
     *  operator, operand). Reading the nth token of a type instead breaks on
     *  mixed operators — in `a - b + c`, the first `PLUS` sits at the second
     *  operator position, not the first. */
    private operatorAt;
    visitAdditiveExpression: (ctx: AdditiveExpressionContext) => Expression;
    visitMultiplicativeExpression: (ctx: MultiplicativeExpressionContext) => Expression;
    visitUnaryExpression: (ctx: UnaryExpressionContext) => Expression;
    visitPostfixExpression: (ctx: PostfixExpressionContext) => Expression;
    visitExpressionOrStar: (ctx: ExpressionOrStarContext) => Expression;
    visitPrimaryExpression: (ctx: PrimaryExpressionContext) => Expression;
    private extractLiteralValue;
    visitLiteral: (ctx: LiteralContext) => LiteralExpr;
    visitArrayLiteral: (ctx: ArrayLiteralContext) => ArrayLiteralExpr;
    /**
     * Which of the two brackets this is. Both spell `<head>[...]`, and telling
     * them apart needs to know whether `head` is a link column or a jsonb one —
     * a model question, and the parser has no model. So the rule is syntactic,
     * and it is the one the grammar used to encode before `linkArrayAgg` was
     * folded into `postfixAccess`, generalised from "the body is a call" to "the
     * body contains one":
     *
     * - a modifier (`DISTINCT`, `FILTER`, `SORT`) — only a link bracket has any;
     * - a call anywhere in the body — `[max(x)]`, and now `[sum(a) / count(*)]`;
     * - a bare single column — the collecting form, `[quantity]`.
     *
     * Everything else — a literal, a parameter, a path, arithmetic over them —
     * is a subscript, exactly as before. Nothing that read as one form reads as
     * the other now; the widening only claims shapes that used to compile to a
     * column name that does not exist.
     */
    private static isLinkBracket;
    private linkBracketBodyKind;
    /** The retired `linkArrayAgg` rule's AST shape, now built from the one
     *  bracket rule. `column` stays the sentinel an aggregate leaves empty. */
    private buildLinkArrayAgg;
    visitColumnRef: (ctx: ColumnRefContext) => ColumnRef | FunctionCall | LinkArrayAggExpr;
    visitLinkExpression: (ctx: LinkExpressionContext) => LinkExpr;
    private mapLinkOperator;
    visitFunctionCall: (ctx: FunctionCallContext) => FunctionCall;
    visitWindowCall: (ctx: WindowCallContext) => FunctionCall;
    visitWindowRef: (ctx: WindowRefContext) => string | WindowSpec;
    visitWindowSpec: (ctx: WindowSpecContext) => WindowSpec;
    visitWindowPart: (ctx: WindowPartContext) => {
        partitionBy?: Expression[];
        orderBy?: SortItem[];
        frame?: FrameSpec;
    };
    visitFrameSpec: (ctx: FrameSpecContext) => FrameSpec;
    visitFrameStart: (ctx: FrameStartContext) => FrameBound;
    visitFrameEnd: (ctx: FrameEndContext) => FrameBound;
    visitSignedInteger: (ctx: SignedIntegerContext) => number;
    private buildFrameBound;
    visitCaseExpression: (ctx: CaseExpressionContext) => CaseExpr;
    visitInlineSql: (ctx: InlineSqlContext) => InlineSqlExpr;
    visitCastExpression: (ctx: CastExpressionContext) => CastExpr;
    visitParameterRef: (ctx: ParameterRefContext) => ParameterRef;
    visitExpressionList: (ctx: ExpressionListContext) => Expression[];
    /** Literal-only default for `${param ?? <default>}` — null/true/false, a
     *  quoted string, or a number. Anything else throws: falling back to `raw`
     *  used to turn `${page ?? offset}` into the literal string "offset". */
    private parseInlineDefault;
    private getTextList;
    private createEmptyBody;
}
