import type { ParameterMeta, ParameterRef, Query } from './nodes';
export interface FilterInfo {
    column: string;
    operator: string;
    value: string;
}
export interface NestedTableInfo {
    table: string;
    filters: FilterInfo[];
}
export interface StatementSummary {
    operation: string;
    tables: string[];
    columns: string[] | '*';
    parameters: string[];
    filters: FilterInfo[];
    nested: NestedTableInfo[];
}
/** A single Query may contain multiple statements (CTE + main query) */
export type QuerySummary = StatementSummary[];
export declare function summarizeAST(queries: Query[]): QuerySummary[];
/**
 * False for a name no caller may bind (`context`/`env`/`application`) or a
 * non-`${}` reference to a CTE alias — a SQL-level result column, not a bind
 * parameter. Shared by every pass that walks `ParameterRef` nodes looking for
 * real caller-suppliable parameters, so a new reserved namespace (e.g. the
 * presence-flag prefix) is excluded everywhere in one edit.
 */
export declare function isBindableParameter(param: ParameterRef, cteNames: ReadonlySet<string>): boolean;
export declare function collectCTENames(queries: Query[]): Set<string>;
/**
 * The accepted parameter set: names a caller may supply, enforced by the
 * executor's guard and turned into a params type by the type generator.
 */
export declare function extractParameterMeta(queries: Query[]): Record<string, ParameterMeta>;
/**
 * The fixed alias an `EACH` row is addressed through inside the object.
 * Exported so the anchor pass (`parameter-anchors.ts`) can skip it too — it
 * walks the same mutation fields and would otherwise anchor `$item.*` as if
 * it were a caller-supplied parameter.
 */
export declare const EACH_ROW_ALIAS = "item";
