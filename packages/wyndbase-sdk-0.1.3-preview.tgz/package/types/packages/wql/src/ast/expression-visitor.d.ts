import type { ColumnSegment, Expression, LinkArrayAggExpr, LinkExpr, WindowSpec } from './nodes';
export declare function windowSpecExpressions(spec: WindowSpec): Expression[];
/**
 * The link-carrying kinds name their column in string fields, so a walk
 * looking for `ColumnRef` finds nothing under them.
 */
declare const CHILDLESS: readonly ["CapabilityCheck", "InlineSql", "LinkArrayAggExpr", "LinkExpr", "Literal", "ParameterRef", "PolicyMacro", "StarExpr"];
export type ChildlessExpressionType = (typeof CHILDLESS)[number];
export declare const CHILDLESS_EXPRESSION_TYPES: ReadonlySet<Expression['type']>;
export declare function linkReferenceSegments(node: LinkExpr | LinkArrayAggExpr): ColumnSegment[];
/** Adds a synthetic `ColumnRef` per link-carrying leaf, so a gate judges
 *  `>team.secret` like `team.secret`. */
export declare function forEachGateChildExpression(expr: Expression, fn: (child: Expression) => undefined | false): void;
export declare function getChildExpressions(expr: Expression): Expression[];
/** The callback may return `false` to short-circuit. */
export declare function forEachChildExpression(expr: Expression, fn: (child: Expression) => undefined | false): void;
/** Depth-first pre-order walk over every node in the tree. */
export declare function walkExpression(expr: Expression, callback: (node: Expression) => void): void;
/** A node reachable from two slots is visited once per slot. */
export declare function walkExpressionWithParent(expr: Expression, callback: (node: Expression, parent: Expression | undefined) => void, parent?: Expression): void;
export declare function someExpression(expr: Expression, predicate: (node: Expression) => boolean): boolean;
export declare function everyExpression(expr: Expression, predicate: (node: Expression) => boolean): boolean;
/**
 * Bottom-up transform; an unchanged subtree keeps its identity, so a
 * `transform` must never mutate in place.
 */
export declare function mapExpression(expr: Expression, transform: (node: Expression) => Expression | null, shouldDescend?: (node: Expression) => boolean): Expression;
export declare function collectFromExpression<T>(expr: Expression, collector: (node: Expression) => T | undefined): T[];
export {};
