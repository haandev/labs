/**
 * Identifier spelling for round-tripping WQL text. `"x"` is always a value,
 * never a name; keywords lex case-insensitively, so a colliding name must be delimited.
 */
import { isDelimitedWqlName, undelimitWqlName } from '../../../model/src/utils/index';
export declare const BARE_IDENTIFIER_RE: RegExp;
/**
 * SQL-standard niladic temporal functions: reserved bare keywords, printed and
 * emitted without parentheses — `current_date()` is a Postgres syntax error.
 */
export declare const NILADIC_TEMPORAL_FUNCTIONS: ReadonlySet<string>;
/**
 * Case-insensitive keyword tokens from the grammar's letter-only lexer rules.
 * Excludes `contained`/`strictly`: their bare first word lexes as an ordinary IDENTIFIER.
 */
export declare const RESERVED_WORDS: ReadonlySet<string>;
/** True when `name` can be written back with no delimiters at all. */
export declare function isBareIdentifier(name: string): boolean;
/**
 * True when `name` already carries its delimiters. AST fields vary — use
 * {@link requoteStoredIdentifier} or {@link quoteIdentifierIfNeeded} accordingly.
 */
export declare const isQuotedIdentifier: typeof isDelimitedWqlName;
/** Strip a stored name's outer backticks and undouble internal ones. */
export declare const unquoteIdentifier: typeof undelimitWqlName;
/** Write an undelimited name back, delimiting it only if bare-unsafe. */
export declare function quoteIdentifierIfNeeded(name: string): string;
/**
 * Like {@link quoteIdentifierIfNeeded}, but a name that already carries its
 * delimiters passes through — re-delimiting it would double the backticks.
 */
export declare function requoteStoredIdentifier(name: string): string;
