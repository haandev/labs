import type { DefinitionStatement, Statement } from './nodes';
export declare function isDefinitionStatement(stmt: Statement): stmt is DefinitionStatement;
