import type { JoinType } from '../../../model/src/types';
export interface Position {
    line: number;
    column: number;
}
export interface ASTNode {
    type: string;
    position?: Position;
}
export interface Query extends ASTNode {
    type: 'Query';
    statements: Statement[];
}
export type Statement = QueryStatement | InsertStatement | UpdateStatement | UpsertStatement | DeleteStatement | TransactionBlock | CTEDefinition | DefineStatement | ExposeStatement | DropStatement;
export interface QueryStatement extends ASTNode {
    type: 'QueryStatement';
    /** Result contract: the statement must yield at least one row or the batch aborts. */
    required?: boolean;
    windows: WindowDefinition[];
    ctes: CTEDefinition[];
    bodies: QueryBody[];
    setOperations: ('UNION' | 'UNION ALL' | 'INTERSECT' | 'EXCEPT' | 'EXCEPT ALL')[];
}
export interface CTEDefinition extends ASTNode {
    type: 'CTEDefinition';
    name: string;
    body: CTEBody;
}
export type CTEBody = QueryBody | InsertStatement | UpdateStatement | UpsertStatement | DeleteStatement;
export type MutationStatement = InsertStatement | UpdateStatement | UpsertStatement | DeleteStatement;
export interface QueryBody extends ASTNode {
    type: 'QueryBody';
    hard?: boolean;
    required?: boolean;
    from: FromClause;
    select?: SelectClause;
    summarize?: SummarizeClause;
    groupBy?: Expression[];
    filter?: Expression;
    /** Statement-scoped point-in-time moment; every source read resolves at it. */
    asOf?: Expression;
    orderBy?: SortItem[];
    take?: TakeClause;
    loop?: LoopExpr;
    rank?: RankExpr;
    links?: LinkDefinition[];
}
export interface NQInvocationArg {
    paramName: string;
    value: Expression;
}
export interface LinkDefinition extends ASTNode {
    type: 'LinkDefinition';
    name: string;
    source: string;
    target: string;
    on?: string;
    targetInvocationArgs?: NQInvocationArg[];
    multi?: boolean;
}
export interface FromClause extends ASTNode {
    type: 'FromClause';
    sources: TableRef[];
    setOperations: SetOperation[];
}
export interface TableRef extends ASTNode {
    type: 'TableRef';
    alias?: string;
    schema?: string;
    name: string;
    isCTE: boolean;
    invocationArgs?: NQInvocationArg[];
    /** When true, `name` is the parameter name (without leading `$$`) to
     *  resolve at execute time through the model tree. */
    dynamic?: boolean;
    dynamicParam?: string;
    /** Set by the SQL generator once a dynamic ref resolves; schema inference
     *  reads it to keep emitting a broad row shape. */
    dynamicResolved?: boolean;
}
export interface SetOperation extends ASTNode {
    type: 'SetOperation';
    operator: 'UNION' | 'INTERSECT';
    source: TableRef;
}
export interface SelectClause extends ASTNode {
    type: 'SelectClause';
    distinct: boolean;
    projections: Projection[];
    lock?: SelectLock;
}
export interface SelectLock extends ASTNode {
    type: 'SelectLock';
    mode: 'update';
    skipLocked: boolean;
    nowait: boolean;
}
export interface AnnotationNode extends ASTNode {
    type: 'Annotation';
    name: string;
    args?: Record<string, string | number | boolean>;
}
export interface Projection extends ASTNode {
    type: 'Projection';
    alias?: string;
    expression: Expression | '*' | NestedSubquery;
    annotation?: AnnotationNode;
}
export interface NestedSubquery extends ASTNode {
    type: 'NestedSubquery';
    isHard: boolean;
    isValue: boolean;
    annotation?: AnnotationNode;
    linkColumn: string;
    linkPath?: string[];
    joinType: JoinType;
    hasLinkOperator: boolean;
    isExpand: boolean;
    first: boolean;
    select?: SelectClause;
    summarize?: SummarizeClause;
    filter?: Expression;
    orderBy?: SortItem[];
    take?: TakeClause;
    links?: LinkDefinition[];
}
export interface TableName extends ASTNode {
    type: 'TableName';
    schema?: string;
    name: string;
    dynamic?: boolean;
    dynamicParam?: string;
}
/**
 * Inline `(SELECT …)` source for `INSERT … EACH (subquery) { … }`, generated
 * as a synthetic CTE so it reuses the set-based emitter of the `EACH $cte` form.
 */
export interface SubquerySource extends ASTNode {
    type: 'SubquerySource';
    query: QueryBody;
}
export interface InsertStatement extends ASTNode {
    type: 'InsertStatement';
    table: TableName;
    object: MutationObject;
    /** EACH source: a `$cte`/array `ParameterRef`, or an inline `(SELECT …)`. */
    each?: ParameterRef | SubquerySource;
    onConflict?: OnConflictClause;
    returning?: ReturningSpec;
}
export interface OnConflictClause extends ASTNode {
    type: 'OnConflictClause';
    columns: string[];
    action: 'DO UPDATE' | 'DO NOTHING';
    updateObject?: MutationObject;
}
export interface UpdateStatement extends ASTNode {
    type: 'UpdateStatement';
    table: TableName;
    guard: Expression;
    object: MutationObject;
    hard?: boolean;
    required?: boolean;
    returning?: ReturningSpec;
}
export interface UpsertStatement extends ASTNode {
    type: 'UpsertStatement';
    table: TableName;
    guard: Expression;
    object: MutationObject;
    hard?: boolean;
    returning?: ReturningSpec;
}
export interface DeleteStatement extends ASTNode {
    type: 'DeleteStatement';
    table: TableName;
    guard: Expression;
    hard?: boolean;
    required?: boolean;
    returning?: ReturningSpec;
}
export interface TransactionBlock extends ASTNode {
    type: 'TransactionBlock';
    statements: Statement[];
    errorHandler?: TransactionErrorHandler;
    endAction: 'COMMIT' | 'ROLLBACK';
}
export interface TransactionErrorHandler extends ASTNode {
    type: 'TransactionErrorHandler';
    message?: Expression;
}
export interface MutationObject extends ASTNode {
    type: 'MutationObject';
    fields: (MutationField | MutationSpread)[];
}
export interface MutationField extends ASTNode {
    type: 'MutationField';
    name: string;
    value: MutationValue;
    conditional?: boolean;
}
export interface MutationSpread extends ASTNode {
    type: 'MutationSpread';
    param: ParameterRef;
}
export type MutationValue = Expression | LinkLookup | MutationArray;
export interface MutationArray extends ASTNode {
    type: 'MutationArray';
    items: MutationArrayItem[];
}
export type MutationArrayItem = NestedInsert | Expression | LinkLookup;
export interface NestedInsert extends ASTNode {
    type: 'NestedInsert';
    object: MutationObject;
    returning?: ReturningSpec;
}
export interface LinkLookup extends ASTNode {
    type: 'LinkLookup';
    mode: 'strict' | 'nullable';
    message?: Expression;
    table?: TableName;
    useColumnRef?: boolean;
    predicate: Expression;
    update?: MutationObject;
}
export interface ChoiceRef extends ASTNode {
    type: 'ChoiceRef';
    plural: boolean;
    keys: ChoiceKeyArg[];
}
export interface ChoiceKeyArg {
    list?: string;
    key?: string;
    keyExpr?: Expression;
}
/** `POLICY('x')` — replaced by the named policy's text, never evaluated. */
export interface PolicyMacro extends ASTNode {
    type: 'PolicyMacro';
    name: string;
}
/** `CAN('x')` — does the caller hold this key, and could it be true. */
export interface CapabilityCheck extends ASTNode {
    type: 'CapabilityCheck';
    name: string;
}
export interface ReturningSpec extends ASTNode {
    type: 'ReturningSpec';
    expressions: Expression[];
}
/**
 * Stores a named query, invoked by name where a table stands. Writes the
 * model, not rows, so it generates no SQL — ask `isDefinitionStatement` first.
 */
export interface DefineStatement extends ASTNode {
    type: 'DefineStatement';
    /** Owning space; undefined when the name was written unqualified. */
    space?: string;
    name: string;
    /** `DEFINE OR REPLACE` — an existing definition is refused without it. */
    replace: boolean;
    /**
     * `elevated` — the query runs with service authority. Always present, like
     * `replace`: it is a flag, and its absence is the same fact as `false`.
     * Unlike `exposure`, where absence and a written `service` differ.
     */
    elevated: boolean;
    /**
     * Undefined means no modifier was written, which is not the same fact as a
     * written `service`: `DEFINE OR REPLACE` resets an absent one to the default.
     */
    exposure?: string;
    /**
     * A plain record rather than named fields: these keys name `system.models`
     * columns, and this package does not know that model. The driver owns them.
     */
    options?: Record<string, string>;
    /**
     * Keys the statement wrote more than once — `options` cannot hold a key
     * twice, so the driver refuses rather than letting the last value win.
     */
    duplicateOptionKeys?: string[];
    /**
     * The original source slice, spacing intact: re-joined tokens corrupt inline
     * SQL, and this text is what every later invocation re-parses.
     */
    body: string;
}
/** `EXPOSE [space.]name AS <level>` — changes who may invoke a named query. */
export interface ExposeStatement extends ASTNode {
    type: 'ExposeStatement';
    /** Owning space; undefined when the name was written unqualified. */
    space?: string;
    name: string;
    /**
     * Lowercased, and always one of the levels the grammar admits — the parser
     * refuses anything else, so no caller has to re-check.
     */
    exposure: string;
    /** `EXPOSE q AS elevated public`. Always present; see `DefineStatement`. */
    elevated: boolean;
}
/** `DROP [space.]name` — removes a named query from its space. */
export interface DropStatement extends ASTNode {
    type: 'DropStatement';
    /** Owning space; undefined when the name was written unqualified. */
    space?: string;
    name: string;
}
/** The three statements that write the model rather than rows. */
export type DefinitionStatement = DefineStatement | ExposeStatement | DropStatement;
export interface SummarizeClause extends ASTNode {
    type: 'SummarizeClause';
    groupBy: Expression[];
    /** Output names for the group keys, index-aligned with `groupBy`; an absent
     *  entry (or an absent array) names that key the way it has always been
     *  named, from the expression itself. WQL text cannot spell this — only a
     *  programmatic caller composing a statement through the fluent builder,
     *  which is why the parser never produces it. */
    groupByAliases?: (string | undefined)[];
    aggregations: Aggregation[];
    derive?: Derivation[];
}
export interface Aggregation extends ASTNode {
    type: 'Aggregation';
    alias?: string;
    expression: Expression;
}
export interface Derivation extends ASTNode {
    type: 'Derivation';
    alias?: string;
    expression: Expression;
}
export interface WindowDefinition extends ASTNode {
    type: 'WindowDefinition';
    name: string;
    spec: WindowSpec;
}
export interface WindowSpec extends ASTNode {
    type: 'WindowSpec';
    partitionBy?: Expression[];
    orderBy?: SortItem[];
    frame?: FrameSpec;
}
export interface FrameSpec extends ASTNode {
    type: 'FrameSpec';
    mode: 'ROWS' | 'RANGE';
    start: FrameBound;
    end: FrameBound;
}
export interface FrameBound extends ASTNode {
    type: 'FrameBound';
    boundType: 'UNBOUNDED_PRECEDING' | 'UNBOUNDED_FOLLOWING' | 'CURRENT' | 'VALUE';
    value?: number;
    inclusive: boolean;
}
export type WindowRef = string | WindowSpec;
export type Expression = LiteralExpr | ArrayLiteralExpr | ColumnRef | ParameterRef | BinaryExpr | UnaryExpr | FunctionCall | CaseExpr | InlineSqlExpr | CastExpr | StarExpr | RangeExpr | InExpr | BetweenExpr | IsNullExpr | LikeExpr | ExistsExpr | LinkArrayAggExpr | LoopExpr | LinkExpr | LinkLookup | ChoiceRef | PolicyMacro | CapabilityCheck | SearchExpr | TableSearchExpr;
export interface LiteralExpr extends ASTNode {
    type: 'Literal';
    value: string | number | boolean | null;
    dataType: 'string' | 'integer' | 'decimal' | 'boolean' | 'null' | 'number';
}
export interface ArrayLiteralExpr extends ASTNode {
    type: 'ArrayLiteral';
    elements: Expression[];
}
export interface ParameterRef extends ASTNode {
    type: 'ParameterRef';
    name: string;
    path?: string[];
    metadata?: ParameterMeta;
    definite?: boolean;
}
export interface ParameterMeta {
    type?: string;
    required?: boolean;
    default?: string | number | boolean | null;
    label?: string;
    min?: number;
    max?: number;
    isArray?: boolean;
    pgType?: string;
    encrypt?: boolean;
    schema?: unknown;
    [key: string]: unknown;
}
/** Null is not a declared default — the compiler emits no fallback for it. */
export declare function parameterDeclaresDefault<T extends {
    default?: unknown;
}>(meta: T | undefined): meta is T & {
    default: string | number | boolean;
};
export interface ColumnRef extends ASTNode {
    type: 'ColumnRef';
    segments: ColumnSegment[];
    /** `@unmask` written in front of this reference; asks to open the value,
     *  and the decision rule still decides. */
    annotation?: AnnotationNode;
}
/** No leading link operator spells a right join — a top-level `>` reads as
 *  inner; only a path segment's `>` means right. */
export type LinkOperator = Exclude<JoinType, 'right'>;
export interface ColumnSegment {
    /**
     * Canonical text form: the identifier for a field, the bracket form (`"[0]"`,
     * `"[$idx]"`) for a subscript, so joining segments with `.` stays stable.
     */
    name: string;
    linkType?: JoinType;
    tableAlias?: boolean;
    /** Undefined is equivalent to `'field'`, so callers that only set `name`
     *  remain compatible. */
    kind?: 'field' | 'jsonIndex';
    /** Present only when `kind === 'jsonIndex'`. Any Expression is structurally
     *  allowed and rejected downstream if semantically invalid. */
    indexExpr?: Expression;
}
export interface BinaryExpr extends ASTNode {
    type: 'BinaryExpr';
    operator: string;
    left: Expression;
    right: Expression;
}
export interface UnaryExpr extends ASTNode {
    type: 'UnaryExpr';
    operator: 'NOT' | '-';
    operand: Expression;
}
export interface FunctionCall extends ASTNode {
    type: 'FunctionCall';
    name: string;
    arguments: Expression[];
    filter?: Expression;
    window?: WindowRef;
}
export interface CaseExpr extends ASTNode {
    type: 'CaseExpr';
    branches: {
        condition: Expression;
        result: Expression;
    }[];
    elseResult?: Expression;
}
export interface InlineSqlExpr extends ASTNode {
    type: 'InlineSql';
    sql: string;
}
export interface CastExpr extends ASTNode {
    type: 'CastExpr';
    expression: Expression;
    target: string;
}
export interface StarExpr extends ASTNode {
    type: 'StarExpr';
}
export interface RangeExpr extends ASTNode {
    type: 'RangeExpr';
    start?: Expression;
    end?: Expression;
    startInclusive: boolean;
    endInclusive: boolean;
}
export interface InExpr extends ASTNode {
    type: 'InExpr';
    expression: Expression;
    /**
     * A list emits `IN (a, b, c)`, a `RangeExpr` lowers to `BETWEEN a AND b`, and
     * a single expression (an array column) emits `= ANY(expr)`.
     */
    values: Expression[] | RangeExpr | Expression;
    negated: boolean;
}
export interface BetweenExpr extends ASTNode {
    type: 'BetweenExpr';
    expression: Expression;
    low: Expression;
    high: Expression;
    negated: boolean;
}
export interface IsNullExpr extends ASTNode {
    type: 'IsNullExpr';
    expression: Expression;
    negated: boolean;
}
export interface LikeExpr extends ASTNode {
    type: 'LikeExpr';
    expression: Expression;
    pattern: Expression;
    negated: boolean;
}
/**
 * The vector `column` is matched against is a physical column beside it,
 * absent from the model — a `BinaryExpr` would be gated on the wrong permission.
 */
export interface SearchExpr extends ASTNode {
    type: 'Search';
    column: ColumnRef;
    term: Expression;
}
/**
 * `columns` is set only when `ON` was written; otherwise the set resolves from
 * the model at SQL-gen time. Kept unflattened for `printExpression`.
 */
export interface TableSearchExpr extends ASTNode {
    type: 'TableSearch';
    term: Expression;
    columns?: ColumnRef[];
}
export interface ExistsExpr extends ASTNode {
    type: 'ExistsExpr';
    source: TableRef;
    predicate: Expression;
    negated: boolean;
    annotation?: AnnotationNode;
    linkPath?: string[];
}
export interface LinkArrayAggExpr extends ASTNode {
    type: 'LinkArrayAggExpr';
    source: TableRef;
    column: string;
    distinct: boolean;
    orderBy: SortItem[];
    filter?: Expression;
    /** Any expression that reduces the linked rows to one value: a call, or
     *  arithmetic over calls (`sum(qty) / count(*)`). Not restricted to a single
     *  `FunctionCall` — the bracket's job is one value, not one call. */
    aggregate?: Expression;
    /**
     * The other reading of the same text, for the one bracket shape that has
     * two: `head[bareColumn]`. It is the collecting form when `head` is a link
     * (`timesheets[hours]`) and a JSONB subscript when `head` is a jsonb column
     * (`meta[restricted]`) — a model question, and the parser has no model, so
     * it carries both and `resolveBracketReading` picks one where the model is
     * in hand. Absent on every other shape, which is unambiguous.
     */
    subscript?: ColumnRef;
}
export interface LoopExpr extends ASTNode {
    type: 'LoopExpr';
    anchorCondition: Expression;
    childColumn: string;
    parentColumn: string;
    queryBody: QueryBody;
}
export interface LinkExpr extends ASTNode {
    type: 'LinkExpr';
    operator: LinkOperator;
    column: string;
    path?: string[];
}
export interface RankExpr extends ASTNode {
    type: 'RankExpr';
    limit: number;
    direction: 'top' | 'bottom';
    includeRest: boolean;
    table: TableRef;
    projections: Projection[];
    rankColumns: string[];
}
export interface SortItem extends ASTNode {
    type: 'SortItem';
    expression: Expression;
    direction: 'ASC' | 'DESC';
    /**
     * Omitted leaves it to PostgreSQL: `NULLS LAST` for `ASC`, `NULLS FIRST` for
     * `DESC`. No WQL syntax sets it — only the fluent builder.
     */
    nulls?: 'FIRST' | 'LAST';
}
export interface TakeClause extends ASTNode {
    type: 'TakeClause';
    limit?: number | Expression;
    offset?: number | Expression;
}
