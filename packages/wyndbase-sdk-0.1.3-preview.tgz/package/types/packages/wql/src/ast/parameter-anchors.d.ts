import type { WynModelTree } from '../../../model/src/utils/index';
import type { Query } from './nodes';
export interface AnchoredParamContract {
    /** ParameterMeta.type vocabulary ('number' | 'date' | 'datetime' | 'boolean' | 'text' | 'json' | …) */
    type?: string;
    /** Only ever set true by an unconditional write anchor (D2). */
    required?: boolean;
    isArray?: boolean;
    /** Uppercase PG type for casts/array binds, e.g. 'NUMERIC', 'UUID'. */
    pgType?: string;
    /** Anchor identity, for wql-sql to re-resolve the column instance. */
    table: string;
    columnPath: string[];
}
export declare class ParameterAnchorConflictError extends Error {
    paramName: string;
    a: string;
    b: string;
    constructor(paramName: string, a: string, b: string);
}
/**
 * Registered column types with no inference decision, on purpose: the bound
 * value is not a scalar of the column's own type, so a mapped type here
 * would be a lie rather than a narrowing.
 * - `link`, `polyLink` — the value is a target row id, not the target's type.
 * - `file`, `binary` — an opaque blob reference, not the file's own content.
 * - `formula` — computed by the engine; never itself the target of a write
 *   or a bind parameter.
 * - `numberrange`, `daterange`, `datetimerange`, `timerange` — a tuple of two
 *   bounds, not a single scalar.
 * - `monthYear`, `monthyear-zoned` — a compound value, not one of the
 *   `ParameterMeta.type` scalars.
 * Exported so the drift test can name the reviewed set explicitly: a new
 * registered column type must be sorted into one side or the other, not
 * left to silently infer nothing.
 */
export declare const DELIBERATELY_UNMAPPED: ReadonlySet<string>;
/** Column model type → ParameterMeta.type. Exported: the single mapping. */
export declare function columnTypeToParamMetaType(columnType: string): string | undefined;
export declare function resolveParameterAnchors(queries: Query[], model: WynModelTree): Record<string, AnchoredParamContract>;
