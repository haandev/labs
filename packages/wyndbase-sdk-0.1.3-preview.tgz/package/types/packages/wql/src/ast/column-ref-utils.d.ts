/**
 * ColumnRef utility helpers.
 *
 * Pure functions that inspect or describe `ColumnRef` / `ColumnSegment`
 * structures without depending on SQL generation, schema inference, or any
 * runtime context. Kept here so every package that walks column references
 * (wql parser, wql-sql generator, schema-inference) can share a single
 * canonical implementation.
 */
import type { ColumnRef, ColumnSegment, Expression } from './nodes';
/**
 * Produce the canonical `name` for a `jsonIndex` segment.
 *
 *  - Integer / number literal           → `"[0]"`
 *  - Parameter reference                → `"[$name]"`
 *  - Anything else (e.g. col ref, expr) → `"[${rawText}]"`
 *
 * The result is purely cosmetic: it flows through `segments.map(s => s.name)`
 * consumers (ast summarize, filter tree, mutation serializer, etc.) so that
 * joined debug strings like `foo.[0].bar` remain stable and readable. The
 * authoritative data for SQL generation is `indexExpr`, not this string.
 */
export declare function canonicalJsonIndexName(expr: Expression, rawText: string): string;
/**
 * True if any segment in the column reference is a JSONB bracket subscript.
 *
 * Used by SQL generation, schema inference, and projection builders to
 * either dispatch to the JSONB path resolver or (until Faz 1-3 ship) emit a
 * "not yet supported" error. Kept as a tiny helper so callers do not open-code
 * `segments.some(s => s.kind === 'jsonIndex')` in a dozen places.
 */
export declare function hasJsonIndexSegment(ref: ColumnRef): boolean;
/** Narrow a segment to the `'jsonIndex'` kind. */
export declare function isJsonIndexSegment(seg: ColumnSegment): boolean;
