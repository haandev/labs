/**
 * The one bracket decision the parser cannot take.
 *
 * `head[body]` has two meanings and one syntax. With a modifier or a call in
 * the body it is a link bracket and nothing else; with a literal, a parameter
 * or a path it is a JSONB subscript and nothing else. `visitColumnRef` settles
 * both. What it cannot settle is `head[bareColumn]`: `timesheets[hours]`
 * collects a column through a link, `meta[restricted]` subscripts a jsonb
 * column by another column's value, and which one a given text is depends on
 * what `head` is in the model.
 *
 * So the parser carries both readings on the node and every consumer that has
 * a model and a scope calls this to pick one. One rule, applied per scope —
 * not one rule per consumer.
 */
import type { ResolvedTable } from '../../../model/src/types';
import type { WynModelTree } from '../../../model/src/utils/index';
import type { ColumnRef, LinkArrayAggExpr } from './nodes';
/**
 * `node.subscript` when the head names a non-link column, the node itself
 * otherwise.
 *
 * A head that resolves to nothing keeps the link reading: an alias, a CTE or a
 * dynamic source resolves later or not at all, and the link bracket is the
 * reading that has a fallback for it.
 */
export declare function resolveBracketReading(node: LinkArrayAggExpr, model: WynModelTree | undefined, parent: ResolvedTable | undefined): LinkArrayAggExpr | ColumnRef;
