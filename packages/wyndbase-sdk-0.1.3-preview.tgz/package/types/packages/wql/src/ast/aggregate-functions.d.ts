import type { Expression } from './nodes';
/** A call to an aggregate collapses a plain nested SELECT to a single row. */
export declare function expressionUsesAggregateCall(expr: Expression): boolean;
