import { Elysia } from 'elysia';
/**
 * The tenant id of the main control-plane base. MCP discovery / OAuth flows
 * advertise endpoints under `/api/${MAIN_TENANT_ID}/oauth2/*`.
 */
declare const MAIN_TENANT_ID = "wyndbase";
/**
 * Builds what the route hands the handler factory. The counterpart of
 * {@link identityFrom} — the base the token names rides along with the userId,
 * because platform identity is decided on it and never on the base a call
 * targets. Exported so the pair can be pinned together: a field written here
 * and not read there is silent.
 */
export declare function authInfoFor(claims: {
    userId: string;
    baseId?: string;
}, token: string): {
    clientId: string;
    extra: {
        baseId: string | undefined;
        userId: string;
    };
    scopes: string[];
    token: string;
};
/**
 * Reads the identity the route put on `authInfo.extra`. Exported because
 * nothing else can reach inside the handler factory, and an unread home base
 * refuses a platform caller their own authority.
 *
 * `homeBaseId` is deliberately not coerced the way `userId` is: an absent one
 * must stay absent, since the platform predicate is fail-closed on it and
 * `'undefined'` would read as a base name.
 */
export declare function identityFrom(extra: Record<string, unknown> | undefined): {
    homeBaseId: string | undefined;
    userId: string;
};
/**
 * One SDK-v2 handler for the whole endpoint. The factory mints a fresh
 * `McpServer` per serving unit; the SDK routes 2026-07-28 (envelope) traffic to
 * it directly and serves 2025-era clients through its built-in stateless
 * fallback — same factory, both eras. Identity travels on `authInfo.extra`
 * (strictly pass-through: the Elysia route below verified the bearer token
 * before calling `fetch`).
 *
 * Exported so the shipped posture is asserted on the object the route uses, not
 * on a copy of its options.
 */
export declare const handler: import("@modelcontextprotocol/server").McpHttpHandler;
/**
 * Stateless MCP endpoint: no protocol-level session, no `Mcp-Session-Id`,
 * no cross-request state. Each request authenticates via bearer token and
 * carries all state (notably `baseId`) in its own arguments — per the
 * 2026-07-28 MCP spec's removal of protocol sessions. The bearer rule is
 * shared via `@wyndb/driver`.
 */
export declare const mcpPlugin: Elysia<"", {
    decorator: {
        jwt: {
            sign(signValue: {
                [x: string]: string | number | boolean | (string | number | boolean | (string | number | boolean | (string | number | boolean | (string | number | boolean | (string | number | boolean | (string | number | boolean | (string | number | boolean | (string | number | boolean | (string | number | boolean | (string | number | boolean | (string | number | boolean | /*elided*/ any | {
                    [key: string]: string | number | boolean | /*elided*/ any | /*elided*/ any | null | undefined;
                } | null | undefined)[] | {
                    [key: string]: string | number | boolean | any | any | null | undefined;
                } | null | undefined)[] | {
                    [key: string]: string | number | boolean | any | any | null | undefined;
                } | null | undefined)[] | {
                    [key: string]: string | number | boolean | any | any | null | undefined;
                } | null | undefined)[] | {
                    [key: string]: string | number | boolean | any | any | null | undefined;
                } | null | undefined)[] | {
                    [key: string]: string | number | boolean | any | any | null | undefined;
                } | null | undefined)[] | {
                    [key: string]: string | number | boolean | any | any | null | undefined;
                } | null | undefined)[] | {
                    [key: string]: string | number | boolean | any | any | null | undefined;
                } | null | undefined)[] | {
                    [key: string]: string | number | boolean | any | any | null | undefined;
                } | null | undefined)[] | {
                    [key: string]: string | number | boolean | any | any | null | undefined;
                } | null | undefined)[] | {
                    [key: string]: string | number | boolean | any | any | null | undefined;
                } | null | undefined)[] | {
                    [key: string]: string | number | boolean | any | any | null | undefined;
                } | null | undefined;
                iss?: string;
                sub?: string;
                aud?: string | string[];
                jti?: string;
                nbf?: string | number;
                exp?: string | number;
                iat?: boolean;
            }): Promise<string>;
            verify(jwt?: string, options?: import("jose").JWTVerifyOptions): Promise<false | ({
                [x: string]: string | number | boolean | (string | number | boolean | (string | number | boolean | (string | number | boolean | (string | number | boolean | (string | number | boolean | (string | number | boolean | (string | number | boolean | (string | number | boolean | (string | number | boolean | (string | number | boolean | (string | number | boolean | /*elided*/ any | {
                    [key: string]: string | number | boolean | /*elided*/ any | /*elided*/ any | null | undefined;
                } | null | undefined)[] | {
                    [key: string]: string | number | boolean | any | any | null | undefined;
                } | null | undefined)[] | {
                    [key: string]: string | number | boolean | any | any | null | undefined;
                } | null | undefined)[] | {
                    [key: string]: string | number | boolean | any | any | null | undefined;
                } | null | undefined)[] | {
                    [key: string]: string | number | boolean | any | any | null | undefined;
                } | null | undefined)[] | {
                    [key: string]: string | number | boolean | any | any | null | undefined;
                } | null | undefined)[] | {
                    [key: string]: string | number | boolean | any | any | null | undefined;
                } | null | undefined)[] | {
                    [key: string]: string | number | boolean | any | any | null | undefined;
                } | null | undefined)[] | {
                    [key: string]: string | number | boolean | any | any | null | undefined;
                } | null | undefined)[] | {
                    [key: string]: string | number | boolean | any | any | null | undefined;
                } | null | undefined)[] | {
                    [key: string]: string | number | boolean | any | any | null | undefined;
                } | null | undefined)[] | {
                    [key: string]: string | number | boolean | any | any | null | undefined;
                } | null | undefined;
            } & Omit<import("@elysiajs/jwt").JWTPayloadSpec, never>)>;
        };
    };
    store: {};
    derive: {};
    resolve: {};
}, {
    typebox: {};
    error: {};
} & {
    typebox: {};
    error: {};
}, {
    schema: {};
    standaloneSchema: {};
    macro: {};
    macroFn: {};
    parser: {};
    response: {};
} & {
    schema: {};
    standaloneSchema: {};
    macro: {};
    macroFn: {};
    parser: {};
    response: {};
}, {
    mcp: {
        [x: string]: {
            body: unknown;
            params: {};
            query: unknown;
            headers: unknown;
            response: {
                200: "" | Response;
            };
        };
    };
}, {
    derive: {};
    resolve: {};
    schema: {};
    standaloneSchema: {};
    response: {};
}, {
    derive: {};
    resolve: {};
    schema: {};
    standaloneSchema: {};
    response: {};
} & {
    derive: {};
    resolve: {};
    schema: {};
    standaloneSchema: {};
    response: {};
}>;
export { MAIN_TENANT_ID };
