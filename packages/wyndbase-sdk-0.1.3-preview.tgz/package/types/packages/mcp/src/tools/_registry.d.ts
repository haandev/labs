import type { McpServer } from '@modelcontextprotocol/server';
import type { WynConnectionHandler } from '../../../driver/src/schema/models';
export type ToolContext = {
    /**
     * Resolves a base by reference (`_id`, physical name or display name) and
     * returns its connection handler. Throws `BaseResolutionError` when the ref
     * matches no live base. Stateless: every call names its base explicitly —
     * there is no per-session current base.
     */
    getBase: (baseRef: string) => Promise<WynConnectionHandler>;
    /** Returns the authenticated userId for this request. */
    getUserId: () => string;
    /** The base this request's token was minted against — what platform
     *  identity is decided on. `undefined` when the token named none. */
    getHomeBaseId: () => string | undefined;
    /**
     * Public-facing origin (scheme + host) of the wyndbase BE this MCP server is
     * running inside, honoring reverse-proxy headers. Derived from the request
     * being served so resource handlers can build same-origin fetch URLs without
     * hardcoding `localhost` or the deployed hostname.
     */
    getOrigin: () => string;
};
export type ToolRegistrar = (server: McpServer, ctx: ToolContext) => void;
export declare function registerTool(fn: ToolRegistrar): void;
/**
 * The gate. Every registration is forced through `TOOL_OUTPUT_SCHEMAS`, so a
 * tool cannot be added without declaring what it returns, and the declaration
 * cannot silently stop matching the tool it belongs to — an absent entry throws
 * at startup rather than shipping a tool whose payload no client will surface.
 *
 * Exported so the gate itself can be tested against a stub server, without
 * pushing a bogus tool into the process-wide registrar list.
 */
export declare function guardServer(server: McpServer): McpServer;
/**
 * Apply every registered tool to the given server. Tools carry their full
 * descriptions into `tools/list` — the v2 SDK's `cacheHints` (`ttlMs`)
 * let clients cache the listing, so there is no thinning layer.
 *
 * Registration goes through `guardServer`, which supplies each tool's
 * `outputSchema` and mirrors its payload into `content[]`.
 */
export declare function applyAllTools(server: McpServer, ctx: ToolContext): void;
