/**
 * OpenAPI spec resources.
 *
 * Exposes the wyndbase HTTP API's OpenAPI 3.0.3 specification to MCP
 * clients so the agent can self-discover endpoints, parameter types,
 * response shapes, and field-level metadata without trial-and-error.
 *
 * URI layout:
 *   wyndb://openapi              — index: tag list + per-tag endpoint
 *                                  counts + pointers to sub-resources
 *   wyndb://openapi/tag/{tag}    — operations under one tag (full
 *                                  request/response JSON Schemas)
 *   wyndb://openapi/full         — entire spec (~1.6 MB; prefer the
 *                                  index + per-tag resources)
 *
 * The spec is fetched on first read from `${ctx.getOrigin()}/docs/json` —
 * the same public origin the incoming MCP request came in on (honoring
 * x-forwarded-* through nginx). Cached for the BE process lifetime; the
 * deploy restart is the only invalidation, which matches the spec's
 * actual update cadence.
 */
export {};
