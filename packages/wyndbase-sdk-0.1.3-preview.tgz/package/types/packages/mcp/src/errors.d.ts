export type McpErrorCode = 'BASE_ACCESS_DENIED' | 'INVALID_REQUEST' | 'INVALID_PARAMS' | 'PERMISSION_DENIED' | 'CONFIRM_REQUIRED' | 'WQL_SYNTAX' | 'CONSTRAINT_VIOLATION' | 'INTERNAL';
export type McpToolErrorInput = {
    code: McpErrorCode;
    message: string;
    hint?: string;
    relatedResources?: string[];
};
/**
 * Canonical `WQL_SYNTAX` hint, shared by run_wql / run_wql_dry
 * so the guidance can't drift across the WQL entry points. Names the
 * tool-surface helpers a tools-only client can actually call; the resource
 * URIs ride along in each call's `relatedResources` for resource-capable
 * clients.
 *
 * The specification is not a resource. It is seeded into the MAIN base's
 * knowledgebase and searched there — which is why the hint names a search, and
 * why it names the base. Every other base's knowledgebase belongs to its owner:
 * searching one of those for WQL grammar finds nothing, or finds somebody's
 * unrelated article and reads as documentation.
 */
export declare const WQL_SYNTAX_HINT = "Search the WQL specification for the construct you need: `exec_nq { baseId: \"wyndbase\", name: \"system.searchArticles\", params: { term: \"INSERT EACH\" } }` ranks chapters by full-text match and answers with a slug and a snippet; `system.getArticle { slug }`, on the same base, reads one whole. `baseId: \"wyndbase\"` is load-bearing \u2014 the specification is seeded into the main base only, and another base's knowledgebase holds its owner's articles instead. Verify table/column names via exec_nq system.listTablesInSpace / system.listColumnsInTable on the base you are working in.";
export type McpToolErrorResult = {
    isError: true;
    content: Array<{
        type: 'text';
        text: string;
    }>;
    structuredContent: {
        error: {
            code: McpErrorCode;
            message: string;
            hint?: string;
            relatedResources?: string[];
        };
    };
};
export declare function mcpToolError(e: McpToolErrorInput): McpToolErrorResult;
/** Thrown by `ToolContext.getBase` when a base ref matches no live base. */
export declare class BaseResolutionError extends Error {
    constructor(baseRef: string);
}
export declare function baseAccessDeniedError(baseId: string): McpToolErrorResult;
export declare function confirmRequiredError(_preview: unknown): McpToolErrorResult;
export declare function mainBaseAdminRequiredError(reason: string): McpToolErrorResult;
