import { Elysia } from 'elysia';
/**
 * Protected-resource metadata, served at both the path-insertion URL and
 * the root — some strict clients compute the path form and 404 without it.
 *
 * Only the `/mcp` resource is described here. The authorization server it
 * names — its metadata, and the dynamic client registration that goes with
 * it — belongs to the platform, not to MCP, and lives in `apps/be`.
 */
export declare const mcpResourceMetadataPlugin: Elysia<"", {
    decorator: {};
    store: {};
    derive: {};
    resolve: {};
}, {
    typebox: {};
    error: {};
}, {
    schema: {};
    standaloneSchema: {};
    macro: {};
    macroFn: {};
    parser: {};
    response: {};
}, {
    ".well-known": {
        "oauth-protected-resource": {
            mcp: {
                get: {
                    body: unknown;
                    params: {};
                    query: unknown;
                    headers: unknown;
                    response: {
                        200: import("./well-known").ProtectedResourceMetadata;
                    };
                };
            };
        };
    };
} & {
    ".well-known": {
        "oauth-protected-resource": {
            get: {
                body: unknown;
                params: {};
                query: unknown;
                headers: unknown;
                response: {
                    200: import("./well-known").ProtectedResourceMetadata;
                };
            };
        };
    };
}, {
    derive: {};
    resolve: {};
    schema: {};
    standaloneSchema: {};
    response: {};
}, {
    derive: {};
    resolve: {};
    schema: {};
    standaloneSchema: {};
    response: {};
}>;
