export type ProtectedResourceMetadata = {
    resource: string;
    authorization_servers: string[];
    bearer_methods_supported: string[];
    scopes_supported: string[];
};
/**
 * RFC 9728 metadata for the one resource this package owns: the `/mcp`
 * endpoint. The authorization server it points at is the platform's own,
 * described by `apps/be/src/lib/oauth2/metadata.ts`.
 */
export declare function buildProtectedResourceMetadata(origin: string): ProtectedResourceMetadata;
