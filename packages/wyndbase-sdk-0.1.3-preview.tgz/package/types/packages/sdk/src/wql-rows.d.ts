import { tagWqlRows } from '../../wql/src/index';
/**
 * What the run address reports about a call, as opposed to what the call
 * answered. Narrower than the compiler's own result: the route answers from a
 * field allow-list, so nothing the compiler worked out comes back here.
 */
export type WqlRunMeta = {
    isMutation: boolean;
    mutatedTables: string[];
    /** Absent when the statement reports no count; `0` is a count. */
    rowCount?: number;
    /** Present only when the call asked the server for realtime tracking. */
    trackingId?: string;
    /** Present only under `as: 'explain-analyze'`. */
    explainAnalyzeReport?: unknown[];
};
/** The rows, with what the run reported about itself hung off them. */
export type WqlRows<Row> = Row[] & WqlRunMeta;
/**
 * TanStack's own structural sharing treats an array carrying extra properties
 * as neither an array nor a plain object and replaces it wholesale, which costs
 * every row its identity on every fetch. This shares the rows the way it would
 * have, then re-attaches the *incoming* metadata — so a refetch that returns
 * identical rows still reports its own `trackingId`.
 */
export declare function wqlStructuralSharing<T>(prev: T | undefined, next: T): T;
export { tagWqlRows };
