/**
 * RealtimeManager — Client-side subscription management with cross-tab SSE sharing.
 *
 * Uses SharedWorker when available (1 SSE connection across all tabs).
 * Falls back to DirectTransport (per-tab SSE) otherwise.
 *
 * Deduplicates subscriptions by queryKey hash.
 * Routes invalidation signals to TanStack Query + manual callbacks.
 */
import type { QueryClient } from '@tanstack/query-core';
import type { HttpClient } from './http-client';
import type { RealtimeTransportStatus } from './realtime-transport';
type OnExpireMode = 'resubscribe' | 'invalidate' | 'drop';
interface RealtimeManagerDeps {
    http: HttpClient;
    queryClient: QueryClient;
    /** Called whenever a server push is applied client-side (invalidate fan-out
     *  or a reconnect-recovery refetch) — the refetches it triggers are the
     *  push's effect, not a user request. */
    onPushApplied?: () => void;
}
export type RealtimeConnectionState = 'idle' | 'connected' | 'reconnecting' | 'disconnected';
export interface RealtimeStatusSnapshot {
    /** Watched queries in this tab (deduplicated by queryKey hash). */
    subscriptionCount: number;
    connectionState: RealtimeConnectionState;
}
/** Worst state wins; no transports at all is `idle`, not an outage. */
export declare function combineConnectionStates(states: RealtimeTransportStatus[]): RealtimeConnectionState;
export type WatchOptions = {
    onInvalidate?: () => void;
    forceRefetch?: boolean | ((data: unknown) => void);
    queryOptions?: {
        queryKey: unknown[];
        queryFn: () => Promise<unknown>;
    };
    /** Per-subscription idle TTL override (ms). Server clamps to [30s, 6h]. */
    ttlMs?: number;
    /** Recovery mode on idle eviction. Default 'resubscribe'. */
    onExpire?: OnExpireMode;
    /** Release sub while tab hidden, rebind on visible. Default false. */
    pauseWhenHidden?: boolean;
};
export declare class RealtimeManager {
    private deps;
    private transports;
    /** In-flight transport inits, so concurrent watch() calls on one base share
     *  a single transport instead of leaking a zombie connection. */
    private transportInit;
    private watched;
    /** keyHashes currently in the resubscribe pipeline (debounce). */
    private resubscribing;
    /** Monotonic counter minting a fresh claim id per handleResubscribe call. */
    private flushSeq;
    /** The claim id that owns each key's in-flight resubscribeBatch call.
     *  A flush whose captured token no longer matches this map's current
     *  value has been superseded — its response is stale and must not act. */
    private flushToken;
    /** keyHashes whose subscribe was refused by the auth layer. Re-arming them
     *  with the same credentials only repeats the refusal — and, through the
     *  resubscribe fallback refetch, loops. Cleared when the headers change. */
    private unauthorized;
    /** Recovery attempts spent per key in the current connection generation. */
    private attempts;
    /** Keys whose budget is spent. Cleared on the next successful connect, so a
     *  query is set aside rather than abandoned. */
    private abandoned;
    /** Per-key timer that lifts an abandon and retries: after
     *  `RESUBSCRIBE_MAX_DELAY_MS` the key's budget is cleared and a fresh burst
     *  is started, so a route that never reconnects (subscribe itself failing,
     *  not the stream) recovers without waiting on a connect event. */
    private reArmTimers;
    /** Per-base batch buffer of keyHashes pending resubscribe. Drained on the
     *  next microtask via `transport.resubscribeBatch`. */
    private pendingBatch;
    /** Per-base flush schedule, keyed by baseId so one key's delay never
     *  governs another base's — and, within a base, a shorter request
     *  preempts a longer one already armed. */
    private baseSchedule;
    private transportStatus;
    private statusListeners;
    private statusSnapshot;
    constructor(deps: RealtimeManagerDeps);
    getSnapshot(): RealtimeStatusSnapshot;
    subscribe(listener: () => void): () => void;
    private bumpStatus;
    /** Deterministic FNV-1a (64-bit) hash of queryKey for compact identification.
     *  64-bit keyspace makes birthday-paradox collisions practically impossible
     *  (~50% probability requires ~4 billion concurrent subscriptions). */
    hashQueryKey(queryKey: unknown[]): string;
    /** Binds every server-driven callback of a transport to this manager.
     *  Extracted from {@link ensureTransport} so the wiring has one home. */
    private wireTransport;
    /** Get or create a transport for the given baseId */
    private ensureTransport;
    watch(baseId: string, trackingId: string, queryKey: unknown[], options?: WatchOptions): Promise<() => void>;
    /** True when the key no longer belongs to the entry a caller is holding. A
     *  watch can outlive its own entry — its subscribe is awaited, and the cache
     *  listener may drop the query meanwhile — so acting on the key afterwards
     *  would hit whichever watcher owns it now. */
    private releasesForeignEntry;
    /** Recovery state for one key: attempts, the abandon flag, its pending
     *  re-arm timer, the resubscribe debounce flag, and its flush claim id.
     *  Cleared together wherever a key's recovery starts over, so no site
     *  clears only half — and so an event-driven clear invalidates any flush
     *  already in flight for this key, not just the ones still queued. */
    private clearRecoveryBudget;
    /** A rebind the server accepted: the attempts it took are spent, so the
     *  next failure starts a fresh burst. Narrower than
     *  {@link clearRecoveryBudget} — the entry is mid-recovery. A refusal
     *  reported during the subscribe has already taken the claim, either by
     *  releasing it or by minting a newer one, so this yields. */
    private noteRecovered;
    /** The query executed and produced a handle. Arms tracking the first time;
     *  afterwards it only feeds a rebind a recovery is waiting for, because a
     *  re-execution is not a new watcher. */
    noteExecuted(baseId: string, trackingId: string, queryKey: unknown[], options?: WatchOptions): Promise<void>;
    /** Unwatch by queryKey — forces refCount to 0 (used by global cache listener) */
    unwatchByKey(queryKey: unknown[]): void;
    private unwatch;
    /** Routes a server `expired` event through the per-query `onExpire`
     *  policy. Default 'resubscribe' falls back to {@link handleResubscribe}. */
    private handleExpired;
    /** Schedules a batched resubscribe for the given keyHash. Multiple
     *  per-key triggers in the same tick coalesce into a single
     *  `transport.resubscribeBatch` call per base. The cache hits are rebound
     *  server-side without re-executing the originating queries; cache misses
     *  fall back to the per-key refetch path. */
    private handleResubscribe;
    /** Arms (or tightens) the flush for one base. Scoped by baseId so an
     *  exhausted key's long wait on one base can never stall — or be skipped
     *  by — a fresh key's microtask on another. Within a base, a shorter
     *  request preempts a longer one already armed; a longer request leaves
     *  the existing, sooner schedule alone. */
    private scheduleBaseFlush;
    /** Drains one base's pending bucket, calls `transport.resubscribeBatch`,
     *  and per-key falls back to query refetch for cache misses. */
    private flushResubscribeBatch;
    /** Tell every transport that the page is being hidden so it can release
     *  server-side subscriptions before the worker GC kicks in. Safe to call
     *  multiple times. */
    notifyClosing(): void;
    /** Releases server-side subscriptions for every watched query that opted
     *  in to `pauseWhenHidden`. Called by the SDK on
     *  `document.visibilityState === 'hidden'`. `resumeHiddenSubscriptions`
     *  takes them up again, re-executing the query to do so. */
    pauseHiddenSubscriptions(): void;
    /** Reverse of {@link pauseHiddenSubscriptions}: takes every paused sub
     *  back through the batched resubscribe pipeline, which answers with the
     *  keys to re-execute. */
    resumeHiddenSubscriptions(): void;
    /** Called by OAuth2 plugin after token refresh. Updates all active transports. */
    refreshTransportHeaders(): void;
    destroy(): void;
}
export {};
