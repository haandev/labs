import type { AuthStore, OAuth2 } from './plugins/oauth2';
export declare function createAuthStore(auth: OAuth2): <U>(selector: (state: AuthStore) => U) => U;
