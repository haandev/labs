import type { NetworkMeter } from './network-meter';
/** Marks a request as a preparation step, so the automatic success toast
 *  skips it instead of announcing an unfinished operation as done. */
export declare const NOTIFICATION_SILENT_HEADER = "x-notification-silent";
/** Suppresses the automatic error toast when the caller reports failure
 *  itself with a better message than the generic one. */
export declare const ERROR_SILENT_HEADER = "x-error-silent";
export interface HttpRequestConfig {
    url?: string;
    method?: string;
    baseURL?: string;
    headers?: Headers;
    data?: any;
    withCredentials?: boolean;
    /** Used by oauth2 plugin to prevent infinite retry loops */
    isRetry?: boolean;
    /** Used by oauth2 plugin to replay a step-up challenged request exactly once */
    stepUpRetried?: boolean;
    retry?: {
        retries: number;
    };
}
export interface HttpResponse<T = any> {
    data: T;
    status: number;
    statusText: string;
    headers: Headers;
    config: HttpRequestConfig;
}
export declare class HttpError<T = unknown> extends Error {
    readonly isHttpError = true;
    config?: HttpRequestConfig;
    response?: HttpResponse<T>;
    status?: number;
    constructor(message: string, config?: HttpRequestConfig, response?: HttpResponse<T>);
}
/**
 * Reads the HTTP status off any failure that carries one. `isHttpError` accepts
 * only `HttpError`; treaty calls throw `EdenFetchError` and token requests throw
 * `TokenRequestError`, both with a numeric `status` and no `isHttpError` flag.
 */
export declare function httpStatusOf(error: unknown): number | undefined;
export declare function isHttpError<T = any>(value: unknown): value is HttpError<T>;
/** Park `notify` until the outcome of the request that produced `error` is
 *  known. A non-object error cannot be keyed, so it fires immediately. */
export declare function deferNotification(error: unknown, notify: () => void): void;
/** The request failed for good — fire everything parked on `error`. */
export declare function flushNotifications(error: unknown): void;
/** The request was recovered and ended successfully — drop the notifications. */
export declare function discardNotifications(error: unknown): void;
type FulfillFn<V> = ((value: V) => V | Promise<V>) | null;
type RejectFn = ((error: any) => any) | null;
interface InterceptorHandler<V> {
    fulfilled: FulfillFn<V>;
    rejected: RejectFn;
}
declare class InterceptorManager<V> {
    private handlers;
    use(fulfilled?: FulfillFn<V>, rejected?: RejectFn): number;
    eject(id: number): void;
    forEach(fn: (handler: InterceptorHandler<V>) => void): void;
}
export declare class HttpClient {
    /** Set by the SDK so non-treaty requests land in the same interaction metric. */
    meter?: NetworkMeter;
    defaults: {
        baseURL: string;
        headers: Record<string, string>;
        withCredentials: boolean;
    };
    interceptors: {
        request: InterceptorManager<HttpRequestConfig>;
        response: InterceptorManager<HttpResponse<any>>;
    };
    constructor(config: {
        baseURL?: string;
        headers?: Record<string, string>;
        withCredentials?: boolean;
    });
    private mergeHeaders;
    request<T = any>(config: HttpRequestConfig): Promise<HttpResponse<T>>;
    private dispatch;
    get<T = any>(url: string, config?: Partial<HttpRequestConfig>): Promise<HttpResponse<T>>;
    post<T = any>(url: string, data?: any, config?: Partial<HttpRequestConfig>): Promise<HttpResponse<T>>;
    put<T = any>(url: string, data?: any, config?: Partial<HttpRequestConfig>): Promise<HttpResponse<T>>;
    patch<T = any>(url: string, data?: any, config?: Partial<HttpRequestConfig>): Promise<HttpResponse<T>>;
    delete<T = any>(url: string, config?: Partial<HttpRequestConfig>): Promise<HttpResponse<T>>;
    /** Uploads to an arbitrary URL via XMLHttpRequest — unlike `request()`, does
     *  not prepend baseURL or send default auth headers (for presigned S3 URLs). */
    upload(url: string, data: any, options?: {
        onUploadProgress?: (event: {
            loaded: number;
            total: number;
        }) => void;
        signal?: AbortSignal;
        headers?: Record<string, string>;
    }): Promise<{
        headers: Headers;
        status: number;
    }>;
}
export {};
