import type { AuthorizeConfig } from './oauth2';
/** Everything the handler needs from the plugin; narrow so the decision can
 *  be exercised without a browser. */
export type HostedStepUpTarget = {
    authorize: (config?: AuthorizeConfig) => Promise<void>;
};
export type HostedStepUpOptions = {
    popup?: {
        width?: number;
        height?: number;
    };
};
/**
 * `reachedAal` is read off the token the exchange returned, so a forged
 * completion message cannot clear a challenge it did not raise; `null` is a
 * ceremony that produced no token at all.
 */
export declare function stepUpCleared(outcome: {
    requiredAal: number;
    reachedAal: number | null;
}): boolean;
/**
 * An `onStepUpRequired` for an application that is not the identity
 * provider's own front end: it hands the person to the provider in a window
 * and answers whether the level was actually reached. It never throws and
 * never hangs — a refused window, a closed one and a level that fell short
 * all answer `false`, which leaves the tripped request unreplayed.
 *
 * Requests refused together share one ceremony: `window.open` reuses the named
 * window and each authorization overwrites the PKCE verifier, so a second one
 * would restart the climb under a person half-way through it and leave only
 * the last flow redeemable.
 */
export declare function hostedStepUpHandler(oauth2: HostedStepUpTarget, options?: HostedStepUpOptions): (requiredAal: number) => Promise<boolean>;
