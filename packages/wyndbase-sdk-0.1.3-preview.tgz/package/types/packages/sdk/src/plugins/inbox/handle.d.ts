import type { wyndbaseSDK } from '../../core';
import type { InboxChannel, InboxItem } from './contract';
export type InboxData<Id extends string = string> = {
    total: number;
    count: Record<Id, number>;
    list: Record<Id, InboxItem[]>;
};
export type InboxMode = 'unread' | 'all';
export type InboxQueryDef<Id extends string> = {
    queryKey: readonly unknown[];
    queryFn: () => Promise<InboxData<Id>>;
    /** Same definition, except the first run arms one realtime subscription per
     *  ref the mode reads. They are released when the composed cache entry is
     *  removed. */
    realtime: () => {
        queryKey: readonly unknown[];
        queryFn: () => Promise<InboxData<Id>>;
    };
};
export type InboxSubscription = {
    unsubscribe: () => void;
};
export type InboxOptions = {
    /** The base the inbox collects from. Defaults to the SDK's home base — a
     *  base the user is only browsing must not move their own inbox. A host that
     *  can impersonate injects the acted base here. */
    resolveBaseId?: () => string;
};
export type InboxHandle<Id extends string> = {
    unread: InboxQueryDef<Id>;
    all: InboxQueryDef<Id>;
    markSeen: (channelId: Id, ids: string[]) => Promise<void>;
    markAllSeen: () => Promise<void>;
    subscribe: (opts: {
        onNew?: (items: InboxItem[]) => void;
        onCount?: (total: number, byChannel: Record<Id, number>) => void;
    }) => InboxSubscription;
};
export declare function createInboxHandle<const Chs extends readonly InboxChannel<string, any>[]>(sdk: wyndbaseSDK, channels: Chs, options?: InboxOptions): InboxHandle<Chs[number]['id']>;
