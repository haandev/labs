import { type wyndbaseSDK } from '../core';
import type { InboxChannel } from './inbox/contract';
type CreateAlertInput = {
    name: string;
    query: string;
    description?: string;
    notifyOnResolve?: boolean;
};
type UpdateAlertPatch = {
    name?: string;
    query?: string;
    description?: string | null;
    notifyOnResolve?: boolean;
};
export type AlertNotificationRow = {
    _id: string;
    alertId: string | null;
    type: 'fired' | 'resolved';
    occurredAt: string;
    payload: {
        alertName?: string;
    } | null;
    readAt: string | null;
};
export declare const alertsInboxChannel: InboxChannel<'alerts', AlertNotificationRow>;
export declare const Alerts: import("..").DefinedPlugin<(sdk: wyndbaseSDK) => {
    accessWarnings(alertId: string): Promise<{
        warnings: import("../../../driver/src/types").AlertWarning[];
    }>;
    create(input: CreateAlertInput): Promise<Record<string, unknown> & {
        _id: string;
        ownerId?: string;
        trackingEntries?: {
            tables?: string[];
        }[];
        warnings?: import("../../../driver/src/types").AlertWarning[];
        description?: string | null;
        lastError?: string | null;
    }>;
    inbox: InboxChannel<"alerts", AlertNotificationRow>;
    pause(alertId: string): Promise<Record<string, unknown> & {
        _id: string;
        ownerId?: string;
        trackingEntries?: {
            tables?: string[];
        }[];
        warnings?: import("../../../driver/src/types").AlertWarning[];
        description?: string | null;
        lastError?: string | null;
    }>;
    remove(alertId: string): Promise<{
        ok: boolean;
    }>;
    resume(alertId: string): Promise<Record<string, unknown> & {
        _id: string;
        ownerId?: string;
        trackingEntries?: {
            tables?: string[];
        }[];
        warnings?: import("../../../driver/src/types").AlertWarning[];
        description?: string | null;
        lastError?: string | null;
    }>;
    update(alertId: string, patch: UpdateAlertPatch): Promise<Record<string, unknown> & {
        _id: string;
        ownerId?: string;
        trackingEntries?: {
            tables?: string[];
        }[];
        warnings?: import("../../../driver/src/types").AlertWarning[];
        description?: string | null;
        lastError?: string | null;
    }>;
}, "alerts">;
export {};
