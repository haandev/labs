import { type PublicKeyCredentialCreationOptionsJSON } from '@simplewebauthn/browser';
import { type wyndbaseSDK } from '../core';
import type { QueryDefinition } from '../define-query';
import { type HttpClient } from '../http-client';
import { pluginName } from '../Pluggable';
import type { OAuth2 } from './oauth2';
/** Shared wording: a second sentence distinguishing "failed" from "accepted"
 *  would leak whether the account exists. */
export declare const PASSWORD_ENROLLMENT_SENT_MESSAGE = "If the account exists, a set-password link has been sent.";
type FlowNextShape = {
    factors: string[];
    required: boolean;
    mode: 'verify' | 'enroll' | 'update_password';
    autoSelect?: string;
    escapes: string[];
};
export type IDPConfig = {
    onDiscover?: (settings: IDPSettings) => void;
    onDiscoverError?: (error: Error) => void;
};
/** For applications that own their sign-in, registration and consent screens
 *  instead of using the OAuth2 flow. Install after the OAuth2 plugin. */
/**
 * The `system.listMySessions` projection — a transport-level DTO, spelled
 * here because this package compiles without the generated WQL types.
 */
export type AccountSession = {
    _id: string;
    revokedAt: string | null;
    device: string | null;
    browser: string | null;
    os: string | null;
    clientInfo: {
        _id: string;
        name: string | null;
        shortName: string | null;
    }[];
};
export declare class IDP {
    private readonly sdk;
    private readonly config?;
    static readonly [pluginName] = "idp";
    private _settings;
    private _discovered;
    readonly discover: QueryDefinition<IDPSettings, never>;
    constructor(sdk: wyndbaseSDK & {
        auth: OAuth2;
        http: HttpClient;
    }, config?: IDPConfig | undefined);
    private discoverRetries;
    private discoverCall;
    private shouldBeDiscovered;
    get settings(): IDPSettings;
    signIn<P extends keyof IDPLoginProviderPayload>(provider: P, payload: IDPLoginProviderPayload[P]): Promise<IDPSignInResult>;
    private handleCredentialsSignIn;
    /** Verify one factor of a login flow; returns the next step, or done. */
    advanceFlow(payload: {
        flowToken: string;
        factorType: string;
        code: string;
    }): Promise<IDPSignInResult>;
    /** Begin in-flow enrollment for a factor the flow requires but the user has
     *  not enrolled. The returned `factorId` is PENDING until confirmed. */
    beginEnroll(payload: {
        flowToken: string;
        factorType: string;
    }): Promise<{
        factorId?: string;
        secret?: string;
        uri?: string;
        challengeToken?: string;
        options?: PublicKeyCredentialCreationOptionsJSON;
        label?: string;
    }>;
    /** Confirm an in-flow factor enrollment. TOTP submits `{ factorId, code }`;
     *  passkey submits `{ challengeToken, response, label }`. */
    confirmFlowEnroll(payload: {
        flowToken: string;
        factorType: string;
        factorId?: string;
        code?: string;
        challengeToken?: string;
        response?: unknown;
        label?: string;
    }): Promise<IDPEnrollResult>;
    /** Answers the `update_password` step: there is no session yet, so the flow
     *  token is the only credential the caller holds. */
    updateFlowPassword(payload: {
        flowToken: string;
        newPassword: string;
        confirmPassword?: string;
    }): Promise<IDPSignInResult>;
    /** Returns the server's own message and nothing derived — no boolean, no
     *  throw: the answer must not reveal whether the account exists. A failure
     *  still has to read the same as success on screen, so the request is
     *  marked silent — otherwise the SDK's own global error notification
     *  would flag exactly the case the response body works so hard not to. */
    requestPasswordEnrollment(identifier: string): Promise<{
        message: string;
    }>;
    /** Returns the server's own message and nothing derived — no boolean, no
     *  throw: the answer must not reveal whether the address is already in use.
     *  The same contract as `requestPasswordEnrollment`. A failure still has to
     *  read the same as success on screen, so the request is marked silent —
     *  otherwise the SDK's own global error notification would flag exactly
     *  the case the response body works so hard not to. */
    register(payload: {
        email: string;
        username?: string;
        name?: string;
        /** Where the visitor was headed; rides the enrolment mail's link so the
         *  set-password screen can send them back. The server drops anything
         *  that is not its own origin. */
        redirectTo?: string;
    }): Promise<{
        message: string;
    }>;
    enrollPasskey(payload: {
        flowToken: string;
        factorType: string;
        label?: string;
    }): Promise<IDPEnrollResult>;
    /** Enroll a passkey for the signed-in user. On first MFA activation the
     *  result carries one-time recovery codes, shown once. */
    registerPasskey(label?: string): Promise<{
        status: string;
        recoveryCodes?: string[];
    }>;
    authenticatePasskey(payload: {
        flowToken: string;
        factorType: string;
    }): Promise<IDPSignInResult>;
    /** Usernameless login: an assertion with an empty allow-list. */
    discoverableLogin(): Promise<IDPSignInResult>;
    /** Returns the URL to send the browser to; it does not navigate. The path is
     *  rebuilt locally so a discovery answer cannot redirect the caller. */
    beginProviderSignIn(providerId: string, options?: {
        returnTo?: string;
    }): Promise<{
        authorizeUrl: string;
    }>;
    /** Redeems the HttpOnly cookie the federated callback set. `false` rather
     *  than a throw, so a stale `?federated=complete` just shows the form again. */
    completeFederatedSession(): Promise<boolean>;
    /** Every factor enrolled on the account, PENDING enrollments included. */
    get getFactors(): QueryDefinition<({
        _id: string;
        type: string;
        createdAt: string;
        label: string | null;
        status: string;
        lastUsedAt: string | null;
        mustChange: boolean;
        isPasskey: boolean;
        source: 'factor' | 'passkey' | 'recovery';
        canRemove: boolean;
    } | {
        canRemove: boolean;
        _id: string;
        type: string;
        status: string;
        label: (string | null);
        lastUsedAt: (string | null);
        createdAt: string;
    })[], import("../define-query").NullableDeps<Record<string, unknown>, string>>;
    /** Removes a factor (server rejects with 403 if it would lower AAL). */
    get deleteFactor(): import("../define-query").MutationDefinition<{
        message: string;
    }, [id: string]>;
    get verifyFactor(): import("../define-query").MutationDefinition<{
        factorId: string;
        status: string;
    } | {
        factorId: string;
        status: string;
        recoveryCodes: string[];
    }, [id: string, code: string]>;
    /** Returns the shared secret + otpauth URI to show once; the factor stays
     *  PENDING until verified. */
    get setupTotpFactor(): import("../define-query").MutationDefinition<{
        factorId: string | undefined;
    }, []>;
    /** Resumes a PENDING TOTP enrollment (returns secret for verify step). */
    get resumeTotpFactor(): import("../define-query").MutationDefinition<{
        factorId: string;
        secret: string;
        status: string;
        uri: string;
    }, [id: string]>;
    /**
     * Replaces the account's recovery codes with a fresh batch, invalidating
     * whatever came before. The answer carries the new codes once and they are
     * never retrievable again, so a caller that drops it costs the user their
     * backup.
     *
     * `codes` is renamed at this boundary, as `recovery_codes` already is on the
     * sign-in path: the frontend's seam check refuses a surface that names the
     * field for itself, and one holding it under another name is exactly the
     * copy that check exists to stop.
     */
    get regenerateRecoveryCodes(): import("../define-query").MutationDefinition<{
        recoveryCodes: string[];
    }, []>;
    get getAccountSessions(): QueryDefinition<AccountSession[], import("../define-query").NullableDeps<Record<string, unknown>, string>>;
    get revokeAccountSession(): import("../define-query").MutationDefinition<{
        message: string;
    }, [sessionId: string]>;
    /** Revokes every session for the account, the current one included. */
    get revokeAllSessionsMutation(): import("../define-query").MutationDefinition<{
        message: string;
    }, []>;
    /** Changing the password invalidates every existing session. */
    get updateAccountPassword(): import("../define-query").MutationDefinition<{
        message: string;
    }, [currentPassword: string, newPassword: string, confirmPassword: string]>;
    /** Sets a password for an account that has none yet (self-enrollment). */
    get setAccountPassword(): import("../define-query").MutationDefinition<{
        message: string;
    }, [newPassword: string, confirmPassword: string]>;
}
export type IDPSignInResult = {
    flowRequired: false;
} | {
    flowRequired: true;
    flowToken: string;
    next: FlowNextShape;
};
export type IDPEnrollResult = IDPSignInResult & {
    recoveryCodes?: string[];
};
/** `displayName` is administrator-supplied text rendered before anybody has
 *  signed in, so whoever puts it on screen owns neutralising it. */
export interface IDPExternalProvider {
    id: string;
    type: string;
    displayName: string;
    /** Informational only — sign-in never follows this URL. */
    startUrl: string;
}
export interface IDPSettings {
    providers: string[];
    /** Ranked by the base. Distinct from `providers`, which lists local kinds. */
    externalProviders: IDPExternalProvider[];
    allowRegister: boolean;
    allowedFirstFactors?: string[];
}
export type IDPLoginProviderPayload = {
    credentials: IDPCredentialsProviderPayload;
};
export type IDPCredentialsProviderPayload = {
    /** Username or verified email; the password is a separate `flow` step. */
    identifier: string;
};
export {};
