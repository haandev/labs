import type { wyndbaseSDK } from '../../core';
import type { InboxChannel } from './contract';
import { type InboxHandle, type InboxOptions } from './handle';
/** Both call forms compose one handle. The array form is the one that carries
 *  options; the variadic form stays the plain default. */
type ChannelsCombinator = {
    <const Chs extends readonly InboxChannel<string, any>[]>(channels: Chs, options?: InboxOptions): InboxHandle<Chs[number]['id']>;
    <const Chs extends readonly InboxChannel<string, any>[]>(...channels: Chs): InboxHandle<Chs[number]['id']>;
};
export declare const Inbox: import("../..").DefinedPlugin<(sdk: wyndbaseSDK) => {
    channels: ChannelsCombinator;
}, "inbox">;
export type * from './contract';
export type * from './handle';
