export type WqlRef = {
    nq: string;
    params?: Record<string, unknown>;
};
export type InboxItem = {
    id: string;
    channelId: string;
    title: string;
    description?: string;
    occurredAt: string;
    unread: boolean;
};
export type MarkSeen = {
    kind: 'item';
    nq: string;
    idParam: string;
    allNq?: string;
} | {
    kind: 'cursor';
};
export type InboxChannel<Id extends string = string, Row = unknown> = {
    id: Id;
    queries: {
        unread: WqlRef;
        all: WqlRef;
        count: WqlRef;
    };
    toItem: (row: Row) => InboxItem;
    markSeen?: MarkSeen;
};
