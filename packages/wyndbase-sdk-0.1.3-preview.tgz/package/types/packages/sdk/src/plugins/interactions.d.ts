import type { wyndbaseSDK } from '../core';
import type { InboxChannel } from './inbox/contract';
export type PendingInteractionRow = {
    _id: string;
    createdAt: string;
    description: string;
    kind: string;
    name: string;
    status: string;
};
export declare const interactionsInboxChannel: InboxChannel<'interactions', PendingInteractionRow>;
export declare const Interactions: import("..").DefinedPlugin<(_sdk: wyndbaseSDK) => {
    inbox: InboxChannel<"interactions", PendingInteractionRow>;
}, "interactions">;
