import { type OAuth2Request, type OAuth2RequestCommons, type OAuth2TokenResponse } from '../../../shared/src/auth-types';
import { type SignInButtonSize } from '../../../shared/src/signin-button';
import { type StoreApi } from 'zustand/vanilla';
import type { wyndbaseSDK } from '../core';
import { pluginName } from '../Pluggable';
import { type HostedStepUpOptions } from './hosted-step-up';
export interface AuthorizeConfig {
    /** Opens in a new tab if undefined; opens as a popup (default 500x600) otherwise. */
    popup?: {
        width?: number;
        height?: number;
    };
    /** Full-page redirect instead of a popup/new tab: the whole flow happens in
     *  this tab and returns to the current URL, where `grant()` finishes the
     *  exchange and `complete({ onSuccess })` hands control back to the app's
     *  router. `popup` and `onSuccess` are meaningless in this mode — there is
     *  no second window to listen to. */
    redirect?: boolean;
    /** OAuth2 scopes to request (RFC 6749 §3.3). The server narrows to what
     *  the signing-in user may hold — e.g. `wql:raw` survives only for a base
     *  administrator — and the granted set comes back on the token response. */
    scope?: string[];
    /** Minimum assurance the identity provider should end the visit at, sent as
     *  `acr_values`. It selects whether a ceremony runs; the level actually
     *  reached is the one on the token that comes back, never this number. */
    acrValues?: number;
    /** Step-up exit: replaces the reload/`onSuccess` ending, because raising
     *  assurance must leave the calling page and its state standing. Receives
     *  the level read off the adopted token, or `null` when the visit produced
     *  no token — a refused window, or one the person closed. */
    onFinished?: (result: {
        aal: number;
    } | null) => void;
    /** Runs on successful authentication; defaults to a page reload. */
    onSuccess?: () => void;
}
export interface OAuth2Config {
    clientId: string;
    /**
     * Register this client automatically (RFC 7591 DCR) when the base does not
     * know the declared `clientId`. The minted `client_id` is persisted and
     * reused, and DCR dedups on name + redirect set, so every browser of the
     * same app converges on one shared client. An operator-registered client
     * with this id always wins — the probe runs before any registration — and
     * the registered client starts unprivileged: raw WQL stays an operator
     * upgrade (or a `wql:raw` scope grant).
     */
    autoRegister?: boolean | {
        /** RFC 7591 `client_name`; defaults to the declared `clientId`. */
        clientName?: string;
        /** Registered callbacks; defaults to this page's origin + path.
         *  Keep it deterministic — DCR dedup converges on it. */
        redirectUris?: string[];
    };
    onToken?: (tokenResponse: OAuth2TokenResponse) => void;
    onUnauthorized?: () => void;
}
export interface OAuth2ClientMetadata {
    _id: string;
    name: string;
    shortName: string;
    allowRawWql: boolean;
    allowedOrigins: string[];
    redirectUrls: string[];
    isIdp: boolean;
    idpClient: string | null;
    idpSettings: Record<string, any> | null;
    isActive: boolean;
    accessTokenTtl: number;
    refreshTokenTtl: number;
    sessionDuration: number;
    inactivityTimeout: number;
    rateLimitRpm: number;
    rateLimitBurst: number;
    createdAt: string;
    updatedAt: string;
}
export interface AuthStore {
    accessToken: string | null;
    publicProfile: Record<string, any>;
    jwtPayload: Record<string, any> | null;
    isAuthenticated: boolean | undefined;
}
/** What `tokenRequest` learned about a failed grant: `refused` when the
 *  token endpoint said the grant itself is dead (a real 401, or a 400
 *  carrying the code the standard gives an invalid, expired or revoked
 *  refresh token); `unavailable` for everything else — no answer, another
 *  4xx, a 5xx, or an empty or unreadable success body. Only a `refused`
 *  classification clears the stored session. */
export type TokenRequestFailure = 'refused' | 'unavailable';
export declare class TokenRequestError extends Error {
    readonly classification: TokenRequestFailure;
    readonly status: number | undefined;
    constructor(classification: TokenRequestFailure, status: number | undefined, message: string, options?: {
        cause?: unknown;
    });
}
/**
 * PKCE (Proof Key for Code Exchange) configuration
 */
export interface PKCEConfig {
    codeVerifier: string;
    codeChallenge: string;
    codeChallengeMethod: 'S256' | 'plain';
}
/** OAuth2 authentication manager for apps that don't have their own sign-in,
 *  registration or profile UI — those are handled by the IdP. */
/**
 * The `system.getMe` projection, spelled here because this package compiles
 * without the generated WQL types the apps carry — a transport-level DTO,
 * not a hand-written row type an app should copy.
 */
export type AccountMe = {
    _id: string;
    name: string | null;
    givenName: string | null;
    familyName: string | null;
    username: string | null;
    picture: string[];
    zoneinfo: string | null;
    createdAt: string;
    isPlatformUser: boolean | null;
    emails: {
        _id: string;
        email: string;
        primary: boolean | null;
        verified: string | null;
    }[];
};
export declare class OAuth2 {
    private readonly sdk;
    private readonly config;
    static readonly [pluginName] = "auth";
    store: StoreApi<AuthStore>;
    /** Invoked when a request fails with `step_up_required`. The token is
     *  still valid, so this must NOT log the user out; resolving `true`
     *  replays the request that tripped the gate. */
    onStepUpRequired?: (requiredAal: number) => void | Promise<boolean>;
    /** Set when a 401 on `refresh_token` already evicted the session, so 401
     *  recovery doesn't evict it twice. Cleared before each recovery refresh. */
    private refreshGrantEvicted;
    /** The DCR-minted client id, when `autoRegister` had to mint one. */
    private mintedClientId;
    /** The wire identity was validated against the base this page-load. */
    private clientEnsured;
    /** Concurrent flows share one probe/registration round trip. */
    private ensureClientPromise;
    /** Concurrent failures share one deleted-client recovery. */
    private recoverClientPromise;
    constructor(sdk: wyndbaseSDK, config: OAuth2Config);
    /** Fetches one of the fixed sign-in button SVG variants; `md` by default. */
    getSignInButton(size?: SignInButtonSize): Promise<import("@elysiajs/eden").Treaty.TreatyResponse<{
        200: Response;
        422: {
            type: 'validation';
            on: string;
            summary?: string;
            message?: string;
            found?: unknown;
            property?: string;
            expected?: string;
        };
    }>>;
    tokenRequest(request: Omit<OAuth2Request, 'client_id'>): {
        request: OAuth2Request & OAuth2RequestCommons;
        send: () => Promise<OAuth2TokenResponse>;
    };
    /** The client id the wire sees: the DCR-minted identity once one exists,
     *  the declared one otherwise. Needed by custom login routes that don't go
     *  through `tokenRequest` (e.g. discoverable passkey login). */
    get clientId(): string;
    /**
     * Resolves the wire client id before a flow starts. With `autoRegister`
     * on, validates whichever identity is held (a previously minted one first)
     * and registers via RFC 7591 DCR when the base knows neither. No-op
     * otherwise.
     */
    private ensureRegisteredClient;
    /** Whether the base knows a client under this id — 404 is the one "no". */
    private clientExists;
    private resolveClientRegistration;
    /** The client id a server refusal names as unknown, or null. Matches the
     *  exact `Client not found: <id>` sentence the auth endpoints 500 with when
     *  the wire client id no longer resolves — the flow probe can't catch this
     *  case, because it only runs before `authorize()` and treats only a 404 as
     *  "no". */
    private unknownClientIdOf;
    /** Recovers from the base no longer knowing the wire client id (an operator
     *  cleanup, a reset dev base): the stored DCR identity is dropped, the dead
     *  session — its tokens were minted for the deleted client and no grant can
     *  revive them — is signed out, and with `autoRegister` on a fresh client is
     *  registered so the next sign-in runs under an id the base knows instead of
     *  failing on the stale one until storage is cleared by hand. */
    private recoverDeletedClient;
    private reRegisterAfterClientLoss;
    /** Store an externally-obtained token response (e.g. from the discoverable
     *  passkey login route, which isn't a `/token` grant). */
    applyTokenResponse(tokens: OAuth2TokenResponse): void;
    /** The current URL scrubbed of any previous round's callback params.
     *  Starting a flow FROM a callback URL (a retry after a failed or expired
     *  exchange) must not nest the old code into the next redirect_uri — the
     *  return leg would then carry two code/state pairs and the exchange would
     *  read the burned first pair. */
    private cleanReturnUrl;
    /** The redirect_uri this app registers and presents: origin + path, never
     *  the query. RFC 6749 §3.1.2.3 compares byte-for-byte against the
     *  registered set, so the URI must not vary per visit — a login URL
     *  carrying `?redirect=/app` would mint a new unregistered URI for every
     *  distinct return target (masked in development by the loopback
     *  exception, refused in production). Anything the page carries in its
     *  query rides `state.redirect` instead and is handed back by `grant()`. */
    private canonicalRedirectUri;
    /** Opt-in for an application that is not the identity provider's own front
     *  end: registers an `onStepUpRequired` that raises assurance in a window
     *  at the provider instead of in a dialog this app would have to build. */
    enableHostedStepUp(options?: HostedStepUpOptions): void;
    /** Starts OAuth2 authorization with PKCE, opening a popup or new tab and
     *  listening for completion. */
    authorize(config?: AuthorizeConfig): Promise<void>;
    /** Completes the authorization code grant: exchanges the code in the URL
     *  for tokens using the stored PKCE verifier.
     *
     *  Resolves `undefined` when the URL carries no grant, and
     *  `{ returnUrl }` after a successful exchange — the URL the flow started
     *  from, query intact. The callback lands on the canonical (query-less)
     *  redirect_uri, so anything the starting page carried in its own query
     *  (a `?redirect=` target, filters) comes back HERE, not in
     *  `window.location`. */
    grant(): Promise<{
        returnUrl: string | null;
    } | undefined>;
    /** The state's return URL, or null for anything not on this origin. The
     *  state is CSRF-checked against this tab's own storage, so a foreign
     *  value should be impossible — but a navigation target is exactly where
     *  "should be" is not enough. */
    private sameOriginReturnUrl;
    /**
     * The whole redirect sign-in as one call, for a login page that wants no
     * button and no flow bookkeeping. Call it from the login route's loader
     * and render by the returned status:
     *
     * - `granted` — this was the return leg; the code in the URL was exchanged.
     *   In a popup the window signalled its opener and closed; in the same-tab
     *   flow `onSuccess` ran (navigate away with your router).
     * - `authenticated` — a live session already exists; `onSuccess` ran.
     * - `redirecting` — the flow was started; the page is navigating to the IdP.
     * - `failed` — the exchange was refused or unreachable. Deliberately NOT restarted here:
     *   auto-reauthorizing on a failed exchange loops the browser between this
     *   page and the IdP. Offer a retry that calls `authorize({redirect:true})`.
     */
    signIn(config?: {
        /** Leaves the callback URL after a grant (or an existing session) — hand
         *  it your router's replace/navigate. Without it the page keeps
         *  rendering and the caller acts on the returned status instead. On the
         *  return leg `ctx.returnUrl` is the URL the flow started from (see
         *  {@link grant}); on an already-authenticated visit it is null and the
         *  current URL still carries the page's own query. */
        onSuccess?: (ctx?: {
            returnUrl: string | null;
        }) => void;
        /** Scopes to request when the flow starts — see {@link AuthorizeConfig.scope}. */
        scope?: string[];
    }): Promise<{
        status: 'granted' | 'authenticated' | 'redirecting' | 'failed';
        /** Set on `granted`: the URL the flow started from, query intact. */
        returnUrl?: string | null;
    }>;
    /** Finishes a granted sign-in. In the popup/tab flow it signals the opener
     *  and closes this window; in the redirect flow (no opener) there is
     *  nothing to close — it hands control to `onSuccess` so the app's router
     *  can leave the callback URL (falling back to a full reload). */
    complete(config?: {
        onSuccess?: () => void;
    }): void;
    /** Clears stored tokens and the authorization header; does not call the
     *  server-side revocation endpoint. */
    /**
     * Signs out. `scope: 'app'` (default) keeps today's semantics — local
     * tokens are cleared, the IdP SSO session survives and the next `signIn`
     * completes silently. `scope: 'sso'` is the Keycloak-style single logout:
     * a full-page redirect to the `end_session_endpoint`, which revokes both
     * this client's session and the IdP SSO session, then returns to
     * `postLogoutRedirectUri` (must be registered for the client; defaults to
     * the current page without its OAuth params).
     */
    logout(config?: {
        scope?: 'app' | 'sso';
        postLogoutRedirectUri?: string;
    }): void;
    /** What it takes to reach `aal`: verify a held factor, enrol one that
     *  isn't, or answer `unsatisfiable`. The `client` narrowing happens in
     *  the route, not the engine, so a client cannot claim its way past a
     *  step-up gate. */
    getStepUpFactors(aal: number, client?: {
        webauthn: boolean;
    }): Promise<{
        aal: number;
        mode: 'verify' | 'enroll' | 'unsatisfiable';
        factors: string[];
        escapes: string[];
        autoSelect?: string;
    }>;
    /** WebAuthn assertion options for a step-up with an enrolled passkey. */
    stepUpChallenge(factorType: string): Promise<any>;
    /** Begin enrolling a factor for step-up. TOTP returns `factorId`+`secret`;
     *  a passkey returns `challengeToken`+`options` and writes no pending row. */
    beginStepUpEnroll(payload: {
        type: string;
        label?: string;
    }): Promise<{
        factorId?: string;
        challengeToken?: string;
        options?: any;
        secret?: string;
        uri?: string;
    }>;
    /** Elevate the session's AAL (step-up) by verifying or enrolling a
     *  factor; the elevated token is swapped in transparently.
     *  `recoveryCodes`, when present, are shown once and never retrievable
     *  again — a caller that drops them costs the user their backup. */
    stepUp(payload: {
        factorType: string;
        intent?: 'verify' | 'enroll';
        code?: string;
        factorId?: string;
        challengeToken?: string;
        response?: unknown;
        label?: string;
        aal?: number;
    }): Promise<{
        aal: number;
        recoveryCodes?: string[];
    }>;
    isAuthenticated(): false | {
        acr?: string | undefined;
        amr?: string[] | undefined;
        baseId: string;
        clientId: string;
        exp: number;
        iss: string;
        roles: string[];
        scope: string;
        sid?: string | undefined;
        sub: string;
        typ: "access" | "session";
        userId: string;
    } | null;
    discover(): void;
    private validateCSRFState;
    private handleCSRFError;
    private generateCodeVerifier;
    private generateCodeChallenge;
    private generatePKCE;
    private getPrefixed;
    start(): Promise<string | undefined>;
    /** Refreshes the access token using the stored refresh token; no-op if the
     *  current token is still valid unless `force`. */
    refresh(tokenOnly?: boolean, force?: boolean): Promise<string | undefined>;
    private set;
    private use;
    private unset;
    private getStorage;
    private setTokens;
    private clearTokens;
    /** `skewMs` treats the token as expired this early; the 401 classifier
     *  passes an allowance because its verdict is the server's clock, not ours. */
    private isTokenExpired;
    /** Distinguishes a 401 caused by our bearer token (worth a refresh) from
     *  one caused by the request itself, e.g. a wrong password — refreshing on
     *  the latter would sign the user out over a typo. `isTokenAudienceChallenge`
     *  exempts a token minted for a different base, which no refresh can fix. */
    private classifyUnauthorized;
    private parseJwt;
    private setAuthorizationHeader;
    private initializeInterceptors;
    private initializeStore;
    /** The account behind the current token — profile, emails and username.
     *  Straight off `system.getMe`, pinned to the token's own base; the
     *  identity context is derived server-side from the session, never from
     *  anything this client sends. */
    get getMe(): import("../define-query").QueryDefinition<AccountMe | null, import("../define-query").NullableDeps<Record<string, unknown>, string>>;
    /** `isAdmin` answers "holds the role in that base"; `canAdministerBase` is
     *  also true for a platform administrator working in a tenant base.
     *  `baseId` is required: a caller that does not say which base it means is
     *  the defect this argument exists to prevent. */
    get getMyRoles(): import("../define-query").QueryDefinition<{
        roles: string[];
        isAdmin: boolean;
        canAdministerBase: boolean;
    }, import("../define-query").NullableDeps<{
        baseId: string;
    }, "baseId">>;
    /**
     * A complete buttonless login route in one call — hand the result to your
     * router and the SDK does the rest: starts the redirect flow when signed
     * out, exchanges the returned code, retries a failed exchange once with a
     * fresh authorization, and leaves the page through the router.
     *
     * ```ts
     * export const Route = createFileRoute('/login')(
     *   wyndbase.auth.signInRouteOptions(() => router),
     * )
     * ```
     *
     * `getRouter` is a thunk because route modules evaluate while the router
     * module is still mid-import (the route tree imports them) — a direct
     * reference would read the binding before it exists.
     */
    signInRouteOptions(getRouter: () => {
        history: {
            replace: (href: string) => void;
        };
    }, options?: {
        /** Scopes every sign-in through this route requests — see
         *  {@link AuthorizeConfig.scope}. */
        scope?: string[];
    }): {
        loader: ({ deps }: {
            deps: {
                redirect?: string;
            };
        }) => Promise<{
            status: "authenticated" | "failed" | "granted" | "redirecting";
        }>;
        loaderDeps: ({ search }: {
            search: {
                redirect?: string;
            };
        }) => {
            redirect: string | undefined;
        };
        validateSearch: (search: Record<string, unknown>) => {
            redirect?: string;
        };
    };
}
