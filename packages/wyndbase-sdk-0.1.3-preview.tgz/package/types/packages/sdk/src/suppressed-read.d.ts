/** A read the data layer declined to issue, and why — lets a caller tell "I never asked" from "I asked and there was nothing there". */
export type SuppressionReport = {
    query: string;
    /** Declared dependencies that were absent, in declaration order. */
    missing: string[];
};
/** Where the report rides on a query's options object. */
export declare const SUPPRESSED_READ_META_KEY = "__wynSuppressedRead";
/** Thrown by the imperative read paths (`await`, `.fetch()`, `.ensure()`) instead of issuing a request the declaration forbids. */
export declare class SuppressedReadError extends Error {
    readonly query: string;
    readonly missing: string[];
    constructor(report: SuppressionReport);
}
/** Compute the report for one call; `undefined` means the read may be issued. Absence is `undefined`/`null` only — an empty string is a value the caller chose. */
export declare function suppressionReport(query: string, deps: readonly string[], args: Record<string, unknown>): SuppressionReport | undefined;
/**
 * Ask this about the query-options object, not a `useQuery` result (which
 * drops `meta`). Useless with `useSuspenseQuery`, which hard-forces `enabled: true`.
 */
export declare function isSuppressedRead(source: unknown): {
    suppressed: boolean;
    missing: string[];
    query?: string;
};
