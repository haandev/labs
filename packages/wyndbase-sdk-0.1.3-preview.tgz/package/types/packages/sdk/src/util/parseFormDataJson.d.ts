/**
 * Convert FormData (browser) to JSON object
 */
export declare function parseFormDataJson(formData: FormData): Record<string, any>;
