/**
 * Coordinates one step-up challenge so every request that tripped the gate at
 * once observes the same outcome. Both `onStepUpRequired` implementations
 * share it: the identity provider's own dialog and the hosted window handler.
 */
export type StepUpChallenge = {
    /**
     * Join the challenge in flight, or open one — `open` runs only for the
     * caller that actually opened it. Resolves when the challenge settles.
     *
     * A waiter is told `true` only if its required level was reached; a lower
     * challenge tells it `false` so it is re-challenged at its own level.
     */
    join: (requiredAal: number, open: () => void) => Promise<boolean>;
    /** Report the outcome to every waiter and end the challenge. */
    settle: (cleared: boolean) => void;
    isPending: () => boolean;
};
export declare function createStepUpChallenge(): StepUpChallenge;
