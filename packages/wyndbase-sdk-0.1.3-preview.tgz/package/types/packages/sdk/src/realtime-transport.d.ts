export interface RealtimeTransportConfig {
    baseURL: string;
    baseId: string;
    headers: Record<string, string>;
}
/** Why a subscribe POST gave up. `'unauthorized'` must not be re-armed with
 *  the same credentials — that is what produces a subscribe/refetch loop.
 *  `'deferred'` means nothing was sent: the stream has no usable connection
 *  id, so its reconnect is the retry and no attempt was spent. */
export type SubscribeFailureReason = 'unauthorized' | 'failed' | 'deferred';
export type RealtimeTransportStatus = 'connected' | 'reconnecting' | 'disconnected';
export interface RealtimeTransport {
    init(config: RealtimeTransportConfig): Promise<void>;
    /** `ttlMs` is an optional per-subscription idle TTL override; the server clamps it to [30s, 6h].
     *
     *  Resolves once the server has accepted or refused the subscribe, never on
     *  merely sending it — a caller may read the settle as an acceptance. A
     *  refusal reaches `onSubscribeFailed` first, so the subscription must be on
     *  the caller's own books before the call. */
    subscribe(keyHash: string, trackingId: string, ttlMs?: number): Promise<void>;
    unsubscribe(keyHash: string): Promise<void>;
    /** Resolves to the keyHashes the server could NOT recover; the caller must re-execute those to get fresh trackingIds. */
    resubscribeBatch(keyHashes: string[]): Promise<string[]>;
    onInvalidate(handler: (keyHash: string) => void): void;
    onExpired(handler: (keyHash: string) => void): void;
    onReconnected(handler: () => void): void;
    onSubscribeFailed(handler: (keyHash: string, reason: SubscribeFailureReason) => void): void;
    onStatusChange(handler: (status: RealtimeTransportStatus) => void): void;
    updateHeaders(headers: Record<string, string>): void;
    /** Implementations should send a sync message to release server-side subscriptions before the port closes. */
    notifyClosing?(): void;
    destroy(): void;
}
export declare class DirectTransport implements RealtimeTransport {
    private sse;
    private connId;
    private invalidateHandler?;
    private expiredHandler?;
    private reconnectedHandler?;
    private subscribeFailedHandler?;
    private statusHandler?;
    /** Opening counts as reconnecting — not connected, but expecting to be, so
     *  a stream refused before it ever connects still reports a change. */
    private status;
    private config;
    private closed;
    /** `undefined` until the first header set, so initialization never counts as a subject change. */
    private subject;
    init(config: RealtimeTransportConfig): Promise<void>;
    /** `isReconnect` is passed by {@link reconnect}, which clears `connId`
     *  before calling — and a drop now clears it too — so the id can no
     *  longer say whether this is a first connect, and a caller that knows
     *  has to say so. Never pass it together with `onFirstConnect`: that
     *  callback wins, and the reconnect would go unannounced — which is the
     *  defect this flag exists to fix. */
    private connect;
    subscribe(keyHash: string, trackingId: string, ttlMs?: number): Promise<void>;
    resubscribeBatch(keyHashes: string[]): Promise<string[]>;
    unsubscribe(keyHash: string): Promise<void>;
    onInvalidate(handler: (keyHash: string) => void): void;
    onExpired(handler: (keyHash: string) => void): void;
    onReconnected(handler: () => void): void;
    onSubscribeFailed(handler: (keyHash: string, reason: SubscribeFailureReason) => void): void;
    onStatusChange(handler: (status: RealtimeTransportStatus) => void): void;
    private setStatus;
    updateHeaders(headers: Record<string, string>): void;
    private reconnect;
    destroy(): void;
}
