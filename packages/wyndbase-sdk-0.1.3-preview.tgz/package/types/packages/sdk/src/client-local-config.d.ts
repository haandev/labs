/**
 * Fields this library reads itself, stripped before the query endpoint sees
 * them — its schema is a strictObject that 400s on an unknown key.
 */
export declare const CLIENT_LOCAL_CONFIG: Readonly<{
    /** Selects the mutation caller and defaults `allowMutation`. Server-ignored. */
    mutation: boolean | undefined;
    /** Selects which base's caller is built. Never leaves the client. */
    overrideBaseId: string | undefined;
    /** Becomes the `x-wql-silent` header. Stays on the read caller's body until
     *  just before the POST, so two reads differing only here key separately
     *  despite identical wire bodies. */
    silent: boolean | undefined;
}>;
/** Fields named by {@link CLIENT_LOCAL_CONFIG}, derived so the two can't diverge. */
export type ClientLocalQueryConfig = Partial<typeof CLIENT_LOCAL_CONFIG>;
/** Everything {@link CLIENT_LOCAL_CONFIG} allows except the routing flag,
 *  which only the general caller acts on. */
export type RoutingFreeClientLocalConfig = Omit<ClientLocalQueryConfig, 'mutation'>;
/** Splits a caller's query config into the part this library reads (`local`)
 *  and the part the query endpoint receives (`wire`). */
export declare function splitQueryConfig<C extends object>(config: (C & ClientLocalQueryConfig) | undefined): {
    local: ClientLocalQueryConfig;
    wire: Omit<C, keyof ClientLocalQueryConfig>;
};
