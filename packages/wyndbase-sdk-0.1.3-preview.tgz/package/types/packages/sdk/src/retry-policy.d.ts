/**
 * Six attempts is ~30s with the default backoff — fine for a background
 * query, too slow for one a reader is waiting on.
 */
export declare const DEFAULT_QUERY_MAX_FAILURES = 5;
/** Pass a smaller `maxFailures` to tighten one query's patience without restating the status list. */
export declare function shouldRetryQuery(failureCount: number, error: unknown, maxFailures?: number): boolean;
