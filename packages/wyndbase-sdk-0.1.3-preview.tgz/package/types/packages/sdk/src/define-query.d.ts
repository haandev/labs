import type { EnsureQueryDataOptions, FetchQueryOptions, InvalidateOptions, QueryObserverOptions } from '@tanstack/query-core';
import type { Promice } from '../../shared/src/promice';
import type { QueryFnContext } from './core';
/**
 * Return type for SDK query methods that combines lazy promise execution with TanStack Query integration.
 *
 * This hybrid type allows queries to be:
 * - Awaited directly for immediate execution
 * - Passed to `useQuery` hook with automatic queryKey and queryFn
 * - Chained with fetch/ensure/invalidate methods
 *
 * @template T - The QueryEnvelope type with config-based fields
 *
 * @example
 * ```typescript
 * // Direct await
 * const result = await sdk.query('users', { status: 'active' })
 *
 * // Use with React Query
 * const { data } = useQuery(sdk.query('users', { status: 'active' }))
 *
 * // Chained methods
 * await sdk.query('users', { status: 'active' }).fetch({ staleTime: 10000 })
 * ```
 */
export type wqlQuery<T> = CallerOutput<T>;
export type wqlMutation<T> = MutationCallerOutput<T>;
export type QueryOptionals<A> = Omit<A, 'queryFn' | 'queryKey'>;
export type MutationOptionals<A> = Omit<A, 'mutationFn' | 'mutationKey'>;
export type AllowedOptions<T = unknown> = QueryOptionals<FetchQueryOptions<T> | EnsureQueryDataOptions<T>>;
export type ParemeterlessTSQFuncions<T> = {
    /**
     * Fetches query data with optional TanStack Query configuration.
     * Always executes a fresh query request.
     *
     * @param options - Optional TanStack Query fetch options (staleTime, gcTime, etc.)
     * @returns Lazy promise resolving to query data
     */
    fetch: (options?: QueryOptionals<FetchQueryOptions<T>>) => Promice<T>;
    /**
     * Ensures query data exists in cache, fetching only if needed.
     * More efficient than fetch when data might already be cached.
     *
     * @param options - Optional TanStack Query ensure options
     * @returns Lazy promise resolving to cached or freshly fetched data
     */
    ensure: (options?: QueryOptionals<EnsureQueryDataOptions<T>>) => Promice<T>;
    /**
     * Marks this query as stale in the TanStack Query cache, triggering refetch on next access.
     *
     * @param options - Optional invalidation options (refetchType, etc.)
     * @returns Lazy promise that resolves when invalidation completes
     */
    invalidate: (options?: QueryOptionals<InvalidateOptions>) => Promice<void>;
    options: (options?: QueryOptionals<QueryObserverOptions<T>>) => FetchQueryOptions<T>;
    /** Mark this query for realtime invalidation via SSE */
    realtime: (config?: RealtimeConfig<T>) => CallerOutput<T> & RealtimeMeta;
};
export interface ParameterizedTSQFuncions<T, Args> {
    /**
     * Fetches query data with explicit parameters and optional configuration.
     *
     * @param args - Query parameter arguments as tuple
     * @param options - Optional TanStack Query fetch options
     * @returns Lazy promise resolving to query data
     */
    fetch: (args: Args, options?: QueryOptionals<FetchQueryOptions<T>>) => Promice<T>;
    /**
     * Ensures query data exists for given parameters, fetching only if needed.
     *
     * @param args - Query parameter arguments as tuple
     * @param options - Optional TanStack Query ensure options
     * @returns Lazy promise resolving to cached or freshly fetched data
     */
    ensure: (args: Args, options?: QueryOptionals<EnsureQueryDataOptions<T>>) => Promice<T>;
    /**
     * Invalidates query cache for specific parameters.
     *
     * @param args - Query parameter arguments as tuple
     * @param options - Optional invalidation options
     * @returns Lazy promise that resolves when invalidation completes
     */
    invalidate: (args: Args, options?: QueryOptionals<InvalidateOptions>) => Promice<void>;
    options: (args: Args, options?: QueryOptionals<QueryObserverOptions<T>>) => FetchQueryOptions<T>;
    /** Returns a realtime-aware query definition */
    realtime: (config?: RealtimeConfig<T>) => RealtimeCallerFn<T>;
}
export interface RealtimeConfig<T = unknown> {
    /** Called when the server signals that the query's data may have changed (before refetch) */
    onInvalidate?: () => void;
    /**
     * Controls automatic refetch on invalidation, independent of TanStack Query observers.
     * - `true`: SDK refetches the query and updates the cache
     * - `(data: T) => void`: SDK refetches and passes the new data to the callback
     * - `undefined`: no SDK-driven refetch (TanStack Query handles it via observers)
     *
     * Safe to use alongside useQuery — same QueryClient ensures dedup.
     */
    forceRefetch?: boolean | ((data: T) => void);
    /**
     * Per-subscription idle TTL override (ms). Server-side `RealtimeHub.sweep`
     * uses this instead of the global default (5min) when deciding when to
     * evict an idle subscription. The server clamps to [30s, 6h].
     *
     * Use a longer TTL (e.g. 6h) for queries that may stay idle for long
     * periods (inbox, settings) to avoid the resubscribe round-trip on every
     * sweep. Use a shorter TTL when you need tight memory bounds.
     */
    ttlMs?: number;
    /**
     * Behavior when the server drops the subscription via the idle-TTL sweep
     * (`expired` event). Does not affect `subscribe-failed` or `reconnected`
     * recovery — those always resubscribe.
     *
     * - `'resubscribe'` (default): batched rebind via the server tracking
     *   cache; transparent recovery, no observer impact.
     * - `'invalidate'`: mark the query stale (`refetchType: 'none'`) without
     *   resubscribing. The next observer access fetches fresh data and the
     *   resulting cache update naturally re-arms realtime tracking. Use when
     *   the data is cheap to refetch and you want to avoid background work.
     * - `'drop'`: stop tracking entirely. Realtime invalidations no longer
     *   reach this query for the remainder of its lifetime. Use when realtime
     *   was only relevant for an initial window.
     */
    onExpire?: 'resubscribe' | 'invalidate' | 'drop';
    /**
     * Default `false`. Set to `true` to release server-side subscriptions
     * while the tab is hidden (`document.visibilityState === 'hidden'`) and
     * take them up again when it becomes visible. Saves server fan-out work
     * for background tabs; the query re-executes on return.
     *
     * Keep `false` (the default) for queries whose invalidations must reach
     * the user even when the tab is in the background (inbox notifications,
     * presence, etc).
     */
    pauseWhenHidden?: boolean;
}
export interface RealtimeMeta {
    __realtime: true;
    __realtimeKeyHash: string;
    __realtimeConfig?: RealtimeConfig;
    /** Unsubscribe from realtime invalidation. Safe to call multiple times. */
    unsubscribe: () => void;
}
type RealtimeCallerFn<T> = (...args: any[]) => CallerOutput<T> & RealtimeMeta;
interface QueryOptions<T> {
    queryFn: () => Promise<T>;
    queryKey: any[];
}
/**
 * Return type when a query is called with parameters.
 *
 * Combines three interfaces to create a versatile query result that can:
 * 1. Be awaited as a lazy promise (Promice<T>)
 * 2. Be spread into useQuery hook (QueryOptions<T>)
 * 3. Chain parameterless methods (ParemeterlessTSQFuncions<T>)
 *
 * @template T - The data type returned by the query
 *
 * @example
 * ```typescript
 * const result = sdk.users({ status: 'active' })
 *
 * // 1. Await directly
 * const data = await result
 *
 * // 2. Pass to useQuery
 * const { data } = useQuery(result)
 *
 * // 3. Chain methods
 * await result.fetch({ staleTime: 10000 })
 * await result.invalidate()
 * ```
 */
export interface CallerOutput<T> extends Promice<T>, QueryOptions<T>, ParemeterlessTSQFuncions<T> {
}
/** Makes the specified keys nullable (used by deps) */
export type NullableDeps<T extends Record<string, unknown>, K extends keyof T> = {
    [P in keyof T]: P extends K ? T[P] | null | undefined : T[P];
};
type CallerFn<T, Args extends Record<string, unknown>> = (args?: Args, context?: QueryFnContext) => CallerOutput<T>;
/**
 * Complete query definition type returned by `defineQuery`.
 *
 * Represents a fully-featured query that can be:
 * 1. Called with parameters to get CallerOutput
 * 2. Used with parameterized methods (fetch/ensure/invalidate with explicit args)
 *
 * This dual nature enables both imperative and declarative query patterns.
 *
 * @template T - The data type returned by the query
 * @template Args - Tuple type of query parameter arguments
 *
 * @example
 * ```typescript
 * // Created by defineQuery
 * const getUsers: QueryDefinition<User[], [{ status: string }]> =
 *   sdk.defineQuery('getUsers', (params) => api.getUsers(params))
 *
 * // Pattern 1: Call then use
 * const result = getUsers({ status: 'active' })
 * await result
 *
 * // Pattern 2: Parameterized methods
 * await getUsers.fetch([{ status: 'active' }])
 * await getUsers.invalidate([{ status: 'active' }])
 * ```
 */
export interface QueryDefinition<T, Args extends Record<string, unknown>> extends CallerFn<T, Args>, ParameterizedTSQFuncions<T, Args> {
}
export interface MutationCallerOutput<T> extends Promice<T> {
    mutationFn: () => Promise<T>;
}
type MutationCaller<T, Args extends unknown[]> = (...args: Args) => MutationCallerOutput<T>;
export interface MutationDefinition<T, Args extends unknown[]> extends MutationCaller<T, Args> {
    mutationFn: (args: Args) => Promise<T>;
}
export {};
