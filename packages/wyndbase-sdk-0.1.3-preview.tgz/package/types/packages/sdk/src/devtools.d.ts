import type { QueryClient } from '@tanstack/query-core';
export interface WyndbaseDevtoolsPanelProps {
    /** The QueryClient whose cache the panel inspects. */
    client: QueryClient;
    /** Load the real panel in production builds too (the default entry no-ops outside development). */
    keepOnProduction?: boolean;
}
export interface WyndbaseDevtoolsProps extends WyndbaseDevtoolsPanelProps {
}
/** Standalone form for hosts without chrome of their own: a fixed logomark
 *  trigger toggling a bottom sheet that holds the panel. A host with its own
 *  slot (a status bar, a drawer) embeds {@link WyndbaseDevtoolsPanel} instead. */
export declare function WyndbaseDevtools({ client, keepOnProduction, }: WyndbaseDevtoolsProps): import("react").JSX.Element;
/** The wyndbase-branded TanStack Query devtools panel, sized to fill its host. */
export declare function WyndbaseDevtoolsPanel({ client, keepOnProduction, }: WyndbaseDevtoolsPanelProps): import("react").JSX.Element;
