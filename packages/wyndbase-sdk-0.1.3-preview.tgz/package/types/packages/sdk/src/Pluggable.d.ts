/**
 * The symbol used to identify a plugin.
 * Use this to define a class that can be plugged into the Pluggable instance.
 * ```typescript
 * class MyPlugin {
 *   static readonly [pluginName] = 'myPlugin'
 * }
 * ```
 */
export declare const pluginName: unique symbol;
export type PluginName = typeof pluginName;
type Prettify<T> = {
    [K in keyof T]: T[K];
} & {};
type ClassType = {
    new (...args: any[]): InstanceType<any>;
};
type Tail<T extends any[]> = T extends [any, ...infer Rest] ? [...Rest] : [];
type PluggingClass<T> = new (core: T, ...args: any[]) => any;
type AutoPluggableClass<T, Name extends string | symbol> = PluggingClass<T> & {
    [pluginName]: Name;
};
type PluggingFunction<T> = (core: T, ...args: any[]) => unknown;
type AutoPluggableFunction<T, Name extends string | symbol> = PluggingFunction<T> & {
    [pluginName]: Name;
};
type AutoPluggable<T, Name extends string | symbol> = AutoPluggableClass<T, Name> | AutoPluggableFunction<T, Name>;
type InferName<T> = T extends AutoPluggableClass<any, infer Name> ? Name : T extends AutoPluggableFunction<any, infer Name> ? Name : never;
type InferOutput<T> = T extends AutoPluggableClass<any, any> ? InstanceType<T> : T extends AutoPluggableFunction<any, any> ? ReturnType<T> : never;
type Plugin<T> = PluggingFunction<T> | PluggingClass<T>;
/**
 * The type of the Pluggable instance with the plugins.
 * @param PluggableInstance - The Pluggable instance
 * @param Plugins - The plugins
 * @returns The Pluggable instance with the plugins
 * Usefull for enforce one Pluggable instance with some plugins installed.
 * ```typescript
 * type CoreWithPlugins = WithPlugins<Pluggable, { myPlugin: MyPlugin }>
 * class DependentPlugin {
 *   //core is now typed as CoreWithPlugins,
 *   //so you can use DependentPlugin only with the instances which has myPlugin installed.
 *   constructor(private readonly core: MyPlugin) { }
 * }
 * const core = new Pluggable().use(DependentPlugin) // will cause type error because MyPlugin is not installed
 *
 * const core = new Pluggable()
 *  .use(MyPlugin)
 *  .use(DependentPlugin) // will be fine because MyPlugin is installed before DependentPlugin
 * ```
 */
export type WithPlugins<PluggableInstance extends InstanceType<ClassType>, Plugins extends Record<string | symbol, unknown>> = PluggableInstance & Plugins;
/**
 * The Pluggable class is the core class that allows you to plugin plugins into the instance.
 * class Core extends Pluggable {
 *   //your core class implementation
 * }
 * //now your class is able to accept plugins
 * const core = new Core()
 *  .plugin("namedPlugin",MyPlugin)
 *  .use(DependentPlugin)
 * ```
 */
export declare class Pluggable {
    private installerFunction;
    private installerClass;
    /**
     * Plugin a class which has a static [pluginName] property into the Pluggable instance.
     * @param f - The class to plugin
     * @param params - The parameters to pass to the class
     * @returns The Pluggable instance
     */
    use<F extends AutoPluggable<this, string | symbol>>(f: F, ...params: F extends PluggingClass<this> ? Tail<ConstructorParameters<F>> : F extends PluggingFunction<this> ? Tail<Parameters<F>> : never): WithPlugins<this, { [K in InferName<F>]: InferOutput<F>; }> extends infer T ? { [K in keyof T]: T[K]; } : never;
    /**
     * Plugin a function or class into the Pluggable instance.
     * @param name - The name of the plugin
     * @param f - The function or class to plugin
     * @param params - The parameters to pass to the function or class
     * @returns The Pluggable instance
     */
    plugin<F extends Plugin<this>, Name extends string | symbol>(name: Name, f: F, ...params: F extends PluggingClass<this> ? Tail<ConstructorParameters<F>> : []): WithPlugins<this, { [K in Name]: any; }> extends infer T ? { [K in keyof T]: T[K]; } : never;
}
/**
 * Makes a class pluggable by adding plugin functionality.
 *
 * Note: For classes that accept generic type parameters, use direct inheritance instead:
 * ```typescript
 * class MyPluggableClass<T> extends Pluggable {
 *   // your class implementation
 * }
 * ```
 */
export declare function makePluggable<T extends ClassType>(Base: T): {
    new (...args: ConstructorParameters<T>): Prettify<InstanceType<T> & Pluggable>;
};
/**
 * Named, so a plugin's declaration can spell its type: a unique symbol key
 * has no `import()` form, and an anonymous `{ [pluginName]: Name }` is
 * unnameable from any other file's emitted declarations.
 */
export type DefinedPlugin<Fn, Name extends string | symbol> = Fn & {
    [pluginName]: Name;
};
export declare const definePlugin: <Name extends string | symbol, Fn extends PluggingFunction<any>>(name: Name, fn: Fn) => DefinedPlugin<Fn, Name>;
export {};
