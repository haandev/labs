import { EdenFetchError, type Treaty, treaty } from '@elysiajs/eden';
export { EdenFetchError, treaty };
import { type MutationOptions, QueryClient, type QueryFunctionContext, type QueryOptions } from '@tanstack/query-core';
import type { Events } from '../../shared/src/event';
import { SSEClient } from '../../shared/src/sse-client';
import type { WQLOptions } from '../../wql/src/index';
import type { AppType } from '../../../apps/be/src/app-type';
/**
 * The per-base client, spelled through the treaty rather than inferred: the
 * inferred shape mentions an internal Eden type no declaration can import.
 */
export type BaseClient = ReturnType<Treaty.Create<AppType>['api']>;
import { ERROR_SILENT_HEADER, HttpClient, HttpError, type HttpResponse, httpStatusOf, isHttpError, NOTIFICATION_SILENT_HEADER } from './http-client';
import { type WqlRows } from './wql-rows';
export { NetworkMeter, type NetworkMeterSnapshot } from './network-meter';
export type { RealtimeConnectionState, RealtimeStatusSnapshot, } from './realtime-manager';
export type { AppType };
/** Last element of every realtime-tracked query's key. */
export declare const REALTIME_KEY_MARKER = "__realtime__";
import { type ClientLocalQueryConfig, type RoutingFreeClientLocalConfig } from './client-local-config';
import type { AllowedOptions, CallerOutput, MutationDefinition, MutationOptionals, NullableDeps, QueryDefinition, QueryOptionals, wqlMutation, wqlQuery } from './define-query';
import { NetworkMeter } from './network-meter';
import { Pluggable } from './Pluggable';
import { RealtimeManager } from './realtime-manager';
export declare const throwOnError: <D, E>({ error, data }: {
    error: E;
    data: D;
}) => NonNullable<D>;
type QueryFnContext = Partial<QueryFunctionContext> & {
    /** Base the request must target; absent means the active base. Set by
     *  `defineQuery`'s `overrideBaseId`, read by the inner fns that build the
     *  URL — the override rides the query fn itself, so it holds no matter who
     *  runs it (useQuery, fetchQuery, a refetch). */
    baseId?: string;
};
type SDKConfig = {
    serverUrl: string;
    /** A base reference: its `_id`, its physical name, or its name. */
    baseId: string;
    queryClient?: QueryClient;
    onSuccess?: (response: HttpResponse) => void;
    onError?: (error: HttpError) => void;
    /** Extra key element scoping the cache to an effective identity (e.g.
     *  act-as). Undefined keeps the plain three-element key. */
    queryKeyContext?: () => string | undefined;
};
/** Fallback: if no .wql.gen.d.ts is loaded, WQLGenerated defaults to empty. */
declare global {
    interface WQLGenerated {
    }
}
type InferResult<G, Q> = Q extends keyof G ? G[Q] extends {
    result: infer R;
} ? R & Record<any, unknown> : Record<string, unknown> : Record<string, unknown>;
type InferParams<G, Q> = Q extends keyof G ? G[Q] extends {
    params: infer P;
} ? P : Record<string, unknown> : Record<string, unknown>;
/** Does NOT throw on non-OK responses — Eden Treaty handles that. */
export declare const createInterceptedFetcher: (client: HttpClient, meter?: NetworkMeter) => typeof fetch;
/** Type-safe client for queries, mutations and OAuth2 against a wyndbase server. */
export declare class wyndbaseSDK<Gen = WQLGenerated> extends Pluggable {
    private readonly config;
    readonly http: HttpClient;
    readonly treat: Treaty.Create<AppType>;
    readonly queryClient: QueryClient;
    readonly realtimeManager: RealtimeManager;
    readonly networkMeter: NetworkMeter;
    private readonly wqlQuery;
    private readonly wqlMutation;
    private readonly wqlEnvelopeQuery;
    constructor(config: SDKConfig);
    get base(): BaseClient;
    /** Client for the given base, falling back to the active one. The inner
     *  query fns route through this with the context's `baseId`, which is how
     *  an `overrideBaseId` reaches the wire without touching the active base. */
    private baseFor;
    /** Always the immutable `baseId` from config, never the active one. */
    get tenant(): BaseClient;
    /**
     * The reference this SDK was configured with — a base `_id`, its physical
     * name, or its name. It builds every URL and every storage key, and it never
     * changes: a key derived from something that moves orphans whatever was
     * written under the earlier value.
     */
    get baseRef(): string;
    /**
     * The base's own `_id`, learned from the `X-Wyn-Base-Id` response header.
     * `undefined` until the first response lands, so it must never build a URL
     * or a key — identity questions only.
     */
    get canonicalBaseId(): string | undefined;
    private _canonicalBaseId;
    /** @deprecated Use `baseRef` for URLs and keys, `canonicalBaseId` for identity. */
    get baseId(): string;
    private _activeBaseId;
    get activeBaseId(): string;
    /** The effective-identity element the host scopes cache keys with, read now.
     *  Public so a composed caller keying its own entries scopes them by the
     *  same identity the plain reads underneath it already use. */
    get queryKeyContext(): string | undefined;
    setActiveBaseId(newBaseId: string): void;
    get serverUrl(): string;
    get apiBase(): string;
    get headers(): Record<string, string>;
    defineQuery: <T, Args extends Record<string, unknown>, D extends (keyof NoInfer<Args>)[] = []>(name: string, fn: (context: QueryFnContext, args: Args) => Promise<T>, deps?: D, defaultOptions?: QueryOptionals<QueryOptions>, overrideBaseId?: string) => QueryDefinition<T, D extends [] ? Args : NullableDeps<Args, D[number]>>;
    defineMutation: <T, Args extends any[]>(fn: (...args: Args) => Promise<T>, defaultOptions?: MutationOptionals<MutationOptions>) => MutationDefinition<T, Args>;
    private readonly _wqlQueryInner;
    private readonly _wqlEnvelopeInner;
    private readonly _wqlMutationInner;
    private readonly _wqlQueryCache;
    private readonly _wqlMutationCache;
    private _wqlQueryFor;
    private readonly _wqlEnvelopeCache;
    private _wqlEnvelopeFor;
    private _wqlMutationFor;
    query<Q extends string = string, C extends WQLOptions & AllowedOptions = Record<string, unknown>>(queryInput: Q, params?: InferParams<Gen, Q>, config?: C & RoutingFreeClientLocalConfig): wqlQuery<WqlRows<InferResult<Gen, Q>>>;
    mutation<Q extends string = string, C extends WQLOptions & AllowedOptions = Record<string, unknown>>(mutationInput: Q, params?: InferParams<Gen, Q>, config?: C & RoutingFreeClientLocalConfig): wqlMutation<WqlRows<InferResult<Gen, Q>>>;
    wql<T = unknown, Q extends string = NoInfer<string>, C extends WQLOptions & AllowedOptions & {
        mutation?: boolean;
    } = Record<string, unknown>>(wqlInput: Q, params?: InferParams<Gen, Q>, config?: C & ClientLocalQueryConfig): C extends {
        mutation: true;
    } ? wqlMutation<NoInfer<WqlRows<T & InferResult<Gen, Q>>>> : wqlQuery<NoInfer<WqlRows<T & InferResult<Gen, Q>>>>;
    /** What a query compiles to, without running it: the translated SQL as this
     *  caller would run it and as a policied caller would receive it, the result
     *  schema, the generated type, parameter metadata and an optional plan.
     *  Never returns rows — `wql` is the address for those. */
    wqlEnvelope<Q extends string = string, C extends AllowedOptions = Record<string, unknown>>(wqlInput: Q, params?: InferParams<Gen, Q>, config?: C & ClientLocalQueryConfig): CallerOutput<any>;
    /** Build, version and capability flags of the deployment. Pinned to
     *  `baseRef`, not the active base: the answer describes the server, so it
     *  must not be re-fetched and re-keyed every time a base is navigated. */
    get getServerInfo(): QueryDefinition<{
        buildNumber: string | null;
        env: "development" | "production" | "test";
        version: string;
    }, NullableDeps<Record<string, unknown>, string>>;
    openXHR: (method: 'POST' | 'GET' | 'PUT' | 'DELETE' | 'PATCH', url: string, options?: {
        onUploadProgress?: (event: ProgressEvent) => void;
        signal?: AbortSignal;
    }, { responseType }?: {
        responseType?: XMLHttpRequestResponseType;
    }) => {
        send: (data: any) => Promise<ResponseType>;
        xhr: XMLHttpRequest;
    };
    /** Authenticated by header, not query parameter: a URL carrying a live JWT
     *  lands in proxy and access logs. */
    openSSE: <E extends Events>(url: string, config?: Record<string, any>) => SSEClient<E>;
}
export * from './Pluggable';
export type { WqlRows, WqlRunMeta } from './wql-rows';
export type { HttpResponse, QueryFnContext };
export { ERROR_SILENT_HEADER, HttpError, httpStatusOf, isHttpError, NOTIFICATION_SILENT_HEADER, QueryClient, };
