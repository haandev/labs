/**
 * Groups SDK requests into interaction bursts for the status bar. A burst is
 * the set of requests one user interaction caused: near-simultaneous starts
 * plus the waterfall they trigger. Push-driven refetches (realtime
 * invalidations) are measured but never published — the client did not ask.
 */
export interface NetworkMeterSnapshot {
    /** Requests in the last published interaction burst. */
    requestCount: number;
    /** First request start → last response end of that burst, in ms. */
    durationMs: number;
    /** Sum of content-length over that burst; a lower bound (compressed, and 0 when the header is absent). */
    bytes: number;
    /** Requests currently in flight, across all bursts. */
    inFlight: number;
}
export declare class NetworkMeter {
    private listeners;
    private snapshot;
    private lastPushAt;
    private inFlight;
    private burst;
    getSnapshot(): NetworkMeterSnapshot;
    subscribe(listener: () => void): () => void;
    /** A realtime invalidation was just applied — refetches starting shortly after are its effect, not a user request. */
    notePush(now?: number): void;
    /** Call at request start; invoke the returned function exactly once when the response (or error) arrives. */
    begin(now?: number): (bytes?: number, endAt?: number) => void;
    private publish;
}
