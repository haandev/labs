import type { BaseNode } from '../../model/src/types';
import type { TransactionContext } from '../../shared/src/transaction';
import { type Query, type WQLOptions, type WQLResult, type WqlInfer, type WqlParams, type WqlRows, type WynModel, type WynModelTree } from '../../wql/src/index';
import { ActivityService } from './features/activity/ActivityService';
import { AlertService } from './features/alert/AlertService';
import { AuthService } from './features/auth/AuthService';
import type { BaseOpener } from './features/auth/tokenHomeBase';
import { BrowseService } from './features/browse/BrowseService';
import { DelegationService } from './features/delegation/DelegationService';
import { WorkflowService } from './features/flow/WorkflowService';
import { HistoryService } from './features/history/HistoryService';
import { InboxService } from './features/inbox/InboxService';
import { ModelService } from './features/model/ModelService';
import type { LocalS3Dispatch } from './features/storage/localS3Dispatch';
import { StorageService } from './features/storage/StorageService';
import { S3Service } from './features/storage/s3/S3Service';
import { SchemaCache } from './SchemaCache';
import type { CreationAttributes, ModelStatus } from './schema/ModelSchema';
import { TransactionManager } from './TransactionManager';
import { type ConnectionLane } from './wyndbase';
export declare class WynConnectionHandler {
    disposed: boolean;
    protected _definition: any;
    protected _status: ModelStatus;
    private _systemDefinition;
    /** Fixed at construction — the pool opens while the handler is built, so no
     *  later caller could still choose. */
    private _lane;
    private _transactionManager;
    private _schemaCache;
    private _parameterEngine;
    private _policyResolver;
    private _queryExecutor;
    private _activity;
    private _alerts;
    private _auth;
    private _browse;
    private _delegations;
    private _history;
    private _inbox;
    private _model;
    private _workflow;
    private _storage;
    private _s3;
    get activity(): ActivityService;
    get alerts(): AlertService;
    get auth(): AuthService;
    /** The engine's base opener, for collaborators that hold a handler and
     *  must open a different base. */
    get bases(): BaseOpener;
    get browse(): BrowseService;
    get delegations(): DelegationService;
    get history(): HistoryService;
    get storage(): StorageService;
    /** The host-installed local object route, or undefined before install. */
    get localS3Dispatch(): LocalS3Dispatch | undefined;
    get inbox(): InboxService;
    get model(): ModelService;
    get workflow(): WorkflowService;
    get s3Service(): S3Service;
    constructor(definition: CreationAttributes<BaseNode>, status?: ModelStatus, lane?: ConnectionLane);
    clone(): Promise<WynConnectionHandler>;
    dispose(): void;
    [Symbol.dispose](): void;
    get id(): any;
    get physicalName(): any;
    get name(): any;
    get existing(): boolean;
    get definition(): any;
    getStoredDefinition(): any;
    getDefinition(): Promise<any>;
    get immutable(): any;
    /**
     * Fail-closed on anything that is not literally `true`, including the
     * long-lived main-base handler, which never re-reads its definition.
     */
    get allowAnonymousAccess(): boolean;
    /**
     * This base's self-registration setting, read fresh from its own
     * `system.settings` row on every call — a changed setting takes effect
     * without a restart, unlike the definition-frozen getters this replaced.
     * Fail-closed: `enabled` is true only when literally `true`, and a role
     * that is not a non-empty string reads as "none" — a base that names
     * nothing must grant nothing.
     */
    selfRegistration(): Promise<{
        enabled: boolean;
        role: string | null;
    }>;
    get status(): ModelStatus;
    get lane(): ConnectionLane;
    get tx(): Promise<Bun.SQL> | Promise<Bun.TransactionSQL>;
    get con(): Promise<Bun.SQL>;
    get transactionContext(): Partial<TransactionContext> | null;
    /**
     * Who authenticated on this request, or `null` where nobody did — the
     * anonymous sentinel is a placeholder identity, never a principal.
     */
    sessionActor(): {
        userId: string | null;
    };
    /**
     * The identity a write is happening under. Public because the flow tier is
     * derived from it, and fail-closed on both unknowns: no caller, and a
     * session that does not say which base it authenticated against.
     */
    actingIdentity(): Promise<{
        userId: string | null;
        isPlatformUser: boolean;
    }>;
    /**
     * Wraps compilation and execution, since either can refuse. `budget` is a
     * parameter, not a field: compiling nests a `wql()` that would clobber a slot.
     */
    private withAnonymousExit;
    private resolveActorRoles;
    /**
     * The single seam every user-mode call site derives `$context` through, so
     * hand-built ones cannot drift. Explicit `config.context` wins, for act-as.
     */
    private policyContext;
    /**
     * The base this session authenticated against. The one place that knows
     * where it lives on a handler — every gate that weighs platform identity
     * reads it here rather than walking the context itself.
     */
    get callerHomeBaseId(): string | undefined;
    /**
     * Platform identity is a property of the session, not of the user row: it
     * asks which base the caller authenticated against. A context carrying no
     * home base — a job runner, an internal clone — is not a platform caller.
     */
    isPlatformCaller(): boolean;
    clearContext(): void;
    inTransaction<T extends (handler: WynConnectionHandler) => any>(exec: T): Promise<ReturnType<T>>;
    beginTransaction(): Promise<void>;
    finishTransaction(error?: any): void;
    setSystemDefinition(spaceDef: Record<string, any>): void;
    get structure(): any;
    drop(): Promise<void>;
    getStrippedModel(): Promise<WynModel>;
    /** Deduplicates concurrent callers onto a single DB fetch. */
    ensureStructure(): Promise<WynModel>;
    ensureModelTree(): Promise<WynModelTree>;
    invalidateStructure(): void;
    findModel(id: string): Promise<Record<string, any> | undefined>;
    /** One setup for both query doors, so policy, budget and bound cannot drift
     *  between them. */
    private prepareExecution;
    /** Use wql as a tagged template for parameterized queries. */
    wql<T = unknown>(strings: TemplateStringsArray, ...values: unknown[]): Promise<WqlRows<T & Record<string, unknown>>>;
    /** Use wql as prepared string statement with parameters object */
    wql<T = unknown, const Q extends string = string, C extends WQLOptions & {
        raw?: boolean;
        model?: WynModel | WynModelTree;
        skipRealtimeInvalidation?: boolean;
        skipPolyDisplay?: boolean;
    } = WQLOptions & {
        raw?: boolean;
        model?: WynModel | WynModelTree;
        skipRealtimeInvalidation?: boolean;
        skipPolyDisplay?: boolean;
    }>(query: Q, parameters?: WqlParams<Q>, config?: C): Promise<WqlRows<T & WqlInfer<Q> & Record<any, unknown>, C>>;
    /**
     * The design-write gate sits on the doors, not in `base.model.*` — undo and
     * migration replay call those with no user — so this third door installs it.
     */
    private applyDefinition;
    /** Labels the result's polymorphic link cells. On the execution path rather
     *  than in a surface, so browse, named queries and the SDK share one shape. */
    private addPolyDisplays;
    /** Execute a fluent API query built with `from().select().build()`. */
    raw<T extends Record<string, unknown> = Record<string, unknown>, C extends WQLOptions & {
        raw?: boolean;
        skipPolyDisplay?: boolean;
    } = WQLOptions & {
        raw?: boolean;
        skipPolyDisplay?: boolean;
    }>(query: Query | Query[], parameters?: Record<string, any>, config?: C): Promise<WQLResult<T, C>>;
    getCookieName(idp: string, clientId: string): Promise<string>;
    get schema(): SchemaCache;
    get transactions(): TransactionManager;
    transaction<T>(exec: (handler: WynConnectionHandler) => Promise<T>): Promise<T>;
    setContext(context: Partial<TransactionContext>): void;
}
