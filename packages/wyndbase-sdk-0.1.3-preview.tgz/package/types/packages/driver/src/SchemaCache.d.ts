import type { WqlRows, WynModel } from '../../wql/src/index';
import { WynModelTree } from '../../wql/src/index';
type QueryFn = (wql: string, params: Record<string, any>, config?: any) => Promise<WqlRows<any, any>>;
export declare class SchemaCache {
    private queryFn;
    private structureChildrenProvider;
    private handlerName;
    private _raw;
    private _tree;
    private _promise;
    private _treePromise;
    constructor(queryFn: QueryFn, structureChildrenProvider: () => any, handlerName: string);
    load(): Promise<WynModel>;
    /** Concurrent cold-cache callers share one in-flight tree build. */
    loadTree(): Promise<WynModelTree>;
    /**
     * Matches `_id` first, then `physicalName`, then `name`, in separate
     * passes so an `_id` match always wins over a name collision elsewhere.
     */
    find(id: string): Promise<Record<string, any> | undefined>;
    stripped(): Promise<WynModel>;
    invalidate(): void;
    shareTo(other: SchemaCache): void;
    get cached(): WynModel | null;
    get cachedTree(): WynModelTree | null;
    /** @internal Ad-hoc LINK directives inline the self-referencing join
     *  because `children` comes from the model this query is fetching. */
    private _load;
}
export {};
