export declare class UnauthenticatedError extends Error {
    readonly status = 401;
    constructor(message?: string);
}
