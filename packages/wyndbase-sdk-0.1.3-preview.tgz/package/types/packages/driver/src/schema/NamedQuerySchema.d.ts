import type { QueryFrom } from '../../../shared/src/query';
export { isNamedQuerySchema, NamedQueryCreationSchema, NamedQuerySchema, } from '../../../model/src/node-schemas';
type TimestampTzString = `${number}-${number}-${number}T${number}:${number}:${number}${string}`;
type TypeFromString<T extends string> = T extends 'string' ? string : T extends 'number' ? number : T extends 'timestamptz' ? TimestampTzString : T extends 'boolean' ? boolean : T extends 'any' ? any : T extends 'object' ? object : T extends 'array' ? any[] : unknown;
export type ParameterMetadataMap = Record<string, {
    required?: boolean;
    type: string;
}>;
export type InferParametersType<T extends ParameterMetadataMap | undefined> = T extends Record<string, any> ? {
    [K in keyof T as T[K]['required'] extends true ? K : never]: TypeFromString<T[K]['type']>;
} & {
    [K in keyof T as T[K]['required'] extends true ? never : K]?: TypeFromString<T[K]['type']>;
} : null | undefined | never | unknown;
export type DynamicQuery = QueryFrom & {
    parameterMetadata?: ParameterMetadataMap;
};
export type DynamicQueryParams<D extends DynamicQuery = DynamicQuery> = InferParametersType<D['parameterMetadata']>;
