import { z } from 'zod';
export declare const TableFullSchema: z.ZodObject<{
    _id: z.ZodString;
    description: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    displayName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    folder: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    isSystem: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
    name: z.ZodString;
    physicalName: z.ZodString;
    metadata: z.ZodOptional<z.ZodNullable<z.ZodObject<{
        displayFieldId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        hasComments: z.ZodOptional<z.ZodBoolean>;
        hasVersion: z.ZodOptional<z.ZodBoolean>;
        transient: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strip>>>;
    parent: z.ZodString;
    type: z.ZodLiteral<"table">;
    columns: z.ZodArray<z.ZodObject<{
        _id: z.ZodOptional<z.ZodString>;
        description: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        displayName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        folder: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        isDynamic: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        isSystem: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        name: z.ZodString;
        ordinal: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        parent: z.ZodString;
        physicalName: z.ZodOptional<z.ZodString>;
        metadata: z.ZodLazy<z.ZodDiscriminatedUnion<[z.ZodObject<{
            allowEnd: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                both: "both";
                "exclusive-only": "exclusive-only";
                "inclusive-only": "inclusive-only";
            }>>>;
            allowedCountries: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodEnum<{
                [x: string]: string;
            }>>>>;
            allowedMimeTypes: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodString>>>;
            allowedTables: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodString>>>;
            allowFilter: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            allowOpenEnd: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            allowOpenStart: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            allowSearch: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            allowStart: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                both: "both";
                "exclusive-only": "exclusive-only";
                "inclusive-only": "inclusive-only";
            }>>>;
            allowsAnyTable: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            bucket: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            canHaveMultiple: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            dataMask: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                char: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                email: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
                enabled: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
                leading: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
                separators: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
                trailing: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
            }, z.core.$strip>>>;
            defaultValue: z.ZodOptional<z.ZodNullable<z.ZodAny>>;
            encrypt: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            formula: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            hidden: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            immutable: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            inputMask: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            isArray: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            isDynamic: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            isMultiSelect: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                no: "no";
                yes: "yes";
            }>>>;
            isNqTarget: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            isPrimaryKey: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            isUnique: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            listName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            maxFileSizeBytes: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
            mirrorColumns: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodObject<{
                _id: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                canHaveMultiple: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
                name: z.ZodString;
                physicalName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                table: z.ZodString;
            }, z.core.$strip>>>>;
            notAllowedCountries: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodEnum<{
                [x: string]: string;
            }>>>>;
            notNull: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            onDelete: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                cascade: "cascade";
                keep: "keep";
                restrict: "restrict";
                setNull: "setNull";
            }>>>;
            optimizeSort: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            precision: z.ZodOptional<z.ZodNullable<z.ZodInt>>;
            rules: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodObject<{
                args: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodAny>>>;
                name: z.ZodString;
            }, z.core.$strip>>>>;
            scale: z.ZodOptional<z.ZodNullable<z.ZodInt>>;
            schema: z.ZodOptional<z.ZodNullable<z.ZodRecord<z.ZodString, z.ZodUnknown>>>;
            sensitive: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                always: "always";
                "explicitly-open": "explicitly-open";
            }>>>;
            summaryTypes: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodString>>>;
            targetTables: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodObject<{
                junctionSourceColumn: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                junctionTable: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                junctionTargetColumn: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                table: z.ZodString;
                targetColumn: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strip>>>>;
            type: z.ZodString;
            versioning: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        }, z.core.$strip>, ...z.ZodObject<{
            allowEnd: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                both: "both";
                "exclusive-only": "exclusive-only";
                "inclusive-only": "inclusive-only";
            }>>>;
            allowedCountries: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodEnum<{
                [x: string]: string;
            }>>>>;
            allowedMimeTypes: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodString>>>;
            allowedTables: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodString>>>;
            allowFilter: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            allowOpenEnd: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            allowOpenStart: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            allowSearch: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            allowStart: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                both: "both";
                "exclusive-only": "exclusive-only";
                "inclusive-only": "inclusive-only";
            }>>>;
            allowsAnyTable: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            bucket: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            canHaveMultiple: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            dataMask: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                char: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                email: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
                enabled: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
                leading: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
                separators: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
                trailing: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
            }, z.core.$strip>>>;
            defaultValue: z.ZodOptional<z.ZodNullable<z.ZodAny>>;
            encrypt: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            formula: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            hidden: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            immutable: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            inputMask: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            isArray: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            isDynamic: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            isMultiSelect: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                no: "no";
                yes: "yes";
            }>>>;
            isNqTarget: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            isPrimaryKey: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            isUnique: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            listName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            maxFileSizeBytes: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
            mirrorColumns: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodObject<{
                _id: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                canHaveMultiple: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
                name: z.ZodString;
                physicalName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                table: z.ZodString;
            }, z.core.$strip>>>>;
            notAllowedCountries: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodEnum<{
                [x: string]: string;
            }>>>>;
            notNull: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            onDelete: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                cascade: "cascade";
                keep: "keep";
                restrict: "restrict";
                setNull: "setNull";
            }>>>;
            optimizeSort: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
            precision: z.ZodOptional<z.ZodNullable<z.ZodInt>>;
            rules: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodObject<{
                args: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodAny>>>;
                name: z.ZodString;
            }, z.core.$strip>>>>;
            scale: z.ZodOptional<z.ZodNullable<z.ZodInt>>;
            schema: z.ZodOptional<z.ZodNullable<z.ZodRecord<z.ZodString, z.ZodUnknown>>>;
            sensitive: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                always: "always";
                "explicitly-open": "explicitly-open";
            }>>>;
            summaryTypes: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodString>>>;
            targetTables: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodObject<{
                junctionSourceColumn: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                junctionTable: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                junctionTargetColumn: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                table: z.ZodString;
                targetColumn: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strip>>>>;
            type: z.ZodString;
            versioning: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        }, z.core.$strip>[]], "type">>;
        type: z.ZodPrefault<z.ZodLiteral<"column">>;
    }, z.core.$strip>>;
    space: z.ZodObject<{
        _id: z.ZodOptional<z.ZodString>;
        description: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        displayName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        folder: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        isDynamic: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        isSystem: z.ZodOptional<z.ZodNullable<z.ZodBoolean>>;
        metadata: z.ZodOptional<z.ZodNullable<z.ZodRecord<z.ZodString, z.ZodAny>>>;
        name: z.ZodString;
        ordinal: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        physicalName: z.ZodOptional<z.ZodString>;
        parent: z.ZodOptional<z.ZodNull>;
        type: z.ZodPrefault<z.ZodLiteral<"space">>;
    }, z.core.$strip>;
}, z.core.$strip>;
export type TableFullSchema = z.infer<typeof TableFullSchema>;
export declare const isTableFullSchema: (schema: any) => schema is TableFullSchema;
export declare const isTableFullSchemaArray: (schema: any) => schema is TableFullSchema[];
