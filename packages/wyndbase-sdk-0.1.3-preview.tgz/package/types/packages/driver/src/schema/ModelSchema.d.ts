export { ModelSchema } from '../../../model/src/node-schemas';
export type CreationAttributes<Definition extends {
    _id?: any;
    physicalName?: any;
}> = Omit<Definition, 'type' | 'parent' | '_id' | 'createdAt' | 'updatedAt' | 'physicalName'> & Partial<{
    _id: Definition['_id'];
    physicalName: Definition['physicalName'];
}>;
export type ModelStatus = 'existing' | 'pending' | 'disposed';
