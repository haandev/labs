import type { TransactionContext } from '../../shared/src/transaction';
import type { ConnectionLane, ConnectionSource } from './ConnectionSource';
/**
 * One transaction's after-commit dispatches. Owned by the `wrap()` call that
 * opened it, so a dispatch can never be flushed — or discarded — by a
 * different transaction that happened to be open when it was queued.
 */
export type CommitQueue = {
    entries: (() => void)[];
    settled: boolean;
};
/**
 * Connection access, transaction lifecycle, and context persistence.
 * One instance per WynConnectionHandler.
 */
export declare class TransactionManager {
    private physicalName;
    private deletedAt;
    private lane;
    private connections;
    private _queue;
    private _context;
    private _executor;
    private _txPromise;
    private _txReady;
    clientTXJoin: Promise<unknown> | null;
    constructor(physicalName: string, deletedAt: string | null, lane: ConnectionLane, connections: ConnectionSource);
    get connection(): Promise<Bun.SQL> | Promise<Bun.TransactionSQL>;
    get regularConnection(): Promise<Bun.SQL>;
    get inTransaction(): boolean;
    wrap<T>(exec: () => Promise<T>): Promise<T>;
    /**
     * The open transaction's queue, read before a statement runs. A dispatch
     * carries the queue it was captured with, so it cannot attach to a
     * transaction its own statement never ran in.
     */
    get commitQueue(): CommitQueue | null;
    /** Run `dispatch` when `queue`'s transaction commits, or now when it has none. */
    afterCommit(queue: CommitQueue | null, dispatch: () => void): void;
    /** Join the transaction already in flight, or open one via wrap(). */
    wrapOrJoin<T>(exec: () => Promise<T>): Promise<T>;
    /** Begin long-running transaction. Resolves when executor is ready. */
    begin(): Promise<void>;
    /** Commit or rollback the long-running transaction. */
    finish(error?: any): void;
    /** Hand over the pending client-transaction join, clearing it in the same call. */
    takeClientJoin(): Promise<unknown> | null;
    /** Set transaction context (userId, baseId, browser, etc.) */
    setContext(context: Partial<TransactionContext>): void;
    getContext(): Partial<TransactionContext> | null;
    /** Reset a long-lived handler between unrelated units of work. */
    clearContext(): void;
    /** Persist context as PostgreSQL SET LOCAL config. */
    private sync;
    /** Exposed for internal use by QueryExecutor. */
    get executor(): Bun.TransactionSQL | null;
    dispose(): void;
}
