import type { TenantCredential } from '../../../../storage/src/types';
import type { WynConnectionHandler } from '../../WynConnectionHandler';
export declare class CredentialService {
    private base;
    constructor(base: WynConnectionHandler);
    private cached;
    /** Drops the cached list and rebuilds the S3 clients signing with the old pair. */
    invalidate(): void;
    tenantCredentials(): Promise<TenantCredential[]>;
    root(): Promise<{
        accessKeyId: string;
        secretAccessKey: string;
    } | null>;
    list(): Promise<import("../../../../wql/src/index").WqlRows<{
        _id: string;
        name: string;
        accessKey: string;
        permissions: unknown;
        isRoot: boolean;
        isActive: boolean;
        expiresAt: (string | null);
        creationDate: string;
        bucketId: (string | null);
        bucket: (string | null);
    } & Record<any, unknown>, import("../../../../wql/src/index").WQLOptions<boolean, boolean, boolean, import("../../../../wql/src/index").WQLExecutionMode> & {
        raw?: boolean;
        model?: import("../../../../wql/src/index").WynModel | import("../../../../wql/src/index").WynModelTree;
        skipRealtimeInvalidation?: boolean;
        skipPolyDisplay?: boolean;
    }>>;
    issue(input: {
        name: string;
        bucketId?: string | null;
        permissions?: string[];
        expiresAt?: string | null;
    }): Promise<{
        credential: {
            _id: string;
            name: string;
            accessKey: string;
            isRoot: boolean;
            isActive: boolean;
            expiresAt: (string | null);
            creationDate: string;
            permissions: unknown;
            bucketId: (string | null);
        } & Record<any, unknown>;
        secretKey: string;
    }>;
    revoke(id: string): Promise<boolean>;
    rotateRoot(): Promise<{
        accessKey: string;
        secretKey: string;
    }>;
}
