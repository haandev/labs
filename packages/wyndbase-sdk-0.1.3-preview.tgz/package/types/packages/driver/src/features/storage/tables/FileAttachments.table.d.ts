/**
 * ## Module: File Attachments Table
 *
 * This module defines the `file_attachments` table for tracking relationships
 * between storage objects and table rows.
 *
 * Purpose:
 * - Links storage_objects to specific table/row/column combinations
 * - Enables access control based on row permissions
 * - Tracks file ownership and cleanup on row deletion
 * - Supports orphan file detection
 *
 * Notes:
 * - One `file_attachments` table is created per database
 * - When a row with FILE column is deleted, associated attachments are cleaned up
 */
export declare const FILE_ATTACHMENTS_TABLE = "file_attachments";
declare const factory: () => {
    children: ({
        displayName: string;
        isSystem: boolean;
        metadata: {
            allowFilter?: undefined;
            defaultValue?: undefined;
            notNull: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        displayName: string;
        isSystem: boolean;
        metadata: {
            defaultValue?: undefined;
            allowFilter: boolean;
            notNull: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        displayName: string;
        isSystem: boolean;
        metadata: {
            notNull?: undefined;
            defaultValue?: undefined;
            allowFilter: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        displayName: string;
        isSystem: boolean;
        metadata: {
            allowFilter?: undefined;
            defaultValue: string;
            notNull: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        displayName: string;
        isSystem: boolean;
        metadata: {
            notNull?: undefined;
            allowFilter?: undefined;
            defaultValue?: undefined;
            type: string;
        };
        name: string;
        type: 'column';
    })[];
    displayName: string;
    folder: string;
    isSystem: boolean;
    metadata: {
        displayFieldId: string;
    };
    name: string;
    type: 'table';
};
export default factory;
export type FileAtachmentStatus = 'pending' | 'uploaded' | 'orphan';
export type FileAttachmentsType = {
    _id: string;
    bucketId: string;
    key: string;
    filename: string;
    tableId: string;
    recordId?: string;
    columnId: string;
    status: FileAtachmentStatus;
    size?: number;
    etag?: string;
    contentType?: string;
};
