export declare const STORAGE_EVENTS_TABLE = "storage_events";
declare const factory: () => {
    children: ({
        isSystem: boolean;
        metadata: {
            schema?: undefined;
            defaultValue?: undefined;
            notNull: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            schema?: undefined;
            defaultValue: string;
            notNull: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            defaultValue?: undefined;
            notNull?: undefined;
            schema: {
                additionalProperties: boolean;
                type: string;
            };
            type: string;
        };
        name: string;
        type: 'column';
    })[];
    displayName: string;
    folder: string;
    isSystem: boolean;
    name: string;
    type: 'table';
};
export default factory;
type Type = {
    _id: string;
    type: string;
    bucketId: string;
    key: string;
    date: Date;
    metadata?: Record<string, any>;
};
export type StorageEventsType = Omit<Type, 'date'> & {
    date: Date;
};
