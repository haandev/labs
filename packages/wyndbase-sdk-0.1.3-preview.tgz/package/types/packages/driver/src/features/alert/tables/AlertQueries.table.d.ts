export declare const ALERT_QUERIES_TABLE = "alert_queries";
declare const factory: () => {
    children: ({
        isSystem: boolean;
        metadata: {
            allowFilter: boolean;
            notNull: boolean;
            onDelete: string;
            targetTables: {
                table: string;
            }[];
            type: string;
            schema?: undefined;
            defaultValue?: undefined;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            allowFilter?: undefined;
            onDelete?: undefined;
            targetTables?: undefined;
            notNull: boolean;
            type: string;
            schema?: undefined;
            defaultValue?: undefined;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            allowFilter?: undefined;
            onDelete?: undefined;
            targetTables?: undefined;
            type: string;
            schema?: undefined;
            defaultValue?: undefined;
            notNull?: undefined;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            allowFilter?: undefined;
            onDelete?: undefined;
            targetTables?: undefined;
            notNull: boolean;
            schema: {
                items: {
                    additionalProperties: boolean;
                    type: string;
                };
                type: string;
            };
            type: string;
            defaultValue?: undefined;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            onDelete?: undefined;
            targetTables?: undefined;
            schema?: undefined;
            allowFilter: boolean;
            defaultValue: boolean;
            notNull: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            onDelete?: undefined;
            targetTables?: undefined;
            schema?: undefined;
            allowFilter: boolean;
            defaultValue: string;
            notNull: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            allowFilter?: undefined;
            onDelete?: undefined;
            targetTables?: undefined;
            schema?: undefined;
            defaultValue: boolean;
            notNull: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            allowFilter?: undefined;
            onDelete?: undefined;
            targetTables?: undefined;
            schema?: undefined;
            defaultValue: number;
            notNull: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    })[];
    displayName: string;
    folder: string;
    isSystem: boolean;
    name: string;
    type: 'table';
};
export default factory;
export type AlertState = 'unknown' | 'ok' | 'firing';
export type AlertQueryRow = {
    _id: string;
    ownerId: string;
    name: string;
    description: string | null;
    query: string;
    trackingEntries: unknown[];
    trackingStale: boolean;
    state: AlertState;
    notifyOnResolve: boolean;
    isActive: boolean;
    lastEvaluatedAt: string | null;
    lastFiredAt: string | null;
    lastResolvedAt: string | null;
    lastError: string | null;
    errorCount: number;
};
