import { type ProviderIdentity, type RuleRefusal } from '../../../../../shared/src/auth-factors/index';
import { UnauthenticatedError } from '../../../errors/Unauthenticated';
import type { WynConnectionHandler } from '../../../WynConnectionHandler';
import type { FederatedProviderRow } from './FederatedService';
/** Shown to a refused person; naming the rule would leak the admission policy one attempt at a time. */
export declare const PROVIDER_REFUSED = "You may not sign in with this provider here";
/** D5 with linking off: tells the person what to do, never that the address is already taken (D9). */
export declare const LINK_FROM_SETTINGS: string;
/**
 * A refused identity as a class, not a message, so the HTTP callback can tell
 * refusals apart without matching on reworded text.
 */
export declare class FederatedRefusedError extends UnauthenticatedError {
    constructor(message?: string);
}
/** The link refusal (D5), carrying the owner's id for the audit row; `userId` is non-enumerable so it never leaks into a response body. */
export declare class FederatedLinkRefusedError extends FederatedRefusedError {
    readonly userId: string;
    constructor(userId: string);
}
/** Why an identity was refused. Administrator-facing; never shown to the person. */
export type IdentityRefusalCause = 'rules' | 'provider_inactive'
/** `providerType` names something this build does not serve (D16). */
 | 'provider_type_unknown'
/** `defaultDecision` is neither `accept` nor `reject` (D16). */
 | 'provider_default_decision'
/** A rule — or the whole rules container — could not be parsed (D14). */
 | 'provider_rules_unreadable' | 'resolution';
export type IdentityVerdict = {
    accepted: boolean;
    /** Everything worth logging; never put in a response — that undoes {@link PROVIDER_REFUSED}. */
    detail: {
        cause: IdentityRefusalCause | null;
        matchedIndex: number | null;
        refusals: readonly RuleRefusal[];
    };
    /** The only text that may reach the person. `null` when accepted. */
    message: string | null;
};
/** Pure and never throws — a gate that throws hands its decision to the nearest `catch` (D14). */
export declare function decideIdentity(provider: FederatedProviderRow, identity: ProviderIdentity): IdentityVerdict;
/** How the person behind an accepted identity was found. */
export type FederatedResolution = {
    /** The `auth_factors` row recording this external identity. */
    factorId: string;
    outcome: 'returning' | 'provisioned' | 'linked';
    userId: string;
};
/** One instance per callback; concurrent mutating queries through the same handler serialize. */
export declare class FederatedIdentityService {
    private readonly base;
    constructor(base: WynConnectionHandler);
    /**
     * No row is written until the decision is final. Re-runs
     * {@link decideIdentity} so no call site can accidentally bypass the gate.
     */
    resolveUser(provider: FederatedProviderRow, identity: ProviderIdentity): Promise<FederatedResolution>;
    /** Step 1: has this exact external account signed in here before? */
    private findFactor;
    /** An ordinary factor row (D2): `!== 'ACTIVE'` refuses it like any other. */
    private returning;
    /** Runs at most twice: a unique violation means the second pass re-reads and re-decides. */
    private resolveNewIdentity;
    /** `held` (unlinkable or unverified) differs from `free`: D5 needs verified-to-verified. */
    private ownerOf;
    /** D5 with linking on: attach to the existing account, then tell its owner. */
    private link;
    /**
     * Address is written only when verified and unclaimed — an unverified claim
     * would permanently occupy `unique_email`. A losing race rolls the user back.
     */
    private provision;
    /** Best-effort, after the factor write: a row left behind can never be confirmed. */
    private releaseAddressElsewhere;
    /** `ACTIVE` because the redirect was the enrolment (D3); the provider keeps the credential. */
    private writeFactor;
    /**
     * Best-effort undo; a failure here must not change the sign-in's outcome.
     *
     * Both deletes are one transaction: a deferred trigger refuses to leave an
     * existing user with no address, so deleting the email row alone is refused
     * and the address stays locked under `unique_email`.
     */
    private rollback;
}
