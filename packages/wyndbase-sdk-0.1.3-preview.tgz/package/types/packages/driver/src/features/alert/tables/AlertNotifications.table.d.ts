export declare const ALERT_NOTIFICATIONS_TABLE = "alert_notifications";
declare const factory: () => {
    children: ({
        isSystem: boolean;
        metadata: {
            notNull: boolean;
            onDelete: string;
            targetTables: {
                table: string;
            }[];
            type: string;
            schema?: undefined;
            allowFilter?: undefined;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            allowFilter: boolean;
            notNull: boolean;
            onDelete: string;
            targetTables: {
                table: string;
            }[];
            type: string;
            schema?: undefined;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            onDelete?: undefined;
            targetTables?: undefined;
            notNull: boolean;
            type: string;
            schema?: undefined;
            allowFilter?: undefined;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            onDelete?: undefined;
            targetTables?: undefined;
            notNull: boolean;
            schema: {
                additionalProperties: boolean;
                type: string;
            };
            type: string;
            allowFilter?: undefined;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            onDelete?: undefined;
            targetTables?: undefined;
            notNull?: undefined;
            schema?: undefined;
            allowFilter: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    })[];
    displayName: string;
    folder: string;
    isSystem: boolean;
    name: string;
    type: 'table';
};
export default factory;
export type AlertNotificationType = 'fired' | 'resolved';
export type AlertNotificationRow = {
    _id: string;
    alertId: string;
    ownerId: string;
    type: AlertNotificationType;
    occurredAt: string;
    payload: AlertNotificationPayload;
    readAt: string | null;
    dismissedAt: string | null;
};
export type AlertNotificationPayload = {
    rowCount: number;
    sampleRows: unknown[];
    alertName: string;
};
