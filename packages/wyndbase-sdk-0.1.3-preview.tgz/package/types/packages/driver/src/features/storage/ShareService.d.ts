import type { ShareDownloadInputSchemaType, ShareDownloadSchemaType, ShareObjectsResponseType, ShareTreeItemType, ShareUploadInputSchemaType } from '../../types';
import type { WynConnectionHandler } from '../../WynConnectionHandler';
export type ShareAuthRefusal = 'not_found' | 'revoked' | 'expired' | 'exhausted' | 'password';
export type ShareAuthResult = {
    success: true;
    share: any;
} | {
    success: false;
    share: any;
    reason: ShareAuthRefusal;
};
export declare class ShareService {
    private base;
    constructor(base: WynConnectionHandler);
    private prepareDownloadShare;
    private prepareUploadShare;
    private assertFutureExpiry;
    private assertBucketExists;
    createDownloadShare(input: ShareDownloadInputSchemaType): Promise<{
        pathName: string;
    }>;
    createUploadShare(input: ShareUploadInputSchemaType): Promise<{
        pathName: string;
    }>;
    private generateToken;
    private hashToken;
    private hashPassword;
    verifyPassword(password: string, hashedPassword: string): Promise<boolean>;
    logAudit(input: {
        action: 'access' | 'download' | 'password_attempt' | 'revoke' | 'upload';
        ipAddress?: string | null;
        metadata?: Record<string, unknown>;
        status: 'expired' | 'failure' | 'max_uses_exceeded' | 'password_failed' | 'revoked' | 'success';
        /** Plaintext token; hashed before persisting so the audit table never stores raw secrets. */
        token: string;
        userAgent?: string | null;
    }): Promise<import("../../../../wql/src/index").WqlRows<Record<any, unknown>, import("../../../../wql/src/index").WQLOptions<boolean, boolean, boolean, import("../../../../wql/src/index").WQLExecutionMode> & {
        raw?: boolean;
        model?: import("../../../../wql/src/index").WynModel | import("../../../../wql/src/index").WynModelTree;
        skipRealtimeInvalidation?: boolean;
        skipPolyDisplay?: boolean;
    }>>;
    getDownloadShare(token: string): Promise<({
        _id: string;
        tokenHash: string;
        type: string;
        expiresAt: (string | null);
        revokedAt: (string | null);
        maxUses: (number | null);
        usesCount: number;
        password: (string | null);
        bucketId: string;
        metadata: ({
            keys?: string[];
            prefixes?: string[];
            maxFileSize?: number;
            uploadPrefix?: string;
            allowedMimeTypes?: string[];
            [k: string]: unknown;
        } | null);
        createdAt: string;
        updatedAt: string;
        createdBy: (string | null);
        updatedBy: (string | null);
    } & Record<any, unknown> & {
        createdAt: string;
    }) | null>;
    getUploadShare(token: string): Promise<({
        _id: string;
        tokenHash: string;
        type: string;
        expiresAt: (string | null);
        revokedAt: (string | null);
        maxUses: (number | null);
        usesCount: number;
        password: (string | null);
        bucketId: string;
        metadata: ({
            keys?: string[];
            prefixes?: string[];
            maxFileSize?: number;
            uploadPrefix?: string;
            allowedMimeTypes?: string[];
            [k: string]: unknown;
        } | null);
        createdAt: string;
        updatedAt: string;
        createdBy: (string | null);
        updatedBy: (string | null);
    } & Record<any, unknown> & {
        createdAt: string;
    }) | null>;
    listSharedObjects(share: ShareDownloadSchemaType): Promise<ShareObjectsResponseType>;
    /** Returns shared objects as a tree for FE TreeView (BFF). Root = selected prefixes + selected keys. */
    listSharedObjectsAsTree(share: ShareDownloadSchemaType): Promise<ShareTreeItemType[]>;
    private buildTreeFromRaw;
    private listSharedObjectsRaw;
    private getLastModified;
    private getContentType;
    /** Whether a share has been used as many times as its maximum allows. A
     *  share with no maximum is never exhausted. The one comparison behind
     *  both `shareStatus` and the anonymous pre-flights, so it exists once. */
    isExhausted(share: {
        maxUses: number | null;
        usesCount: number;
    }): boolean;
    /** The one place revocation, expiry and the use limit are decided, for both
     *  the anonymous refusal path and the management listing. */
    shareStatus(share: {
        revokedAt: string | null;
        expiresAt: string | null;
        maxUses: number | null;
        usesCount: number;
    }): 'revoked' | 'expired' | 'exhausted' | 'active';
    /** Validate a share is accessible (not revoked, not expired, not spent) */
    validateShareAccess(share: any): {
        valid: boolean;
        reason?: 'revoked' | 'expired' | 'exhausted' | 'not_found';
    };
    list(): Promise<{
        status: "active" | "exhausted" | "expired" | "revoked";
        _id: string;
        type: string;
        bucketId: string;
        expiresAt: (string | null);
        revokedAt: (string | null);
        maxUses: (number | null);
        usesCount: number;
        metadata: ({
            keys?: string[];
            prefixes?: string[];
            maxFileSize?: number;
            uploadPrefix?: string;
            allowedMimeTypes?: string[];
            [k: string]: unknown;
        } | null);
        createdAt: string;
        requiresPassword: boolean;
    }[]>;
    revoke(id: string): Promise<'revoked' | 'already-revoked' | 'not-found'>;
    consumeUse(id: string): Promise<'consumed' | 'exhausted'>;
    /**
     * Opens a share: the one place a use is spent. A caller that already holds
     * a valid session is continuing an opening, not starting one, so it is
     * admitted before the use limit and before the password are looked at — the
     * session is already proof of both, and the opening it belongs to was
     * audited when it was minted. A fresh opening pays: the spend sits after the
     * password check so a wrong guess never burns a use, and it is the
     * conditional update that decides a race. Revocation and expiry still refuse
     * everyone.
     */
    authenticateShare(token: string, type: 'download' | 'upload', params: {
        password?: string;
        ipAddress?: string;
        userAgent?: string;
        holdsSession?: boolean;
    }): Promise<ShareAuthResult>;
    /** Authorize a download key against a share's allowed keys/prefixes */
    authorizeDownloadKey(share: any, key: string): boolean;
    /** Authorize an upload key against a share's upload prefix, with no storage call. */
    authorizeUploadKey(share: any, key: string): boolean;
    /** Authorize an upload checking prefix, MIME type, and file size */
    authorizeUpload(share: any, params: {
        key: string;
        contentType?: string;
        size?: number;
    }): {
        allowed: boolean;
        reason?: string;
    };
}
