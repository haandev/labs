import { type Factor, type FactorContext } from './Factor';
/** Password as a first-class factor: the hash lives (encrypted) in an
 *  auth_factors row of type 'password', not on users.password. */
export declare class PasswordFactor implements Factor {
    readonly type: 'password';
    readonly tier: 'T1';
    challenge(): Promise<null>;
    verify({ base, userId, input }: FactorContext & {
        input: string;
    }): Promise<import("./Factor").VerifyResult>;
    beginEnroll(): Promise<{}>;
    /** Hash + upsert; `mustChange` is written in the same statement so a
     *  change always leaves a settled flag. Breach-checked here (NIST SP
     *  800-63B §5.1.1.2) because this is the one funnel every password write
     *  passes through — no carve-out, including admin-seeded credentials. */
    confirmEnroll({ base, userId, input, temporary, }: FactorContext & {
        factorId?: string;
        input?: string;
        temporary?: boolean;
    }): Promise<{
        factorType: "password";
        replaced: boolean;
        status: string;
    }>;
}
