import type { HistoryItem } from '../../../../../shared/src/history';
export declare const BUNDLE_FORMAT: 'wyndb-migration';
export declare const BUNDLE_VERSION: 5;
export type BundleRow = Record<string, unknown>;
export type ClientSettingsPackage = {
    publishers: BundleRow[];
    clients: BundleRow[];
    settings: BundleRow[];
};
export type MigrationBundle = {
    $format: typeof BUNDLE_FORMAT;
    $version: typeof BUNDLE_VERSION;
    exportedAt: string;
    sourceBaseId: string | null;
    schema: HistoryItem[];
    alwaysData: {
        choices: BundleRow[];
    };
    data: {
        clientSettings?: ClientSettingsPackage;
    };
    /**
     * What a forward normalisation discarded — otherwise the plan would just be
     * quietly smaller than the source bundle, with no record of why.
     */
    warnings?: string[];
};
/** Parsed legacy v1: bare HistoryItem[] array, no data scopes. */
export type LegacyV1Bundle = HistoryItem[];
