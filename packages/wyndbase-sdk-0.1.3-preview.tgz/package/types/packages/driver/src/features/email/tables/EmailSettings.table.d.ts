export declare const EMAIL_SETTINGS_TABLE = "email_settings";
declare const factory: () => {
    children: {
        isSystem: boolean;
        metadata: {
            onDelete: string;
            targetTables: {
                table: string;
            }[];
            type: string;
        };
        name: string;
        type: 'column';
    }[];
    displayName: string;
    folder: string;
    isSystem: boolean;
    name: string;
    type: 'table';
};
export default factory;
export type EmailSettingsType = {
    _id: string;
    defaultProvider: {
        _id: string;
    }[] | null;
};
