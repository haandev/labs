import type { WynConnectionHandler } from '../../WynConnectionHandler';
/**
 * Single-use MFA recovery codes. Stored only as an HMAC-SHA256 hash peppered
 * with the JWT secret; a code is consumed by deleting its row.
 */
export declare class RecoveryCodeService {
    private base;
    constructor(base: WynConnectionHandler);
    /** Number of unused recovery codes the user has left. */
    count(userId: string): Promise<number>;
    /** Whether the user has at least one unused recovery code. */
    hasUnused(userId: string): Promise<boolean>;
    /**
     * One query, not `hasUnused` + `oldestUnusedAt` separately: two reads would
     * race a code being spent between them.
     */
    unusedBatch(userId: string): Promise<{
        count: number;
        oldestAt: string | null;
    }>;
    /**
     * Replace the user's recovery codes with a fresh batch. Returns the plaintext
     * codes to show exactly once — they are never retrievable afterwards.
     * Refused while the account holds no active factor that keeps a batch.
     */
    generate(userId: string): Promise<string[]>;
    /**
     * Generates a batch only when the user has none and holds an active factor
     * that keeps one; `null` otherwise, never a throw, since enrolment
     * confirmations call it.
     */
    generateIfNone(userId: string): Promise<string[] | null>;
    /**
     * `generateIfNone` without the audit line and the mail, for a caller that
     * runs it inside its own transaction and announces after the commit.
     */
    mintIfNone(userId: string): Promise<string[] | null>;
    /**
     * The batch is written under the user's factor inventory lock, which the
     * removal of a factor also takes, so the inventory read here is the one the
     * write is judged against. `null` when nothing qualifies or, for
     * `onlyIfNone`, a batch already exists.
     */
    private mint;
    /**
     * Audited and mailed here, the one funnel every batch passes through; only
     * the count is recorded, since a code is a credential.
     */
    announce(userId: string, count: number): Promise<void>;
    /** Verifies and consumes (single-use) a submitted recovery code. */
    verifyAndConsume(userId: string, code: string): Promise<boolean>;
}
