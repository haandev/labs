export declare const BUCKETS_TABLE = "buckets";
/**
 * Fixed rather than generated: `Users.table.ts` needs this id at module
 * scope, before the seed hook that would otherwise create it can run.
 */
export declare const DEFAULT_AVATAR_BUCKET_ID = "00000000-0000-7000-8000-000000000001";
/** S3 bucket name behind {@link DEFAULT_AVATAR_BUCKET_ID}. */
export declare const DEFAULT_AVATAR_BUCKET_NAME = "avatars";
/**
 * Fixed rather than generated: `Comments.table.ts` needs this id at module
 * scope, before the seed hook that would otherwise create it can run.
 */
export declare const DEFAULT_COMMENTS_BUCKET_ID = "00000000-0000-7000-8000-000000000003";
/** S3 bucket name behind {@link DEFAULT_COMMENTS_BUCKET_ID}. */
export declare const DEFAULT_COMMENTS_BUCKET_NAME = "comments";
/** Bucket a knowledgebase article's attachments land in. */
export declare const DEFAULT_DOCUMENTS_BUCKET_ID = "00000000-0000-7000-8000-00000000000c";
/** S3 bucket name behind {@link DEFAULT_DOCUMENTS_BUCKET_ID}. */
export declare const DEFAULT_DOCUMENTS_BUCKET_NAME = "documents";
declare const factory: () => {
    children: ({
        displayName: string;
        isSystem: boolean;
        metadata: {
            encrypt?: undefined;
            defaultValue?: undefined;
            allowFilter: boolean;
            notNull: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        displayName: string;
        isSystem: boolean;
        metadata: {
            encrypt?: undefined;
            allowFilter?: undefined;
            defaultValue: string;
            notNull: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        displayName: string;
        isSystem: boolean;
        metadata: {
            encrypt?: undefined;
            allowFilter?: undefined;
            defaultValue?: undefined;
            notNull: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        displayName: string;
        isSystem: boolean;
        metadata: {
            encrypt?: undefined;
            allowFilter: boolean;
            defaultValue: string;
            notNull: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        displayName: string;
        isSystem: boolean;
        metadata: {
            allowFilter?: undefined;
            defaultValue?: undefined;
            encrypt: boolean;
            notNull: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        displayName: string;
        isSystem: boolean;
        metadata: {
            encrypt?: undefined;
            allowFilter?: undefined;
            defaultValue: boolean;
            notNull: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    })[];
    displayName: string;
    folder: string;
    isSystem: boolean;
    name: string;
    type: 'table';
};
export default factory;
export type BucketVersioningStatus = 'Enabled' | 'Suspended';
export type BucketType = 'local' | 'remote';
export type BucketsType = {
    _id: string;
    name: string;
    creationDate: string;
    versioning: BucketVersioningStatus;
    type: BucketType;
    endpoint?: string;
    accessKey?: string;
    secretKey?: string;
    region?: string;
    forcePathStyle?: boolean;
};
