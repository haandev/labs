export declare const CHOICES_TABLE = "choices";
declare const factory: () => {
    children: ({
        isSystem: boolean;
        metadata: {
            schema?: undefined;
            allowFilter: boolean;
            notNull: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            allowFilter?: undefined;
            schema?: undefined;
            notNull: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            allowFilter?: undefined;
            schema?: undefined;
            notNull?: undefined;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            allowFilter?: undefined;
            notNull?: undefined;
            schema: {
                additionalProperties: boolean;
                type: string;
            };
            type: string;
        };
        name: string;
        type: 'column';
    })[];
    constraints: {
        columns: string[];
        constraintType: 'unique';
    }[];
    displayName: string;
    folder: string;
    isSystem: boolean;
    metadata: {
        displayFieldId: string;
    };
    name: string;
    type: 'table';
};
export default factory;
export type ChoicesType = {
    _id: string;
    listName: string;
    key: string;
    label: string;
    icon?: string;
    color?: string;
    sortOrder?: number;
    meta?: Record<string, any>;
    createdAt: string;
    updatedAt: string;
};
