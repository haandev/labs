import type { WynConnectionHandler } from '../../WynConnectionHandler';
import { FlowService } from './FlowService';
export declare class WorkflowService {
    private base;
    constructor(base: WynConnectionHandler);
    private _flowService?;
    get flow(): FlowService;
}
