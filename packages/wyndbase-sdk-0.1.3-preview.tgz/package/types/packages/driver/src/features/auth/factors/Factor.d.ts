import type { FactorTier, FactorType } from '../../../../../shared/src/auth-factors/index';
import type { WynConnectionHandler } from '../../../WynConnectionHandler';
export type FactorContext = {
    base: WynConnectionHandler;
    userId: string;
};
/**
 * Pre-response challenge, or `null` when none is needed — kept as a hook so
 * later challenge-factors can add one without reshaping the engine.
 */
export type ChallengeResult = {
    issued: boolean;
    hint?: string;
    /** Factor-specific payload to drive the client (e.g. WebAuthn options + token). */
    data?: Record<string, unknown>;
} | null;
/** Data returned to the client to drive enrollment (e.g. TOTP secret + uri). */
export type EnrollInit = {
    factorId?: string;
    data?: Record<string, unknown>;
};
/**
 * On success, `factorType` is what was ACTUALLY verified server-side (not the
 * client-requested type), since that is what the AAL is computed from.
 */
export type VerifyResult = {
    ok: false;
} | {
    ok: true;
    factorType: FactorType;
};
export declare function verified(factorType: FactorType): VerifyResult;
export declare const rejected: VerifyResult;
/** One credential as the account's own screens list it. */
export type InventoryRow = {
    _id: string;
    type: string;
    createdAt: string;
    label: string | null;
    status: string;
    lastUsedAt: string | null;
    mustChange: boolean;
    isPasskey: boolean;
    source: 'factor' | 'passkey' | 'recovery';
};
/**
 * `confirmEnroll` has no rejection channel and can only throw. Use this only
 * where a submitted credential is evaluated and found wrong — lockout accounting depends on the distinction.
 */
export declare function rejectCredential(message: string): never;
/**
 * Contract every authentication method implements (password, TOTP, recovery
 * codes today). Resolved by `FactorRegistry` so callers never special-case by type.
 */
export interface Factor {
    readonly type: FactorType;
    readonly tier: FactorTier;
    challenge(ctx: FactorContext): Promise<ChallengeResult>;
    verify(ctx: FactorContext & {
        input: string;
    }): Promise<VerifyResult>;
    beginEnroll(ctx: FactorContext & {
        params?: Record<string, unknown>;
    }): Promise<EnrollInit>;
    /**
     * Burns the single-use material an enrolment spends (a TOTP step, a
     * WebAuthn challenge) and returns what `confirmEnroll` needs as `claim`.
     * Run before the enrolment transaction, so the burn survives its rollback
     * and a replay stays refused; that holds when no outer transaction is open,
     * since the burn then joins it. Absent: `confirmEnroll` spends nothing.
     * The return value is passed back as `claim`; `undefined` means nothing was
     * claimed and `confirmEnroll` claims itself. A factor whose `claimEnroll`
     * returns `undefined` must therefore NOT have burned anything, or
     * `confirmEnroll` claims again and a replay is rejected.
     */
    claimEnroll?(ctx: FactorContext & {
        factorId?: string;
        input?: string;
    }): Promise<unknown>;
    /**
     * Validate + activate the factor. `factorType` is the type ACTUALLY stored —
     * e.g. a passkey's synced/device-bound class is set by attestation, not the requested type.
     */
    confirmEnroll(ctx: FactorContext & {
        factorId?: string;
        input?: string;
        requireDeviceBound?: boolean;
        /** What `claimEnroll` returned; absent, `confirmEnroll` claims itself. */
        claim?: unknown;
        /** Password-only. Absent means false — an ordinary password write
         *  CLEARS a flag an earlier write set. */
        temporary?: boolean;
    }): Promise<{
        status: string;
        factorType: FactorType;
        /** Password-only: distinguishes `password.set` from `password.changed`
         *  for the audit trail, since `confirmEnroll` is one upsert for both. */
        replaced?: boolean;
        /** The name its owner gave this credential, when it has one. Only a
         *  passkey does; it is what names the method in the enrollment notice. */
        label?: string | null;
    }>;
    /**
     * Rows this method holds outside the shared factor store. Absent where the
     * method is stored with the others, which is the common case.
     */
    inventory?(ctx: FactorContext): Promise<InventoryRow[]>;
}
