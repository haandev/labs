import type { WynConnectionHandler } from '../../WynConnectionHandler';
export type ActivitySession = {
    pid: number;
    usename: string | null;
    application_name: string;
    client_addr: string | null;
    state: string | null;
    query: string | null;
    backend_start: Date;
    state_change: Date | null;
    wait_event_type: string | null;
    wait_event: string | null;
};
export type TupleIn = {
    schemaname: string;
    relname: string;
    inserts: number;
    updates: number;
    deletes: number;
    total: number;
};
export type TupleOut = {
    schemaname: string;
    relname: string;
    seq_scan: number;
    seq_tup_read: number;
    idx_scan: number | null;
    idx_tup_fetch: number | null;
    total: number;
};
export type BlockIO = {
    schemaname: string;
    relname: string;
    heap_blks_read: number;
    heap_blks_hit: number;
    idx_blks_read: number;
    idx_blks_hit: number;
    toast_blks_read: number;
    toast_blks_hit: number;
    total_reads: number;
    total_hits: number;
};
export type TransactionStats = {
    xact_commit: number;
    xact_rollback: number;
    total_transactions: number;
    stats_reset: Date | null;
    seconds_since_reset: number | null;
    tps: number;
};
export declare class ActivityService {
    private base;
    constructor(base: WynConnectionHandler);
    get con(): Promise<Bun.SQL>;
    getSessions(): Promise<ActivitySession[]>;
    getTuplesIn(): Promise<TupleIn[]>;
    getTuplesOut(): Promise<TupleOut[]>;
    getBlockIO(): Promise<BlockIO[]>;
    getTPS(): Promise<TransactionStats[]>;
}
