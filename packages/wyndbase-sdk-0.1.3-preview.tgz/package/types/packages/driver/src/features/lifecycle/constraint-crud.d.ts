import type { ConstraintMetadata } from '../../../../model/src/types';
import type { WynConnectionHandler } from '../../WynConnectionHandler';
/**
 * Resolves columns in `columnIds` declaration order — not table-children order.
 * Auto-names and UNIQUE DDL both surface this order to the user.
 */
export declare function orderColumnsByIds<T extends {
    _id: string;
}>(columnIds: string[], columns: T[]): T[];
/** A row predicate scopes uniqueness; only a system table declaration sets one. */
export declare function refuseSystemOnlyConstraintOptions(metadata: unknown): void;
export type CreateConstraintInput = {
    tableId: string;
    name?: string;
    metadata: unknown;
    isSystem?: boolean;
};
export type ConstraintRow = {
    _id: string;
    name: string;
    physicalName: string;
    type: 'constraint';
    parentId: string;
    metadata: ConstraintMetadata;
    isSystem: boolean;
};
/** Creates a table-level constraint (currently: unique only). */
export declare function createConstraint(base: WynConnectionHandler, input: CreateConstraintInput): Promise<ConstraintRow>;
export type UpdateConstraintInput = {
    constraintId: string;
    name?: string;
    metadata?: unknown;
};
/** Updates a constraint, picking the cheapest DDL for the diff (rename vs
 * DROP+ADD). System constraints are immutable. */
export declare function updateConstraint(base: WynConnectionHandler, input: UpdateConstraintInput): Promise<ConstraintRow>;
export declare function listConstraintsByColumn(base: WynConnectionHandler, columnId: string): Promise<ConstraintRow[]>;
export type GetColumnConstraintImpactInput = {
    columnId: string;
};
/** Used by the FE to show a cascade warning before column delete. */
export declare function getColumnConstraintImpact(base: WynConnectionHandler, input: GetColumnConstraintImpactInput): Promise<ConstraintRow[]>;
export type DeleteConstraintInput = {
    constraintId: string;
};
export declare function deleteConstraint(base: WynConnectionHandler, input: DeleteConstraintInput): Promise<void>;
