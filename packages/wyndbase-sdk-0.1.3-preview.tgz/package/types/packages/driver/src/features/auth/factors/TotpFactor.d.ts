import { type Factor, type FactorContext } from './Factor';
/**
 * TOTP authenticator factor. Codes are single-use — the accepted step is
 * persisted, so a captured code can't be replayed within the ±1 window.
 */
export declare class TotpFactor implements Factor {
    readonly type: 'totp';
    readonly tier: 'T2';
    challenge(): Promise<null>;
    verify({ base, userId, input }: FactorContext & {
        input: string;
    }): Promise<import("./Factor").VerifyResult>;
    beginEnroll({ base, userId, params, }: FactorContext & {
        params?: Record<string, unknown>;
    }): Promise<{
        data: {
            secret: string;
            status: string;
            uri: string;
        };
        factorId: string;
    }>;
    /** Validates the code and burns its step; see `Factor.claimEnroll`. */
    claimEnroll({ base, userId, factorId, input, }: FactorContext & {
        factorId?: string;
        input?: string;
    }): Promise<boolean>;
    confirmEnroll({ base, userId, factorId, input, claim, }: FactorContext & {
        factorId?: string;
        input?: string;
        claim?: unknown;
    }): Promise<{
        factorType: "totp";
        status: string;
    }>;
}
