import type { ModelNode, WynModel } from '../../../../model/src/types';
import type { WynConnectionHandler } from '../../WynConnectionHandler';
export declare function ensureId(def: Record<string, any>): Record<string, any>;
/**
 * Logical table name(s) a model change affects, for alert stale-flagging.
 * Resolved against the pre-change model so a deleted node still matches.
 */
export declare function collectAffectedLogicalTables(model: WynModel, node: any): string[];
/**
 * Derive computed metadata fields that aren't user-settable, centralised so
 * every column-write path stays in sync without a zod transform (transforms break toJSONSchema).
 */
export declare function deriveComputedMetadata(meta: Record<string, any> | undefined, columnType: string | undefined): void;
/**
 * The one INSERT every model create goes through. Access rules live only in
 * `system.decision_matrix`, so nothing here needs to be stripped out.
 */
export declare function insertModel(base: WynConnectionHandler, def: Record<string, any>): Promise<string>;
export declare function createModel(base: WynConnectionHandler, definition: Record<string, any>): Promise<ModelNode>;
export type DeleteModelOptions = {
    /**
     * Referencing constraints: false (default) throws ConstraintInUseError;
     * true drops them first, then deletes the column.
     */
    cascadeConstraints?: boolean;
    /**
     * Internal: set on the recursive deletes a link-column cascade issues
     * (mirror column, junction table) so they cannot cascade back.
     */
    __skipLinkCascade?: boolean;
};
/**
 * Deletes a model node and everything under it. Alert stale-flagging fires
 * once here, not per recursive child, so it doesn't re-scan per column.
 */
export declare function deleteModel(base: WynConnectionHandler, modelId: string, options?: DeleteModelOptions): Promise<{
    _id: string;
    physicalName: string;
    parent: (string | null);
    type: string;
    isSystem: (boolean | null);
    isDynamic: (boolean | null);
    name: string;
    displayName: (string | null);
    description: (string | null);
    metadata: ({
        [k: string]: unknown;
    } | null);
    folder: (string | null);
    ordinal: (number | null);
    children: string[];
    createdAt: string;
    updatedAt: string;
    createdBy: (string | null);
    updatedBy: (string | null);
    parentId: (string | null);
} & Record<any, unknown>>;
/**
 * The delete itself, without the alert stale flag — for callers already
 * inside an operation that flags for them. Call `deleteModel` otherwise.
 */
export declare function deleteModelNode(base: WynConnectionHandler, modelId: string, options?: DeleteModelOptions): Promise<{
    _id: string;
    physicalName: string;
    parent: (string | null);
    type: string;
    isSystem: (boolean | null);
    isDynamic: (boolean | null);
    name: string;
    displayName: (string | null);
    description: (string | null);
    metadata: ({
        [k: string]: unknown;
    } | null);
    folder: (string | null);
    ordinal: (number | null);
    children: string[];
    createdAt: string;
    updatedAt: string;
    createdBy: (string | null);
    updatedBy: (string | null);
    parentId: (string | null);
} & Record<any, unknown>>;
export declare function updateModel(base: WynConnectionHandler, modelId: string, body: Record<string, any>): Promise<any>;
