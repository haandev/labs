/** The only answer ever recorded — the other answer creates the node. */
export declare const LEAVE_ABSENT: 'leave-absent';
/**
 * Keyed by node alone, not by base pair: a bundle's source id can be
 * null, so pairing by base would skip asking exactly when it matters.
 */
declare const factory: () => {
    children: {
        isSystem: boolean;
        metadata: {
            notNull: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    }[];
    constraints: {
        columns: string[];
        constraintType: 'unique';
    }[];
    displayName: string;
    folder: string;
    isSystem: boolean;
    metadata: {
        displayFieldId: string;
    };
    name: string;
    type: 'table';
};
export default factory;
export type MigrationDecisionsType = {
    _id: string;
    nodeId: string;
    decision: string;
    decidedAt: string;
};
