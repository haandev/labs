import type { WynConnectionHandler } from '../../WynConnectionHandler';
export type SetCacheParams = {
    key?: unknown;
    value?: unknown;
    ttlSeconds?: unknown;
};
export declare class CacheService {
    set(base: WynConnectionHandler, params: SetCacheParams): Promise<import("../../../../wql/src/index").WqlRows<Record<any, unknown>, {
        allowMutation: true;
    }>>;
    clearAll(base: WynConnectionHandler): Promise<import("../../../../wql/src/index").WqlRows<Record<any, unknown>, {
        allowMutation: true;
        user: false;
    }>>;
}
