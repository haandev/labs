import type { RealtimeTrackingEntry } from '../../../../shared/src/index';
import type { ConnectionLane } from '../../ConnectionSource';
import type { WynConnectionHandler } from '../../WynConnectionHandler';
export type ActiveAlert = {
    _id: string;
    ownerId: string;
    name: string;
    query: string;
    trackingEntries: RealtimeTrackingEntry[];
    state: 'unknown' | 'ok' | 'firing';
    notifyOnResolve: boolean;
    errorCount: number;
};
export declare const isAlertTable: (table: string) => boolean;
export type BaseSource = {
    base(baseId: string, lane?: ConnectionLane): Promise<WynConnectionHandler>;
};
/**
 * Per-process reactive alert engine. All state lives in `alert_queries.state`,
 * so a restart loses nothing — the next matching mutation reconverges.
 */
export declare class AlertEvaluator {
    private readonly bases;
    private readonly cache;
    private readonly loadGenerations;
    /** In-flight reload per base, so a superseded one can hand off to the
     *  reload that replaced it instead of reporting a cache it discarded. */
    private readonly pendingLoads;
    /** Per-alert evaluation chain: at most one evaluation runs at a time, and
     *  `rerun` records that work arrived while one was in flight. */
    private readonly evaluationChains;
    /** Batches that arrived while a base's cache was reloading, in arrival order. */
    private readonly reloadBuffers;
    private readonly reloadDrops;
    private readonly RELOAD_BUFFER_LIMIT;
    constructor(bases: BaseSource);
    /**
     * `lane` lets a caller scanning every base in the background route to the
     * count-bounded maintenance pool, not one interactive pool per base.
     */
    loadCache(baseId: string, lane?: ConnectionLane): Promise<void>;
    private runLoad;
    /**
     * Never rejects. Await it before returning to the client: until the reload
     * lands the alert is not cached, and the first change to its data is missed.
     */
    invalidateCache(baseId: string, lane?: ConnectionLane): Promise<boolean>;
    clearCache(baseId: string): void;
    /**
     * Mutation hook. Synchronous and non-blocking — it only schedules microtasks,
     * so the originating mutation's latency is untouched.
     */
    onMutation(baseId: string, mutating: RealtimeTrackingEntry[]): void;
    /**
     * Drops the oldest batch past the cap: a reload that never settles must not
     * grow memory without bound, and a silent drop is worse than a logged one.
     */
    private bufferDuringReload;
    private drainReloadBuffer;
    /**
     * Serialized per alert: unserialized, the evaluation that read the older
     * state can land last and leave the alert `firing` after its rows are gone.
     */
    private scheduleEvaluation;
    /** Re-evaluates one alert under its owner's identity and emits on transition. */
    evaluateAlert(baseId: string, alert: ActiveAlert, baseOverride?: WynConnectionHandler): Promise<void>;
    private transitionToFiring;
    private transitionToResolved;
    private recordError;
}
