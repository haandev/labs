import type { FileAttachmentsType } from '../../system';
import type { WynConnectionHandler } from '../../WynConnectionHandler';
export type InitUploadInput = {
    columnId: string;
    recordId?: string;
    filename: string;
    mimeType?: string;
    size: number;
};
export type InitUploadResult = {
    attachmentId: string;
    presignedUrl: string;
};
export type ListAttachmentsInput = {
    columnId: string;
    recordId?: string | null;
};
export declare const ATTACHMENT_LIST_FIELDS: readonly ['_id', 'filename', 'bucketId', 'key', 'contentType', 'size', 'status', 'etag', 'recordId', 'tableId', 'columnId'];
/** A live table row whose attachment cell holds the attachment for a given object. */
export type ObjectRowReference = {
    attachmentId: string;
    tableId: string;
    columnId: string;
    rowId: string;
};
export declare class FileAttachmentService {
    private base;
    constructor(base: WynConnectionHandler);
    /**
     * Never `column.parent`: `SchemaCache` projects that link to the parent's
     * display field, so it holds the table's *name*, never its `_id`.
     *
     * The identifier is a column `_id` or a canonical dotted path
     * (`space.table.column`): the wire speaks paths so no client has to resolve
     * ids first, and ids keep working because attachment rows store them.
     */
    private findColumnAncestry;
    private getById;
    private validateUpload;
    /**
     * The record's attachments plus the unattached pool, since `initUpload` sends
     * no `recordId`. That mixed AND/OR the browse filter cannot express.
     *
     * The table is derived from the column's ancestry, never taken from the
     * caller: rows are written with the ancestry's ids, so a caller-supplied
     * table could silently filter everything out.
     */
    list(input: ListAttachmentsInput): Promise<FileAttachmentsType[]>;
    initUpload(input: InitUploadInput): Promise<{
        attachmentId: string;
        presignedUrl: string;
    }>;
    completeUpload(attachmentId: string, recordId?: string): Promise<({
        _id: string;
        bucketId: string;
        key: string;
        filename: string;
        tableId: string;
        recordId: (string | null);
        columnId: string;
        status: string;
        size: (number | null);
        etag: (string | null);
        contentType: (string | null);
        createdAt: string;
        updatedAt: string;
        createdBy: (string | null);
        updatedBy: (string | null);
    } & Record<any, unknown>) | undefined>;
    /**
     * An attachment cell carries no foreign key and `status`/`recordId` are never
     * reconciled, so only the cells themselves answer. Where the ids sit inside a
     * cell depends on the column type, so the expression comes from the column
     * class. Runs as the system.
     */
    findRowReferencesForObject(bucketId: string, key: string): Promise<ObjectRowReference[]>;
    /**
     * `tableId` may arrive as an `_id`, a physical name or a name, so it is
     * resolved; a miss means no such table, hence nothing to orphan.
     */
    markAsOrphan(tableId: string, recordId: string): Promise<void>;
}
