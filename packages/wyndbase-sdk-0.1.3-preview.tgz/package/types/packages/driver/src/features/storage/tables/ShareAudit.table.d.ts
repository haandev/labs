/**
 * ## Module: Storage Share Audit Table
 *
 * This module defines the `storage_share_audit` table for share link auditing.
 *
 * Purpose:
 * - Logs all share link access attempts
 * - Tracks password failures, expired access, revoked access
 * - Provides audit trail for share usage
 *
 * Notes:
 * - Separate from storage_audit_logs for share-specific events
 * - Logs are immutable - no updates or deletes
 */
export declare const STORAGE_SHARE_AUDIT_TABLE = "storage_share_audit";
declare const factory: () => {
    children: ({
        displayName: string;
        isSystem: boolean;
        metadata: {
            schema?: undefined;
            defaultValue: string;
            notNull: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        displayName?: undefined;
        isSystem: boolean;
        metadata: {
            schema?: undefined;
            defaultValue?: undefined;
            notNull: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        displayName?: undefined;
        isSystem: boolean;
        metadata: {
            schema?: undefined;
            notNull?: undefined;
            defaultValue?: undefined;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        displayName?: undefined;
        isSystem: boolean;
        metadata: {
            notNull?: undefined;
            defaultValue?: undefined;
            schema: {
                additionalProperties: boolean;
                type: string;
            };
            type: string;
        };
        name: string;
        type: 'column';
    })[];
    displayName: string;
    folder: string;
    isSystem: boolean;
    name: string;
    type: 'table';
};
export default factory;
export type StorageShareAuditType = {
    _id: string;
    tokenHash: string;
    action: string;
    status: string;
    ipAddress: string | null;
    userAgent: string | null;
    metadata: Record<string, any> | null;
    timestamp: Date;
};
