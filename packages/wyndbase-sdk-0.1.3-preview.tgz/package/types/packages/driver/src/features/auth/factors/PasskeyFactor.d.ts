import type { FactorType } from '../../../../../shared/src/auth-factors/index';
import { type RpConfig } from '../PasskeyService';
import { type Factor, type FactorContext, type InventoryRow } from './Factor';
/** Synced vs device-bound is a property of the stored credential (from the
 *  backup-eligible flag at registration), so both factors share every
 *  method and differ only in `type`. */
declare abstract class BasePasskeyFactor implements Factor {
    protected rp: () => RpConfig;
    abstract readonly type: FactorType;
    readonly tier: 'T3';
    constructor(rp: () => RpConfig);
    private svc;
    /** Only the user's credentials of THIS passkey class are offered, so the
     *  ceremony can never be started against a class they have not enrolled. */
    challenge({ base, userId }: FactorContext): Promise<{
        data: {
            challengeToken: string;
            options: import("@simplewebauthn/server").PublicKeyCredentialRequestOptionsJSON;
        };
        issued: boolean;
    }>;
    /** Checks user AND factor type: without the type check a synced passkey
     *  satisfies a device-bound verification, recording an AAL3 step for an
     *  AAL2 authenticator. */
    verify({ base, userId, input }: FactorContext & {
        input: string;
    }): Promise<import("./Factor").VerifyResult>;
    beginEnroll({ base, userId, params, }: FactorContext & {
        params?: Record<string, unknown>;
    }): Promise<{
        data: {
            challengeToken: string;
            label: string;
            options: import("@simplewebauthn/server").PublicKeyCredentialCreationOptionsJSON;
        };
    }>;
    /** Consumes the challenge; see `Factor.claimEnroll`. */
    claimEnroll({ base, userId, input, }: FactorContext & {
        input?: string;
    }): Promise<string>;
    confirmEnroll({ base, userId, input, requireDeviceBound, claim, }: FactorContext & {
        input?: string;
        requireDeviceBound?: boolean;
        claim?: unknown;
    }): Promise<{
        factorType: "email_otp" | "hardware_key" | "magic_link" | "oidc_external" | "passkey_device_bound" | "passkey_synced" | "password" | "password_reset" | "pin" | "push_notification" | "recovery_codes" | "security_question" | "sms_otp" | "social_apple" | "social_github" | "social_google" | "totp";
        label: any;
        status: string;
    }>;
    /** Reads only credentials of THIS passkey class: both classes share one
     *  table, so without the filter every credential would be listed twice. */
    inventory({ base, userId }: FactorContext): Promise<InventoryRow[]>;
}
/** Synced passkey (multi-device, e.g. iCloud Keychain / Google) → AAL2. */
export declare class PasskeySyncedFactor extends BasePasskeyFactor {
    readonly type: 'passkey_synced';
}
/** Device-bound passkey (single-device, non-exportable key) → AAL3. */
export declare class PasskeyDeviceBoundFactor extends BasePasskeyFactor {
    readonly type: 'passkey_device_bound';
}
export {};
