export declare const EMAIL_TEMPLATES_TABLE = "email_templates";
declare const factory: () => {
    children: ({
        isSystem: boolean;
        metadata: {
            allowFilter: boolean;
            notNull: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            allowFilter?: undefined;
            notNull: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    })[];
    constraints: {
        columns: string[];
        constraintType: 'unique';
        name: string;
    }[];
    displayName: string;
    folder: string;
    isSystem: boolean;
    metadata: {
        displayFieldId: string;
    };
    name: string;
    type: 'table';
};
export default factory;
export type EmailTemplatesType = {
    _id: string;
    messageId: string;
    subject: string;
    body: string;
};
