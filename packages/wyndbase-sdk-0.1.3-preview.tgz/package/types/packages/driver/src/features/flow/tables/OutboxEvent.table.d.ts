export declare const OUTBOX_EVENT_TABLE = "outbox_event";
export default _default;
declare function _default(): {
    children: ({
        isSystem: boolean;
        metadata: {
            onDelete?: undefined;
            targetTables?: undefined;
            schema?: undefined;
            notNull?: undefined;
            allowFilter: boolean;
            defaultValue: string;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            schema?: undefined;
            defaultValue?: undefined;
            allowFilter: boolean;
            notNull: boolean;
            onDelete: string;
            targetTables: {
                table: string;
            }[];
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            allowFilter?: undefined;
            onDelete?: undefined;
            targetTables?: undefined;
            defaultValue?: undefined;
            notNull?: undefined;
            schema: {
                properties: {
                    _id: {
                        type: string;
                    };
                    createdAt: {
                        type: string;
                    };
                    description: {
                        type: string[];
                    };
                    isActive: {
                        type: string;
                    };
                    name: {
                        type: string;
                    };
                    nodes: {
                        items: {
                            additionalProperties: boolean;
                            type: string;
                        };
                        type: string;
                    };
                    startNodeId: {
                        type: string[];
                    };
                    stateSchema: {
                        items: {
                            additionalProperties: boolean;
                            type: string;
                        };
                        type: string;
                    };
                    trigger: {
                        properties: {
                            metadata: {
                                additionalProperties: boolean;
                                type: string;
                            };
                            type: {
                                type: string;
                            };
                        };
                        required: string[];
                        type: string;
                    };
                    updatedAt: {
                        type: string;
                    };
                };
                required: string[];
                type: string;
                additionalProperties?: undefined;
                items?: undefined;
            };
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            allowFilter?: undefined;
            onDelete?: undefined;
            targetTables?: undefined;
            defaultValue?: undefined;
            notNull?: undefined;
            schema: {
                properties?: undefined;
                required?: undefined;
                additionalProperties: boolean;
                type: string;
                items?: undefined;
            };
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            schema?: undefined;
            defaultValue?: undefined;
            notNull?: undefined;
            allowFilter: boolean;
            onDelete: string;
            targetTables: {
                table: string;
            }[];
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            allowFilter?: undefined;
            onDelete?: undefined;
            targetTables?: undefined;
            defaultValue?: undefined;
            notNull?: undefined;
            schema: {
                properties?: undefined;
                required?: undefined;
                additionalProperties?: undefined;
                items: {
                    additionalProperties: boolean;
                    type: string;
                };
                type: string;
            };
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            onDelete?: undefined;
            targetTables?: undefined;
            schema?: undefined;
            defaultValue?: undefined;
            notNull?: undefined;
            allowFilter: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    })[];
    description: string;
    displayName: string;
    folder: string;
    isSystem: boolean;
    name: string;
    type: 'table';
};
