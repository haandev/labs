import type { ColumnNode, TableNode, WynModel } from '../../../../model/src/types';
import type { WynConnectionHandler } from '../../WynConnectionHandler';
export declare function applyColumnDDLChanges(base: WynConnectionHandler, currentNode: ColumnNode, newDef: Record<string, any>): Promise<void>;
export declare function syncTableColumns(base: WynConnectionHandler, tableNode: TableNode, creationColumns: Record<string, any>[], _model?: WynModel): Promise<void>;
