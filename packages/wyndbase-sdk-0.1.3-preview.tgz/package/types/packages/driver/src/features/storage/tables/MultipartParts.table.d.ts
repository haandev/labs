/**
 * ## Module: Multipart Parts Table
 *
 * This module defines the `multipart_parts` table for tracking S3 multipart upload parts.
 *
 * Purpose:
 * - Tracks individual parts of a multipart upload
 * - Stores part numbers, ETags, and sizes
 *
 * Notes:
 * - Parts are linked to uploads via uploadId
 * - Parts should be cleaned up when upload completes or aborts
 */
export declare const MULTIPART_PARTS_TABLE = "multipart_parts";
declare const factory: () => {
    children: ({
        displayName: string;
        isSystem: boolean;
        metadata: {
            allowFilter: boolean;
            notNull: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        displayName?: undefined;
        isSystem: boolean;
        metadata: {
            allowFilter?: undefined;
            notNull: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    })[];
    displayName: string;
    folder: string;
    isSystem: boolean;
    name: string;
    type: 'table';
};
export default factory;
export type MultipartPartsType = {
    _id: string;
    uploadId: string;
    partNumber: number;
    etag: string;
    size: number;
    createdAt: string;
};
