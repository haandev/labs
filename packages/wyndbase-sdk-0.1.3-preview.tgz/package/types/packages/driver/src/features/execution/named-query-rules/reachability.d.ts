import type { NamedQueryNode, NQExposure, WynModel } from '../../../../../model/src/types';
/** One row of the inventory a person reviews. */
export interface ElevatedSurfaceEntry {
    /** `space.name`, the spelling a reviewer reads. */
    query: string;
    exposure: NQExposure;
    /**
     * The elevated queries this call reaches, itself included when it is itself
     * elevated — calling an elevated query does reach one that runs without
     * access rules, and a row reading `reaches: []` would say the opposite.
     */
    reaches: string[];
}
/**
 * The elevated named queries `nq` reaches by calling, itself excluded.
 *
 * Strictly downstream, because the question this answers is "what does calling
 * this get me that I could not get directly" — a reviewer already knows an
 * elevated query is elevated. `elevatedSurface` asks the other question and
 * keeps the self entry.
 *
 * The walk, the cycle guard and the table-before-named-query resolution order
 * all live in `computeFacts`; this only drops the starting node, so the two
 * answers can never disagree about what an edge is.
 */
export declare function elevatedReachableFrom(nq: NamedQueryNode, model: WynModel): string[];
/**
 * Every named query an outside caller can name that reaches one running with
 * service authority.
 *
 * `service` is excluded because nothing outside can name it: it is reachable
 * only from another named query, and that other query appears here in its own
 * right if it is itself callable. So the list is the doors, not the rooms
 * behind them.
 *
 * Two things this under-reports, both inherited from the fact walk and both
 * worth knowing before trusting an empty result:
 *
 * - A chain through a body that does not currently parse reports nothing,
 *   because an unparseable body yields no edges at all. An elevated query
 *   reached only through such a body is invisible here.
 * - `computeFacts` collects CTE names across a whole body, so a CTE named `X`
 *   in one statement suppresses the edge to a named query `X` named by a
 *   sibling statement.
 *
 * Both fail towards silence rather than towards noise, which is the wrong
 * direction for a security inventory: a short list is weaker evidence than a
 * long one.
 */
export declare function elevatedSurface(model: WynModel): ElevatedSurfaceEntry[];
