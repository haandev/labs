import type { RealtimeTrackingEntry } from '../../../../shared/src/index';
/** Repairs alerts flagged `trackingStale` by re-deriving tracking under the owner's identity. */
export declare class AlertRetracker {
    private readonly coordinator;
    private isRunning;
    start(): Promise<void>;
    stop(): void;
    /**
     * The column, not the table: this loop's own repair writes `alert_queries`
     * and every evaluation stamps it, so waking on the table would re-wake the
     * loop after each repair and drain once per evaluation.
     */
    onMutation(baseId: string, mutating: RealtimeTrackingEntry[]): void;
    /** Drops the cached base list; call when bases are added or removed. */
    invalidateCache(): Promise<void>;
    /** One scan over all bases. Public so tests can drive it without the sweep. */
    tick(): Promise<void>;
    /**
     * Staleness has a cause, not a due time, so the coordinator arms no timer:
     * this base is left alone until something flags an alert or the sweep comes.
     */
    private retrackBase;
    private retrackOne;
}
