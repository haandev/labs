import type { ClientLevel } from '../../../../wql/src/index';
import type { WynConnectionHandler } from '../../WynConnectionHandler';
export declare class BrowseService {
    private base;
    constructor(base: WynConnectionHandler);
    /** Derive the calling client's trust level from its record. */
    deriveClientLevel(clientConfig: {
        allowRawWql?: boolean | null;
    }): ClientLevel;
    /** Check if a query string is a named query (no whitespace) */
    isNamedQuery(query: string): boolean;
    /**
     * Get a single record by ID with full projections
     * (ref columns, file columns with nested selects, decrypt support)
     */
    getRecord(modelId: string, rowId: string, options?: {
        /** Columns to project through `@unmask` — names, not a switch; the
         *  annotation is refused on a column no rule governs. */
        unmask?: string[];
        /** Columns to project through `@decrypt`. */
        decrypt?: string[];
        select?: string[] | string;
        user?: boolean;
        /** Policy `$context` (role + userId) — set under act-as so the
         *  policy gate evaluates the impersonated user, not the caller. */
        context?: Record<string, unknown>;
    }): Promise<{
        _id: string;
    } & Record<string, unknown>>;
    /**
     * Every version of a row's lineage, newest first. Policied callers are
     * gated by `read` (origin) and `readHard` (history); an unauthorized result is `[]`.
     */
    getHistory(modelId: string, rowId: string, user: boolean, context?: Record<string, unknown>): Promise<({
        _id: string;
    } & Record<string, unknown>)[]>;
    /** Delete a record and mark its file attachments as orphans */
    deleteRecord(modelId: string, rowId: string, user: boolean, context?: Record<string, unknown>): Promise<void>;
    /** Delete several records in one statement, so a refusal deletes none. */
    deleteRecords(modelId: string, rowIds: string[], user: boolean, context?: Record<string, unknown>): Promise<void>;
}
