import { z } from 'zod';
export declare const ShareDownloadSchema: z.ZodObject<{
    bucketId: z.ZodString;
    createdAt: z.ZodISODateTime;
    expiresAt: z.ZodOptional<z.ZodNullable<z.ZodISODateTime>>;
    maxUses: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    metadata: z.ZodOptional<z.ZodNullable<z.ZodObject<{
        keys: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodString>>>;
        prefixes: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodString>>>;
    }, z.core.$strip>>>;
    password: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    revokedAt: z.ZodNullable<z.ZodISODateTime>;
    tokenHash: z.ZodString;
    type: z.ZodPrefault<z.ZodString>;
    usesCount: z.ZodDefault<z.ZodNumber>;
}, z.core.$strip>;
export type ShareDownloadSchemaType = z.infer<typeof ShareDownloadSchema>;
export declare const ShareDownloadInputSchema: z.ZodObject<{
    bucketId: z.ZodString;
    expiresAt: z.ZodOptional<z.ZodNullable<z.ZodISODateTime>>;
    maxUses: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    password: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    keys: z.ZodNullable<z.ZodArray<z.ZodString>>;
    prefixes: z.ZodNullable<z.ZodArray<z.ZodString>>;
}, z.core.$strip>;
export type ShareDownloadInputSchemaType = z.infer<typeof ShareDownloadInputSchema>;
export declare const ShareUploadSchema: z.ZodObject<{
    bucketId: z.ZodString;
    createdAt: z.ZodISODateTime;
    expiresAt: z.ZodOptional<z.ZodNullable<z.ZodISODateTime>>;
    maxUses: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    password: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    revokedAt: z.ZodNullable<z.ZodISODateTime>;
    tokenHash: z.ZodString;
    usesCount: z.ZodDefault<z.ZodNumber>;
    metadata: z.ZodObject<{
        allowedMimeTypes: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodString>>>;
        maxFileSize: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        uploadPrefix: z.ZodString;
    }, z.core.$strip>;
    type: z.ZodLiteral<"upload">;
}, z.core.$strip>;
export type ShareUploadSchemaType = z.infer<typeof ShareUploadSchema>;
export declare const ShareUploadInputSchema: z.ZodObject<{
    bucketId: z.ZodString;
    expiresAt: z.ZodOptional<z.ZodNullable<z.ZodISODateTime>>;
    maxUses: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    password: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    allowedMimeTypes: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodString>>>;
    maxFileSize: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    uploadPrefix: z.ZodString;
}, z.core.$strip>;
export type ShareUploadInputSchemaType = z.infer<typeof ShareUploadInputSchema>;
export declare const ShareMetadataResponseSchema: z.ZodObject<{
    exhausted: z.ZodBoolean;
    expired: z.ZodBoolean;
    expiresAt: z.ZodNullable<z.ZodString>;
    requiresPassword: z.ZodBoolean;
    revoked: z.ZodBoolean;
}, z.core.$strip>;
export type ShareMetadataResponseType = z.infer<typeof ShareMetadataResponseSchema>;
export declare const ShareAuthResponseSchema: z.ZodObject<{
    reason: z.ZodOptional<z.ZodEnum<{
        exhausted: "exhausted";
        expired: "expired";
        revoked: "revoked";
    }>>;
    success: z.ZodBoolean;
}, z.core.$strip>;
export type ShareAuthResponseType = z.infer<typeof ShareAuthResponseSchema>;
export declare const UploadShareMetadataResponseSchema: z.ZodObject<{
    exhausted: z.ZodBoolean;
    expired: z.ZodBoolean;
    expiresAt: z.ZodNullable<z.ZodString>;
    requiresPassword: z.ZodBoolean;
    revoked: z.ZodBoolean;
    allowedMimeTypes: z.ZodNullable<z.ZodArray<z.ZodString>>;
    maxFileSize: z.ZodNullable<z.ZodNumber>;
    uploadPrefix: z.ZodString;
}, z.core.$strip>;
export type UploadShareMetadataResponseType = z.infer<typeof UploadShareMetadataResponseSchema>;
export declare const FileNodeSchema: z.ZodObject<{
    contentType: z.ZodNullable<z.ZodString>;
    key: z.ZodString;
    lastModified: z.ZodString;
    name: z.ZodString;
    size: z.ZodNumber;
}, z.core.$strip>;
export type FileNodeType = z.infer<typeof FileNodeSchema>;
export type FolderNodeType = {
    children: {
        files: FileNodeType[];
        folders: FolderNodeType[];
    };
    name: string;
    path: string;
};
export declare const FolderNodeSchema: z.ZodType<FolderNodeType>;
export declare const ShareObjectsResponseSchema: z.ZodObject<{
    files: z.ZodArray<z.ZodObject<{
        contentType: z.ZodNullable<z.ZodString>;
        key: z.ZodString;
        lastModified: z.ZodString;
        name: z.ZodString;
        size: z.ZodNumber;
    }, z.core.$strip>>;
    folders: z.ZodArray<z.ZodType<FolderNodeType, unknown, z.core.$ZodTypeInternals<FolderNodeType, unknown>>>;
}, z.core.$strip>;
export type ShareObjectsResponseType = z.infer<typeof ShareObjectsResponseSchema>;
/** Tree node for BFF: FE TreeView consumes with minimal mapping (add icons only). */
export type ShareTreeItemType = {
    children?: ShareTreeItemType[];
    key?: string;
    kind: 'file' | 'folder';
    label: string;
    size?: number;
};
export declare const ShareTreeItemSchema: z.ZodType<ShareTreeItemType>;
/** The management listing's shape. Deliberately narrower than the stored row:
 *  the password hash and the token hash live on the same record and must never
 *  reach a client — `requiresPassword` is the one fact about the hash allowed
 *  through, and only as a derived boolean. The use count is an administrator
 *  fact; the anonymous pre-flight still carries only `exhausted`. */
export declare const ShareInfoSchema: z.ZodObject<{
    _id: z.ZodString;
    bucketId: z.ZodString;
    createdAt: z.ZodCodec<z.ZodUnion<readonly [z.ZodISODateTime, z.ZodISODateTime, z.ZodDate]>, z.ZodUnion<readonly [z.ZodISODateTime, z.ZodISODateTime]>>;
    expiresAt: z.ZodNullable<z.ZodCodec<z.ZodUnion<readonly [z.ZodISODateTime, z.ZodISODateTime, z.ZodDate]>, z.ZodUnion<readonly [z.ZodISODateTime, z.ZodISODateTime]>>>;
    maxUses: z.ZodNullable<z.ZodNumber>;
    metadata: z.ZodNullable<z.ZodObject<{
        allowedMimeTypes: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodString>>>;
        keys: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodString>>>;
        maxFileSize: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        prefixes: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodString>>>;
        uploadPrefix: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, z.core.$strip>>;
    requiresPassword: z.ZodBoolean;
    revokedAt: z.ZodNullable<z.ZodCodec<z.ZodUnion<readonly [z.ZodISODateTime, z.ZodISODateTime, z.ZodDate]>, z.ZodUnion<readonly [z.ZodISODateTime, z.ZodISODateTime]>>>;
    status: z.ZodEnum<{
        active: "active";
        exhausted: "exhausted";
        expired: "expired";
        revoked: "revoked";
    }>;
    type: z.ZodString;
    usesCount: z.ZodNumber;
}, z.core.$strip>;
export type TShareInfo = z.infer<typeof ShareInfoSchema>;
