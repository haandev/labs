import { type Factor, type FactorContext, type InventoryRow } from './Factor';
/** Single-use recovery codes — the lost-authenticator backup. Auto-provisioned
 *  on first MFA activation, so it is never a forced inline enrollment. */
export declare class RecoveryCodesFactor implements Factor {
    readonly type: 'recovery_codes';
    readonly tier: 'T2';
    challenge(): Promise<null>;
    verify({ base, userId, input }: FactorContext & {
        input: string;
    }): Promise<import("./Factor").VerifyResult>;
    beginEnroll(): Promise<{}>;
    confirmEnroll({ base, userId }: FactorContext): Promise<{
        factorType: "recovery_codes";
        status: string;
    }>;
    /** The batch as one inventory row, or nothing when every code is spent. */
    inventory({ base, userId }: FactorContext): Promise<InventoryRow[]>;
}
