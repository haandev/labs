export declare class UndeclaredVariableError extends Error {
    readonly undeclared: string[];
    readonly available: string[];
    constructor(messageId: string, undeclared: string[], available: string[]);
}
export declare function escapeHtml(value: string): string;
/** In order of appearance, de-duplicated. */
export declare function placeholdersIn(text: string): string[];
export declare function undeclaredPlaceholders(messageId: string, ...texts: string[]): string[];
/**
 * The save path's gate. Without it a mistyped name sends a silent gap and the
 * recipient is the first to notice.
 */
export declare function assertTemplateIsValid(messageId: string, subject: string, body: string): void;
/**
 * Names a message's body or subject places, that the message declares as
 * NON-optional, and that the caller did not supply. Every one of them renders
 * as an empty string — an empty `href` on a call to action, a blank where a
 * method name belongs — with nothing in the output to say a value was missing.
 * A declared `optional` variable is not reported: its fallback is the answer.
 *
 * Returned rather than thrown or logged here so this module stays free of the
 * driver's logger and of any policy about what to do. `EmailService.send`
 * decides; the catalogue call-site test asserts the list is empty for every
 * shipped message.
 */
export declare function missingRequiredVariables(messageId: string, values: Record<string, unknown>, ...texts: string[]): string[];
/** A subject is plain text, so it is interpolated without escaping. */
export declare function renderSubject(messageId: string, subject: string, values: Record<string, unknown>): string;
/** A body is markup, so every interpolated value is escaped into it. */
export declare function renderBody(messageId: string, body: string, values: Record<string, unknown>): string;
