import type { WynConnectionHandler } from '../../WynConnectionHandler';
export type CreateDelegationInput = {
    /** Omit to delegate the caller's own key. */
    delegatorId?: string;
    delegateId: string;
    key: string;
    startsAt: string;
    endsAt: string;
};
export declare class DelegationService {
    private base;
    constructor(base: WynConnectionHandler);
    private refuse;
    create(input: CreateDelegationInput): Promise<{
        _id: string;
    }>;
}
