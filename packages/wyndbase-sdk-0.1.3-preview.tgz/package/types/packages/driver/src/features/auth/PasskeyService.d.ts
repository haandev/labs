import type { FactorType } from '../../../../shared/src/auth-factors/index';
import type { WynConnectionHandler } from '../../WynConnectionHandler';
export type RpConfig = {
    rpId: string;
    rpName: string;
    origin: string;
};
export type ResolvedCredential = {
    credentialId: string;
    factorType: FactorType;
    userId: string;
};
export declare class PasskeyService {
    private base;
    private rp;
    private readonly challenges;
    constructor(base: WynConnectionHandler, rp: RpConfig);
    beginRegistration(userId: string, params?: {
        label?: string;
        authenticatorAttachment?: 'platform' | 'cross-platform';
    }): Promise<{
        challengeToken: string;
        label: string;
        options: import("@simplewebauthn/server").PublicKeyCredentialCreationOptionsJSON;
    }>;
    /** Consumes the registration challenge (single-use); see `confirmRegistration`. */
    takeRegistrationChallenge(userId: string, challengeToken: string): Promise<string>;
    /**
     * `opts.challenge` is a challenge the caller already consumed with
     * `takeRegistrationChallenge`, so the burn can sit outside a transaction
     * this call runs in.
     */
    confirmRegistration(userId: string, challengeToken: string, response: unknown, label?: string, opts?: {
        requireDeviceBound?: boolean;
        challenge?: string;
    }): Promise<{
        factorType: FactorType;
        status: string;
    }>;
    /**
     * Without a `userId` this is a discoverable (usernameless) ceremony; an empty
     * allow-list is refused rather than silently degrading into one.
     */
    beginAuthentication(userId?: string, factorType?: FactorType): Promise<{
        challengeToken: string;
        options: import("@simplewebauthn/server").PublicKeyCredentialRequestOptionsJSON;
    }>;
    /**
     * `expected` is checked before the single-use challenge is consumed and the
     * counter bumped, so a rejected assertion advances no credential state; the
     * `onResolved` hook runs at that same point, so throwing from it aborts the
     * ceremony untouched.
     */
    verifyAssertion(challengeToken: string, response: unknown, expected?: {
        userId?: string;
        factorType?: FactorType;
    }, onResolved?: (resolved: ResolvedCredential) => Promise<void>): Promise<{
        factorType: FactorType;
        userId: string;
    } | null>;
    /**
     * Why a credential survives a counter regression, or `null` when revoking is
     * safe. Auto-revocation can cost an account its last way in.
     */
    private counterRegressionKeepReason;
    /**
     * Does this user hold another active credential that is not an escape? Both
     * tables are read here because `FactorRegistry` constructs this service.
     */
    private hasAnotherEntryFactor;
    /**
     * Best-effort and runs last: a failure here must not replace the
     * counter-regression refusal with an unrelated error.
     */
    private notifyCounterRegression;
}
