import type { HistoryStepHandler } from '../../../../shared/src/history';
import type { WynConnectionHandler } from '../../WynConnectionHandler';
export declare class HistoryService {
    private base;
    constructor(base: WynConnectionHandler);
    get tx(): Promise<Bun.SQL> | Promise<Bun.TransactionSQL>;
    get con(): Promise<Bun.SQL>;
    get(point?: string): Promise<import("../../../../wql/src/index").WqlRows<{
        _id: string;
        serial: number;
        operation_type: string;
        old_data: ({
            [k: string]: unknown;
        } | null);
        new_data: ({
            [k: string]: unknown;
        } | null);
        operation_timestamp: string;
        tags: string[];
        createdAt: string;
        updatedAt: string;
        createdBy: (string | null);
        updatedBy: (string | null);
    } & Record<any, unknown>, import("../../../../wql/src/index").WQLOptions<boolean, boolean, boolean, import("../../../../wql/src/index").WQLExecutionMode> & {
        raw?: boolean;
        model?: import("../../../../wql/src/index").WynModel | import("../../../../wql/src/index").WynModelTree;
        skipRealtimeInvalidation?: boolean;
        skipPolyDisplay?: boolean;
    }>>;
    createTag(operation: string, historyTag: string): Promise<void>;
    deleteTag(historyTag: string): Promise<void>;
    restore(restorePoint: string, callback: HistoryStepHandler): Promise<void>;
    private getChange;
    /**
     * Calls `rekeyTables` directly, not via `ModelService`, so a swallowed
     * "model already gone" catch here can't also swallow the rekey.
     */
    private deleteModel;
    private insertModel;
    private updateModel;
    private insertChoice;
    private updateChoice;
    private deleteChoice;
    /**
     * These three are the only authority for a rule on replay: a model
     * definition declares no rules, so nothing else could re-derive one.
     */
    private insertDecision;
    private updateDecision;
    private deleteDecision;
    private insertRole;
    private updateRole;
    private deleteRole;
    /**
     * `'same-base'`: a restore undoes within the base the flow was authored
     * in, so the cross-base placement check has nothing left to ask.
     */
    private insertFlow;
    private updateFlow;
    private deleteFlow;
    private undoChange;
    private applyChange;
}
