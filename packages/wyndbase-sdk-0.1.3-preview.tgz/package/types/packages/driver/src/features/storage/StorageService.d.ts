import type { WynConnectionHandler } from '../../WynConnectionHandler';
import { BucketService } from './BucketService';
import { CredentialService } from './CredentialService';
import { DeviceService } from './DeviceService';
import { EventService } from './EventService';
import { FileAttachmentService } from './FileAttachmentService';
import { ObjectService } from './ObjectService';
import { ShareService } from './ShareService';
export declare class StorageService {
    private base;
    constructor(base: WynConnectionHandler);
    private _bucketService?;
    private _credentialService?;
    private _deviceService?;
    private _eventService?;
    private _objectService?;
    private _shareService?;
    private _fileAttachmentService?;
    get bucket(): BucketService;
    get fileAttachment(): FileAttachmentService;
    get object(): ObjectService;
    get credential(): CredentialService;
    get device(): DeviceService;
    get event(): EventService;
    get share(): ShareService;
    dispose(): void;
}
