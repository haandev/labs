import { z } from 'zod';
export declare const CreateCredentialInputSchema: z.ZodObject<{
    bucketId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    expiresAt: z.ZodOptional<z.ZodNullable<z.ZodISODateTime>>;
    name: z.ZodString;
    permissions: z.ZodOptional<z.ZodArray<z.ZodEnum<{
        AbortMultipartUpload: "AbortMultipartUpload";
        CompleteMultipartUpload: "CompleteMultipartUpload";
        CreateBucket: "CreateBucket";
        CreateMultipartUpload: "CreateMultipartUpload";
        DeleteBucket: "DeleteBucket";
        DeleteObject: "DeleteObject";
        DeleteObjectTagging: "DeleteObjectTagging";
        GetBucketVersioning: "GetBucketVersioning";
        GetObject: "GetObject";
        GetObjectTagging: "GetObjectTagging";
        HeadBucket: "HeadBucket";
        HeadObject: "HeadObject";
        ListBuckets: "ListBuckets";
        ListMultipartUploads: "ListMultipartUploads";
        ListObjectVersions: "ListObjectVersions";
        ListObjects: "ListObjects";
        ListObjectsV2: "ListObjectsV2";
        ListParts: "ListParts";
        PutBucketVersioning: "PutBucketVersioning";
        PutObject: "PutObject";
        PutObjectTagging: "PutObjectTagging";
        UploadPart: "UploadPart";
    }>>>;
}, z.core.$strip>;
export type TCreateCredentialInput = z.infer<typeof CreateCredentialInputSchema>;
/** The listing shape: `system.listBucketCredentials`'s row, minus nothing —
 *  it never carries a secret, so nothing needs stripping before this is sent
 *  to a client. */
export declare const CredentialInfoSchema: z.ZodObject<{
    _id: z.ZodString;
    accessKey: z.ZodString;
    bucket: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    bucketId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    creationDate: z.ZodCodec<z.ZodUnion<readonly [z.ZodISODateTime, z.ZodISODateTime, z.ZodDate]>, z.ZodUnion<readonly [z.ZodISODateTime, z.ZodISODateTime]>>;
    expiresAt: z.ZodOptional<z.ZodNullable<z.ZodCodec<z.ZodUnion<readonly [z.ZodISODateTime, z.ZodISODateTime, z.ZodDate]>, z.ZodUnion<readonly [z.ZodISODateTime, z.ZodISODateTime]>>>>;
    isActive: z.ZodBoolean;
    isRoot: z.ZodBoolean;
    name: z.ZodString;
    permissions: z.ZodArray<z.ZodString>;
}, z.core.$strip>;
export type TCredentialInfo = z.infer<typeof CredentialInfoSchema>;
/** The one shape carrying a secret: the create response. `createBucketCredential`'s
 *  RETURNING projects `bucketId`/`permissions` back out, so this is the row as
 *  written, not the request as received. */
export declare const IssuedCredentialSchema: z.ZodObject<{
    _id: z.ZodString;
    accessKey: z.ZodString;
    bucket: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    bucketId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    creationDate: z.ZodCodec<z.ZodUnion<readonly [z.ZodISODateTime, z.ZodISODateTime, z.ZodDate]>, z.ZodUnion<readonly [z.ZodISODateTime, z.ZodISODateTime]>>;
    expiresAt: z.ZodOptional<z.ZodNullable<z.ZodCodec<z.ZodUnion<readonly [z.ZodISODateTime, z.ZodISODateTime, z.ZodDate]>, z.ZodUnion<readonly [z.ZodISODateTime, z.ZodISODateTime]>>>>;
    isActive: z.ZodBoolean;
    isRoot: z.ZodBoolean;
    name: z.ZodString;
    permissions: z.ZodArray<z.ZodString>;
    secretKey: z.ZodString;
}, z.core.$strip>;
export type TIssuedCredential = z.infer<typeof IssuedCredentialSchema>;
/** The other shape carrying a secret: rotating root only ever changes the
 *  key pair, so `CredentialService.rotateRoot` has no fuller row to report. */
export declare const RotatedRootCredentialSchema: z.ZodObject<{
    accessKey: z.ZodString;
    secretKey: z.ZodString;
}, z.core.$strip>;
export type TRotatedRootCredential = z.infer<typeof RotatedRootCredentialSchema>;
