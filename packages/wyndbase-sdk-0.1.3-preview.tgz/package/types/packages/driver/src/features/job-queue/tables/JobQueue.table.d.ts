export declare const JOB_QUEUE_TABLE = "job_queue";
declare const factory: () => {
    children: ({
        isSystem: boolean;
        metadata: {
            allowFilter?: undefined;
            notNull: boolean;
            schema: {
                additionalProperties: boolean;
                type: string;
            };
            type: string;
            defaultValue?: undefined;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            schema?: undefined;
            notNull?: undefined;
            allowFilter: boolean;
            defaultValue: string;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            allowFilter?: undefined;
            schema?: undefined;
            notNull?: undefined;
            defaultValue: number;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            allowFilter?: undefined;
            notNull?: undefined;
            defaultValue?: undefined;
            schema: {
                additionalProperties: boolean;
                type: string;
            };
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            allowFilter?: undefined;
            schema?: undefined;
            notNull?: undefined;
            defaultValue?: undefined;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            schema?: undefined;
            notNull?: undefined;
            defaultValue?: undefined;
            allowFilter: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    })[];
    displayName: string;
    folder: string;
    isSystem: boolean;
    name: string;
    type: 'table';
};
export default factory;
export type JobQueueType = {
    _id: string;
    metadata: Record<string, any>;
    status: string;
    priority: number;
    maxAttempts: number;
    attempts: number;
    result: Record<string, any> | null;
    errorMessage: string | null;
    workerId: string | null;
    leaseUntil: string | null;
    nextAttemptAt: string | null;
};
