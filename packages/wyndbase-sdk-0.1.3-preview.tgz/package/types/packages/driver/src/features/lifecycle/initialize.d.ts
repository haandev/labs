/** Initialization orchestrator: explicit DDL → hooks → persist → seed sequencing. */
import type { WynConnectionHandler } from '../../WynConnectionHandler';
export declare function initializeDatabase(base: WynConnectionHandler, options?: {
    isMainBase?: boolean;
    skipDatabaseCreation?: boolean;
    /** Called once this call's `CREATE DATABASE` has succeeded. */
    onDatabaseCreated?: () => void;
}): Promise<void>;
