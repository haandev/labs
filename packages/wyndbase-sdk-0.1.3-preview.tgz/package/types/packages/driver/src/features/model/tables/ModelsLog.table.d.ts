export declare const MODELS_LOG_TABLE = "models_log";
declare const factory: () => {
    children: ({
        isSystem: boolean;
        metadata: {
            schema?: undefined;
            allowFilter: boolean;
            notNull: boolean;
            type: string;
        };
        name: string;
        physicalName: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            schema?: undefined;
            allowFilter?: undefined;
            notNull: boolean;
            type: string;
        };
        name: string;
        physicalName: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            notNull?: undefined;
            allowFilter?: undefined;
            schema: {
                additionalProperties: boolean;
                type: string;
            };
            type: string;
        };
        name: string;
        physicalName: string;
        type: 'column';
    })[];
    displayName: string;
    folder: string;
    isSystem: boolean;
    name: string;
    physicalName: string;
    type: 'table';
};
type HistoryOperationType = 'INSERT MODEL' | 'UPDATE MODEL' | 'DELETE MODEL' | 'INSERT CHOICE' | 'UPDATE CHOICE' | 'DELETE CHOICE' | 'INSERT CONSTRAINT' | 'UPDATE CONSTRAINT' | 'DELETE CONSTRAINT' | 'INSERT DECISION' | 'UPDATE DECISION' | 'DELETE DECISION';
export default factory;
export type ModelsLogType = {
    _id: string;
    operation_type: HistoryOperationType;
    old_data: Record<string, any> | null;
    new_data: Record<string, any> | null;
    operation_timestamp: Date;
};
