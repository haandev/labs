import type { WynConnectionHandler } from '../../WynConnectionHandler';
import { type EmailAttachment, type EmailMessageId } from './';
import { type ResolvedProvider, resolveProvider } from './resolve';
/** 503-shaped: nothing failed — an administrator has to set `PUBLIC_URL`. */
export declare class PublicUrlNotSetError extends Error {
    constructor();
}
export declare class EmailNotConfiguredError extends Error {
    constructor();
}
export type SendParams = {
    messageId: EmailMessageId;
    to: string;
    /** The account's display name. Absent falls back to the address's local part. */
    recipientName?: string | null;
    variables?: Record<string, unknown>;
};
export type SendOutcome = {
    queued: true;
    jobId: string;
} | {
    queued: false;
    reason: 'not-configured' | 'no-template';
};
/**
 * Built from `PUBLIC_URL` and nothing else. `federatedUrl` takes it from the
 * same place and for the same reason: an origin derived from a request is one
 * an attacker can influence, and a link in a mailbox outlives the request.
 *
 * Validated by the same reader `federatedOrigin` uses, so `localhost:3000`
 * is refused here as it is there rather than yielding a relative address a
 * mailbox cannot follow.
 *
 * @throws {PublicUrlNotSetError} unset or blank.
 * @throws {InvalidPublicOriginError} set, but not an absolute http(s) URL.
 */
export declare function absoluteUrl(path: string): string;
/**
 * The one builder for every link the product mails. Nothing else may assemble
 * one, including the links that used to append the base by hand — three
 * spellings of one rule is how four of the six shipped links ended up
 * resolving against the wrong tenant.
 *
 * The browser resolves its tenant from `?tenant=`, once, at load
 * (`apps/fe/src/integrations/sdk.tsx`), defaulting to the platform base. So a
 * link to `/account/security` sent from base `acme` opened the PLATFORM
 * base's security screen, and `base.url` was a bare `/`. `tenant` is the
 * base's NAME rather than its id: the front end compares it with the literal
 * `wyndbase` (`apps/fe/src/shared/utils/main-base.ts`), and a uuid there
 * would read as "not the main base" even for the main base.
 *
 * `params` is the rest of the query, built here rather than concatenated so
 * every value is escaped once and in one place. `baseId`, which the two
 * pre-auth screens read to aim their API call, is one of these — it is a
 * different thing from `tenant` and both are needed on those two links.
 *
 * @throws {PublicUrlNotSetError} unset origin — see `absoluteUrl`.
 */
export declare function productUrl(base: {
    id: string;
    name?: string | null;
}, path: string, params?: Record<string, string>): string;
/** Readable in a mailbox; an ISO string in a message body is a defect. */
export declare function formatTimestamp(value: Date): string;
/** A provider that cannot carry inline content sends without the logo; the
 *  frame falls back to the base name on its own. */
export declare function attachmentsFor(logo: EmailAttachment | null, supportsAttachments: boolean): EmailAttachment[] | undefined;
export declare class EmailService {
    private readonly base;
    private readonly resolve;
    /**
     * `resolve` defaults to the real `resolveProvider` — the one place a slug
     * becomes a sender (Principle 1). Overridable so a test can prove `send`
     * honours a provider's `supportsAttachments` without registering a
     * throwaway type in the frozen provider registry (Principle 7); every real
     * caller passes only `base`.
     */
    constructor(base: WynConnectionHandler, resolve?: typeof resolveProvider);
    /**
     * The base's logo as inline content, or `null` when it has none, cannot be
     * read, or is too large to carry on every message. Never throws: a message
     * that cannot be branded is still a message, and the frame falls back to the
     * base name on its own.
     */
    logoAttachment(): Promise<EmailAttachment | null>;
    /**
     * Never throws for a base that cannot send: every caller has already
     * completed the thing it is reporting, and a missing transport must not turn
     * that into a failed request. The outcome is what an administrator reads.
     *
     * It does throw when the origin is unset, because a relative link in a
     * mailbox is a useless message rather than a degraded one.
     */
    send(params: SendParams): Promise<SendOutcome>;
    /**
     * The one synchronous path. An administrator is standing at the screen and
     * has to be told what is wrong, which a queued job cannot do — so this throws
     * the provider's own error rather than recording it.
     */
    sendTest(params: {
        to: string;
        provider: ResolvedProvider;
    }): Promise<void>;
}
