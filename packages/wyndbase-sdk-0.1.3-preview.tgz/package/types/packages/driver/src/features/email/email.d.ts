/**
 * The one settings row every base is seeded with. Named queries target this id
 * as a literal, so a client cannot aim a write at a different row.
 */
export declare const EMAIL_SETTINGS_ROW_ID = "00000000-0000-7000-8000-000000000010";
/**
 * The logo rides with the message as an inline attachment rather than a link:
 * a remote image is blocked by default in much of the corporate mail estate,
 * and any URL long-lived enough to survive in a mailbox is one nothing can
 * revoke. Referenced from the body as `cid:wyndb-logo`.
 */
export declare const EMAIL_LOGO_CID = "wyndb-logo";
/**
 * A cap for mail only. The appearance screen accepts 2MB, base64 adds a third,
 * and every queued message carries a copy — a logo past this is refused and
 * the message goes out with the base name instead.
 */
export declare const MAX_EMAIL_LOGO_BYTES: number;
/** Renders as nothing when a base has no logo, rather than a broken image. */
export declare const TRANSPARENT_PIXEL = "data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==";
/** Inline content for one message, base64 because the job payload is JSON. */
export type EmailAttachment = {
    cid: string;
    content: string;
    contentType?: string;
    filename?: string;
};
