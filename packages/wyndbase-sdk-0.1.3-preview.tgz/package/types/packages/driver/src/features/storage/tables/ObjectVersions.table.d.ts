/**
 * ## Module: Object Versions Table
 *
 * This module defines the `object_versions` table for S3-compatible storage versioning.
 *
 * Purpose:
 * - Stores S3 object version metadata
 * - Tracks version IDs, delete markers, and version ordering
 * - Enables point-in-time access to previous object versions
 *
 * Notes:
 * - One `object_versions` table is created per database
 * - Each PUT operation creates a new version when versioning is enabled
 * - Delete operations create delete markers instead of removing data
 */
export declare const OBJECT_VERSIONS_TABLE = "object_versions";
declare const factory: () => {
    children: ({
        displayName: string;
        isSystem: boolean;
        metadata: {
            schema?: undefined;
            defaultValue?: undefined;
            allowFilter: boolean;
            notNull: boolean;
            type: string;
            default?: undefined;
        };
        name: string;
        type: 'column';
    } | {
        displayName?: undefined;
        isSystem: boolean;
        metadata: {
            schema?: undefined;
            defaultValue?: undefined;
            allowFilter: boolean;
            notNull: boolean;
            type: string;
            default?: undefined;
        };
        name: string;
        type: 'column';
    } | {
        displayName?: undefined;
        isSystem: boolean;
        metadata: {
            schema?: undefined;
            allowFilter?: undefined;
            defaultValue?: undefined;
            notNull: boolean;
            type: string;
            default?: undefined;
        };
        name: string;
        type: 'column';
    } | {
        displayName?: undefined;
        isSystem: boolean;
        metadata: {
            schema?: undefined;
            allowFilter?: undefined;
            defaultValue: string;
            notNull: boolean;
            type: string;
            default?: undefined;
        };
        name: string;
        type: 'column';
    } | {
        displayName?: undefined;
        isSystem: boolean;
        metadata: {
            allowFilter?: undefined;
            defaultValue?: undefined;
            notNull?: undefined;
            schema: {
                additionalProperties: boolean;
                type: string;
            };
            type: string;
            default?: undefined;
        };
        name: string;
        type: 'column';
    } | {
        displayName?: undefined;
        isSystem: boolean;
        metadata: {
            schema?: undefined;
            allowFilter?: undefined;
            defaultValue?: undefined;
            default: string;
            notNull: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    })[];
    constraints: {
        columns: string[];
        constraintType: 'unique';
    }[];
    displayName: string;
    folder: string;
    isSystem: boolean;
    name: string;
    type: 'table';
};
export default factory;
type Type = {
    versionId: string;
    bucket: string;
    key: string;
    size: number;
    etag: string;
    contentType: string;
    lastModified: Date;
    metadata: any;
    isLatest: boolean;
    isDeleteMarker: boolean;
    sequenceNumber: number;
};
export type ObjectVersionsType = Omit<Type, 'lastModified'> & {
    lastModified: Date;
};
