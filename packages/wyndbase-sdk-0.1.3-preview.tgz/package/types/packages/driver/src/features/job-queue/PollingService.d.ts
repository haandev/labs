import type { WynConnectionHandler } from '../../WynConnectionHandler';
import type { QueueDepthSnapshot, QueueObserver } from './queue-observer';
export interface PollingConfig {
    /**
     * How many actions one base may have running at once. Every recorded pass
     * ends on this number, so it is the constant that fixes how much one drain
     * moves.
     */
    maxInflightJobs?: number;
    /** How many jobs one pass may take before it gives the lane back. */
    maxJobsPerPass?: number;
    /**
     * The safety-net sweep, in milliseconds — not the delivery path, which is
     * the wake at the mutation seam and each base's own due-time timer. `0`
     * leaves only those two.
     */
    pollingInterval?: number;
    /** Transaction timeout in milliseconds */
    transactionTimeout?: number;
    /**
     * How long a finished job or event is kept, in milliseconds. `0` keeps none.
     * Defaults to `QUEUE_RETENTION_DAYS` days, or thirty.
     */
    retentionMs?: number;
}
export interface PollingDependencies {
    /** Live handlers for every openable base, on the maintenance lane. */
    listBases: () => Promise<WynConnectionHandler[]>;
    /** How many bases may be scanned at once. */
    scanConcurrency: () => number;
    /** Whether a base's two queues may drain at the same time. */
    drainsQueuesTogether: () => boolean;
}
export declare class PollingService {
    private readonly config;
    private readonly deps;
    private readonly coordinator;
    /** Tables whose mutation can produce work, per base. */
    private readonly wakeTables;
    /** Bases whose flow list could not be read, and when it was last tried. */
    private readonly wakeTablesFailedAt;
    private isRunning;
    /** Breaks a drain mid-flight on `stop()`. */
    private stopping;
    /** Stamped on a lease, so an abandoned one names who took it. */
    private readonly workerId;
    /** Actions running right now, per base. */
    private readonly inFlight;
    /** The action's deadline plus a grace, so a lease outlives its own work. */
    private readonly leaseMs;
    /** Bases whose drain stopped for want of an in-flight slot. */
    private readonly saturated;
    /** Reports what the queue is doing; the backend turns it into metrics. */
    private observer;
    /** Last depth reading per base, taken on the sweep. */
    private readonly depths;
    constructor(deps: PollingDependencies, config?: PollingConfig);
    /** Starts the worker: one scan, then the safety-net sweep. */
    start(): Promise<void>;
    stop(): void;
    /**
     * The signal that replaces the clock. Called after a mutation commits, it
     * wakes the base only when a table that can leave work behind was touched —
     * an unrelated write costs nothing but this comparison.
     *
     * A flow trigger's own INSERT into the outbox is invisible here, because
     * `mutating` is static analysis of the submitted statement and the trigger
     * runs inside Postgres. That is why the trigger's *own* table counts.
     */
    onMutation(baseId: string, mutating: {
        tables: string[];
    }[]): void;
    /**
     * Installs the reporter. One at a time, like the realtime hub's: the caller
     * is the process's own metrics layer, not a subscription surface.
     */
    setObserver(observer: QueueObserver): void;
    /**
     * The last depth reading for every base that has been swept. Plain data and
     * no database: a scrape must not turn into a round trip per base.
     */
    getQueueDepths(): ReadonlyMap<string, QueueDepthSnapshot>;
    /** Runs a scan now: for one base, or for every base. */
    notify(baseId?: string): Promise<void>;
    /** Invalidates the base cache (call when bases are added/removed) */
    invalidateCache(): Promise<void>;
    /**
     * What each base's current drain has moved. Keyed by base because several
     * drain at once, and a shared counter read as a before/after delta would
     * hand each of them the sum of all of them. One base's drains are serialised
     * by the coordinator, so this cannot be raced.
     */
    private readonly tally;
    private tallyFor;
    /** Returns whether the service is currently running */
    get running(): boolean;
    private canProduceWork;
    /**
     * Tables carrying a flow trigger on this base. A deactivated flow stays in
     * the set: its trigger is uninstalled, so the cost is one wasted claim, and
     * keeping it avoids a projection the stored query does not carry.
     */
    private loadWakeTables;
    /**
     * One base, emptied. Reports when it next has something due so the
     * coordinator can wait for that moment instead of polling for it.
     */
    private drainBase;
    /**
     * Deliberately looser than the claim: only rows due in the *future*. A row
     * that is already due but not runnable — parked on a blocker that has
     * finished — would otherwise arm a timer for a moment already past, and the
     * drain that followed would find nothing and arm it again.
     */
    private nextDueAt;
    /** The soonest future attempt among jobs waiting out their backoff. */
    private nextDueJobAt;
    private nextDueEventAt;
    /** `true` when a budget stopped the drain with rows still queued. */
    private processJobs;
    /**
     * Removes finished jobs and events past the retention window. Read-then-
     * delete-by-id, batched: a base with years of history must not spend a whole
     * statement timeout here, and a row that arrived after the read must not be
     * caught by a predicate it was never measured against.
     */
    /**
     * Everything the clock owes each base, on one pass and one connection:
     * what the queues look like, then what has aged out of them. Sampling the
     * depths here rather than answering them on demand is the whole point — a
     * metrics scrape must not become a round trip per base, and the sweep is
     * already holding the handle.
     */
    private sweepUpkeep;
    /** One reading per base, or none: a base that will not answer is skipped. */
    private sampleDepths;
    private readDepth;
    private sweepRetention;
    private sweepCache;
    /** One base's share: both queues, bounded. Returns how many rows went. */
    private removeExpired;
    /**
     * Of these jobs, the ones an event is still parked on. Nothing in the
     * database enforces that reference: deleting a blocker leaves its event
     * pointing at a row that is gone, and the event claim's terminal-status gate
     * then matches none of its disjuncts — the event never runs again.
     */
    private stillBlocking;
    /** Returns jobs whose lease expired to the queue; `true` if any were. */
    private reclaimExpiredLeases;
    /**
     * A lease, not a lock held for the length of the work: a short transaction
     * takes the batch and stamps it, each action runs with no connection at
     * all, and a second short write settles it. An `'empty'` outcome is what
     * ends the drain; a failed claim reads the same way, so a broken base
     * cannot spin here.
     */
    private claimAndRunJobs;
    private inFlightFor;
    /**
     * The action, then its outcome. Its own clone: the drain that claimed the
     * job has long since disposed of the one it used.
     */
    private runAndSettle;
    /**
     * Claims a batch and stamps each row in one short transaction. The claim is
     * a locking read, so each lease is its own statement beside it — and each
     * attempt count comes from what the claim returned rather than from a
     * self-reference in the SET. `taken` counts every row the claim returned,
     * malformed ones included, so the pass can tell a short batch (a drained
     * queue) from a full one.
     */
    private leaseJobs;
    /**
     * A spent budget is terminal and keeps its evidence; anything short of it
     * goes back to the queue behind a doubling delay, so a fault that clears
     * costs a wait rather than the job.
     */
    private settleFailure;
    /**
     * A pass that parked every row it served reports `false`: the rows remain,
     * but nothing here can move them — what unblocks a parked event is a wake
     * from the job or interaction it waits on.
     */
    private processEvents;
    /**
     * One node, one transaction. The next node needs no special case: the row
     * commits with its cursor advanced and matches the claim again, so the
     * loop's next turn picks it up — while a deferred or finished row stops
     * matching.
     *
     * `null` ends the drain: the claim found nothing this pass may still act on.
     */
    private claimAndRunOneEvent;
    private getBlockerJob;
    private getBlockerInteraction;
}
/** The same reader, reachable from a test; the shape is easy to get wrong. */
export declare function readDateForTests(value: unknown): Date | null;
