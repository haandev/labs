import { type FactorType } from '../../../../../shared/src/auth-factors/index';
import type { WynConnectionHandler } from '../../../WynConnectionHandler';
import { type ResolvedCredential, type RpConfig } from '../PasskeyService';
import type { Factor, VerifyResult } from './Factor';
export type ActiveFactorRow = {
    _id: string;
    type: string;
    isPasskey: boolean;
    mustChange: boolean;
    createdAt: string;
    /** The name its owner gave it. Only a passkey carries one; every other
     *  credential is identified by its kind alone. */
    label: string | null;
    /** `'recovery'` is one row over many stored codes: no id to delete, and it
     *  is replaced rather than removed. */
    source: 'factor' | 'passkey' | 'recovery';
};
export declare class FactorRegistry {
    private base;
    private readonly factors;
    private rpConfig?;
    constructor(base: WynConnectionHandler);
    setRpConfig(rp: RpConfig): void;
    /**
     * Undefined when the request never configured one. Read so an operation
     * handed to another base's registry can carry the request's own config.
     */
    get rp(): RpConfig | undefined;
    private requireRp;
    private passkey;
    beginDiscoverable(): Promise<{
        challengeToken: string;
        options: import("@simplewebauthn/server").PublicKeyCredentialRequestOptionsJSON;
    }>;
    /** The resolved user id and factor type are read from the stored
     *  credential, never from the request. */
    completeDiscoverable(input: string, onResolved?: (resolved: ResolvedCredential) => Promise<void>): Promise<{
        factorType: FactorType;
        userId: string;
    }>;
    get(type: string): Factor;
    verify(type: string, userId: string, input: string): Promise<VerifyResult>;
    challenge(type: string, userId: string): Promise<import("./Factor").ChallengeResult>;
    beginEnroll(type: string, userId: string, params?: Record<string, unknown>): Promise<import("./Factor").EnrollInit>;
    confirmEnroll(type: string, userId: string, factorId?: string, input?: string, opts?: {
        requireDeviceBound?: boolean;
        temporary?: boolean;
    }): Promise<{
        status: string;
        factorType: FactorType;
        replaced?: boolean;
        label?: string | null;
    }>;
    /**
     * Confirms an enrolment and provisions the recovery batch in one
     * transaction: what has to hold is that activation and mint share it, so a
     * removal either sees the new factor and keeps the batch, or commits first
     * and the mint then finds no batch and writes one. The inventory lock is
     * taken before the transaction's own factor writes, the order `removeFactor`
     * uses. A TOTP `claimEnroll` updates the pending factor row before that, in
     * autocommit, and releases its row lock at once, so it cannot wait on a
     * removal.
     *
     * The single-use material (TOTP step, WebAuthn challenge) is burned before
     * the transaction, so a failure inside it cannot roll the burn back.
     *
     * `recoveryCodes` is null when a batch already existed or nothing
     * qualifies. The batch's audit line and mail are sent by `announceBatch`,
     * which the caller runs where its own side effects belong.
     */
    confirmEnrollWithBatch(type: string, userId: string, factorId?: string, input?: string, opts?: {
        requireDeviceBound?: boolean;
        temporary?: boolean;
    }): Promise<{
        announceBatch: () => Promise<void>;
        recoveryCodes: string[] | null;
        result: {
            status: string;
            factorType: FactorType;
            replaced?: boolean;
            label?: string | null;
        };
    }>;
    private activateEnroll;
    private announceEnroll;
    /**
     * The one assurance question. The listing asks it to draw a control and the
     * removal asks it to enforce, so it is asked in one place rather than
     * expressed twice on paths that would drift.
     */
    private refusesRemoval;
    /** Whether removing `factorId` removes the last factor that keeps the batch. */
    private static dropsLastAal2;
    /**
     * The account page draws its Remove controls from this, so the verdict is
     * stamped here rather than recomputed in the browser: one wire answer means
     * no two sections can disagree about the same account.
     *
     * `additiveOnly` is the caller's, exactly as `removeFactor` takes it — the
     * registry enforces the rule and never decides whose setting applies.
     */
    listFactors(userId: string, additiveOnly?: boolean): Promise<({
        _id: string;
        type: string;
        createdAt: string;
        label: string | null;
        status: string;
        lastUsedAt: string | null;
        mustChange: boolean;
        isPasskey: boolean;
        source: 'factor' | 'passkey' | 'recovery';
        canRemove: boolean;
    } | {
        canRemove: boolean;
        _id: string;
        type: string;
        status: string;
        label: (string | null);
        lastUsedAt: (string | null);
        createdAt: string;
    })[]>;
    /** Rows the methods hold outside the shared factor store. The registry does
     *  not know which those are; it asks all of them. */
    private contributedRows;
    /** Resume a PENDING TOTP enrollment (returns secret once; owner-only). */
    getTotpEnrollment(userId: string, factorId: string): Promise<{
        factorId: string;
        secret: string;
        status: string;
        uri: string;
    }>;
    /** Credentials the account actually holds: an unconfirmed SETUP or PENDING
     *  enrollment is not one of them. */
    activeFactors(userId: string): Promise<ActiveFactorRow[]>;
    passwordChangeRequired(userId: string): Promise<boolean>;
    /** Factor types that support in-flow enrollment (begin + confirm). */
    get enrollableTypes(): FactorType[];
    getActiveFactorTypes(userId: string): Promise<FactorType[]>;
    /** Remove a factor, rejected when it would lower the user's achievable AAL. */
    removeFactor(params: {
        userId: string;
        factorId: string;
        additiveOnly: boolean;
    }): Promise<{
        ok: boolean;
    }>;
}
