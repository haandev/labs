export declare const INTERACTIONS_TABLE = "interactions";
export default _default;
declare function _default(): {
    children: ({
        isSystem: boolean;
        metadata: {
            schema?: undefined;
            allowFilter?: undefined;
            defaultValue?: undefined;
            notNull: boolean;
            type: string;
            onDelete?: undefined;
            targetTables?: undefined;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            allowFilter?: undefined;
            defaultValue?: undefined;
            notNull: boolean;
            schema: {
                additionalProperties: boolean;
                type: string;
            };
            type: string;
            onDelete?: undefined;
            targetTables?: undefined;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            allowFilter?: undefined;
            defaultValue?: undefined;
            notNull?: undefined;
            schema: {
                additionalProperties: boolean;
                type: string;
            };
            type: string;
            onDelete?: undefined;
            targetTables?: undefined;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            schema?: undefined;
            allowFilter?: undefined;
            defaultValue?: undefined;
            notNull?: undefined;
            type: string;
            onDelete?: undefined;
            targetTables?: undefined;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            schema?: undefined;
            allowFilter?: undefined;
            defaultValue?: undefined;
            notNull?: undefined;
            onDelete: string;
            targetTables: {
                table: string;
            }[];
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            schema?: undefined;
            defaultValue?: undefined;
            notNull?: undefined;
            allowFilter: boolean;
            onDelete: string;
            targetTables: {
                table: string;
            }[];
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            schema?: undefined;
            defaultValue?: undefined;
            notNull?: undefined;
            onDelete?: undefined;
            targetTables?: undefined;
            allowFilter: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            schema?: undefined;
            allowFilter?: undefined;
            onDelete?: undefined;
            targetTables?: undefined;
            defaultValue: string;
            notNull: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            schema?: undefined;
            onDelete?: undefined;
            targetTables?: undefined;
            allowFilter: boolean;
            defaultValue: string;
            notNull: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    })[];
    displayName: string;
    folder: string;
    isSystem: boolean;
    metadata: {
        displayFieldId: string;
    };
    name: string;
    type: 'table';
};
export type InteractionType = {
    _id: string;
    name: string;
    description: string;
    schema: Record<string, unknown>;
    response: Record<string, unknown> | null;
    respondedAt: string | null;
    respondedBy: string | null;
    assignedTo: string | null;
    requiredKey: string | null;
    kind: string;
    createdAt: string;
    updatedAt: string;
    createdBy: string | null;
    updatedBy: string | null;
    status: 'pending' | 'completed';
};
