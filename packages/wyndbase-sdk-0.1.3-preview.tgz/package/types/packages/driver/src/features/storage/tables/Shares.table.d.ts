export declare const STORAGE_SHARE_TABLE = "storage_share";
declare const factory: () => {
    children: ({
        displayName: string;
        isSystem: boolean;
        metadata: {
            schema?: undefined;
            allowFilter: boolean;
            notNull: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        displayName?: undefined;
        isSystem: boolean;
        metadata: {
            allowFilter?: undefined;
            schema?: undefined;
            notNull?: undefined;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        displayName?: undefined;
        isSystem: boolean;
        metadata: {
            allowFilter?: undefined;
            schema?: undefined;
            notNull: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        displayName?: undefined;
        isSystem: boolean;
        metadata: {
            allowFilter?: undefined;
            notNull?: undefined;
            schema: {
                properties: {
                    allowedMimeTypes: {
                        items: {
                            type: string;
                        };
                        type: string;
                    };
                    keys: {
                        items: {
                            type: string;
                        };
                        type: string;
                    };
                    maxFileSize: {
                        type: string;
                    };
                    prefixes: {
                        items: {
                            type: string;
                        };
                        type: string;
                    };
                    uploadPrefix: {
                        type: string;
                    };
                };
                type: string;
            };
            type: string;
        };
        name: string;
        type: 'column';
    })[];
    constraints: {
        columns: string[];
        constraintType: 'unique';
    }[];
    displayName: string;
    folder: string;
    isSystem: boolean;
    name: string;
    type: 'table';
};
export default factory;
export type StorageShareType = 'download' | 'upload';
export type StorageShareTableType = {
    _id: string;
    tokenHash: string;
    type: StorageShareType;
    expiresAt: string | null;
    revokedAt: string | null;
    maxUses: number | null;
    usesCount: number;
    password: string | null;
    bucketId: string;
    metadata: Record<string, any>;
    createdAt: string;
};
