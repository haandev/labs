import type { EmailProviderDescriptor } from '../../../../../shared/src/email-providers';
import type { EmailAttachment } from '../email';
/** One rendered message, provider-agnostic. */
export type OutboundMessage = {
    to: string;
    subject: string;
    html: string;
    text?: string;
    from: {
        email: string;
        name?: string | null;
    };
    replyTo?: string | null;
    cc?: string[];
    bcc?: string[];
    attachments?: EmailAttachment[];
};
/** A provider row's secret half, decrypted, plus its secret-free settings. */
export type ProviderSecret = {
    credential: string | null;
    config: Record<string, unknown>;
};
/** The descriptor plus what actually moves a message. */
export type EmailProviderSpec = EmailProviderDescriptor & {
    send(message: OutboundMessage, secret: ProviderSecret): Promise<{
        providerMessageId?: string;
    }>;
    /** SMTP only. For an HTTP provider the test send is the check. */
    verify?(secret: ProviderSecret): Promise<void>;
};
export type { ConfigFieldDescriptor } from '../../../../../shared/src/email-providers';
