export declare const SCREENS_TABLE = "screens";
declare const factory: () => {
    children: ({
        isSystem: boolean;
        metadata: {
            schema?: undefined;
            defaultValue?: undefined;
            allowFilter: boolean;
            notNull: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            allowFilter?: undefined;
            schema?: undefined;
            defaultValue?: undefined;
            notNull: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            allowFilter?: undefined;
            schema?: undefined;
            defaultValue?: undefined;
            notNull?: undefined;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            allowFilter?: undefined;
            defaultValue: {};
            notNull: boolean;
            schema: {
                items?: undefined;
                additionalProperties: boolean;
                type: string;
            };
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            allowFilter?: undefined;
            defaultValue: never[];
            notNull: boolean;
            schema: {
                additionalProperties?: undefined;
                items: {
                    properties: {
                        name: {
                            type: string;
                        };
                        required: {
                            type: string;
                        };
                        type: {
                            type: string;
                        };
                    };
                    required: string[];
                    type: string;
                };
                type: string;
            };
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            allowFilter?: undefined;
            schema?: undefined;
            defaultValue: boolean;
            notNull: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    })[];
    constraints: {
        columns: string[];
        constraintType: 'unique';
    }[];
    displayName: string;
    folder: string;
    isSystem: boolean;
    metadata: {
        displayFieldId: string;
    };
    name: string;
    type: 'table';
};
export default factory;
export type ScreenInputDef = {
    name: string;
    type: 'string' | 'number';
    required?: boolean;
};
export type ScreenType = {
    _id: string;
    key: string;
    name: string;
    icon: string | null;
    layout: Record<string, unknown>;
    inputs: ScreenInputDef[];
    enabled: boolean;
};
