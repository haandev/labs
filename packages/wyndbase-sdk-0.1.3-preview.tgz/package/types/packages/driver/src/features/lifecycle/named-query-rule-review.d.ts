/**
 * The one place a rule-engine verdict becomes a refusal or a warning.
 *
 * Both doors that judge a named-query declaration — the WQL definition path and
 * the model-write path the product's own settings form saves through — read the
 * verdict here, so "an `error` refuses, a `warn` travels" is stated once. A
 * second spelling is how one door would keep refusing while the other quietly
 * stopped.
 */
import type { Diagnostic } from '../execution/named-query-rules';
/**
 * The id a create has not been given yet. Never matches a stored one, so the
 * reachability walk cannot mistake the node being judged for a saved one.
 *
 * Shared by both doors: they project the same kind of not-yet-written node, and
 * two constants would be two answers to one question.
 */
export declare const PENDING_NAMED_QUERY_ID = "";
/**
 * `status = 400`: an unstatused error defaults to 500 and logs as a crash.
 */
export declare class NamedQueryRuleViolationError extends Error {
    readonly ruleId: string;
    readonly name = "NamedQueryRuleViolationError";
    readonly status = 400;
    constructor(ruleId: string, message: string);
}
/**
 * Refuses on the first `error`-severity diagnostic and RETURNS the rest.
 *
 * The returning half is the point. Every `warn` the engine computed used to be
 * dropped at this step, so a rule could fire, phrase itself, and reach nobody:
 * the caller saw a save that succeeded and no sign that anything had been said
 * about it.
 */
export declare function reviewNamedQueryDiagnostics(diagnostics: readonly Diagnostic[]): Diagnostic[];
