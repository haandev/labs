import type { HistoryItem } from '../../../../../shared/src/history';
/**
 * The family an operation belongs to — the last word of `operation_type`
 * (`INSERT MODEL`, `UPDATE DECISION`), which `applySchemaItem` dispatches on.
 */
export type OperationFamily = 'MODEL' | 'CHOICE' | 'FLOW' | 'DECISION' | 'ROLE';
/** The family an `operation_type` belongs to, or `null` if it names none. */
export declare function operationFamily(operationType: string): OperationFamily | null;
/**
 * `false` for an unknown family on purpose: an entry nobody classified must not
 * be silently resolved as though writing it back were safe.
 */
export declare function travelsWhole(operationType: string): boolean;
/**
 * The id of the thing an entry is about, as opposed to the id of the entry
 * itself — `computePlan` diffs on the entry id.
 */
export declare function nodeIdOf(item: HistoryItem): string | null;
