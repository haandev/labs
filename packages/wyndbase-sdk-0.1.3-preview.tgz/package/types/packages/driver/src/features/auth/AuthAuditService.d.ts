import type { WynConnectionHandler } from '../../WynConnectionHandler';
/**
 * The values are the log's public schema: already-written rows keep the string
 * they were written with, so never rename one — add a new action instead.
 */
export declare const AUTH_AUDIT_ACTIONS: {
    /**
     * The round trip never reached a verdict — failed exchange, dead issuer,
     * unparseable identity. Not a refusal, which is the base's rules saying no.
     */
    readonly AUTH_FEDERATED_FAILED: 'auth.federated_failed';
    /**
     * The verdict's cause and per-rule reasons go in `detail` — the only place
     * they are written, since the person is told nothing beyond the refusal.
     */
    readonly AUTH_FEDERATED_REFUSED: 'auth.federated_refused';
    readonly AUTH_STEP_UP_COMPLETED: 'auth.step_up_completed';
    readonly EMAIL_ADDED: 'email.added';
    readonly EMAIL_REMOVED: 'email.removed';
    readonly EMAIL_VERIFIED: 'email.verified';
    readonly FACTOR_ENROLLED: 'factor.enrolled';
    readonly FACTOR_REMOVED: 'factor.removed';
    readonly PASSWORD_CHANGED: 'password.changed';
    readonly PASSWORD_SET: 'password.set';
    readonly SESSION_FINGERPRINT_ANOMALY: 'session.fingerprint_anomaly';
    readonly SESSION_REFRESH_REUSE_DETECTED: 'session.refresh_reuse_detected';
    readonly SESSION_REVOKED: 'session.revoked';
    readonly SESSION_ROTATION_FAILED: 'session.rotation_failed';
    readonly WEBAUTHN_COUNTER_REGRESSION: 'webauthn.counter_regression';
};
export type AuthAuditAction = (typeof AUTH_AUDIT_ACTIONS)[keyof typeof AUTH_AUDIT_ACTIONS];
/**
 * `detail` is free-form context; no secret ever goes in it — the trail is read
 * more widely and kept longer than the tables the secrets live in.
 */
export type AuthAuditEntry = {
    action: AuthAuditAction;
    actorUserId: string | null;
    targetUserId: string | null;
    ip?: string | null;
    detail?: Record<string, unknown>;
};
/** The single writer of `auth_audit_logs`; call sites never insert directly. */
export declare class AuthAuditService {
    private base;
    constructor(base: WynConnectionHandler);
    /**
     * Never throws — a failed audit write must not 500 a successful mutation.
     * Never call inside a transaction: the aborted INSERT surfaces on the next.
     */
    record(entry: AuthAuditEntry): Promise<void>;
}
