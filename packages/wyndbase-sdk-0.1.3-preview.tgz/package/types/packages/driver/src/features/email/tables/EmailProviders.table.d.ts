export declare const EMAIL_PROVIDERS_TABLE = "email_providers";
declare const factory: () => {
    children: ({
        isSystem: boolean;
        metadata: {
            allowFilter: boolean;
            notNull: boolean;
            type: string;
            encrypt?: undefined;
            schema?: undefined;
            defaultValue?: undefined;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            notNull: boolean;
            type: string;
            encrypt?: undefined;
            schema?: undefined;
            allowFilter?: undefined;
            defaultValue?: undefined;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            defaultValue: string;
            notNull: boolean;
            type: string;
            encrypt?: undefined;
            schema?: undefined;
            allowFilter?: undefined;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            type: string;
            encrypt?: undefined;
            schema?: undefined;
            allowFilter?: undefined;
            defaultValue?: undefined;
            notNull?: undefined;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            encrypt: boolean;
            type: string;
            schema?: undefined;
            allowFilter?: undefined;
            defaultValue?: undefined;
            notNull?: undefined;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            encrypt?: undefined;
            defaultValue: {};
            notNull: boolean;
            schema: {
                additionalProperties: boolean;
                type: string;
            };
            type: string;
            allowFilter?: undefined;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            encrypt?: undefined;
            schema?: undefined;
            allowFilter: boolean;
            defaultValue: boolean;
            notNull: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            encrypt?: undefined;
            schema?: undefined;
            allowFilter?: undefined;
            defaultValue: number;
            notNull: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    })[];
    constraints: {
        columns: string[];
        constraintType: 'unique';
        name: string;
    }[];
    displayName: string;
    folder: string;
    isSystem: boolean;
    metadata: {
        displayFieldId: string;
    };
    name: string;
    type: 'table';
};
export default factory;
export type EmailProvidersType = {
    _id: string;
    slug: string;
    providerType: string;
    displayName: string;
    fromEmail: string;
    fromName: string;
    replyTo: string | null;
    credential: string | null;
    config: Record<string, unknown>;
    isActive: boolean;
    sortOrder: number;
};
