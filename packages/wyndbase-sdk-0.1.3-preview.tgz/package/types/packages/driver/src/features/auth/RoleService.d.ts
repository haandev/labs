import type { WynConnectionHandler } from '../../WynConnectionHandler';
export declare class RoleService {
    private base;
    constructor(base: WynConnectionHandler);
    getRoles(): Promise<import("../../../../wql/src/index").WqlRows<{
        _id: string;
        name: string;
        lock: boolean;
        permissions: string[];
        users: string[];
        createdAt: string;
        updatedAt: string;
        createdBy: (string | null);
        updatedBy: (string | null);
    } & Record<any, unknown>, import("../../../../wql/src/index").WQLOptions<boolean, boolean, boolean, import("../../../../wql/src/index").WQLExecutionMode> & {
        raw?: boolean;
        model?: import("../../../../wql/src/index").WynModel | import("../../../../wql/src/index").WynModelTree;
        skipRealtimeInvalidation?: boolean;
        skipPolyDisplay?: boolean;
    }>>;
    addRole(role: string, options?: {
        lock?: boolean;
    }): Promise<{
        _id: string;
        name: string;
        lock: boolean;
        createdAt: string;
        updatedAt: string;
        createdBy: (string | null);
        updatedBy: (string | null);
    } & Record<any, unknown>>;
    grantUserRole(userId: string, role: string): Promise<{
        _id: string;
        _originId: string;
        user: (string | null);
        role: (string | null);
        createdAt: string;
        updatedAt: string;
        createdBy: (string | null);
        updatedBy: (string | null);
        startAt: string;
        endAt: (string | null);
        deletedBy: (string | null);
    } & Record<any, unknown>>;
    getUserRoles(userId: string): Promise<(string | null)[]>;
    private getRoleMemberIds;
    /** Role names granted to a user. */
    getUserRoleNames(userId: string): Promise<string[]>;
    hasRole(userId: string, role: string): Promise<boolean>;
    canUserDo(_userId: string, _action: string, _resource: string): Promise<boolean>;
}
