import type { NamedQueryNode, NQExposure, WynModel } from '../../../../../model/src/types';
import { WynModelTree } from '../../../../../model/src/utils/index';
export interface NamedQueryFacts {
    elevated: boolean;
    exposure: NQExposure;
    /** The body reads `$context` anywhere — the caller's identity is used. */
    usesContext: boolean;
    parameters: string[];
    /** Parameters reaching a FILTER, HAVING or link condition: the query's real attack surface. */
    parametersReachingCondition: string[];
    /** Named queries this body names directly. */
    namedQueriesReached: string[];
    /** Policy names the body expands with `POLICY(…)`. A rule's expression is
     *  not a value a caller may read, so a stored body may not name one. */
    expandsPolicies: string[];
    /** Elevated named queries reachable transitively, this one included when it is elevated. */
    reachesElevated: string[];
    mutates: boolean;
    /** False when the body did not parse; every rule that could refuse must check it. */
    parsed: boolean;
}
/** `space.name`, the spelling a person reads in a diagnostic. */
export declare function namedQueryDisplayName(nq: NamedQueryNode, tree: WynModelTree): string;
/**
 * What the rules read. A body that did not parse yields no edges. The save
 * doors refuse new text that cannot be parsed, and a row already stored must
 * not crash this walk. `parsed` says so, so a rule that could refuse declines
 * to speak instead of speaking from empty facts.
 */
export declare function computeFacts(nq: NamedQueryNode, model: WynModel | WynModelTree): NamedQueryFacts;
