declare const factory: () => {
    children: ({
        isSystem: boolean;
        metadata: {
            allowFilter?: undefined;
            mirrorColumns: {
                canHaveMultiple: boolean;
                name: string;
                table: string;
            }[];
            notNull: boolean;
            onDelete: string;
            targetTables: {
                table: string;
            }[];
            type: string;
        };
        name: string;
        physicalName: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            onDelete?: undefined;
            targetTables?: undefined;
            mirrorColumns?: undefined;
            allowFilter: boolean;
            notNull: boolean;
            type: string;
        };
        name: string;
        physicalName: string;
        type: 'column';
    })[];
    constraints: {
        columns: string[];
        constraintType: 'unique';
    }[];
    displayName: string;
    folder: string;
    isSystem: boolean;
    metadata: {
        displayFieldId: string;
    };
    name: string;
    type: 'table';
};
export default factory;
export type HistoryTagsType = {
    _id: string;
    operation: string;
    history_tag: string;
};
