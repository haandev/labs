import type { WynConnectionHandler } from '../../WynConnectionHandler';
export type EmailProviderInput = {
    slug?: string;
    providerType?: string;
    displayName?: string;
    fromEmail: string;
    fromName?: string;
    replyTo?: string | null;
    credential?: string | null;
    config?: Record<string, unknown>;
    /** Installation makes its first provider the default; nothing else does. */
    makeDefault?: boolean;
};
/**
 * Writes a provider row outright and optionally points the base at it. Unlike
 * the client write path, an absent credential binds null rather than keeping a
 * stored one — callers run at installation time, where none exists.
 */
export declare function applyEmailProvider(base: WynConnectionHandler, input: EmailProviderInput): Promise<void>;
