import type { WynConnectionHandler } from '../../WynConnectionHandler';
import type { EmailMessageId } from '../email';
import { type SendOutcome } from '../email/EmailService';
export type Notification = {
    messageId: EmailMessageId;
    to: string;
    recipientName?: string | null;
    /**
     * A function is evaluated inside the same `try` as the send below — the
     * only way a helper that can throw (`absoluteUrl`, unset `PUBLIC_URL`)
     * shares this guard. Handed to `notify` as an already-built object, the
     * expression is evaluated in the *caller's* frame before this function is
     * even entered, so a throw there would never reach this `catch`.
     */
    variables?: Record<string, unknown> | (() => Record<string, unknown>);
};
export type NotifyOutcome = {
    queued: true;
} | {
    queued: false;
    reason: Extract<SendOutcome, {
        queued: false;
    }>['reason'] | 'error';
};
/**
 * Best-effort by design. Every caller has already completed the thing it is
 * reporting, so a mail server that is down, a base with no transport, or an
 * origin nobody configured must not turn a finished action into a 500. What
 * happened is on the job record and in this log. It never throws; it returns
 * the outcome so a caller that must tell a person the truth can.
 */
export declare function notify(base: WynConnectionHandler, params: Notification): Promise<NotifyOutcome>;
/**
 * Verification is deliberately not filtered on: an admin-created account's
 * primary address is unverified until its owner follows this very link.
 */
export declare function primaryEmailOf(base: WynConnectionHandler, userId: string): Promise<{
    _id: string;
    email: string;
    name: string | null;
} | null>;
/**
 * Best-effort: every caller has already completed the thing it is reporting,
 * so a missing address or a failed read must not turn that into a 500.
 */
export declare function notifyUser(base: WynConnectionHandler, params: {
    messageId: EmailMessageId;
    userId: string;
    variables?: Notification['variables'];
}): Promise<void>;
