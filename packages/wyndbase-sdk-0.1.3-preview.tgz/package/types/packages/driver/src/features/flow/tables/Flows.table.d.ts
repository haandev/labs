export declare const FLOWS_TABLE = "flows";
export default _default;
declare function _default(): {
    children: ({
        isSystem: boolean;
        metadata: {
            schema?: undefined;
            notNull: boolean;
            type: string;
            defaultValue?: undefined;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            notNull?: undefined;
            schema?: undefined;
            type: string;
            defaultValue?: undefined;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            schema?: undefined;
            defaultValue: boolean;
            notNull: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            defaultValue: never[];
            notNull: boolean;
            schema: {
                items: {
                    properties: {
                        readonly name?: undefined;
                        id: {
                            type: string;
                        };
                        nextNodeId: {
                            type: string[];
                        };
                        payload: {
                            additionalProperties: boolean;
                            type: string;
                        };
                        type: {
                            type: string;
                            enum?: undefined;
                        };
                        defaultValue?: undefined;
                    };
                    required: string[];
                    type: string;
                };
                type: string;
                properties?: undefined;
                required?: undefined;
            };
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            notNull: boolean;
            schema: {
                properties: {
                    metadata: {
                        additionalProperties: boolean;
                        type: string;
                    };
                    type: {
                        enum: string[];
                        type: string;
                    };
                };
                required: string[];
                type: string;
                items?: undefined;
            };
            type: string;
            defaultValue?: undefined;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            notNull?: undefined;
            defaultValue: never[];
            schema: {
                properties?: undefined;
                required?: undefined;
                items: {
                    properties: {
                        nextNodeId?: undefined;
                        payload?: undefined;
                        defaultValue: {};
                        id: {
                            type: string;
                        };
                        name: {
                            type: string;
                        };
                        type: {
                            enum: string[];
                            type: string;
                        };
                    };
                    required: string[];
                    type: string;
                };
                type: string;
            };
            type: string;
        };
        name: string;
        type: 'column';
    })[];
    displayName: string;
    folder: string;
    isSystem: boolean;
    metadata: {
        displayFieldId: string;
    };
    name: string;
    type: 'table';
};
