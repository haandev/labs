import { z } from 'zod';
export declare const EventLogSchema: z.ZodObject<{
    end: z.ZodNumber;
    nodeId: z.ZodString;
    start: z.ZodNumber;
    state: z.ZodOptional<z.ZodAny>;
    status: z.ZodDefault<z.ZodEnum<{
        error: "error";
        info: "info";
        processing: "processing";
        success: "success";
        warning: "warning";
    }>>;
}, z.core.$strip>;
export declare const EventSchema: z.ZodObject<{
    _id: z.ZodString;
    blockerInteraction: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    blockerJob: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    currentNodeId: z.ZodNullable<z.ZodDefault<z.ZodString>>;
    flowId: z.ZodString;
    flowSnapshot: z.ZodObject<{
        _id: z.ZodString;
        createdAt: z.ZodString;
        description: z.ZodNullable<z.ZodString>;
        isActive: z.ZodBoolean;
        lock: z.ZodBoolean;
        name: z.ZodString;
        nodes: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            payload: z.ZodObject<{
                attachments: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    cid: z.ZodString;
                    content: z.ZodString;
                    contentType: z.ZodOptional<z.ZodString>;
                    filename: z.ZodOptional<z.ZodString>;
                }, z.core.$strip>>>;
                bcc: z.ZodOptional<z.ZodArray<z.ZodString>>;
                body: z.ZodString;
                cc: z.ZodOptional<z.ZodArray<z.ZodString>>;
                fromName: z.ZodOptional<z.ZodString>;
                providerSlug: z.ZodOptional<z.ZodString>;
                replyTo: z.ZodOptional<z.ZodString>;
                subject: z.ZodString;
                text: z.ZodOptional<z.ZodString>;
                to: z.ZodString;
            }, z.core.$strict>;
            type: z.ZodLiteral<"sendEmail">;
            id: z.ZodString;
            nextNodeId: z.ZodNullable<z.ZodString>;
        }, z.core.$strip>, z.ZodObject<{
            payload: z.ZodObject<{
                body: z.ZodString;
                to: z.ZodString;
            }, z.core.$strip>;
            type: z.ZodLiteral<"sendSms">;
            id: z.ZodString;
            nextNodeId: z.ZodNullable<z.ZodString>;
        }, z.core.$strip>, z.ZodObject<{
            payload: z.ZodObject<{
                duration: z.ZodNumber;
            }, z.core.$strip>;
            type: z.ZodLiteral<"wait">;
            id: z.ZodString;
            nextNodeId: z.ZodNullable<z.ZodString>;
        }, z.core.$strip>, z.ZodObject<{
            payload: z.ZodObject<{
                body: z.ZodOptional<z.ZodString>;
                headers: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
                method: z.ZodEnum<{
                    DELETE: "DELETE";
                    GET: "GET";
                    PATCH: "PATCH";
                    POST: "POST";
                    PUT: "PUT";
                }>;
                url: z.ZodURL;
            }, z.core.$strip>;
            type: z.ZodLiteral<"http">;
            id: z.ZodString;
            nextNodeId: z.ZodNullable<z.ZodString>;
        }, z.core.$strip>, z.ZodObject<{
            payload: z.ZodObject<{
                falseBranch: z.ZodNullable<z.ZodString>;
                logic: z.ZodString;
                trueBranch: z.ZodNullable<z.ZodString>;
            }, z.core.$strip>;
            type: z.ZodLiteral<"condition">;
            id: z.ZodString;
            nextNodeId: z.ZodNullable<z.ZodString>;
        }, z.core.$strip>, z.ZodObject<{
            payload: z.ZodObject<{
                maxTransitions: z.ZodDefault<z.ZodNumber>;
                nodeId: z.ZodString;
            }, z.core.$strip>;
            type: z.ZodLiteral<"bridge">;
            id: z.ZodString;
            nextNodeId: z.ZodNullable<z.ZodString>;
        }, z.core.$strip>, z.ZodObject<{
            payload: z.ZodObject<{
                variables: z.ZodArray<z.ZodObject<{
                    value: z.ZodString;
                    variableName: z.ZodString;
                }, z.core.$strip>>;
            }, z.core.$strip>;
            type: z.ZodLiteral<"setVariable">;
            id: z.ZodString;
            nextNodeId: z.ZodNullable<z.ZodString>;
        }, z.core.$strip>, z.ZodObject<{
            payload: z.ZodObject<{
                data: z.ZodString;
                repeatBranch: z.ZodString;
            }, z.core.$strip>;
            type: z.ZodLiteral<"repeater">;
            id: z.ZodString;
            nextNodeId: z.ZodNullable<z.ZodString>;
        }, z.core.$strip>, z.ZodObject<{
            payload: z.ZodObject<{
                outputSchema: z.ZodOptional<z.ZodObject<{
                    properties: z.ZodRecord<z.ZodString, z.ZodUnknown>;
                }, z.core.$strip>>;
                parameters: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
                query: z.ZodString;
            }, z.core.$strip>;
            type: z.ZodLiteral<"wql">;
            id: z.ZodString;
            nextNodeId: z.ZodNullable<z.ZodString>;
        }, z.core.$strip>, z.ZodObject<{
            payload: z.ZodObject<{
                assignedTo: z.ZodOptional<z.ZodString>;
                description: z.ZodString;
                name: z.ZodString;
                schema: z.ZodAny;
            }, z.core.$strip>;
            type: z.ZodLiteral<"interaction">;
            id: z.ZodString;
            nextNodeId: z.ZodNullable<z.ZodString>;
        }, z.core.$strip>], "type">>;
        startNodeId: z.ZodNullable<z.ZodString>;
        stateSchema: z.ZodOptional<z.ZodArray<z.ZodObject<{
            defaultValue: z.ZodOptional<z.ZodUnknown>;
            id: z.ZodString;
            name: z.ZodString;
            type: z.ZodEnum<{
                array: "array";
                boolean: "boolean";
                number: "number";
                object: "object";
                string: "string";
            }>;
        }, z.core.$strip>>>;
        trigger: z.ZodDiscriminatedUnion<[z.ZodObject<{
            metadata: z.ZodObject<{
                on: z.ZodEnum<{
                    DELETE: "DELETE";
                    INSERT: "INSERT";
                    UPDATE: "UPDATE";
                }>;
                tableId: z.ZodString;
            }, z.core.$strip>;
            type: z.ZodLiteral<"table">;
        }, z.core.$strip>, z.ZodObject<{
            metadata: z.ZodObject<{
                cron: z.ZodString;
                end: z.ZodNullable<z.ZodString>;
                start: z.ZodNullable<z.ZodString>;
            }, z.core.$strip>;
            type: z.ZodLiteral<"schedule">;
        }, z.core.$strip>, z.ZodObject<{
            metadata: z.ZodObject<{
                headers: z.ZodRecord<z.ZodString, z.ZodString>;
                parameters: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
                withCredentials: z.ZodBoolean;
            }, z.core.$strip>;
            type: z.ZodLiteral<"webhook">;
        }, z.core.$strip>, z.ZodObject<{
            metadata: z.ZodObject<{
                type: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                    download: "download";
                    upload: "upload";
                }>>>;
            }, z.core.$strip>;
            type: z.ZodLiteral<"storageEvent">;
        }, z.core.$strip>], "type">;
        updatedAt: z.ZodString;
    }, z.core.$strip>;
    logs: z.ZodDefault<z.ZodArray<z.ZodObject<{
        end: z.ZodNumber;
        nodeId: z.ZodString;
        start: z.ZodNumber;
        state: z.ZodOptional<z.ZodAny>;
        status: z.ZodDefault<z.ZodEnum<{
            error: "error";
            info: "info";
            processing: "processing";
            success: "success";
            warning: "warning";
        }>>;
    }, z.core.$strip>>>;
    nodeStates: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodAny>>;
    occurredAt: z.ZodString;
    processedAt: z.ZodNullable<z.ZodString>;
    state: z.ZodAny;
    status: z.ZodDefault<z.ZodEnum<{
        canceled: "canceled";
        completed: "completed";
        failed: "failed";
        processing: "processing";
        queued: "queued";
    }>>;
    triggerData: z.ZodAny;
    waitUntil: z.ZodOptional<z.ZodNullable<z.ZodString>>;
}, z.core.$strip>;
export type TEvent = z.infer<typeof EventSchema>;
export type TEventLog = z.infer<typeof EventLogSchema>;
