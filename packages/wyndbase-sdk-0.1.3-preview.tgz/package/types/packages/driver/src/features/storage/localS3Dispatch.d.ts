import { Readable } from 'node:stream';
import type { WynConnectionHandler } from '../../WynConnectionHandler';
/**
 * The base a local object request is addressed to.
 *
 * The handle itself, not its id: initialization dispatches uploads before the
 * `system.bases` row exists, so an id the host would have to resolve names
 * nothing yet.
 */
export type LocalS3Target = Pick<WynConnectionHandler, 'id' | 's3Service' | 'storage'>;
/**
 * Hands one S3 request to the local object route without a socket.
 *
 * Installed for the reason initialization has: it uploads before the HTTP
 * server binds, so a loopback request to the port the server is about to take
 * is either refused or — worse — answered by a previous process. Once
 * installed it serves every server-side call to a local bucket, not only the
 * seed. The host application owns the tenant configuration.
 */
export type LocalS3Dispatch = (target: LocalS3Target, request: Request) => Promise<Response>;
export declare function requireLocalS3Dispatch(installed: LocalS3Dispatch | undefined): LocalS3Dispatch;
/**
 * A presigned PUT signs `host`. `fetch()` synthesises that header; a hand-built
 * `Request` does not, and the missing one reads as a forged signature.
 */
export declare function presignedPutRequest(presignedUrl: string, body: Uint8Array, contentType: string): Request;
interface SmithyHttpRequest {
    method: string;
    protocol: string;
    hostname: string;
    port?: number;
    path: string;
    query?: Record<string, string | string[] | null | undefined>;
    headers: Record<string, string>;
    body?: unknown;
}
/**
 * An `HttpHandler` for the AWS SDK that answers from the in-process route.
 * Structural, not a `@smithy/protocol-http` subclass: the SDK only calls these
 * four members, and the driver keeps no dependency on smithy's own packages.
 */
export declare function localS3RequestHandler(target: LocalS3Target, resolveDispatch: () => LocalS3Dispatch | undefined): {
    handle(request: SmithyHttpRequest): Promise<{
        response: {
            body: Readable | undefined;
            headers: {
                [k: string]: string;
            };
            statusCode: number;
        };
    }>;
    httpHandlerConfigs: () => {};
    metadata: {
        handlerProtocol: string;
    };
    updateHttpClientConfig: () => void;
};
export {};
