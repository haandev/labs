import type { WQLOptions } from '../../../../wql/src/index';
import type { WynConnectionHandler } from '../../WynConnectionHandler';
/** What a handler returns to leave the query to its own body. */
export declare const NAMED_QUERY_NOT_HANDLED: unique symbol;
/** Rows, or the sentinel that declines. Named so the contract is visible at
 *  every handler signature rather than only in the dispatcher. */
export type NamedQueryOutcome = unknown | typeof NAMED_QUERY_NOT_HANDLED;
/** The caller's execution authority, for a handler that re-runs the query
 *  somewhere else and must not widen it. Not `context`: by this point that is
 *  the request base's own derived roles, which mean nothing on another base. */
export type NamedQueryHandlerConfig = Pick<WQLOptions, 'clientLevel' | 'user'>;
export type NamedQueryHandler = (base: WynConnectionHandler, params: Record<string, unknown>, config: NamedQueryHandlerConfig) => Promise<NamedQueryOutcome>;
export type NamedQueryHandlerEntry = {
    handler: NamedQueryHandler;
    /** Whether running the handler writes; a policied caller needs
     *  `allowMutation` for one that does. Defaults to true, so a registration
     *  that forgets to say is refused rather than admitted. */
    mutation: boolean;
};
export declare function registerNamedQueryHandler(id: string, handler: NamedQueryHandler, options?: {
    mutation?: boolean;
}): void;
export declare function namedQueryHandler(id: string): NamedQueryHandlerEntry | undefined;
