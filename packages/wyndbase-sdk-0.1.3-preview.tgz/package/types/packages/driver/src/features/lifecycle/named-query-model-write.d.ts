/**
 * Named-query rules on the MODEL-WRITE path: `POST /models` and
 * `PUT /models/:modelId`, which is the door the product's own query-settings
 * form saves through. Until this existed, the rule engine judged the WQL
 * definition path and nothing else, so the UI could save a declaration the DDL
 * path refuses.
 *
 * Asked at the DOOR, and deliberately not inside `createModel` / `updateModel`:
 * those two are also the undo and migration-replay path — their own comment
 * says replay calls them directly — and a rule that refused there would turn a
 * validation refusal into a restore failure, making a row already stored
 * unrestorable the day a rule was added. A door judges a declaration a person
 * is making now; a replay is not that.
 */
import type { WynModelTree } from '../../../../model/src/utils/index';
import { type Diagnostic } from '../execution/named-query-rules';
/**
 * Narrowed to the one call this module makes, so a test needs no database.
 *
 * `ensureModelTree` and not `ensureStructure`: the review has to index the
 * model to find the row a write replaces, and `SchemaCache.loadTree()` has
 * already built and memoized exactly that index. Taking the raw model and
 * re-indexing it here would pay for the same work on every design write.
 */
export type NamedQueryModelWriteTarget = {
    ensureModelTree(): Promise<WynModelTree>;
};
/**
 * Judges the named query a model write would leave behind. Refuses on the first
 * `error`-severity diagnostic and returns the `warn`s for the caller to carry
 * back to whoever asked for the write.
 *
 * Returns an empty list for every write that declares no named query, a delete
 * included: a delete states nothing, so there is nothing to judge, and refusing
 * one on a rule would strand the row. A named-query body the parser rejects
 * throws that parser error before any rule is asked.
 *
 * Must be called BEFORE the write: the rules read the model as it stands, and
 * afterwards the row being judged is already the stored one.
 */
export declare function reviewNamedQueryModelWrite(input: {
    base: NamedQueryModelWriteTarget;
    definition: Record<string, any> | null | undefined;
    modelId: string | null;
}): Promise<Diagnostic[]>;
