import { z } from 'zod';
export type { AlertNotificationPayload, AlertNotificationRow, AlertNotificationType, } from '../tables/AlertNotifications.table';
export { ALERT_NOTIFICATIONS_TABLE } from '../tables/AlertNotifications.table';
export type { AlertQueryRow, AlertState, } from '../tables/AlertQueries.table';
export { ALERT_QUERIES_TABLE } from '../tables/AlertQueries.table';
/**
 * Validation error codes raised by AlertService. The REST layer maps these
 * to HTTP status codes (see apps/be/src/routes/base/alerts.ts).
 */
export declare const AlertErrorCode: {
    readonly INVALID: 'ALERT_QUERY_INVALID';
    readonly MUST_BE_FULL_WQL: 'ALERT_QUERY_MUST_BE_FULL_WQL';
    readonly MUST_BE_SELECT: 'ALERT_QUERY_MUST_BE_SELECT';
    readonly NOT_FOUND: 'ALERT_NOT_FOUND';
    readonly PARSE_ERROR: 'ALERT_QUERY_PARSE_ERROR';
    readonly REFERENCES_ALERT_TABLES: 'ALERT_QUERY_REFERENCES_ALERT_TABLES';
};
export type AlertErrorCode = (typeof AlertErrorCode)[keyof typeof AlertErrorCode];
export declare const AlertWarningCode: {
    readonly OWNER_MISSING_READ: 'ALERT_OWNER_MISSING_READ';
};
export type AlertWarningCode = (typeof AlertWarningCode)[keyof typeof AlertWarningCode];
export type AlertWarning = {
    code: typeof AlertWarningCode.OWNER_MISSING_READ;
    missingKeys: string[];
};
/** HTTP status for each validation code (consumed by the global error handler). */
export declare const ALERT_ERROR_STATUS: Record<AlertErrorCode, number>;
/**
 * Thrown by AlertService. Carries a stable `code` and an HTTP `status`; `name`
 * is set to the code so apps/be's global error handler (which keys off
 * `error.status` and `error.name`) surfaces it without per-route mapping.
 */
export declare class AlertValidationError extends Error {
    readonly code: AlertErrorCode;
    readonly status: number;
    constructor(code: AlertErrorCode, message?: string);
}
export declare const CreateAlertBody: z.ZodObject<{
    description: z.ZodOptional<z.ZodString>;
    name: z.ZodString;
    notifyOnResolve: z.ZodOptional<z.ZodBoolean>;
    query: z.ZodString;
}, z.core.$strip>;
export type CreateAlertBody = z.infer<typeof CreateAlertBody>;
export declare const UpdateAlertBody: z.ZodObject<{
    description: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    name: z.ZodOptional<z.ZodString>;
    notifyOnResolve: z.ZodOptional<z.ZodBoolean>;
    query: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
export type UpdateAlertBody = z.infer<typeof UpdateAlertBody>;
