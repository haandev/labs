import { S3Client } from '@aws-sdk/client-s3';
import type { WynConnectionHandler } from '../../WynConnectionHandler';
/**
 * Presigned URLs are handed to the browser and sign the `host` header, so
 * the endpoint must be the origin the browser reaches this install at —
 * `PUBLIC_URL` when configured. The server's own port is the local-dev
 * fallback, where browser and server share a machine.
 */
export declare function localDeviceEndpoint(baseId: string): string;
export declare class DeviceService {
    private base;
    private cache;
    private localDevice;
    constructor(base: WynConnectionHandler);
    local(): Promise<S3Client>;
    private buildLocalDevice;
    dispose(): void;
    /**
     * Rebuilds the local client on the next `local()` call so it signs with
     * whatever root credential now applies, and evicts every cache entry that
     * pointed at the stale one. The stale build is identified by promise
     * identity, not by whether it has resolved yet — a rotation that lands
     * while a build is still in flight must still discard what that build
     * produces, so the destroy is chained onto the captured promise rather
     * than assumed to already be safe to run.
     */
    resetLocalDevice(): void;
    getByBucketId(bucketId: string): Promise<S3Client | null>;
}
