import { type FactorType } from '../../../../shared/src/auth-factors/index';
export type CompletedFactor = {
    type: FactorType;
};
/**
 * The bar for this login. Escapes never raise it — holding a way out must not
 * put a person on a rung that same way out is then refused as the climb.
 */
export declare function effectiveTarget(opts: {
    minimumAAL: number;
    userAdditiveFactors?: boolean;
    enrolledForTarget: FactorType[];
}): number;
/**
 * `escapes` is a list, not a flag — an account may hold several and all are
 * offered, alongside `enroll` as well as `stepUp`.
 */
export type StepUpDecision = {
    done: true;
} | {
    kind: 'stepUp';
    factors: FactorType[];
    autoSelect?: FactorType;
    escapes: FactorType[];
} | {
    kind: 'enroll';
    factors: FactorType[];
    escapes: FactorType[];
} | {
    unsatisfiable: true;
};
export declare function stepUpDecision(opts: {
    current: number;
    target: number;
    enrolled: FactorType[];
}): StepUpDecision;
/**
 * `mode` keeps "verify what you have" apart from "enrol something first" — the
 * client draws a code field or a ceremony. Escapes stay out of `factors`.
 */
export type StepUpOptions = {
    mode: 'verify' | 'enroll' | 'unsatisfiable';
    factors: FactorType[];
    escapes: FactorType[];
    autoSelect?: FactorType;
};
/**
 * `heldBackByGrace` separates "holds nothing stronger", which must be waved
 * through, from "holds something merely too young", which must be refused.
 */
export type StepUpOffering = StepUpOptions & {
    heldBackByGrace: boolean;
};
export declare function stepUpOptions(opts: {
    target: number;
    enrolled: FactorType[];
}): StepUpOptions;
