import type { StorageStore } from '../../../../../storage/src/index';
import type { WynConnectionHandler } from '../../../WynConnectionHandler';
import { S3AuditService } from './S3AuditService';
import { S3BucketService } from './S3BucketService';
import { S3MultipartService } from './S3MultipartService';
import { S3ObjectService } from './S3ObjectService';
export declare class S3Service implements StorageStore {
    private _bucketStore;
    private _objectStore;
    private _auditStore;
    private _multipartStore;
    private base;
    constructor(base: WynConnectionHandler);
    get buckets(): S3BucketService;
    get objects(): S3ObjectService;
    get audit(): S3AuditService;
    get multipart(): S3MultipartService;
}
