export declare const CACHE_ENTRIES_TABLE = "cache_entries";
declare const factory: () => {
    children: ({
        isSystem: boolean;
        metadata: {
            targetTables?: undefined;
            allowFilter: boolean;
            notNull: boolean;
            type: string;
            onDelete?: undefined;
            schema?: undefined;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            allowFilter: boolean;
            notNull: boolean;
            onDelete: string;
            targetTables: {
                table: string;
            }[];
            type: string;
            schema?: undefined;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            allowFilter?: undefined;
            targetTables?: undefined;
            onDelete?: undefined;
            notNull: boolean;
            schema: {
                additionalProperties: boolean;
                type: string;
            };
            type: string;
        };
        name: string;
        type: 'column';
    })[];
    constraints: {
        columns: string[];
        constraintType: 'unique';
        name: string;
    }[];
    displayName: string;
    folder: string;
    isSystem: boolean;
    metadata: {
        transient: boolean;
    };
    name: string;
    type: 'table';
};
export default factory;
export type CacheEntriesType = {
    _id: string;
    key: string;
    cacheScope: string;
    user: string;
    value: Record<string, unknown>;
    expiresAt: Date;
};
