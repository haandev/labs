export type FrameBrand = {
    baseName: string;
    /** An absolute, publicly reachable URL. Null renders the name instead. */
    logoUrl: string | null;
    /** A CSS colour. Used on the button and nowhere text sits on it. */
    accent: string;
};
/**
 * The block set the frame styles. The editor offers exactly these and nothing
 * else, so nothing can be authored that arrives unstyled.
 *
 * `<br>` is deliberately not in this list, and deliberately allowed anyway:
 * it needs no inline style to render correctly in a mail client, so it is
 * absent because styling it would be a no-op, not because an author may not
 * produce one. A tag this list does not name is copied straight through by
 * `inlineStyles` below, and `toPlainText` already turns `<br>` into a
 * newline, so a soft line break is a fully supported part of the contract.
 */
export declare const FRAME_BLOCK_TAGS: readonly ['p', 'h2', 'h3', 'ul', 'ol', 'li', 'a', 'strong', 'em', 'img'];
/**
 * Wraps an authored fragment in the message the recipient actually receives.
 *
 * Two of the frame's own defences are against the sanitiser rather than the
 * renderer. Proton, HEY, Fastmail, Orange, SFR and La Poste strip the
 * `cellspacing` and `cellpadding` attributes, which restores the browser's
 * default 2px cell spacing and puts a hairline gap around the card, so both
 * tables carry `border-collapse` and `border-spacing` as well. Outlook for
 * macOS, Proton and HEY strip `align`, which is what centres the card, so the
 * inner table carries `margin:0 auto` to be centred without it.
 */
export declare function wrapInFrame(fragmentHtml: string, brand: FrameBrand): string;
/**
 * A readable alternative for a client that will not render HTML, and for the
 * `text` part every message carries. A link keeps its address: without it a
 * plain-text reader cannot act on a confirmation or a reset at all.
 *
 * The address is read from the same scanner the styling half uses, so it
 * survives whatever order, quoting or company the anchor's attributes keep —
 * a positional regular expression over the tag's source dropped a
 * single-quoted `href` outright and leaked raw markup out of an earlier value
 * holding a `>`. An anchor carrying no address degrades to its text rather
 * than trailing an empty `( )`.
 */
export declare function toPlainText(fragmentHtml: string): string;
