import type { WynConnectionHandler } from '../../../WynConnectionHandler';
import { NAMED_QUERY_NOT_HANDLED, type NamedQueryHandlerConfig } from '../../cache/named-query-handlers';
/**
 * The caller's user row lives on the base its session authenticated against,
 * so a profile read asked of any other base is answered from there. Filtering
 * the asked base's own users by an id it does not hold answers "nobody" for a
 * profile that always exists somewhere.
 *
 * The identity is the session's, which is what the query means by "me": a call
 * naming some other user — act-as, a reset flow — carries no home base and is
 * declined here.
 */
export declare function getMeOnHomeBase(base: WynConnectionHandler, _params: Record<string, unknown>, config: NamedQueryHandlerConfig): Promise<typeof NAMED_QUERY_NOT_HANDLED | import("../../../../../wql/src/index").WqlRows<{
    _id: string;
    name: (string | null);
    givenName: (string | null);
    familyName: (string | null);
    username: (string | null);
    picture: string[];
    zoneinfo: (string | null);
    createdAt: string;
    isPlatformUser: unknown;
    emails: {
        _id: string;
        email: string;
        primary: (boolean | null);
        verified: (string | null);
    }[];
} & Record<any, unknown>, NamedQueryHandlerConfig>>;
