export declare const VERIFICATION_TOKEN_TABLE = "verification_token";
declare const factory: () => {
    children: ({
        isSystem: boolean;
        metadata: {
            allowFilter: boolean;
            notNull: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            allowFilter?: undefined;
            notNull?: undefined;
            type: string;
        };
        name: string;
        type: 'column';
    })[];
    constraints: {
        columns: string[];
        constraintType: 'unique';
    }[];
    displayName: string;
    folder: string;
    isSystem: boolean;
    name: string;
    type: 'table';
};
export default factory;
export type VerificationTokenType = {
    _id: string;
    identifier: string;
    token: string;
    expires: Date;
    challenge: string | null;
    challengeMethod: string | null;
    redirectUri: string | null;
    scope: string | null;
    acr: string | null;
    amr: string | null;
    purpose: string;
    clientId: string | null;
    userId: string | null;
    emailId: string | null;
};
export type VerificationTokenBinding = {
    userId: string;
    emailId: string;
};
/** Null on `oauth_code` rows and on rows minted before the columns existed. */
export type StoredVerificationTokenBinding = {
    [K in keyof VerificationTokenBinding]: string | null;
};
