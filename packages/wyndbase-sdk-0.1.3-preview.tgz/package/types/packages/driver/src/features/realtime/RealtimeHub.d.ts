import type { RealtimeServerEvent, RealtimeTrackingEntry } from '../../../../shared/src/index';
/** All but `connectedAt` are optional: `/realtime/stream` runs before the auth plugin. */
export interface ConnectionMeta {
    connectedAt: number;
    ip?: string;
    userAgent?: string;
    userId?: string;
    clientId?: string;
    /** Resolved on the first authenticated subscribe; the stream itself carries
     *  no credential, so a connection that has never subscribed has none. */
    username?: string;
}
export type RealtimeHubSend = (...event: RealtimeServerEvent) => void;
export interface RealtimeHubMetrics {
    subscribesTotal: number;
    unsubscribesTotal: number;
    expiredEvictions: number;
    pendingTrackingExpired: number;
    trackingCacheHits: number;
    trackingCacheMisses: number;
    broadcastConnectionsScanned: number;
    broadcastsTotal: number;
    broadcastsDropped: number;
    broadcastRunsTotal: number;
    trackingEntriesWidened: number;
    mutatingEntriesWidened: number;
    invalidatesEmittedTotal: number;
    invalidatesCoalescedTotal: number;
    resubscribeBatchTotal: number;
}
/** Callbacks must be cheap and synchronous — they fire inline in the broadcast hot path. */
export interface RealtimeHubObserver {
    onBroadcastComplete?: (baseId: string, durationMs: number, subsScanned: number) => void;
    onSseSendError?: (baseId: string, err: unknown) => void;
    onBroadcastError?: (baseId: string, err: unknown) => void;
}
export interface RealtimeHubOptions {
    observer?: RealtimeHubObserver;
    /** Subscriptions per batch before yielding to the event loop. Default `2000`. */
    broadcastBatchSize?: number;
    /** Ms between batches; `0` yields via `setImmediate`, positive spreads via `setTimeout`. Default `1000`. */
    broadcastBatchDelayMs?: number;
    /** Trailing-edge debounce (ms) before `invalidate` is sent; `0` disables it. */
    invalidateDebounceMs?: number;
    /** Ceiling on how long coalescing may defer an `invalidate` while writes keep arriving; measured from the burst's first write. */
    invalidateMaxWaitMs?: number;
    /** Concurrent SSE streams one client address may hold. Default `200`. */
    maxStreamsPerIp?: number;
}
export declare class RealtimeHub {
    private connections;
    /** Per-base shard of `connections`, turning broadcast fan-out from O(K·C) to O(C). */
    private connectionsByBase;
    private pendingTracking;
    /**
     * Keyed by owner scope (`user:id` or `anonymous:connId`) so unauthenticated
     * clients can't collide; lets a client batch-resubscribe without re-querying.
     */
    private trackingCache;
    /** Capped at MAX_PENDING_PER_BASE; an evicted batch is widened into the head, never lost. */
    private pendingBroadcasts;
    /** Bases with a drain loop in flight. The queue empties before a run's
     *  asynchronous work finishes, so its emptiness cannot stand in for this. */
    private broadcastInFlight;
    private sweepInterval;
    private metrics;
    private metricsByBase;
    private readonly DEFAULT_BATCH_SIZE;
    private readonly DEFAULT_BATCH_DELAY_MS;
    private readonly DEFAULT_INVALIDATE_DEBOUNCE_MS;
    private readonly DEFAULT_INVALIDATE_MAX_WAIT_MS;
    private readonly SUB_TTL_MS;
    private readonly PENDING_TTL_MS;
    private readonly MIN_SUB_TTL_MS;
    private readonly MAX_SUB_TTL_MS;
    private readonly TRACKING_CACHE_TTL_MS;
    private readonly SWEEP_INTERVAL_MS;
    /** Public so tests can read the cap without re-declaring it. */
    static MAX_PENDING_PER_BASE: number;
    /** Public so tests can read the default without re-declaring it. */
    static DEFAULT_MAX_STREAMS_PER_IP: number;
    readonly maxStreamsPerIp: number;
    private streamsByIp;
    private readonly broadcastBatchSize;
    private readonly broadcastBatchDelayMs;
    private readonly invalidateDebounceMs;
    private readonly invalidateMaxWaitMs;
    private readonly observer;
    constructor(opts?: RealtimeHubOptions);
    /** Late-binding observer install for app bootstrap; last write wins. */
    setObserver(observer: RealtimeHubObserver): void;
    /** Flood ceiling per client address; an unresolvable address is not counted. */
    canAcceptConnection(ip?: string): boolean;
    registerConnection(connId: string, baseId: string, send: RealtimeHubSend, meta?: Partial<ConnectionMeta>): void;
    /** Write-once bind to owner, within the connection's own base. Unknown,
     *  wrong-base and not-theirs all return false to avoid an existence oracle. */
    claimConnection(connId: string, baseId: string, userId: string): boolean;
    /** Attaches non-identifying client metadata; last write wins. Ownership is not settable here. */
    attachClientIdentity(connId: string, identity: {
        clientId?: string;
        username?: string;
    }): void;
    removeConnection(connId: string): void;
    subscribe(connId: string, tracking: RealtimeTrackingEntry[], keyHash: string, ttlMs?: number): void;
    /** Batch resubscribe from cache; returns keyHashes the cache couldn't satisfy. */
    resubscribeFromCache(connId: string, keyHashes: string[]): {
        ok: string[];
        missing: string[];
    };
    /** Clamps a client-supplied per-sub TTL into the allowed band. */
    private clampTtl;
    /** Raises the connection's record of subscription activity; never lowers it. */
    private recordSubActivity;
    private touchSub;
    private emitInvalidate;
    unsubscribe(connId: string, keyHash: string): void;
    /** Stores tracking entries from a query response; returns a one-time-use ID.
     *  `minterUserId` is null for an anonymous query — such a handle binds to its
     *  base only, since there is no identity to bind to. */
    storeTracking(baseId: string, minterUserId: string | null, tracking: RealtimeTrackingEntry[]): string;
    /** A wrong base, a wrong caller, an unknown id and an expired id are one answer.
     *  A mismatched entry stays: deleting it would let a probe spend another
     *  caller's handle. */
    consumeTracking(trackingId: string, expectedBaseId: string, expectedUserId: string | null): RealtimeTrackingEntry[] | null;
    /** Entry point for mutation-triggered broadcasts; enqueues per base and starts the drain loop. */
    scheduleBroadcast(baseId: string, mutating: RealtimeTrackingEntry[]): void;
    /** Awaits each broadcast so two never run concurrently for one base; yields every 10. */
    private drainBroadcastQueue;
    /**
     * Snapshots connections/subscriptions up front so a concurrent
     * unsubscribe/disconnect during a yield can't corrupt the scan.
     */
    broadcast(baseId: string, mutating: RealtimeTrackingEntry[]): Promise<void>;
    private yieldBetweenBatches;
    /** Trailing-edge debounce for a subscription's next `invalidate` event. */
    private scheduleInvalidate;
    /** Try/catch so a broken transport doesn't skip the rest of the subscribers; sweep evicts it via idle TTL. */
    private safeSend;
    startSweep(intervalMs?: number): void;
    stopSweep(): void;
    private sweep;
    /** Sites where baseId isn't known yet pass `undefined` so only the global counter moves. */
    private bumpMetric;
    /** Reported by the compiler, per execution — a subscription or write it could
     *  only track as "the whole table". */
    recordWidenedEntries(baseId: string, counts: {
        tracking: number;
        mutating: number;
    }): void;
    getStats(): {
        connections: number;
        subscriptions: number;
        pendingTracking: number;
        trackingCacheSize: number;
        perBase: Record<string, number>;
        metrics: RealtimeHubMetrics;
    };
    /** Per-base slice of `getStats`, for a tenant-scoped activity page. */
    getStatsForBase(baseId: string): {
        connections: number;
        subscriptions: number;
        pendingTracking: number;
        trackingCacheSize: number;
        perBase: Record<string, number>;
        metrics: RealtimeHubMetrics;
    };
    /** Per-base gauge snapshot for periodic Prometheus sync; O(K + C), call every ~10s. */
    getStatsAllBases(): Map<string, {
        subscriptionsActive: number;
        connectionsActive: number;
        pendingBroadcasts: number;
    }>;
    /** Top tables by how many live subscriptions in `baseId` track them. */
    inspectBaseTopTables(baseId: string, limit?: number): Array<{
        table: string;
        count: number;
    }>;
    /** One row per live SSE connection for `baseId`, for the Realtime Monitor ops table. */
    inspectBaseClients(baseId: string): Array<{
        connRef: string;
        connectedAt: number;
        idleMs: number | null;
        ip?: string;
        userAgent?: string;
        userId?: string;
        username?: string;
        clientId?: string;
        subCount: number;
        oldestSubAgeMs: number;
    }>;
    /** Live subscriptions for `baseId` with debounce counters, sorted by coalescedCount desc. */
    inspectBaseSubscriptions(baseId: string, limit?: number): Array<{
        keyHash: string;
        connRef: string;
        tables: string[];
        operation: string;
        ttlMs: number;
        createdAt: number;
        lastTouchedAt: number;
        idleMs: number;
        emittedCount: number;
        coalescedCount: number;
    }>;
    /** Histogram of subscription idle-TTL, bucketed to the hub's TTL band. */
    inspectBaseTtlHistogram(baseId: string): Array<{
        bucket: string;
        count: number;
    }>;
    /** Histogram of per-subscription idle time; read alongside the TTL histogram for eviction pressure. */
    inspectBaseIdleHistogram(baseId: string): Array<{
        bucket: string;
        count: number;
    }>;
}
