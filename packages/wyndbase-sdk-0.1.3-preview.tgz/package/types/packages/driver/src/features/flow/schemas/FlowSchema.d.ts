import { z } from 'zod';
export declare const StateVariableSchema: z.ZodObject<{
    defaultValue: z.ZodOptional<z.ZodUnknown>;
    id: z.ZodString;
    name: z.ZodString;
    type: z.ZodEnum<{
        array: "array";
        boolean: "boolean";
        number: "number";
        object: "object";
        string: "string";
    }>;
}, z.core.$strip>;
export type TStateVariable = z.infer<typeof StateVariableSchema>;
export declare const ActionDataSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    payload: z.ZodObject<{
        attachments: z.ZodOptional<z.ZodArray<z.ZodObject<{
            cid: z.ZodString;
            content: z.ZodString;
            contentType: z.ZodOptional<z.ZodString>;
            filename: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>>;
        bcc: z.ZodOptional<z.ZodArray<z.ZodString>>;
        body: z.ZodString;
        cc: z.ZodOptional<z.ZodArray<z.ZodString>>;
        fromName: z.ZodOptional<z.ZodString>;
        providerSlug: z.ZodOptional<z.ZodString>;
        replyTo: z.ZodOptional<z.ZodString>;
        subject: z.ZodString;
        text: z.ZodOptional<z.ZodString>;
        to: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"sendEmail">;
}, z.core.$strip>, z.ZodObject<{
    payload: z.ZodObject<{
        body: z.ZodString;
        to: z.ZodString;
    }, z.core.$strip>;
    type: z.ZodLiteral<"sendSms">;
}, z.core.$strip>, z.ZodObject<{
    payload: z.ZodObject<{
        duration: z.ZodNumber;
    }, z.core.$strip>;
    type: z.ZodLiteral<"wait">;
}, z.core.$strip>, z.ZodObject<{
    payload: z.ZodObject<{
        body: z.ZodOptional<z.ZodString>;
        headers: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
        method: z.ZodEnum<{
            DELETE: "DELETE";
            GET: "GET";
            PATCH: "PATCH";
            POST: "POST";
            PUT: "PUT";
        }>;
        url: z.ZodURL;
    }, z.core.$strip>;
    type: z.ZodLiteral<"http">;
}, z.core.$strip>, z.ZodObject<{
    payload: z.ZodObject<{
        falseBranch: z.ZodNullable<z.ZodString>;
        logic: z.ZodString;
        trueBranch: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>;
    type: z.ZodLiteral<"condition">;
}, z.core.$strip>, z.ZodObject<{
    payload: z.ZodObject<{
        maxTransitions: z.ZodDefault<z.ZodNumber>;
        nodeId: z.ZodString;
    }, z.core.$strip>;
    type: z.ZodLiteral<"bridge">;
}, z.core.$strip>, z.ZodObject<{
    payload: z.ZodObject<{
        variables: z.ZodArray<z.ZodObject<{
            value: z.ZodString;
            variableName: z.ZodString;
        }, z.core.$strip>>;
    }, z.core.$strip>;
    type: z.ZodLiteral<"setVariable">;
}, z.core.$strip>, z.ZodObject<{
    payload: z.ZodObject<{
        data: z.ZodString;
        repeatBranch: z.ZodString;
    }, z.core.$strip>;
    type: z.ZodLiteral<"repeater">;
}, z.core.$strip>, z.ZodObject<{
    payload: z.ZodObject<{
        assignedTo: z.ZodOptional<z.ZodString>;
        description: z.ZodString;
        name: z.ZodString;
        schema: z.ZodAny;
    }, z.core.$strip>;
    type: z.ZodLiteral<"interaction">;
}, z.core.$strip>], "type">;
/** A node id is read from expressions as `nodes.<id>`, so it has to be a JSONata name. */
export declare const NODE_ID_PATTERN: RegExp;
declare const FlowSendEmailNodeSchema: z.ZodObject<{
    payload: z.ZodObject<{
        attachments: z.ZodOptional<z.ZodArray<z.ZodObject<{
            cid: z.ZodString;
            content: z.ZodString;
            contentType: z.ZodOptional<z.ZodString>;
            filename: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>>;
        bcc: z.ZodOptional<z.ZodArray<z.ZodString>>;
        body: z.ZodString;
        cc: z.ZodOptional<z.ZodArray<z.ZodString>>;
        fromName: z.ZodOptional<z.ZodString>;
        providerSlug: z.ZodOptional<z.ZodString>;
        replyTo: z.ZodOptional<z.ZodString>;
        subject: z.ZodString;
        text: z.ZodOptional<z.ZodString>;
        to: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"sendEmail">;
    id: z.ZodString;
    nextNodeId: z.ZodNullable<z.ZodString>;
}, z.core.$strip>;
declare const FlowSendSmsNodeSchema: z.ZodObject<{
    payload: z.ZodObject<{
        body: z.ZodString;
        to: z.ZodString;
    }, z.core.$strip>;
    type: z.ZodLiteral<"sendSms">;
    id: z.ZodString;
    nextNodeId: z.ZodNullable<z.ZodString>;
}, z.core.$strip>;
declare const FlowBridgeNodeSchema: z.ZodObject<{
    payload: z.ZodObject<{
        maxTransitions: z.ZodDefault<z.ZodNumber>;
        nodeId: z.ZodString;
    }, z.core.$strip>;
    type: z.ZodLiteral<"bridge">;
    id: z.ZodString;
    nextNodeId: z.ZodNullable<z.ZodString>;
}, z.core.$strip>;
declare const FlowWaitNodeSchema: z.ZodObject<{
    payload: z.ZodObject<{
        duration: z.ZodNumber;
    }, z.core.$strip>;
    type: z.ZodLiteral<"wait">;
    id: z.ZodString;
    nextNodeId: z.ZodNullable<z.ZodString>;
}, z.core.$strip>;
declare const FlowHttpNodeSchema: z.ZodObject<{
    payload: z.ZodObject<{
        body: z.ZodOptional<z.ZodString>;
        headers: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
        method: z.ZodEnum<{
            DELETE: "DELETE";
            GET: "GET";
            PATCH: "PATCH";
            POST: "POST";
            PUT: "PUT";
        }>;
        url: z.ZodURL;
    }, z.core.$strip>;
    type: z.ZodLiteral<"http">;
    id: z.ZodString;
    nextNodeId: z.ZodNullable<z.ZodString>;
}, z.core.$strip>;
declare const FlowConditionNodeSchema: z.ZodObject<{
    payload: z.ZodObject<{
        falseBranch: z.ZodNullable<z.ZodString>;
        logic: z.ZodString;
        trueBranch: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>;
    type: z.ZodLiteral<"condition">;
    id: z.ZodString;
    nextNodeId: z.ZodNullable<z.ZodString>;
}, z.core.$strip>;
declare const FlowSetVariableNodeSchema: z.ZodObject<{
    payload: z.ZodObject<{
        variables: z.ZodArray<z.ZodObject<{
            value: z.ZodString;
            variableName: z.ZodString;
        }, z.core.$strip>>;
    }, z.core.$strip>;
    type: z.ZodLiteral<"setVariable">;
    id: z.ZodString;
    nextNodeId: z.ZodNullable<z.ZodString>;
}, z.core.$strip>;
declare const FlowRepeaterNodeSchema: z.ZodObject<{
    payload: z.ZodObject<{
        data: z.ZodString;
        repeatBranch: z.ZodString;
    }, z.core.$strip>;
    type: z.ZodLiteral<"repeater">;
    id: z.ZodString;
    nextNodeId: z.ZodNullable<z.ZodString>;
}, z.core.$strip>;
declare const FlowWqlNodeSchema: z.ZodObject<{
    payload: z.ZodObject<{
        outputSchema: z.ZodOptional<z.ZodObject<{
            properties: z.ZodRecord<z.ZodString, z.ZodUnknown>;
        }, z.core.$strip>>;
        parameters: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
        query: z.ZodString;
    }, z.core.$strip>;
    type: z.ZodLiteral<"wql">;
    id: z.ZodString;
    nextNodeId: z.ZodNullable<z.ZodString>;
}, z.core.$strip>;
declare const FlowInteractionNodeSchema: z.ZodObject<{
    payload: z.ZodObject<{
        assignedTo: z.ZodOptional<z.ZodString>;
        description: z.ZodString;
        name: z.ZodString;
        schema: z.ZodAny;
    }, z.core.$strip>;
    type: z.ZodLiteral<"interaction">;
    id: z.ZodString;
    nextNodeId: z.ZodNullable<z.ZodString>;
}, z.core.$strip>;
export declare const FlowNodeSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    payload: z.ZodObject<{
        attachments: z.ZodOptional<z.ZodArray<z.ZodObject<{
            cid: z.ZodString;
            content: z.ZodString;
            contentType: z.ZodOptional<z.ZodString>;
            filename: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>>;
        bcc: z.ZodOptional<z.ZodArray<z.ZodString>>;
        body: z.ZodString;
        cc: z.ZodOptional<z.ZodArray<z.ZodString>>;
        fromName: z.ZodOptional<z.ZodString>;
        providerSlug: z.ZodOptional<z.ZodString>;
        replyTo: z.ZodOptional<z.ZodString>;
        subject: z.ZodString;
        text: z.ZodOptional<z.ZodString>;
        to: z.ZodString;
    }, z.core.$strict>;
    type: z.ZodLiteral<"sendEmail">;
    id: z.ZodString;
    nextNodeId: z.ZodNullable<z.ZodString>;
}, z.core.$strip>, z.ZodObject<{
    payload: z.ZodObject<{
        body: z.ZodString;
        to: z.ZodString;
    }, z.core.$strip>;
    type: z.ZodLiteral<"sendSms">;
    id: z.ZodString;
    nextNodeId: z.ZodNullable<z.ZodString>;
}, z.core.$strip>, z.ZodObject<{
    payload: z.ZodObject<{
        duration: z.ZodNumber;
    }, z.core.$strip>;
    type: z.ZodLiteral<"wait">;
    id: z.ZodString;
    nextNodeId: z.ZodNullable<z.ZodString>;
}, z.core.$strip>, z.ZodObject<{
    payload: z.ZodObject<{
        body: z.ZodOptional<z.ZodString>;
        headers: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
        method: z.ZodEnum<{
            DELETE: "DELETE";
            GET: "GET";
            PATCH: "PATCH";
            POST: "POST";
            PUT: "PUT";
        }>;
        url: z.ZodURL;
    }, z.core.$strip>;
    type: z.ZodLiteral<"http">;
    id: z.ZodString;
    nextNodeId: z.ZodNullable<z.ZodString>;
}, z.core.$strip>, z.ZodObject<{
    payload: z.ZodObject<{
        falseBranch: z.ZodNullable<z.ZodString>;
        logic: z.ZodString;
        trueBranch: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>;
    type: z.ZodLiteral<"condition">;
    id: z.ZodString;
    nextNodeId: z.ZodNullable<z.ZodString>;
}, z.core.$strip>, z.ZodObject<{
    payload: z.ZodObject<{
        maxTransitions: z.ZodDefault<z.ZodNumber>;
        nodeId: z.ZodString;
    }, z.core.$strip>;
    type: z.ZodLiteral<"bridge">;
    id: z.ZodString;
    nextNodeId: z.ZodNullable<z.ZodString>;
}, z.core.$strip>, z.ZodObject<{
    payload: z.ZodObject<{
        variables: z.ZodArray<z.ZodObject<{
            value: z.ZodString;
            variableName: z.ZodString;
        }, z.core.$strip>>;
    }, z.core.$strip>;
    type: z.ZodLiteral<"setVariable">;
    id: z.ZodString;
    nextNodeId: z.ZodNullable<z.ZodString>;
}, z.core.$strip>, z.ZodObject<{
    payload: z.ZodObject<{
        data: z.ZodString;
        repeatBranch: z.ZodString;
    }, z.core.$strip>;
    type: z.ZodLiteral<"repeater">;
    id: z.ZodString;
    nextNodeId: z.ZodNullable<z.ZodString>;
}, z.core.$strip>, z.ZodObject<{
    payload: z.ZodObject<{
        outputSchema: z.ZodOptional<z.ZodObject<{
            properties: z.ZodRecord<z.ZodString, z.ZodUnknown>;
        }, z.core.$strip>>;
        parameters: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
        query: z.ZodString;
    }, z.core.$strip>;
    type: z.ZodLiteral<"wql">;
    id: z.ZodString;
    nextNodeId: z.ZodNullable<z.ZodString>;
}, z.core.$strip>, z.ZodObject<{
    payload: z.ZodObject<{
        assignedTo: z.ZodOptional<z.ZodString>;
        description: z.ZodString;
        name: z.ZodString;
        schema: z.ZodAny;
    }, z.core.$strip>;
    type: z.ZodLiteral<"interaction">;
    id: z.ZodString;
    nextNodeId: z.ZodNullable<z.ZodString>;
}, z.core.$strip>], "type">;
export declare const TableFlowSchema: z.ZodObject<{
    metadata: z.ZodObject<{
        on: z.ZodEnum<{
            DELETE: "DELETE";
            INSERT: "INSERT";
            UPDATE: "UPDATE";
        }>;
        tableId: z.ZodString;
    }, z.core.$strip>;
    type: z.ZodLiteral<"table">;
}, z.core.$strip>;
export declare const ScheduleFlowSchema: z.ZodObject<{
    metadata: z.ZodObject<{
        cron: z.ZodString;
        end: z.ZodNullable<z.ZodString>;
        start: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>;
    type: z.ZodLiteral<"schedule">;
}, z.core.$strip>;
export declare const WebhookFlowSchema: z.ZodObject<{
    metadata: z.ZodObject<{
        headers: z.ZodRecord<z.ZodString, z.ZodString>;
        parameters: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
        withCredentials: z.ZodBoolean;
    }, z.core.$strip>;
    type: z.ZodLiteral<"webhook">;
}, z.core.$strip>;
export declare const StorageEventFlowSchema: z.ZodObject<{
    metadata: z.ZodObject<{
        type: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            download: "download";
            upload: "upload";
        }>>>;
    }, z.core.$strip>;
    type: z.ZodLiteral<"storageEvent">;
}, z.core.$strip>;
/**
 * Exported so external callers validate against the same union the flow
 * runners branch on, instead of re-deriving it and drifting.
 */
export declare const FlowTriggerSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    metadata: z.ZodObject<{
        on: z.ZodEnum<{
            DELETE: "DELETE";
            INSERT: "INSERT";
            UPDATE: "UPDATE";
        }>;
        tableId: z.ZodString;
    }, z.core.$strip>;
    type: z.ZodLiteral<"table">;
}, z.core.$strip>, z.ZodObject<{
    metadata: z.ZodObject<{
        cron: z.ZodString;
        end: z.ZodNullable<z.ZodString>;
        start: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>;
    type: z.ZodLiteral<"schedule">;
}, z.core.$strip>, z.ZodObject<{
    metadata: z.ZodObject<{
        headers: z.ZodRecord<z.ZodString, z.ZodString>;
        parameters: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
        withCredentials: z.ZodBoolean;
    }, z.core.$strip>;
    type: z.ZodLiteral<"webhook">;
}, z.core.$strip>, z.ZodObject<{
    metadata: z.ZodObject<{
        type: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            download: "download";
            upload: "upload";
        }>>>;
    }, z.core.$strip>;
    type: z.ZodLiteral<"storageEvent">;
}, z.core.$strip>], "type">;
export declare const FlowSchema: z.ZodObject<{
    _id: z.ZodString;
    createdAt: z.ZodString;
    description: z.ZodNullable<z.ZodString>;
    isActive: z.ZodBoolean;
    lock: z.ZodBoolean;
    name: z.ZodString;
    nodes: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        payload: z.ZodObject<{
            attachments: z.ZodOptional<z.ZodArray<z.ZodObject<{
                cid: z.ZodString;
                content: z.ZodString;
                contentType: z.ZodOptional<z.ZodString>;
                filename: z.ZodOptional<z.ZodString>;
            }, z.core.$strip>>>;
            bcc: z.ZodOptional<z.ZodArray<z.ZodString>>;
            body: z.ZodString;
            cc: z.ZodOptional<z.ZodArray<z.ZodString>>;
            fromName: z.ZodOptional<z.ZodString>;
            providerSlug: z.ZodOptional<z.ZodString>;
            replyTo: z.ZodOptional<z.ZodString>;
            subject: z.ZodString;
            text: z.ZodOptional<z.ZodString>;
            to: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"sendEmail">;
        id: z.ZodString;
        nextNodeId: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        payload: z.ZodObject<{
            body: z.ZodString;
            to: z.ZodString;
        }, z.core.$strip>;
        type: z.ZodLiteral<"sendSms">;
        id: z.ZodString;
        nextNodeId: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        payload: z.ZodObject<{
            duration: z.ZodNumber;
        }, z.core.$strip>;
        type: z.ZodLiteral<"wait">;
        id: z.ZodString;
        nextNodeId: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        payload: z.ZodObject<{
            body: z.ZodOptional<z.ZodString>;
            headers: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
            method: z.ZodEnum<{
                DELETE: "DELETE";
                GET: "GET";
                PATCH: "PATCH";
                POST: "POST";
                PUT: "PUT";
            }>;
            url: z.ZodURL;
        }, z.core.$strip>;
        type: z.ZodLiteral<"http">;
        id: z.ZodString;
        nextNodeId: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        payload: z.ZodObject<{
            falseBranch: z.ZodNullable<z.ZodString>;
            logic: z.ZodString;
            trueBranch: z.ZodNullable<z.ZodString>;
        }, z.core.$strip>;
        type: z.ZodLiteral<"condition">;
        id: z.ZodString;
        nextNodeId: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        payload: z.ZodObject<{
            maxTransitions: z.ZodDefault<z.ZodNumber>;
            nodeId: z.ZodString;
        }, z.core.$strip>;
        type: z.ZodLiteral<"bridge">;
        id: z.ZodString;
        nextNodeId: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        payload: z.ZodObject<{
            variables: z.ZodArray<z.ZodObject<{
                value: z.ZodString;
                variableName: z.ZodString;
            }, z.core.$strip>>;
        }, z.core.$strip>;
        type: z.ZodLiteral<"setVariable">;
        id: z.ZodString;
        nextNodeId: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        payload: z.ZodObject<{
            data: z.ZodString;
            repeatBranch: z.ZodString;
        }, z.core.$strip>;
        type: z.ZodLiteral<"repeater">;
        id: z.ZodString;
        nextNodeId: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        payload: z.ZodObject<{
            outputSchema: z.ZodOptional<z.ZodObject<{
                properties: z.ZodRecord<z.ZodString, z.ZodUnknown>;
            }, z.core.$strip>>;
            parameters: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
            query: z.ZodString;
        }, z.core.$strip>;
        type: z.ZodLiteral<"wql">;
        id: z.ZodString;
        nextNodeId: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        payload: z.ZodObject<{
            assignedTo: z.ZodOptional<z.ZodString>;
            description: z.ZodString;
            name: z.ZodString;
            schema: z.ZodAny;
        }, z.core.$strip>;
        type: z.ZodLiteral<"interaction">;
        id: z.ZodString;
        nextNodeId: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>], "type">>;
    startNodeId: z.ZodNullable<z.ZodString>;
    stateSchema: z.ZodOptional<z.ZodArray<z.ZodObject<{
        defaultValue: z.ZodOptional<z.ZodUnknown>;
        id: z.ZodString;
        name: z.ZodString;
        type: z.ZodEnum<{
            array: "array";
            boolean: "boolean";
            number: "number";
            object: "object";
            string: "string";
        }>;
    }, z.core.$strip>>>;
    trigger: z.ZodDiscriminatedUnion<[z.ZodObject<{
        metadata: z.ZodObject<{
            on: z.ZodEnum<{
                DELETE: "DELETE";
                INSERT: "INSERT";
                UPDATE: "UPDATE";
            }>;
            tableId: z.ZodString;
        }, z.core.$strip>;
        type: z.ZodLiteral<"table">;
    }, z.core.$strip>, z.ZodObject<{
        metadata: z.ZodObject<{
            cron: z.ZodString;
            end: z.ZodNullable<z.ZodString>;
            start: z.ZodNullable<z.ZodString>;
        }, z.core.$strip>;
        type: z.ZodLiteral<"schedule">;
    }, z.core.$strip>, z.ZodObject<{
        metadata: z.ZodObject<{
            headers: z.ZodRecord<z.ZodString, z.ZodString>;
            parameters: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
            withCredentials: z.ZodBoolean;
        }, z.core.$strip>;
        type: z.ZodLiteral<"webhook">;
    }, z.core.$strip>, z.ZodObject<{
        metadata: z.ZodObject<{
            type: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                download: "download";
                upload: "upload";
            }>>>;
        }, z.core.$strip>;
        type: z.ZodLiteral<"storageEvent">;
    }, z.core.$strip>], "type">;
    updatedAt: z.ZodString;
}, z.core.$strip>;
export declare const FlowCreateSchema: z.ZodObject<{
    description: z.ZodNullable<z.ZodString>;
    isActive: z.ZodBoolean;
    name: z.ZodString;
    nodes: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        payload: z.ZodObject<{
            attachments: z.ZodOptional<z.ZodArray<z.ZodObject<{
                cid: z.ZodString;
                content: z.ZodString;
                contentType: z.ZodOptional<z.ZodString>;
                filename: z.ZodOptional<z.ZodString>;
            }, z.core.$strip>>>;
            bcc: z.ZodOptional<z.ZodArray<z.ZodString>>;
            body: z.ZodString;
            cc: z.ZodOptional<z.ZodArray<z.ZodString>>;
            fromName: z.ZodOptional<z.ZodString>;
            providerSlug: z.ZodOptional<z.ZodString>;
            replyTo: z.ZodOptional<z.ZodString>;
            subject: z.ZodString;
            text: z.ZodOptional<z.ZodString>;
            to: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"sendEmail">;
        id: z.ZodString;
        nextNodeId: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        payload: z.ZodObject<{
            body: z.ZodString;
            to: z.ZodString;
        }, z.core.$strip>;
        type: z.ZodLiteral<"sendSms">;
        id: z.ZodString;
        nextNodeId: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        payload: z.ZodObject<{
            duration: z.ZodNumber;
        }, z.core.$strip>;
        type: z.ZodLiteral<"wait">;
        id: z.ZodString;
        nextNodeId: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        payload: z.ZodObject<{
            body: z.ZodOptional<z.ZodString>;
            headers: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
            method: z.ZodEnum<{
                DELETE: "DELETE";
                GET: "GET";
                PATCH: "PATCH";
                POST: "POST";
                PUT: "PUT";
            }>;
            url: z.ZodURL;
        }, z.core.$strip>;
        type: z.ZodLiteral<"http">;
        id: z.ZodString;
        nextNodeId: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        payload: z.ZodObject<{
            falseBranch: z.ZodNullable<z.ZodString>;
            logic: z.ZodString;
            trueBranch: z.ZodNullable<z.ZodString>;
        }, z.core.$strip>;
        type: z.ZodLiteral<"condition">;
        id: z.ZodString;
        nextNodeId: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        payload: z.ZodObject<{
            maxTransitions: z.ZodDefault<z.ZodNumber>;
            nodeId: z.ZodString;
        }, z.core.$strip>;
        type: z.ZodLiteral<"bridge">;
        id: z.ZodString;
        nextNodeId: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        payload: z.ZodObject<{
            variables: z.ZodArray<z.ZodObject<{
                value: z.ZodString;
                variableName: z.ZodString;
            }, z.core.$strip>>;
        }, z.core.$strip>;
        type: z.ZodLiteral<"setVariable">;
        id: z.ZodString;
        nextNodeId: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        payload: z.ZodObject<{
            data: z.ZodString;
            repeatBranch: z.ZodString;
        }, z.core.$strip>;
        type: z.ZodLiteral<"repeater">;
        id: z.ZodString;
        nextNodeId: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        payload: z.ZodObject<{
            outputSchema: z.ZodOptional<z.ZodObject<{
                properties: z.ZodRecord<z.ZodString, z.ZodUnknown>;
            }, z.core.$strip>>;
            parameters: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
            query: z.ZodString;
        }, z.core.$strip>;
        type: z.ZodLiteral<"wql">;
        id: z.ZodString;
        nextNodeId: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        payload: z.ZodObject<{
            assignedTo: z.ZodOptional<z.ZodString>;
            description: z.ZodString;
            name: z.ZodString;
            schema: z.ZodAny;
        }, z.core.$strip>;
        type: z.ZodLiteral<"interaction">;
        id: z.ZodString;
        nextNodeId: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>], "type">>;
    startNodeId: z.ZodNullable<z.ZodString>;
    stateSchema: z.ZodOptional<z.ZodArray<z.ZodObject<{
        defaultValue: z.ZodOptional<z.ZodUnknown>;
        id: z.ZodString;
        name: z.ZodString;
        type: z.ZodEnum<{
            array: "array";
            boolean: "boolean";
            number: "number";
            object: "object";
            string: "string";
        }>;
    }, z.core.$strip>>>;
    trigger: z.ZodDiscriminatedUnion<[z.ZodObject<{
        metadata: z.ZodObject<{
            on: z.ZodEnum<{
                DELETE: "DELETE";
                INSERT: "INSERT";
                UPDATE: "UPDATE";
            }>;
            tableId: z.ZodString;
        }, z.core.$strip>;
        type: z.ZodLiteral<"table">;
    }, z.core.$strip>, z.ZodObject<{
        metadata: z.ZodObject<{
            cron: z.ZodString;
            end: z.ZodNullable<z.ZodString>;
            start: z.ZodNullable<z.ZodString>;
        }, z.core.$strip>;
        type: z.ZodLiteral<"schedule">;
    }, z.core.$strip>, z.ZodObject<{
        metadata: z.ZodObject<{
            headers: z.ZodRecord<z.ZodString, z.ZodString>;
            parameters: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
            withCredentials: z.ZodBoolean;
        }, z.core.$strip>;
        type: z.ZodLiteral<"webhook">;
    }, z.core.$strip>, z.ZodObject<{
        metadata: z.ZodObject<{
            type: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                download: "download";
                upload: "upload";
            }>>>;
        }, z.core.$strip>;
        type: z.ZodLiteral<"storageEvent">;
    }, z.core.$strip>], "type">;
}, z.core.$strip>;
/**
 * Derived from the create schema so a node payload obeys one rule however it
 * is saved. `strict`, unlike create: an unknown key is refused rather than
 * stripped, which is what keeps `lock` reaching the refusal that explains it.
 */
export declare const FlowUpdateSchema: z.ZodObject<{
    description: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    isActive: z.ZodOptional<z.ZodBoolean>;
    name: z.ZodOptional<z.ZodString>;
    nodes: z.ZodOptional<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        payload: z.ZodObject<{
            attachments: z.ZodOptional<z.ZodArray<z.ZodObject<{
                cid: z.ZodString;
                content: z.ZodString;
                contentType: z.ZodOptional<z.ZodString>;
                filename: z.ZodOptional<z.ZodString>;
            }, z.core.$strip>>>;
            bcc: z.ZodOptional<z.ZodArray<z.ZodString>>;
            body: z.ZodString;
            cc: z.ZodOptional<z.ZodArray<z.ZodString>>;
            fromName: z.ZodOptional<z.ZodString>;
            providerSlug: z.ZodOptional<z.ZodString>;
            replyTo: z.ZodOptional<z.ZodString>;
            subject: z.ZodString;
            text: z.ZodOptional<z.ZodString>;
            to: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodLiteral<"sendEmail">;
        id: z.ZodString;
        nextNodeId: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        payload: z.ZodObject<{
            body: z.ZodString;
            to: z.ZodString;
        }, z.core.$strip>;
        type: z.ZodLiteral<"sendSms">;
        id: z.ZodString;
        nextNodeId: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        payload: z.ZodObject<{
            duration: z.ZodNumber;
        }, z.core.$strip>;
        type: z.ZodLiteral<"wait">;
        id: z.ZodString;
        nextNodeId: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        payload: z.ZodObject<{
            body: z.ZodOptional<z.ZodString>;
            headers: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
            method: z.ZodEnum<{
                DELETE: "DELETE";
                GET: "GET";
                PATCH: "PATCH";
                POST: "POST";
                PUT: "PUT";
            }>;
            url: z.ZodURL;
        }, z.core.$strip>;
        type: z.ZodLiteral<"http">;
        id: z.ZodString;
        nextNodeId: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        payload: z.ZodObject<{
            falseBranch: z.ZodNullable<z.ZodString>;
            logic: z.ZodString;
            trueBranch: z.ZodNullable<z.ZodString>;
        }, z.core.$strip>;
        type: z.ZodLiteral<"condition">;
        id: z.ZodString;
        nextNodeId: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        payload: z.ZodObject<{
            maxTransitions: z.ZodDefault<z.ZodNumber>;
            nodeId: z.ZodString;
        }, z.core.$strip>;
        type: z.ZodLiteral<"bridge">;
        id: z.ZodString;
        nextNodeId: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        payload: z.ZodObject<{
            variables: z.ZodArray<z.ZodObject<{
                value: z.ZodString;
                variableName: z.ZodString;
            }, z.core.$strip>>;
        }, z.core.$strip>;
        type: z.ZodLiteral<"setVariable">;
        id: z.ZodString;
        nextNodeId: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        payload: z.ZodObject<{
            data: z.ZodString;
            repeatBranch: z.ZodString;
        }, z.core.$strip>;
        type: z.ZodLiteral<"repeater">;
        id: z.ZodString;
        nextNodeId: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        payload: z.ZodObject<{
            outputSchema: z.ZodOptional<z.ZodObject<{
                properties: z.ZodRecord<z.ZodString, z.ZodUnknown>;
            }, z.core.$strip>>;
            parameters: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
            query: z.ZodString;
        }, z.core.$strip>;
        type: z.ZodLiteral<"wql">;
        id: z.ZodString;
        nextNodeId: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>, z.ZodObject<{
        payload: z.ZodObject<{
            assignedTo: z.ZodOptional<z.ZodString>;
            description: z.ZodString;
            name: z.ZodString;
            schema: z.ZodAny;
        }, z.core.$strip>;
        type: z.ZodLiteral<"interaction">;
        id: z.ZodString;
        nextNodeId: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>], "type">>>;
    startNodeId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    stateSchema: z.ZodOptional<z.ZodOptional<z.ZodArray<z.ZodObject<{
        defaultValue: z.ZodOptional<z.ZodUnknown>;
        id: z.ZodString;
        name: z.ZodString;
        type: z.ZodEnum<{
            array: "array";
            boolean: "boolean";
            number: "number";
            object: "object";
            string: "string";
        }>;
    }, z.core.$strip>>>>;
    trigger: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
        metadata: z.ZodObject<{
            on: z.ZodEnum<{
                DELETE: "DELETE";
                INSERT: "INSERT";
                UPDATE: "UPDATE";
            }>;
            tableId: z.ZodString;
        }, z.core.$strip>;
        type: z.ZodLiteral<"table">;
    }, z.core.$strip>, z.ZodObject<{
        metadata: z.ZodObject<{
            cron: z.ZodString;
            end: z.ZodNullable<z.ZodString>;
            start: z.ZodNullable<z.ZodString>;
        }, z.core.$strip>;
        type: z.ZodLiteral<"schedule">;
    }, z.core.$strip>, z.ZodObject<{
        metadata: z.ZodObject<{
            headers: z.ZodRecord<z.ZodString, z.ZodString>;
            parameters: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
            withCredentials: z.ZodBoolean;
        }, z.core.$strip>;
        type: z.ZodLiteral<"webhook">;
    }, z.core.$strip>, z.ZodObject<{
        metadata: z.ZodObject<{
            type: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
                download: "download";
                upload: "upload";
            }>>>;
        }, z.core.$strip>;
        type: z.ZodLiteral<"storageEvent">;
    }, z.core.$strip>], "type">>;
}, z.core.$strict>;
export type TFlow = z.infer<typeof FlowSchema>;
export type TFlowNode = z.infer<typeof FlowNodeSchema>;
export type TFlowNodeType = TFlowNode['type'];
export type TFlowTrigger = z.infer<typeof FlowTriggerSchema>;
export type TTableFlow = z.infer<typeof TableFlowSchema>;
export type TScheduleFlow = z.infer<typeof ScheduleFlowSchema>;
export type TWebhookFlow = z.infer<typeof WebhookFlowSchema>;
export type TStorageEventFlow = z.infer<typeof StorageEventFlowSchema>;
export type TFlowSendEmailNode = z.infer<typeof FlowSendEmailNodeSchema>;
export type TFlowSendSmsNode = z.infer<typeof FlowSendSmsNodeSchema>;
export type TFlowBridgeNode = z.infer<typeof FlowBridgeNodeSchema>;
export type TFlowWaitNode = z.infer<typeof FlowWaitNodeSchema>;
export type TFlowHttpNode = z.infer<typeof FlowHttpNodeSchema>;
export type TFlowConditionNode = z.infer<typeof FlowConditionNodeSchema>;
export type TFlowSetVariableNode = z.infer<typeof FlowSetVariableNodeSchema>;
export type TFlowRepeaterNode = z.infer<typeof FlowRepeaterNodeSchema>;
export type TFlowWqlNode = z.infer<typeof FlowWqlNodeSchema>;
export type TFlowInteractionNode = z.infer<typeof FlowInteractionNodeSchema>;
export type TFlowCreate = z.infer<typeof FlowCreateSchema>;
export type TFlowUpdate = z.infer<typeof FlowUpdateSchema>;
export {};
