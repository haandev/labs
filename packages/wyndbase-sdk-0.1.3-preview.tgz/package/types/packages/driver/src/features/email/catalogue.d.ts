/** One value a message body may interpolate. */
export type EmailVariable = {
    name: string;
    description: string;
    /** Rendered in the settings screen's preview, so it must read like a real value. */
    example: string;
    /** True when the value can legitimately be absent at send time. */
    optional?: boolean;
    /** Rendered in place of an absent value. Required whenever `optional`. */
    fallback?: string;
};
export type EmailMessage = {
    id: EmailMessageId;
    displayName: string;
    /** One sentence, shown beside the editor: when this message is sent. */
    trigger: string;
    subject: string;
    /** An HTML fragment. The outer frame is the product's, not the template's. */
    body: string;
    variables: readonly EmailVariable[];
};
export type EmailMessageId = 'account.email_confirm' | 'account.password_enroll' | 'account.registration_exists' | 'account.password_changed' | 'account.email_removed' | 'alert.fired' | 'alert.resolved' | 'auth.recovery_used' | 'auth.recovery_regenerated' | 'auth.step_up_completed' | 'auth.federated_linked' | 'auth.factor_enrolled' | 'auth.factor_removed' | 'webauthn.counter_regression' | 'session.refresh_reuse_detected' | 'session.fingerprint_anomaly' | 'session.revoked_all';
/**
 * Supplied by the delivery layer for every message, so no call site passes
 * them and no message may redeclare one.
 */
export declare const COMMON_VARIABLES: readonly EmailVariable[];
export declare const EMAIL_MESSAGES: readonly EmailMessage[];
export declare function emailMessage(id: string): EmailMessage | undefined;
export declare function isEmailMessageId(id: string): id is EmailMessageId;
/**
 * Common first: the settings screen lists them in this order, and a message
 * may not redeclare one, so the concatenation cannot collide.
 */
export declare function variablesFor(id: string): readonly EmailVariable[];
