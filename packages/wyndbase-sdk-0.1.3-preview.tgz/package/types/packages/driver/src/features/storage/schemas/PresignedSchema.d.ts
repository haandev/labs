import { z } from 'zod';
export declare const MultipartInitiateInputSchema: z.ZodObject<{
    bucket: z.ZodString;
    contentType: z.ZodOptional<z.ZodString>;
    key: z.ZodString;
}, z.core.$strip>;
export type TMultipartInitiateInput = z.infer<typeof MultipartInitiateInputSchema>;
export declare const MultipartInitiateResponseSchema: z.ZodObject<{
    bucket: z.ZodString;
    key: z.ZodString;
    uploadId: z.ZodString;
}, z.core.$strip>;
export type TMultipartInitiateResponse = z.infer<typeof MultipartInitiateResponseSchema>;
export declare const PresignPartInputSchema: z.ZodObject<{
    bucket: z.ZodString;
    expiresIn: z.ZodOptional<z.ZodNumber>;
    key: z.ZodString;
    partNumber: z.ZodNumber;
    uploadId: z.ZodString;
}, z.core.$strip>;
export type TPresignPartInput = z.infer<typeof PresignPartInputSchema>;
export declare const PresignedUrlResponseSchema: z.ZodObject<{
    expiresAt: z.ZodCodec<z.ZodUnion<readonly [z.ZodISODateTime, z.ZodISODateTime, z.ZodDate]>, z.ZodUnion<readonly [z.ZodISODateTime, z.ZodISODateTime]>>;
    url: z.ZodString;
}, z.core.$strip>;
export type TPresignedUrlResponse = z.infer<typeof PresignedUrlResponseSchema>;
export declare const MultipartPartSchema: z.ZodObject<{
    etag: z.ZodString;
    partNumber: z.ZodNumber;
}, z.core.$strip>;
export type TMultipartPart = z.infer<typeof MultipartPartSchema>;
export declare const MultipartCompleteInputSchema: z.ZodObject<{
    bucket: z.ZodString;
    key: z.ZodString;
    parts: z.ZodArray<z.ZodObject<{
        etag: z.ZodString;
        partNumber: z.ZodNumber;
    }, z.core.$strip>>;
    uploadId: z.ZodString;
}, z.core.$strip>;
export type TMultipartCompleteInput = z.infer<typeof MultipartCompleteInputSchema>;
export declare const MultipartCompleteResponseSchema: z.ZodObject<{
    bucket: z.ZodString;
    contentType: z.ZodNullable<z.ZodString>;
    etag: z.ZodString;
    key: z.ZodString;
    lastModified: z.ZodCodec<z.ZodUnion<readonly [z.ZodISODateTime, z.ZodISODateTime, z.ZodDate]>, z.ZodUnion<readonly [z.ZodISODateTime, z.ZodISODateTime]>>;
    size: z.ZodNumber;
}, z.core.$strip>;
export type TMultipartCompleteResponse = z.infer<typeof MultipartCompleteResponseSchema>;
export declare const MultipartAbortInputSchema: z.ZodObject<{
    bucket: z.ZodString;
    key: z.ZodString;
    uploadId: z.ZodString;
}, z.core.$strip>;
export type TMultipartAbortInput = z.infer<typeof MultipartAbortInputSchema>;
export declare const MultipartAbortResponseSchema: z.ZodObject<{
    message: z.ZodString;
}, z.core.$strip>;
export type TMultipartAbortResponse = z.infer<typeof MultipartAbortResponseSchema>;
export declare const PresignedUrlInputSchema: z.ZodObject<{
    bucket: z.ZodString;
    contentType: z.ZodOptional<z.ZodString>;
    expiresIn: z.ZodOptional<z.ZodNumber>;
    key: z.ZodString;
    method: z.ZodEnum<{
        DELETE: "DELETE";
        GET: "GET";
        PUT: "PUT";
    }>;
    versionId: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
export type TPresignedUrlInput = z.infer<typeof PresignedUrlInputSchema>;
