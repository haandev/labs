import type { WynConnectionHandler } from '../../WynConnectionHandler';
export type LinkDeleteImpact = {
    junction?: {
        tableId: string;
        name: string;
        rowCount: number;
    };
    mirror?: {
        columnId: string;
        name: string;
        tableName: string;
    };
};
/**
 * What a link column's delete takes with it: the paired mirror column on the
 * target table, and the junction table when nothing else references it.
 * Resolution never throws — a missing counterpart or dangling metadata (a
 * pre-fix orphan) simply yields no entry.
 */
export declare function getLinkColumnDeleteImpact(base: WynConnectionHandler, columnId: string): Promise<LinkDeleteImpact>;
