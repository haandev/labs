import type { WynConnectionHandler } from '../../WynConnectionHandler';
interface CreateRemoteBucketInput {
    name: string;
    endpoint: string;
    accessKey: string;
    secretKey: string;
    region?: string;
    forcePathStyle?: boolean;
}
export declare class BucketService {
    private base;
    constructor(base: WynConnectionHandler);
    create(name: string): Promise<{
        _id: string;
        name: string;
        creationDate: string;
        versioning: (string | null);
        type: string;
        endpoint: (string | null);
        accessKey: (string | null);
        secretKey: string;
        region: (string | null);
        forcePathStyle: (boolean | null);
        createdAt: string;
        updatedAt: string;
        createdBy: (string | null);
        updatedBy: (string | null);
    } & Record<any, unknown>>;
    connect(input: CreateRemoteBucketInput): Promise<{
        _id: string;
        name: string;
        endpoint: (string | null);
        accessKey: (string | null);
        region: (string | null);
        forcePathStyle: (boolean | null);
    } & Record<any, unknown>>;
    /**
     * One attempt, not the SDK's default three: the user is waiting on the
     * form, and a refusal here is about their input, not a transient blip.
     */
    private probeRemote;
    delete(id: string): Promise<void>;
    list(): Promise<import("../../../../wql/src/index").WqlRows<{
        _id: string;
        name: string;
        versioning: (string | null);
        type: string;
        endpoint: (string | null);
        accessKey: (string | null);
        region: (string | null);
        forcePathStyle: (boolean | null);
    } & Record<any, unknown>, import("../../../../wql/src/index").WQLOptions<boolean, boolean, boolean, import("../../../../wql/src/index").WQLExecutionMode> & {
        raw?: boolean;
        model?: import("../../../../wql/src/index").WynModel | import("../../../../wql/src/index").WynModelTree;
        skipRealtimeInvalidation?: boolean;
        skipPolyDisplay?: boolean;
    }>>;
    findById(id: string): Promise<({
        _id: string;
        name: string;
        creationDate: string;
        versioning: (string | null);
        type: string;
        endpoint: (string | null);
        accessKey: (string | null);
        region: (string | null);
        forcePathStyle: (boolean | null);
        secretKey: (string | null);
    } & Record<any, unknown>) | null>;
    /**
     * `findById` decrypts `secretKey` for server-side use; this strips it so
     * the secret never reaches the FE.
     */
    findByIdForClient(id: string): Promise<{
        _id: string;
        accessKey: string | null;
        creationDate: string;
        endpoint: string | null;
        forcePathStyle: boolean | null;
        name: string;
        region: string | null;
        type: string;
        versioning: string | null;
    } | null>;
}
export {};
