import { isMainBase } from '../../../../shared/src/main-base';
/** True when `ref` is the maintenance ("wyndbase") base, by uuid or by name. */
export { isMainBase };
/**
 * Sentinel userId for an anonymous request; must match the literal used in
 * `WynConnectionHandler.sessionActor()` and `base-context.plugin.ts` exactly.
 */
export declare const ANONYMOUS_USER_ID = "00000000-0000-7000-8000-000000000000";
/**
 * Inputs for `browseUserMode`. An object, not positionals — two of the four
 * are booleans, and the call site is where a security-relevant mix-up would happen.
 */
export type BrowseModeInput = {
    targetBaseId: string;
    /** `''` when there is no token — distinct from `anonymous`, which is what decides that case. */
    callerHomeBaseId: string;
    targetImmutable: boolean;
    anonymous: boolean;
    /** Whether the caller holds the admin role in the target base. Only read by
     *  the main-base exemption below; every other branch ignores it. */
    /** Whether the caller holds the admin role in THEIR HOME base — for a
     *  main-base caller, admin of the platform. A tenant base's own admins
     *  never reach this flag: every tenant-home caller is policied outright. */
    callerIsAdmin: boolean;
};
/** Decide whether a plain (no-act-as) browse request runs with policy injection (`user: true`). */
export declare function browseUserMode(input: BrowseModeInput): boolean;
