import type { WynConnectionHandler } from '../../WynConnectionHandler';
import type { EmailProviderSpec, ProviderSecret } from './providers';
export type ResolvedProvider = {
    slug: string;
    spec: EmailProviderSpec;
    secret: ProviderSecret;
    from: {
        email: string;
        name: string | null;
    };
    replyTo: string | null;
};
/** Why a base could not produce a sender. Distinct reasons, because an
 *  administrator fixes each of them somewhere different. */
export type ProviderUnavailableReason = 'no-default' | 'unknown-slug' | 'inactive' | 'unknown-type';
export declare class EmailProviderUnavailableError extends Error {
    readonly reason: ProviderUnavailableReason;
    constructor(reason: ProviderUnavailableReason, detail: string);
}
/**
 * The one place a slug becomes a sender. Resolved per attempt rather than
 * snapshotted at enqueue time, so no credential is ever written to the job
 * queue and a rotated one takes effect on the backlog. An empty-string slug
 * is treated the same as an omitted one — a flow step's empty provider field
 * means "use the base default".
 */
export declare function resolveProvider(base: WynConnectionHandler, slug?: string | null): Promise<ResolvedProvider>;
