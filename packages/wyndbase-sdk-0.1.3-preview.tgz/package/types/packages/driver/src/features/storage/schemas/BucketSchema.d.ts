import { z } from 'zod';
export { CreateBucketInputSchema, type TCreateBucketInput, } from '../../../../../shared/src/bucket-input';
export declare const BucketTypeSchema: z.ZodEnum<{
    local: "local";
    remote: "remote";
}>;
export type TBucketType = z.infer<typeof BucketTypeSchema>;
export declare const BucketPolicySchema: z.ZodObject<{
    allowedMimeTypes: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodString>>>;
    expirationDays: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    maxObjectSize: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    visibility: z.ZodOptional<z.ZodEnum<{
        private: "private";
        public: "public";
    }>>;
}, z.core.$strip>;
export type TBucketPolicy = z.infer<typeof BucketPolicySchema>;
export declare const BucketInfoSchema: z.ZodObject<{
    createdAt: z.ZodString;
    endpoint: z.ZodOptional<z.ZodString>;
    name: z.ZodString;
    policy: z.ZodOptional<z.ZodObject<{
        allowedMimeTypes: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodString>>>;
        expirationDays: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        maxObjectSize: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        visibility: z.ZodOptional<z.ZodEnum<{
            private: "private";
            public: "public";
        }>>;
    }, z.core.$strip>>;
    region: z.ZodOptional<z.ZodString>;
    type: z.ZodOptional<z.ZodEnum<{
        local: "local";
        remote: "remote";
    }>>;
    versioningStatus: z.ZodOptional<z.ZodEnum<{
        Disabled: "Disabled";
        Enabled: "Enabled";
        Suspended: "Suspended";
    }>>;
}, z.core.$strip>;
export type TBucketInfo = z.infer<typeof BucketInfoSchema>;
export declare const ConnectRemoteBucketInputSchema: z.ZodObject<{
    accessKey: z.ZodString;
    endpoint: z.ZodURL;
    forcePathStyle: z.ZodOptional<z.ZodBoolean>;
    name: z.ZodString;
    region: z.ZodOptional<z.ZodString>;
    secretKey: z.ZodString;
}, z.core.$strip>;
export declare const ObjectInfoSchema: z.ZodObject<{
    bucket: z.ZodString;
    contentType: z.ZodString;
    etag: z.ZodString;
    key: z.ZodString;
    lastModified: z.ZodCodec<z.ZodUnion<readonly [z.ZodISODateTime, z.ZodISODateTime, z.ZodDate]>, z.ZodUnion<readonly [z.ZodISODateTime, z.ZodISODateTime]>>;
    presignedUrl: z.ZodOptional<z.ZodURL>;
    size: z.ZodNumber;
}, z.core.$strip>;
export type TObjectInfo = z.infer<typeof ObjectInfoSchema>;
export declare const StorageListResponseSchema: z.ZodObject<{
    folders: z.ZodArray<z.ZodString>;
    objects: z.ZodArray<z.ZodObject<{
        bucket: z.ZodString;
        contentType: z.ZodString;
        etag: z.ZodString;
        key: z.ZodString;
        lastModified: z.ZodCodec<z.ZodUnion<readonly [z.ZodISODateTime, z.ZodISODateTime, z.ZodDate]>, z.ZodUnion<readonly [z.ZodISODateTime, z.ZodISODateTime]>>;
        presignedUrl: z.ZodOptional<z.ZodURL>;
        size: z.ZodNumber;
    }, z.core.$strip>>;
}, z.core.$strip>;
export type TStorageListResponse = z.infer<typeof StorageListResponseSchema>;
export declare const BulkDeleteRefusalSchema: z.ZodObject<{
    key: z.ZodString;
    reason: z.ZodString;
}, z.core.$strip>;
/**
 * Deleted objects are counted, not listed, to avoid echoing thousands of
 * keys back. Refusals are listed since the caller needs to know which failed.
 */
export declare const BulkDeleteResultSchema: z.ZodObject<{
    deleted: z.ZodNumber;
    refused: z.ZodArray<z.ZodObject<{
        key: z.ZodString;
        reason: z.ZodString;
    }, z.core.$strip>>;
}, z.core.$strip>;
export type TBulkDeleteResult = z.infer<typeof BulkDeleteResultSchema>;
export type TBulkDeleteTargets = {
    keys?: string[];
    prefixes?: string[];
};
export declare const ObjectVersionInfoSchema: z.ZodObject<{
    contentType: z.ZodString;
    etag: z.ZodString;
    isLatest: z.ZodBoolean;
    lastModified: z.ZodCodec<z.ZodUnion<readonly [z.ZodISODateTime, z.ZodISODateTime, z.ZodDate]>, z.ZodUnion<readonly [z.ZodISODateTime, z.ZodISODateTime]>>;
    size: z.ZodNumber;
    versionId: z.ZodString;
}, z.core.$strip>;
export type TObjectVersionInfo = z.infer<typeof ObjectVersionInfoSchema>;
export declare const DeleteMarkerSchema: z.ZodObject<{
    isLatest: z.ZodBoolean;
    key: z.ZodString;
    lastModified: z.ZodCodec<z.ZodUnion<readonly [z.ZodISODateTime, z.ZodISODateTime, z.ZodDate]>, z.ZodUnion<readonly [z.ZodISODateTime, z.ZodISODateTime]>>;
    versionId: z.ZodString;
}, z.core.$strip>;
export type TDeleteMarker = z.infer<typeof DeleteMarkerSchema>;
export declare const ObjectVersionsResultSchema: z.ZodObject<{
    deleteMarkers: z.ZodArray<z.ZodObject<{
        isLatest: z.ZodBoolean;
        key: z.ZodString;
        lastModified: z.ZodCodec<z.ZodUnion<readonly [z.ZodISODateTime, z.ZodISODateTime, z.ZodDate]>, z.ZodUnion<readonly [z.ZodISODateTime, z.ZodISODateTime]>>;
        versionId: z.ZodString;
    }, z.core.$strip>>;
    versions: z.ZodArray<z.ZodObject<{
        contentType: z.ZodString;
        etag: z.ZodString;
        isLatest: z.ZodBoolean;
        lastModified: z.ZodCodec<z.ZodUnion<readonly [z.ZodISODateTime, z.ZodISODateTime, z.ZodDate]>, z.ZodUnion<readonly [z.ZodISODateTime, z.ZodISODateTime]>>;
        size: z.ZodNumber;
        versionId: z.ZodString;
    }, z.core.$strip>>;
}, z.core.$strip>;
export type TObjectVersionsResult = z.infer<typeof ObjectVersionsResultSchema>;
export declare const ListObjectsQuerySchema: z.ZodObject<{
    bucket: z.ZodString;
    limit: z.ZodOptional<z.ZodNumber>;
    prefix: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
export type TListObjectsQuery = z.input<typeof ListObjectsQuerySchema>;
export declare const ListObjectVersionsQuerySchema: z.ZodObject<{
    bucket: z.ZodString;
    key: z.ZodString;
    limit: z.ZodOptional<z.ZodNumber>;
}, z.core.$strip>;
export type TListObjectVersionsQuery = z.input<typeof ListObjectVersionsQuerySchema>;
export declare const ListObjectsResultSchema: z.ZodObject<{
    data: z.ZodArray<z.ZodObject<{
        bucket: z.ZodString;
        contentType: z.ZodString;
        etag: z.ZodString;
        key: z.ZodString;
        lastModified: z.ZodCodec<z.ZodUnion<readonly [z.ZodISODateTime, z.ZodISODateTime, z.ZodDate]>, z.ZodUnion<readonly [z.ZodISODateTime, z.ZodISODateTime]>>;
        presignedUrl: z.ZodOptional<z.ZodURL>;
        size: z.ZodNumber;
    }, z.core.$strip>>;
    isTruncated: z.ZodOptional<z.ZodBoolean>;
    nextMarker: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
export type TListObjectsResult = z.infer<typeof ListObjectsResultSchema>;
export declare const BucketDtoSchema: z.ZodObject<{
    createdAt: z.ZodCodec<z.ZodUnion<readonly [z.ZodISODateTime, z.ZodISODateTime, z.ZodDate]>, z.ZodUnion<readonly [z.ZodISODateTime, z.ZodISODateTime]>>;
    name: z.ZodString;
    policy: z.ZodOptional<z.ZodObject<{
        allowedMimeTypes: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodString>>>;
        expirationDays: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        maxObjectSize: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        visibility: z.ZodOptional<z.ZodEnum<{
            private: "private";
            public: "public";
        }>>;
    }, z.core.$strip>>;
    region: z.ZodOptional<z.ZodString>;
    type: z.ZodOptional<z.ZodEnum<{
        local: "local";
        remote: "remote";
    }>>;
    versioningStatus: z.ZodOptional<z.ZodEnum<{
        Disabled: "Disabled";
        Enabled: "Enabled";
        Suspended: "Suspended";
    }>>;
}, z.core.$strip>;
export type TBucketDto = z.infer<typeof BucketDtoSchema>;
export declare const UpdatePolicyResponseSchema: z.ZodObject<{
    name: z.ZodString;
    policy: z.ZodOptional<z.ZodObject<{
        allowedMimeTypes: z.ZodOptional<z.ZodNullable<z.ZodArray<z.ZodString>>>;
        expirationDays: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        maxObjectSize: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        visibility: z.ZodOptional<z.ZodEnum<{
            private: "private";
            public: "public";
        }>>;
    }, z.core.$strip>>;
}, z.core.$strip>;
export type TUpdatePolicyResponse = z.infer<typeof UpdatePolicyResponseSchema>;
export declare const UpdateVersioningResponseSchema: z.ZodObject<{
    name: z.ZodString;
    versioningStatus: z.ZodEnum<{
        Enabled: "Enabled";
        Suspended: "Suspended";
    }>;
}, z.core.$strip>;
export type TUpdateVersioningResponse = z.infer<typeof UpdateVersioningResponseSchema>;
export declare const MessageResponseSchema: z.ZodObject<{
    message: z.ZodString;
}, z.core.$strip>;
export type TMessageResponse = z.infer<typeof MessageResponseSchema>;
