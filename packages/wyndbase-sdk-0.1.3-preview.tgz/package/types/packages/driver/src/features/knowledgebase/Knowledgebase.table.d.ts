export declare const KNOWLEDGEBASE_TABLE = "knowledgebase";
export default _default;
declare function _default(): {
    children: ({
        displayName: string;
        isSystem: boolean;
        metadata: {
            defaultValue?: undefined;
            onDelete?: undefined;
            targetTables?: undefined;
            allowFilter: boolean;
            allowSearch: boolean;
            notNull: boolean;
            type: string;
            mirrorColumns?: undefined;
            bucket?: undefined;
        };
        name: string;
        type: 'column';
    } | {
        displayName: string;
        isSystem: boolean;
        metadata: {
            defaultValue?: undefined;
            onDelete?: undefined;
            targetTables?: undefined;
            allowFilter: boolean;
            notNull: boolean;
            type: string;
            mirrorColumns?: undefined;
            allowSearch?: undefined;
            bucket?: undefined;
        };
        name: string;
        type: 'column';
    } | {
        displayName: string;
        isSystem: boolean;
        metadata: {
            defaultValue?: undefined;
            notNull?: undefined;
            allowFilter: boolean;
            mirrorColumns: {
                canHaveMultiple: boolean;
                name: string;
                table: string;
            }[];
            onDelete: string;
            targetTables: {
                table: string;
            }[];
            type: string;
            allowSearch?: undefined;
            bucket?: undefined;
        };
        name: string;
        type: 'column';
    } | {
        displayName: string;
        isSystem: boolean;
        metadata: {
            onDelete?: undefined;
            targetTables?: undefined;
            mirrorColumns?: undefined;
            allowFilter: boolean;
            defaultValue: number;
            notNull: boolean;
            type: string;
            allowSearch?: undefined;
            bucket?: undefined;
        };
        name: string;
        type: 'column';
    } | {
        displayName: string;
        isSystem: boolean;
        metadata: {
            allowFilter?: undefined;
            defaultValue?: undefined;
            notNull?: undefined;
            onDelete?: undefined;
            targetTables?: undefined;
            mirrorColumns?: undefined;
            type: string;
            allowSearch?: undefined;
            bucket?: undefined;
        };
        name: string;
        type: 'column';
    } | {
        displayName: string;
        isSystem: boolean;
        metadata: {
            allowFilter?: undefined;
            defaultValue?: undefined;
            notNull?: undefined;
            onDelete?: undefined;
            targetTables?: undefined;
            mirrorColumns?: undefined;
            allowSearch: boolean;
            bucket: string;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        displayName?: undefined;
        isSystem: boolean;
        metadata: {
            allowFilter?: undefined;
            defaultValue?: undefined;
            notNull?: undefined;
            onDelete?: undefined;
            targetTables?: undefined;
            mirrorColumns?: undefined;
            allowSearch?: undefined;
            bucket?: undefined;
            type: string;
        };
        name: string;
        type: 'column';
    })[];
    constraints: {
        columns: string[];
        constraintType: 'unique';
    }[];
    displayName: string;
    folder: string;
    isSystem: boolean;
    metadata: {
        displayFieldId: string;
        hasComments: boolean;
        hasVersion: boolean;
    };
    name: string;
    type: 'table';
};
export type KnowledgebaseType = {
    _id: string;
    _originId: string;
    title: string;
    slug: string;
    parent: string | null;
    ordinal: number;
    icon: string | null;
    content: {
        body: string;
        attachments: string[];
    };
    sourceHash: string | null;
    startAt: string;
    endAt: string | null;
    updatedBy: string | null;
};
