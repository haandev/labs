import type { AuditEvent, AuditFilter, AuditStore } from '../../../../../storage/src/index';
import type { WynConnectionHandler } from '../../../WynConnectionHandler';
export declare class S3AuditService implements AuditStore {
    private base;
    constructor(base: WynConnectionHandler);
    log(event: AuditEvent): Promise<void>;
    query(filter: AuditFilter): Promise<AuditEvent[]>;
}
