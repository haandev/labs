import type { NamedQueryNode, WynModel } from '../../../../../model/src/types';
import type { WynModelTree } from '../../../../../model/src/utils/index';
import { type Diagnostic } from './rules';
export type { NamedQueryFacts } from './facts';
export { type ElevatedSurfaceEntry, elevatedReachableFrom, elevatedSurface, } from './reachability';
export type { Diagnostic, Severity } from './rules';
/**
 * The one entry point. The application's save path and the static declaration
 * guard both call this; a second evaluation site is how the shipped
 * declarations would become the only set exempt from the rules.
 *
 * A prebuilt `WynModelTree` is accepted alongside the raw model so a caller
 * that already had to index the model — to find the row a write replaces, say
 * — does not index it a second time. `computeFacts` takes the same union, so
 * this is a parameter widened, not a second code path.
 */
export declare function evaluateNamedQueryRules(nq: NamedQueryNode, model: WynModel | WynModelTree): Diagnostic[];
