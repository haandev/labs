import type { HistoryItem } from '../../../../../shared/src/history';
import type { DataTableKey, PackageKey } from '../../../../../shared/src/migration-packages';
import type { MigrationBundle } from '../bundle/BundleFormat';
import type { OperationFamily } from './travelsWhole';
export { type DataTableKey, PACKAGE_LABELS, PACKAGE_ORDER, PACKAGE_TABLES, type PackageKey, } from '../../../../../shared/src/migration-packages';
export type DataTableDiff = {
    toInsert: Array<{
        _id: string;
        row: Record<string, unknown>;
    }>;
    toUpdate: Array<{
        _id: string;
        row: Record<string, unknown>;
    }>;
    toSkip: Array<{
        _id: string;
    }>;
};
/**
 * A source row recognised as a target row it already exists as, matched on a
 * unique rule rather than `_id`. References into the source row are repointed.
 */
export type IdentityMatch = {
    table: DataTableKey;
    naturalKeyColumns: string[];
    naturalKeyValue: string | number | boolean | (string | number | boolean)[];
    sourceId: string;
    targetId: string;
};
/**
 * A source row that matched more than one target row, through more than one
 * unique rule. Nothing in the data settles it, so execution is refused.
 */
export type IdentityConflict = {
    table: DataTableKey;
    sourceId: string;
    /**
     * A candidate's `targetId` may equal the `sourceId`: a self-match merges with
     * nothing, but keeping it still writes every column another row may own.
     */
    candidates: Array<{
        targetId: string;
        columns: string[];
        value: string | number | boolean | Array<string | number | boolean>;
    }>;
};
export declare const MODEL_NODE_TYPES: readonly ['space', 'table', 'column', 'namedQuery', 'constraint'];
export type ModelNodeType = (typeof MODEL_NODE_TYPES)[number];
/**
 * A model node a replayed change names and the receiving base does not hold.
 * The operator answers it; execution is refused while one is unanswered.
 */
export type AbsentTarget = {
    nodeId: string;
    /** `'unknown'` only where the folded source log carries no type at all. */
    nodeType: ModelNodeType | 'unknown';
    name: string;
    /** Ancestor names, outermost first. */
    path: string[];
    /**
     * The entries this one decision governs — this node's and its descendants',
     * minus deletes of already-gone nodes, which resolve without a question.
     */
    entryIds: string[];
    /** Set when this base has already answered; then it is reported, not asked. */
    remembered: 'leave-absent' | null;
    /**
     * Whether "revive" would succeed for this subtree: `false` when it names a
     * node type `reviveNode` cannot create. Computed so it is never offered.
     */
    revivable: boolean;
    nonRevivableReason: string | null;
};
export type AbsentDecision = 'leave-absent' | 'revive';
export type PlanRequest = {
    source: {
        kind: 'base';
        baseId: string;
    } | {
        kind: 'bundle';
        bundle: MigrationBundle;
    };
    targetBaseId: string;
    packages: PackageKey[];
};
export type PlanResult = {
    planId: string;
    expiresAt: string;
    requestedPackages: PackageKey[];
    sourceFingerprint: string;
    targetFingerprint: string;
    schema: {
        toApply: HistoryItem[];
        toSkip: Array<{
            _id: string;
            reason: 'already-applied';
        }>;
    };
    alwaysData: {
        choices: DataTableDiff;
    };
    data: Partial<Record<DataTableKey, DataTableDiff>>;
    collisions: IdentityMatch[];
    conflicts: IdentityConflict[];
    absentTargets: AbsentTarget[];
    warnings: string[];
};
export type ExecuteRequest = {
    planId: string;
};
export type ExecuteEvent = ['validate'] | ['validate-fail', string] | ['begin'] | ['schema-item', {
    _id: string;
    operation_type: string;
}] | ['schema-item-ok', string] | ['schema-item-skipped', string, 'left-absent' | 'gone-on-both-sides'] | ['schema-item-revived', string, number] | ['schema-item-recreated', string, Exclude<OperationFamily, 'MODEL'>] | ['always-data', 'choices'] | [
    'always-data-ok',
    'choices',
    {
        inserted: number;
        updated: number;
        skipped: number;
    }
] | ['package', PackageKey] | [
    'package-ok',
    PackageKey,
    Partial<Record<DataTableKey, {
        inserted: number;
        updated: number;
        skipped: number;
    }>>
] | ['commit'] | ['success'] | ['fail', string] | ['closed'];
export type PlanInputs = {
    source: {
        schema: HistoryItem[];
        data: Partial<Record<DataTableKey, Record<string, unknown>[]>>;
        fingerprint: string;
        warnings?: string[];
    };
    target: {
        /**
         * Log entry ids the target has already applied — not the same question as
         * which nodes it holds, since an applied entry's node may be gone.
         */
        schemaIds: Set<string>;
        schemaEntries: HistoryItem[];
        nodeIds: Set<string>;
        rememberedAbsent: Set<string>;
        data: Partial<Record<DataTableKey, Map<string, string>>>;
        rows: Partial<Record<DataTableKey, Map<string, Record<string, unknown>>>>;
        fingerprint: string;
    };
    requestedPackages: PackageKey[];
};
