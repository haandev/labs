export { secret } from '../../../../shared/src/jwt-secret';
