/**
 * Provider CRUD is `trusted` and the browser invokes all of it through
 * `sdk.wql`, so exposure is not the gate here — it only admits a client
 * registered with raw-WQL permission. The gate is the second layer: the
 * `admin` grants on `system.email_providers` in `system-rules.wql`. A write
 * verb added to this module inherits that gate and needs no route of its own;
 * one added over a table without those grants has no gate at all.
 *
 * `getEmailProvider` is the single exception at `service`, because it projects
 * the decrypted credential: no client at any level may ask for it, and only
 * `apps/be/src/routes/base/email.ts` reaches it through `base.wql` on the
 * unpolicied handler. The template queries stay `service` for the same shape of
 * reason — their validation lives only in the route.
 *
 * Nothing here may be `public`. `public` means every client: the browse
 * endpoint accepts a named query from any authenticated caller with no role
 * check, `allowMutation` is a client-supplied field on its config, and a member
 * of the platform base runs unpolicied against any mutable tenant base on
 * membership alone. So at `public` a platform-base member holding no `admin`
 * role anywhere could rewrite a tenant's provider credential and sender
 * identity — redirecting the host or key captures every future outbound message
 * including a password-reset link — and rewrite the body of
 * `account.password_enroll` past the route's validation.
 */
/** This projects the credential, so no client at any level may ask for it. */
export declare const GetEmailProviderQuery: () => {
    description: string;
    displayName: string;
    folder: string;
    metadata: {
        exposure: string;
        query: string;
    };
    name: string;
    type: 'namedQuery';
};
/** The credential never leaves the projection — only whether one is set. */
export declare const ListEmailProvidersQuery: () => {
    description: string;
    displayName: string;
    folder: string;
    metadata: {
        exposure: string;
        query: string;
    };
    name: string;
    type: 'namedQuery';
};
/** The row `listEmailProvidersForFlow` projects. */
export type FlowEmailProviderRow = {
    slug: string;
    displayName: string;
    providerType: string;
};
/** Only what the flow editor's provider picker needs. */
export declare const ListEmailProvidersForFlowQuery: () => {
    description: string;
    displayName: string;
    folder: string;
    metadata: {
        exposure: string;
        query: string;
    };
    name: string;
    type: 'namedQuery';
};
export declare const InsertEmailProviderQuery: () => {
    description: string;
    displayName: string;
    folder: string;
    metadata: {
        exposure: string;
        query: string;
    };
    name: string;
    type: 'namedQuery';
};
/**
 * `slug` is absent from the SET clause: a rename would break every flow step
 * pointing at it, and a jsonb flow definition cannot be cascaded. Every other
 * column binds with `?=`, so an omitted field carries the stored value
 * forward — which is how the credential never has to leave the server.
 */
export declare const SetEmailProviderQuery: () => {
    description: string;
    displayName: string;
    folder: string;
    metadata: {
        exposure: string;
        query: string;
    };
    name: string;
    type: 'namedQuery';
};
/**
 * Its own verb, for the reason the old `clearEmailPassword` was one: a caller
 * should never have to aim a deliberate null at `setEmailProvider` among live
 * fields.
 */
export declare const ClearEmailProviderCredentialQuery: () => {
    description: string;
    displayName: string;
    folder: string;
    metadata: {
        exposure: string;
        query: string;
    };
    name: string;
    type: 'namedQuery';
};
export declare const DeleteEmailProviderQuery: () => {
    description: string;
    displayName: string;
    folder: string;
    metadata: {
        exposure: string;
        query: string;
    };
    name: string;
    type: 'namedQuery';
};
export declare const GetEmailDefaultQuery: () => {
    description: string;
    displayName: string;
    folder: string;
    metadata: {
        exposure: string;
        query: string;
    };
    name: string;
    type: 'namedQuery';
};
/** The row id is a literal, so this cannot write a second settings row. */
export declare const SetEmailDefaultQuery: () => {
    description: string;
    displayName: string;
    folder: string;
    metadata: {
        exposure: string;
        query: string;
    };
    name: string;
    type: 'namedQuery';
};
export declare const ListEmailTemplatesQuery: () => {
    description: string;
    displayName: string;
    folder: string;
    metadata: {
        exposure: string;
        query: string;
    };
    name: string;
    type: 'namedQuery';
};
export declare const GetEmailTemplateQuery: () => {
    description: string;
    displayName: string;
    folder: string;
    metadata: {
        exposure: string;
        query: string;
    };
    name: string;
    type: 'namedQuery';
};
/**
 * Keyed on the message id rather than the row id: the row is minted by the
 * seed and the caller never learns it. The seed guarantees the row exists, so
 * this is an update and not an upsert.
 */
export declare const SetEmailTemplateQuery: () => {
    description: string;
    displayName: string;
    folder: string;
    metadata: {
        exposure: string;
        query: string;
    };
    name: string;
    type: 'namedQuery';
};
