import type { WynConnectionHandler } from '../../WynConnectionHandler';
export type EmailTemplateRow = {
    messageId: string;
    subject: string;
    body: string;
};
export type EmailTemplateReconciliation = {
    /** Every template row this call found already stored, before reconciling. */
    existing: EmailTemplateRow[];
    /** Ids of the catalogue messages this call inserted a row for. */
    insertedIds: string[];
};
/**
 * Inserts a row for every catalogue message a base is missing.
 *
 * Seeding a base's `email_templates` only ever runs once, from the
 * `EMAIL_TEMPLATES_TABLE` hook at base creation (see `hooks.ts`), because
 * `initializeDatabase` itself only ever runs on creation. A base created
 * before the product gained a message type would therefore never hold a row
 * for it, and there are no migrations to backfill one — so this is called
 * again, on every visit to the messages screen, to catch up a base that
 * predates a catalogue addition. Two callers doing "the same thing at
 * startup" is not duplication to delete; it is the same gap closed from both
 * ends.
 *
 * `ON CONFLICT (messageId) DO NOTHING` so a second pass never discards an
 * edited row. Iterates `EMAIL_MESSAGES`, the catalogue's single declared
 * list, rather than any hardcoded count.
 *
 * Reads through a raw table query rather than the `system.listEmailTemplates`
 * named query: the seed-hook call site runs from inside
 * `initializeDatabase`'s `afterAllSaved` phase, before this base has ever
 * answered an ordinary request, and every other seed hook in `hooks.ts`
 * reaches its own table the same raw way rather than through a named query.
 */
export declare function reconcileEmailTemplates(base: WynConnectionHandler): Promise<EmailTemplateReconciliation>;
