/**
 * ## Module: Users Table Initialization
 *
 * This module defines the `users` system table for managing application users.
 *
 * Purpose:
 *
 * - Stores core user credentials and role information.
 *
 * Notes:
 *
 * - One `users` table is created per database.
 */
export declare const USERS_TABLE = "users";
declare const factory: () => {
    children: ({
        isSystem: boolean;
        metadata: {
            allowFilter: boolean;
            type: string;
            allowedMimeTypes?: undefined;
            bucket?: undefined;
            maxFileSizeBytes?: undefined;
            canHaveMultiple?: undefined;
            targetTables?: undefined;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            allowFilter?: undefined;
            type: string;
            allowedMimeTypes?: undefined;
            bucket?: undefined;
            maxFileSizeBytes?: undefined;
            canHaveMultiple?: undefined;
            targetTables?: undefined;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            allowFilter?: undefined;
            allowedMimeTypes: string[];
            bucket: string;
            maxFileSizeBytes: number;
            type: string;
            canHaveMultiple?: undefined;
            targetTables?: undefined;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            allowFilter?: undefined;
            allowedMimeTypes?: undefined;
            bucket?: undefined;
            maxFileSizeBytes?: undefined;
            canHaveMultiple: boolean;
            targetTables: {
                junctionSourceColumn: string;
                junctionTable: string;
                junctionTargetColumn: string;
                table: string;
            }[];
            type: string;
        };
        name: string;
        type: 'column';
    })[];
    constraints: {
        columns: string[];
        constraintType: 'unique';
    }[];
    displayName: string;
    folder: string;
    isSystem: boolean;
    metadata: {
        displayFieldId: string;
    };
    name: string;
    type: 'table';
};
export default factory;
export type UsersType = {
    _id: string;
    username: string;
    name?: string;
    givenName?: string;
    familyName?: string;
    picture?: string[];
    zoneinfo?: string;
    updatedAt?: string;
    roles: string[];
};
