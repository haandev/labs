import type { TFlow, TFlowCreate } from '../../types';
import type { WynConnectionHandler } from '../../WynConnectionHandler';
export type FlowLike = Record<string, unknown> & {
    _id: string;
};
export declare class FlowService {
    private base;
    constructor(base: WynConnectionHandler);
    /**
     * Schema-prefixed: trigger DDL runs on the default search_path, which does
     * not include the `system` schema these tables live in.
     */
    private findTableRef;
    /**
     * Names the flow as well as the table: a migration operator reads this
     * refusal with no access to the id it would otherwise carry alone.
     */
    private requireTableRef;
    getById(id: string): Promise<({
        _id: string;
        name: string;
        description: (string | null);
        isActive: boolean;
        nodes: {
            id: string;
            type: string;
            payload?: {
                [k: string]: unknown;
            };
            nextNodeId?: (string | null);
            [k: string]: unknown;
        }[];
        trigger: {
            type: ("table" | "schedule" | "webhook" | "storageEvent");
            metadata: {
                [k: string]: unknown;
            };
            [k: string]: unknown;
        };
        startNodeId: (string | null);
        stateSchema: ({
            id: string;
            name: string;
            type: ("string" | "number" | "array" | "object" | "boolean");
            defaultValue?: unknown;
            [k: string]: unknown;
        }[] | null);
        lock: boolean;
        createdAt: string;
        updatedAt: string;
        createdBy: (string | null);
        updatedBy: (string | null);
    } & Record<any, unknown>) | null>;
    /**
     * Only unbounded cycles are refused — a repeat-branch body wired back to its
     * repeater is legal, because the repeater counts the iterations.
     */
    private assertRunnableNodeGraph;
    /**
     * No-op when `nodes` isn't part of this save (an update that doesn't touch
     * them has nothing new to validate — what's stored already passed this
     * check when it was saved).
     */
    private assertValidExpressions;
    /**
     * Enforced here, not in the routes: the one choke point every authoring
     * surface passes through, so the rule is written once.
     */
    private assertNoIndividualAddressee;
    /** A mapped path gets its `[]` here, whatever surface authored the flow. */
    private normalized;
    create(data: TFlowCreate): Promise<{
        _id: string;
        name: string;
        description: (string | null);
        isActive: boolean;
        nodes: {
            id: string;
            type: string;
            payload?: {
                [k: string]: unknown;
            };
            nextNodeId?: (string | null);
            [k: string]: unknown;
        }[];
        trigger: {
            type: ("table" | "schedule" | "webhook" | "storageEvent");
            metadata: {
                [k: string]: unknown;
            };
            [k: string]: unknown;
        };
        startNodeId: (string | null);
        stateSchema: ({
            id: string;
            name: string;
            type: ("string" | "number" | "array" | "object" | "boolean");
            defaultValue?: unknown;
            [k: string]: unknown;
        }[] | null);
        lock: boolean;
        createdAt: string;
        updatedAt: string;
        createdBy: (string | null);
        updatedBy: (string | null);
    } & Record<any, unknown>>;
    /**
     * Nobody states a flow's tier: it follows from who is acting and which base
     * they are acting on, read at the moment the flow is made.
     */
    private derivedTier;
    update(id: string, data: Partial<TFlow>): Promise<void>;
    delete(id: string): Promise<({
        _id: string;
        name: string;
        description: (string | null);
        isActive: boolean;
        nodes: {
            id: string;
            type: string;
            payload?: {
                [k: string]: unknown;
            };
            nextNodeId?: (string | null);
            [k: string]: unknown;
        }[];
        trigger: {
            type: ("table" | "schedule" | "webhook" | "storageEvent");
            metadata: {
                [k: string]: unknown;
            };
            [k: string]: unknown;
        };
        startNodeId: (string | null);
        stateSchema: ({
            id: string;
            name: string;
            type: ("string" | "number" | "array" | "object" | "boolean");
            defaultValue?: unknown;
            [k: string]: unknown;
        }[] | null);
        lock: boolean;
        createdAt: string;
        updatedAt: string;
        createdBy: (string | null);
        updatedBy: (string | null);
    } & Record<any, unknown>) | null>;
    updateWithTriggerRefresh(id: string, data: Partial<TFlow>): Promise<FlowLike | null>;
    /**
     * Make the installed trigger match what the row says. `previous` is dropped
     * from the table IT names — not the table `next` names, which is a
     * different table whenever a flow moves its trigger.
     */
    refreshTrigger(previous: FlowLike | null, next: FlowLike | null): Promise<void>;
    /**
     * Re-installs a flow's table trigger and nothing else, for a base being
     * carried onto the widened event list a versioned table needs. Deliberately
     * not `refreshTrigger`: that also runs the schedule path, which enqueues an
     * outbox event, so re-running it over every stored flow would queue a
     * duplicate run for each scheduled one.
     */
    refreshTableTrigger(flow: FlowLike): Promise<void>;
    removeTrigger(flow: FlowLike): Promise<void>;
    private removeTableTrigger;
    private createTableTrigger;
    private createStorageEventTrigger;
    private createScheduleTrigger;
    private removeStorageEventTrigger;
    createTrigger(flow: FlowLike): Promise<void>;
    fireWebhook(id: string): Promise<{
        success: boolean;
        error: string | null;
    }>;
    private getTriggerName;
}
