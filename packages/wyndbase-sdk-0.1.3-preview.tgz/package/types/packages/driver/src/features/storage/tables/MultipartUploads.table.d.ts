/**
 * ## Module: Multipart Uploads Table
 *
 * This module defines the `multipart_uploads` table for tracking S3 multipart uploads.
 *
 * Purpose:
 * - Tracks in-progress multipart uploads
 * - Manages upload lifecycle (inprogress, completed, aborted)
 *
 * Notes:
 * - Uploads should be cleaned up after completion or abort
 * - One `multipart_uploads` table is created per database
 */
export declare const MULTIPART_UPLOADS_TABLE = "multipart_uploads";
declare const factory: () => {
    children: ({
        displayName: string;
        isSystem: boolean;
        metadata: {
            allowFilter: boolean;
            notNull: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        displayName?: undefined;
        isSystem: boolean;
        metadata: {
            allowFilter: boolean;
            notNull: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        displayName?: undefined;
        isSystem: boolean;
        metadata: {
            allowFilter?: undefined;
            notNull?: undefined;
            type: string;
        };
        name: string;
        type: 'column';
    })[];
    constraints: {
        columns: string[];
        constraintType: 'unique';
    }[];
    displayName: string;
    folder: string;
    isSystem: boolean;
    name: string;
    type: 'table';
};
export default factory;
export type MultipartUploadsType = {
    _id: string;
    bucket: string;
    key: string;
    status: string;
    contentType?: string;
    uploadId: string;
    createdAt: string;
};
