import type { WynConnectionHandler } from '../../WynConnectionHandler';
import { type DeleteModelOptions } from '../lifecycle/model-crud';
export declare class ModelService {
    private base;
    constructor(base: WynConnectionHandler);
    /**
     * `create`/`update`/`delete` rekey affected tables after writing, so a
     * renamed object's rule key never goes stale.
     */
    create(definition: Record<string, any>): Promise<{
        _id?: string | undefined;
        description?: string | null | undefined;
        displayName?: string | null | undefined;
        folder?: string | null | undefined;
        isDynamic?: boolean | null | undefined;
        isSystem?: boolean | null | undefined;
        name: string;
        ordinal?: number | null | undefined;
        physicalName?: string | undefined;
        metadata: {
            elevated?: boolean | undefined;
            exposure?: "public" | "service" | "trusted" | undefined;
            query?: string | undefined;
        };
        parent: string;
        type: "namedQuery";
    } | {
        _id?: string | undefined;
        description?: string | null | undefined;
        displayName?: string | null | undefined;
        folder?: string | null | undefined;
        isDynamic?: boolean | null | undefined;
        isSystem?: boolean | null | undefined;
        name: string;
        ordinal?: number | null | undefined;
        parent: string;
        physicalName?: string | undefined;
        metadata: {
            allowEnd?: "both" | "exclusive-only" | "inclusive-only" | null | undefined;
            allowedCountries?: string[] | null | undefined;
            allowedMimeTypes?: string[] | null | undefined;
            allowedTables?: string[] | null | undefined;
            allowFilter?: boolean | null | undefined;
            allowOpenEnd?: boolean | null | undefined;
            allowOpenStart?: boolean | null | undefined;
            allowSearch?: boolean | null | undefined;
            allowStart?: "both" | "exclusive-only" | "inclusive-only" | null | undefined;
            allowsAnyTable?: boolean | null | undefined;
            bucket?: string | null | undefined;
            canHaveMultiple?: boolean | null | undefined;
            dataMask?: {
                char?: string | null | undefined;
                email?: boolean | null | undefined;
                enabled?: boolean | null | undefined;
                leading?: number | null | undefined;
                separators?: boolean | null | undefined;
                trailing?: number | null | undefined;
            } | null | undefined;
            defaultValue?: any;
            encrypt?: boolean | null | undefined;
            formula?: string | null | undefined;
            hidden?: boolean | null | undefined;
            immutable?: boolean | null | undefined;
            inputMask?: string | null | undefined;
            isArray?: boolean | null | undefined;
            isDynamic?: boolean | null | undefined;
            isMultiSelect?: "no" | "yes" | null | undefined;
            isNqTarget?: boolean | null | undefined;
            isPrimaryKey?: boolean | null | undefined;
            isUnique?: boolean | null | undefined;
            listName?: string | null | undefined;
            maxFileSizeBytes?: number | null | undefined;
            mirrorColumns?: {
                _id?: string | null | undefined;
                canHaveMultiple?: boolean | null | undefined;
                name: string;
                physicalName?: string | null | undefined;
                table: string;
            }[] | null | undefined;
            notAllowedCountries?: string[] | null | undefined;
            notNull?: boolean | null | undefined;
            onDelete?: "cascade" | "keep" | "restrict" | "setNull" | null | undefined;
            optimizeSort?: boolean | null | undefined;
            precision?: number | null | undefined;
            rules?: {
                args?: any[] | null | undefined;
                name: string;
            }[] | null | undefined;
            scale?: number | null | undefined;
            schema?: Record<string, unknown> | null | undefined;
            sensitive?: "always" | "explicitly-open" | null | undefined;
            summaryTypes?: string[] | null | undefined;
            targetTables?: {
                junctionSourceColumn?: string | null | undefined;
                junctionTable?: string | null | undefined;
                junctionTargetColumn?: string | null | undefined;
                table: string;
                targetColumn?: string | null | undefined;
            }[] | null | undefined;
            type: string;
            versioning?: boolean | null | undefined;
        };
        type: "column";
    } | {
        _id?: string | undefined;
        description?: string | null | undefined;
        displayName?: string | null | undefined;
        folder?: string | null | undefined;
        isDynamic?: boolean | null | undefined;
        isSystem?: boolean | null | undefined;
        metadata?: Record<string, any> | null | undefined;
        name: string;
        ordinal?: number | null | undefined;
        physicalName?: string | undefined;
        parent?: null | undefined;
        type: "space";
    } | {
        _id?: string | undefined;
        description?: string | null | undefined;
        displayName?: string | null | undefined;
        folder?: string | null | undefined;
        isDynamic?: boolean | null | undefined;
        isSystem?: boolean | null | undefined;
        name: string;
        ordinal?: number | null | undefined;
        physicalName?: string | undefined;
        metadata?: {
            allowDynamicColumns?: boolean | null | undefined;
            displayFieldId?: string | null | undefined;
            hasComments?: boolean | null | undefined;
            hasVersion?: boolean | null | undefined;
            transient?: boolean | null | undefined;
        } | null | undefined;
        parent: string;
        type: "table";
    }>;
    update(id: string, definition: Record<string, any>): Promise<any>;
    /** Deletion preview for a link column — the mirror/junction its delete takes. */
    linkDeleteImpact(columnId: string): Promise<import("../lifecycle").LinkDeleteImpact>;
    delete(id: string, options?: DeleteModelOptions): Promise<{
        _id: string;
        physicalName: string;
        parent: (string | null);
        type: string;
        isSystem: (boolean | null);
        isDynamic: (boolean | null);
        name: string;
        displayName: (string | null);
        description: (string | null);
        metadata: ({
            [k: string]: unknown;
        } | null);
        folder: (string | null);
        ordinal: (number | null);
        children: string[];
        createdAt: string;
        updatedAt: string;
        createdBy: (string | null);
        updatedBy: (string | null);
        parentId: (string | null);
    } & Record<any, unknown>>;
    /**
     * Flexible identifier: `_id`, `physicalName` or `name` first, then a
     * canonical dotted path (`system.knowledgebase`) via the tree — so a client
     * that knows only the path never has to resolve an id first.
     */
    getById(id: string, childDepth?: number): Promise<Record<string, any> | undefined>;
    getStructure(): Promise<import("../../../../wql/src/index").WynModel>;
    getStrippedModel(): Promise<import("../../../../wql/src/index").WynModel>;
    /**
     * Set column display order. Not routed through `update()`, which is
     * DDL-aware; a partial order is rejected outright.
     */
    setColumnOrder(tableId: string, columnIds: string[]): Promise<void>;
    /** Flat list of models with optional type/parentId/spaceName filtering. */
    listFlat(filter?: {
        type?: string;
        parentId?: string;
        spaceName?: string;
    }): Promise<any>;
    /** List tables and named queries, optionally by space */
    listSources(spaceId?: string): Promise<any[]>;
    /** Resolve any node (space/table/column) by flexible identifier + optional scope. */
    resolveNode(identifier: string, scope?: string): Promise<import("../../../../wql/src/index").ResolvedNode | undefined>;
    /**
     * Wire-friendly `resolveNode`: only the terminal node, with its `children`
     * dropped. `resolveNode` returns live tree nodes plus their ancestor
     * segments (space/table) — cheap in memory, but wasteful over the network
     * when the caller only needs the addressed node itself. This copies once
     * and shallowly, so the payload is a single node.
     */
    resolveTerminalNode(identifier: string, scope?: string): Promise<{
        type: 'space' | 'table' | 'column';
        node: Record<string, any>;
    } | undefined>;
    /**
     * Same shape as `resolveNode` — terminal node plus its `space`/`table`
     * segments as separate properties — but every segment shallow-copied with
     * its `children` dropped, so the ancestors travel as headers rather than
     * whole subtrees.
     */
    resolveNodeOwn(identifier: string, scope?: string): Promise<{
        type: 'space' | 'table' | 'column';
        node: Record<string, any>;
        space?: Record<string, any>;
        table?: Record<string, any>;
    } | undefined>;
    renameFolder(spaceId: string, currentName: string, newName: string): Promise<void>;
    deleteFolder(spaceId: string, folderName: string): Promise<void>;
}
