export declare const DECISION_MATRIX_TABLE = "decision_matrix";
declare const factory: () => {
    children: ({
        isSystem: boolean;
        metadata: {
            targetTables?: undefined;
            onDelete?: undefined;
            defaultValue?: undefined;
            allowFilter: boolean;
            notNull: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            notNull?: undefined;
            defaultValue?: undefined;
            allowFilter: boolean;
            onDelete: string;
            targetTables: {
                table: string;
            }[];
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            targetTables?: undefined;
            onDelete?: undefined;
            notNull?: undefined;
            defaultValue?: undefined;
            allowFilter: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            allowFilter?: undefined;
            targetTables?: undefined;
            onDelete?: undefined;
            notNull?: undefined;
            defaultValue?: undefined;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            targetTables?: undefined;
            onDelete?: undefined;
            allowFilter: boolean;
            defaultValue: boolean;
            notNull: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    })[];
    constraints: never[];
    displayName: string;
    folder: string;
    isSystem: boolean;
    name: string;
    type: 'table';
};
export default factory;
