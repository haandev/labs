import type { WynConnectionHandler } from '../../WynConnectionHandler';
export declare class InboxService {
    private base;
    constructor(base: WynConnectionHandler);
    private heldKeys;
    submitForm(interactionId: string, data: Record<string, unknown>): Promise<unknown>;
}
