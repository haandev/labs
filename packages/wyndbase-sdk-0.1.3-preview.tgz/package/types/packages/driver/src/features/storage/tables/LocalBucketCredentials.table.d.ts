export declare const LOCAL_BUCKET_CREDENTIALS_TABLE = "local_bucket_credentials";
/**
 * Fixed so the seed hook and the rotate path address the same row. Must not
 * collide with another fixed id reserved elsewhere in the driver.
 */
export declare const ROOT_CREDENTIAL_ID = "00000000-0000-7000-8000-000000000011";
declare const factory: () => {
    children: ({
        displayName: string;
        isSystem: boolean;
        metadata: {
            encrypt?: undefined;
            allowFilter?: undefined;
            defaultValue?: undefined;
            onDelete?: undefined;
            targetTables?: undefined;
            notNull: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        displayName: string;
        isSystem: boolean;
        metadata: {
            encrypt?: undefined;
            defaultValue?: undefined;
            allowFilter: boolean;
            notNull: boolean;
            onDelete: string;
            targetTables: {
                table: string;
            }[];
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        displayName: string;
        isSystem: boolean;
        metadata: {
            encrypt?: undefined;
            defaultValue?: undefined;
            onDelete?: undefined;
            targetTables?: undefined;
            allowFilter: boolean;
            notNull: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        displayName: string;
        isSystem: boolean;
        metadata: {
            allowFilter?: undefined;
            defaultValue?: undefined;
            onDelete?: undefined;
            targetTables?: undefined;
            encrypt: boolean;
            notNull: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        displayName: string;
        isSystem: boolean;
        metadata: {
            encrypt?: undefined;
            allowFilter?: undefined;
            onDelete?: undefined;
            targetTables?: undefined;
            defaultValue: never[];
            notNull: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        displayName: string;
        isSystem: boolean;
        metadata: {
            encrypt?: undefined;
            onDelete?: undefined;
            targetTables?: undefined;
            allowFilter: boolean;
            defaultValue: boolean;
            notNull: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        displayName: string;
        isSystem: boolean;
        metadata: {
            encrypt?: undefined;
            allowFilter?: undefined;
            onDelete?: undefined;
            targetTables?: undefined;
            defaultValue: string;
            notNull: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    })[];
    displayName: string;
    folder: string;
    isSystem: boolean;
    name: string;
    type: 'table';
};
export default factory;
export type LocalBucketCredentialsType = {
    _id: string;
    name: string;
    bucketId?: string | null;
    accessKey: string;
    secretKey: string;
    permissions: string[];
    isRoot: boolean;
    isActive: boolean;
    expiresAt?: string | null;
    creationDate: string;
};
