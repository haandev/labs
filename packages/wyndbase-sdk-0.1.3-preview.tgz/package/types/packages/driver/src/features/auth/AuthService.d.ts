import { type AmrValue, type FlowNext } from '../../../../shared/src/auth-factors/index';
import type { JwtPayload } from '../../../../shared/src/auth-types';
import type { SessionMeta } from '../../../../shared/src/session';
import type { WynConnectionHandler } from '../../WynConnectionHandler';
import { AuthAuditService } from './AuthAuditService';
import { type StepUpOffering } from './FlowEngine';
import { FactorRegistry } from './factors';
import { FederatedIdentityService } from './federated/FederatedIdentityService';
import { FederatedService } from './federated/FederatedService';
import { secret } from './jwtSecret';
import { RecoveryCodeService } from './RecoveryCodeService';
import { RoleService } from './RoleService';
import type { StoredVerificationTokenBinding } from './tables/VerificationToken.table';
import { UserService } from './UserService';
export { secret };
export type OAuth2TokenResult = {
    accessToken: string;
    expiresIn: number;
    refreshToken: string;
    scopes: string[];
    tokenType: 'Bearer';
    cookieName: string;
    sessionToken: string;
};
/** AAL + authentication methods stamped onto a session/JWT at creation. */
export type AuthInfo = {
    aal: number;
    amr: AmrValue[];
};
/** What a verification token authorizes. Consumption is purpose-checked so a
 *  low-assurance emailed token can't be replayed in a higher-assurance flow
 *  (e.g. an email-verify token submitted as an OAuth authorization code). */
export type VerificationTokenPurpose = 'oauth_code' | 'email_verify' | 'password_enroll';
export type FlowRequiredResult = {
    flowRequired: true;
    flowToken: string;
    next: FlowNext;
};
export declare function isFlowRequired(r: OAuth2TokenResult | FlowRequiredResult): r is FlowRequiredResult;
/**
 * `returnTo` rides along because the handoff is consumed inside
 * `completeFederatedLogin` and cannot be read twice. `null` if none was bound.
 */
export type FederatedLoginResult = (OAuth2TokenResult | FlowRequiredResult) & {
    returnTo: string | null;
};
/**
 * Callback refusals the HTTP layer reaches before this service does. Only
 * `client_excluded_provider` is a verdict rather than an unfinished round trip.
 */
export type FederatedCallbackRefusal = 'no_browser_binding' | 'state_mismatch' | 'provider_error' | 'client_excluded_provider';
/**
 * The decision every call site makes on a failure raised while a credential
 * was being checked, whether it was being verified or enrolled. Only a
 * credential presented and evaluated as wrong burns lockout budget; an
 * infrastructure failure presented none. `recordFailure` is called for the
 * former only, and never to record a success — a non-counting failure gets no
 * row at all rather than one that would erase genuine failures from
 * `failuresSinceLastSuccess`. `attempted` names the surface for the log line
 * and nothing else.
 */
export declare function recordCredentialRejection(err: unknown, recordFailure: () => Promise<void>, attempted?: 'verification' | 'enrollment'): Promise<void>;
export declare class AuthService {
    private base;
    private _role;
    private _factors;
    private _recovery;
    private _audit;
    private _federated;
    private _federatedIdentity;
    get role(): RoleService;
    get factors(): FactorRegistry;
    get recovery(): RecoveryCodeService;
    /** The single writer of the auth audit trail. */
    get audit(): AuthAuditService;
    get federated(): FederatedService;
    get federatedIdentity(): FederatedIdentityService;
    getUserInstance(userId: string): UserService;
    constructor(base: WynConnectionHandler);
    private getClient;
    createSessionUtil(clientId: string, userId: string, sessionMeta: SessionMeta, authInfo?: AuthInfo, scopes?: string[]): Promise<{
        accessToken: string;
        client: {
            _id: string;
            name: string;
            shortName: string;
            description: (string | null);
            isActive: boolean;
            allowRawWql: boolean;
            consentRequired: boolean;
            isIdp: boolean;
            idpClient: (string | null);
            idpSettings: ({
                consentPageUrl?: string;
                [k: string]: unknown;
            } | null);
            accessTokenTtl: number;
            refreshTokenTtl: number;
            sessionDuration: number;
            inactivityTimeout: number;
            apiKey: string;
            allowedOrigins: (string[] | null);
            redirectUrls: (string[] | null);
            rateLimitRpm: number;
            rateLimitBurst: number;
            verified: boolean;
            publisher: (string | null);
            softwareId: (string | null);
            softwareVersion: (string | null);
            clientUri: (string | null);
            logoUri: (string | null);
            contacts: (string[] | null);
            sessions: string[];
            createdAt: string;
            updatedAt: string;
            createdBy: (string | null);
            updatedBy: (string | null);
            publisherId: (string | null);
            idpClientId: (string | null);
        } & Record<any, unknown>;
        session: {
            expires: string | null;
            id: string;
            sessionToken: string | null;
            userId: string;
        };
    }>;
    verifyAndUpdateSession(sessionToken: string, rotate?: boolean): Promise<{
        accessToken: string;
        client: any;
        scopes: string[];
        session: {
            _id: string;
            sessionToken: (string | null);
            previousToken: (string | null);
            user: (string | null);
            expires: (string | null);
            revokedAt: (string | null);
            device: (string | null);
            os: (string | null);
            browser: (string | null);
            client: (string | null);
            aal: (number | null);
            amr: (string[] | null);
            createdAt: string;
            updatedAt: string;
            createdBy: (string | null);
            updatedBy: (string | null);
            userId: (string | null);
        } & Record<any, unknown>;
    }>;
    /**
     * Null when rotation fails: a refresh that cannot rotate is still a valid
     * refresh, and refusing it would turn a database hiccup into a mass logout.
     */
    private rotateSessionToken;
    /**
     * A token that was already rotated is a replay: the legitimate client has
     * moved on. The whole session dies, with no grace window for retries.
     */
    /**
     * The session a presented token was JUST rotated away from — a benign
     * concurrent-refresh race, not reuse — or `null`. Rotation stamps
     * `updatedAt`, which is what bounds the window.
     */
    private recentlyRotatedSession;
    private handleRefreshReuse;
    /**
     * Best-effort: a user with no resolvable address must not turn a completed
     * defence into a 500 on a request that is being refused anyway.
     */
    private notifyRefreshReuse;
    private generateJwt;
    /**
     * One statement is both check and claim: the DELETE guard carries token,
     * expiry, scope and purpose, so a wrong purpose refuses without burning it.
     */
    useVerificationToken(params: {
        identifier?: string;
        token: string;
        expectedPurpose?: VerificationTokenPurpose;
    }): Promise<{
        acr: string | null;
        amr: string | null;
        challenge: string | null;
        challengeMethod: string | null;
        clientId: string | null;
        emailId: string | null;
        expires: Date;
        identifier: string;
        purpose: string;
        redirectUri: string | null;
        scope: string | null;
        token: string;
        userId: string | null;
    }>;
    /** Refused as an unknown token is, so a stale link reads like a random one. */
    private requireBoundAddress;
    createVerificationTokenUtil(params: {
        identifier: string;
        purpose: VerificationTokenPurpose;
        duration?: number;
        pkceChallenge?: {
            challenge: string;
            challengeMethod: string;
        };
        redirectUri?: string | null;
        clientId?: string | null;
        scope?: string | null;
        /** Assurance the row records, so redemption can mint at that level. */
        authInfo?: AuthInfo;
    } & Partial<StoredVerificationTokenBinding>): Promise<{
        _id: string;
        identifier: string;
        token: string;
        expires: string;
        challenge: (string | null);
        challengeMethod: (string | null);
        redirectUri: (string | null);
        scope: (string | null);
        acr: (string | null);
        amr: (string | null);
        purpose: string;
        clientId: (string | null);
        userId: (string | null);
        emailId: (string | null);
        createdAt: string;
        updatedAt: string;
        createdBy: (string | null);
        updatedBy: (string | null);
    } & Record<any, unknown>>;
    createUser(params: {
        email: string;
        emailVerified: string | null;
        name?: string;
        givenName?: string;
        familyName?: string;
        zoneinfo?: string;
        password?: string;
        username?: string;
        role?: string;
        id?: string;
        image?: string | null;
        /** Store `password` as temporary: it grants no session until replaced. */
        temporary?: boolean;
        /** No-password branch only: rides the enrolment mail's link so the
         *  set-password screen can send its reader back where they were headed.
         *  Already origin-checked at the route boundary. */
        redirectTo?: string | null;
    }): Promise<{
        email: string;
        emailVerified: Date | null;
        id: string;
        image: null;
    }>;
    getUserByEmail(params: {
        email: string;
    }): Promise<{
        email: string;
        emailVerified: string | null;
        id: string;
        image: null;
    } | null>;
    /**
     * The account's own primary address, never the string typed. Two lookups
     * because a username or a verified second address misses the first.
     */
    private enrollmentAddress;
    /**
     * Enumeration-safe: returns without signalling whether the identifier
     * resolves to an account. Notification is best-effort, routed through
     * `notify` — see its doc for why a mail failure or an unset `PUBLIC_URL`
     * must not turn this into a 500.
     */
    requestPasswordEnrollment(identifier: string, redirectTo?: string | null): Promise<void>;
    /**
     * Mints the enrolment token and mails the link at an address an account is
     * already known to own. Split out so a caller holding the account's id can
     * skip `enrollmentAddress`, whose two lookups filter on the primary
     * position and on verification and so between them reach no account at all
     * for an address held second and unverified.
     */
    private sendPasswordEnrollment;
    /**
     * Enumeration-safe by construction: every branch returns without signalling
     * whether the address resolves. The one refusal a caller can see is the
     * base's own switch, which is public information about the base and not
     * about any account.
     *
     * A registration for an address whose account holds no credential re-sends
     * the enrolment link rather than refusing, so an unconfirmed registration
     * cannot hold an address its owner could never claim.
     */
    requestSelfRegistration(params: {
        email: string;
        username?: string;
        name?: string;
        /** Return target for the enrolment mail's link; origin-checked at the
         *  route boundary, so this layer only carries it. */
        redirectTo?: string | null;
    }): Promise<void>;
    /**
     * Grants the role this base names for new registrations, at creation
     * rather than at confirmation: the account holds no credential until its
     * owner follows the emailed link, so there is nothing a later grant would
     * protect and no second piece of state to carry it.
     *
     * `createUser` takes a `role` parameter it never reads, so this is the
     * grant, not a duplicate of one.
     *
     * Fails safe rather than failing the registration. The name comes from a
     * console dropdown fed by this base's own roles, so the only way to reach
     * an unresolvable one is to delete the role afterwards — and a deleted
     * role must not become a way to stop people registering. Both a missing
     * role and a faulting insert leave the account created and the answer the
     * caller gets unchanged.
     */
    private grantRegistrationRole;
    /**
     * Whether an account already holds an address, and which address it stores
     * for it. `getUserByEmail` cannot answer this: it filters on the primary
     * position, so an address held second reads as free and the create behind
     * that answer faults on `unique_email`.
     *
     * `silent` is the answer to anything this cannot resolve — a failed read,
     * or a row naming no account. Both must end the registration having done
     * nothing rather than fall through to the create.
     */
    private registrationOwner;
    /**
     * The two answers for an address an account already holds. Both go to the
     * address the account stores, never the string the caller typed.
     */
    private answerHeldAddress;
    /**
     * Public, pre-login surface — never requires an existing password.
     *
     * Consuming the link also verifies the address it was delivered to: the
     * evidence is the same one an `email_verify` token carries, and without it
     * the account this just enrolled could not sign in by that address, since
     * `getUserByCredential` matches a verified address only. An account left
     * without a username — the self-registration collision shape — could not
     * sign in at all.
     */
    setPasswordWithToken(params: {
        identifier: string;
        token: string;
        newPassword: string;
    }): Promise<void>;
    /**
     * Runs `run` on the base the caller's access token names. Confirm keys this
     * wrap off a session token; the offering, challenge and begin-enrolment are
     * bearer-only, so they pass `baseId` directly.
     */
    onCallerHomeBase<T>(homeBaseId: string | undefined, run: (auth: AuthService) => Promise<T>): Promise<T>;
    /**
     * Runs the operation on the base the session lives in. Everything it reads —
     * the session row, roles, client, factors, audit trail — is per-base.
     */
    private onSessionHomeBase;
    /**
     * `sessionMeta` is optional: a caller that cannot observe the request has
     * nothing truthful to say about the device, so the check simply won't run.
     */
    refreshSession(clientId: string, sessionToken: string, rotate?: boolean, sessionMeta?: SessionMeta): Promise<OAuth2TokenResult>;
    private refreshSessionOnHomeBase;
    /**
     * Report only, no logout and no step-up: nothing in the client can answer a
     * challenge raised mid-refresh, so demanding one would break the session.
     */
    private reportFingerprintDrift;
    /**
     * Adopt the reported fingerprint so the move is reported once rather than
     * once per refresh, and the stored row stays true rather than going stale.
     */
    private adoptFingerprint;
    /**
     * Best-effort: the refresh has already succeeded, so a user with no
     * resolvable address must not turn the report into a failed refresh.
     */
    private notifyFingerprintAnomaly;
    createOAuth2Session(clientId: string, userId: string, sessionMeta: SessionMeta, authInfo?: AuthInfo, scopes?: string[]): Promise<OAuth2TokenResult>;
    /**
     * The `/authorize` redirect_uri is bound into the token row and required to
     * match here: PKCE alone does not cover a multi-entry redirect list.
     */
    exchangeAuthorizationCode(params: {
        code: string;
        clientId: string;
        codeVerifier: string;
        redirectUri?: string;
        sessionMeta: SessionMeta;
        /**
         * Scopes the minted session carries. A callback rather than a list: neither
         * the user nor what was granted is known until the code is verified, and
         * the grant rule (which scopes this user may hold) is the route's policy,
         * not the driver's. `granted` is what the code recorded at authorization.
         */
        grantScopes?: (userId: string, granted: string[]) => Promise<string[]>;
    }): Promise<OAuth2TokenResult>;
    /**
     * Signing makes the token tamper-proof and gives it an expiry; sealing keeps
     * the token from answering "does this account exist?" on its own.
     */
    private signFlowToken;
    private verifyFlowToken;
    /**
     * The insert races on the `jti` unique constraint, so a replay loses. Called
     * only where a step SUCCEEDS, so a typo cannot strand a user mid-login.
     */
    private consumeFlowToken;
    private resolveFlow;
    /**
     * Additive-only as configured on the session's MINTING client, which
     * `authPlugin` sealed from the token — never the request's declared one.
     * Fails closed: an unanswerable question must not relax the rule.
     */
    sessionAdditiveOnly(): Promise<boolean>;
    /**
     * Configured first factors minus the discoverable ones. Config-only, so it is
     * identical for every identifier and cannot enumerate accounts.
     */
    private firstStepFactors;
    /**
     * The ways out offered at step 1, derived from what the CLIENT offers and
     * never from what the account holds — the latter would enumerate accounts.
     */
    private firstStepEscapes;
    /** One source for what we offer and what we accept back, so they can't drift. */
    private evaluate;
    /**
     * The offering is AUTHORITATIVE, not advisory: without this a client could
     * skip past the configured first factor and mint a session config forbids.
     */
    private assertOffered;
    /** The factor types acceptable right now, for `mode`. Step 1 (nothing
     *  completed) is config-driven; every later step is the step-up offering. */
    private offeredFactors;
    /** Advance the engine: either issue the session or return the next step. */
    private decide;
    /**
     * Enumeration-safe: `next` is the client's configured first step, so the
     * response is identical whether or not the identifier resolves.
     */
    startFlow(params: {
        clientId: string;
        identifier: string;
        sessionMeta: SessionMeta;
    }): Promise<FlowRequiredResult>;
    /**
     * The client identity and the typed identifier come from the signed flow
     * token, never from the request.
     */
    authenticateFlow(params: {
        clientId: string;
        flowToken: string;
        factorType: string;
        code: string;
        sessionMeta: SessionMeta;
    }): Promise<OAuth2TokenResult | FlowRequiredResult>;
    /** Issue the WebAuthn assertion challenge for a passkey step mid-flow. The
     *  client runs the ceremony and submits the assertion as the `flow` grant code. */
    flowChallenge(params: {
        flowToken: string;
        factorType: string;
    }): Promise<import("./factors").ChallengeResult>;
    /** Begin a usernameless (discoverable) passkey login: assertion options with an
     *  empty allow-list. The owning user is resolved at `completeDiscoverableLogin`. */
    beginDiscoverableLogin(): Promise<{
        challengeToken: string;
        options: import("@simplewebauthn/server").PublicKeyCredentialRequestOptionsJSON;
    }>;
    /**
     * The passkey resolves the user and yields an AAL (synced 2, device-bound 3);
     * short of the target it returns the credentials path's step-up signal.
     */
    completeDiscoverableLogin(params: {
        clientId: string;
        input: string;
        sessionMeta: SessionMeta;
    }): Promise<OAuth2TokenResult | FlowRequiredResult>;
    /**
     * `redirectUri` must be built by the route from its own configuration, never
     * from the request. The provider row's active flag alone decides the offer.
     */
    beginFederatedLogin(params: {
        clientId: string;
        redirectUri: string;
        returnTo?: string | null;
        slug: string;
    }): Promise<{
        authorizeUrl: string;
    }>;
    /**
     * Judging before resolving keeps a refused identity from provisioning a row.
     * `clientId` is checked, never used: the bound one is authoritative.
     */
    completeFederatedLogin(params: {
        clientId: string;
        code: string;
        redirectUri: string;
        sessionMeta: SessionMeta;
        state: string;
    }): Promise<FederatedLoginResult>;
    /**
     * A tripwire on the route, not a boundary. Sequential, never `Promise.all`:
     * `TransactionManager` holds one executor per connection handler.
     */
    private assertBoundClient;
    /**
     * `ProviderIdentityError` is translated because the HTTP layer would answer
     * it with a 500; a dead round trip is already a refusal, so it is rethrown.
     */
    private runFederated;
    /**
     * One writer for both shapes, so the key set does not depend on which half
     * failed. The state token is never echoed: live, it is a credential.
     */
    private auditFederatedFailure;
    /**
     * The provider is not recorded: the only name available is the caller-chosen
     * path segment. Volume is bounded by the endpoint's per-IP bucket, not here.
     */
    auditFederatedCallbackRefusal(params: {
        ip: string | null;
        reason: FederatedCallbackRefusal;
    }): Promise<void>;
    /**
     * Audited, never counted in `auth_attempts`: that table is the brute-force
     * counter, the credential verified, and any principal here is the victim's.
     */
    private auditFederatedRefusal;
    /**
     * Pre-session: the user is mid-login and the engine flagged the step
     * `enroll`. The returned `factorId` is submitted back to the `flow` grant.
     */
    beginFlowEnroll(params: {
        flowToken: string;
        factorType: string;
    }): Promise<{
        factorId?: string;
        data?: Record<string, unknown>;
    }>;
    /**
     * The single inline-enroll confirm path — the `flow` grant itself only
     * verifies existing factors.
     */
    confirmFlowEnroll(params: {
        flowToken: string;
        factorType: string;
        factorId?: string;
        code?: string;
        challengeToken?: string;
        response?: unknown;
        label?: string;
        sessionMeta: SessionMeta;
    }): Promise<(OAuth2TokenResult | FlowRequiredResult) & {
        recoveryCodes?: string[];
    }>;
    /**
     * No session exists yet and none is issued unless the replacement lands:
     * abandoning the flow leaves the flag set and the next login prompts again.
     */
    completeFlowPasswordUpdate(params: {
        flowToken: string;
        newPassword: string;
        sessionMeta: SessionMeta;
    }): Promise<OAuth2TokenResult | FlowRequiredResult>;
    /**
     * A grace-withheld factor reports `unsatisfiable`, never `enroll`: enrolling
     * would hand the climb back to whoever holds the session.
     */
    stepUpOptions(userId: string, requiredAal: number): Promise<StepUpOffering>;
    /**
     * Through the shared `verifiableFactorsFrom`, also read by `apps/be`'s gate,
     * so "what may be submitted" has one definition on both sides.
     */
    availableStepUpFactors(userId: string, requiredAal: number): Promise<string[]>;
    /**
     * The HIGHER of the challenged level and one rung above the session. The
     * maximum makes a client-controlled number safe: it can only raise the bar.
     */
    private targetAal;
    /**
     * The achieved AAL is persisted on the session row so it survives token
     * refresh, and stamped onto a freshly issued access token.
     */
    stepUp(params: {
        clientId: string;
        sessionToken: string;
        expectedUserId: string;
        factorType: string;
        code: string;
        sessionMeta: SessionMeta;
        requiredAal?: number;
        /** The presented token's own scopes, carried onto the one this mints. */
        scopes?: string[];
    }): Promise<OAuth2TokenResult & {
        aal: number;
    }>;
    private stepUpOnHomeBase;
    /** The request's own view of the climb, for a session the write no longer found. */
    private withVerified;
    /**
     * Step UP only, never down. The level comes from the type the SERVER
     * verified — a request's `factorType` only selects which factor runs.
     */
    private elevateSession;
    /**
     * Confirming an enrollment IS a proof of possession, so no second challenge
     * follows it. A second door into the same elevation, never a weaker one.
     */
    stepUpEnroll(params: {
        clientId: string;
        sessionToken: string;
        expectedUserId: string;
        factorType: string;
        factorId?: string;
        input?: string;
        sessionMeta: SessionMeta;
        requiredAal?: number;
        /** The presented token's own scopes, carried onto the one this mints. */
        scopes?: string[];
    }): Promise<OAuth2TokenResult & {
        aal: number;
        recoveryCodes?: string[];
    }>;
    private stepUpEnrollOnHomeBase;
    /**
     * The window is the longest lockout `isLockedOut` can impose: read narrower
     * and escalated failures age out before the lockout they bought expires.
     */
    private readRecentAttempts;
    /**
     * Failures since the last success for an identifier — the CAPTCHA gate's
     * input, read from exactly the rows the lockout reads.
     */
    recentFailureCount(identifier: string): Promise<number>;
    /**
     * A flow's attempts sit in two buckets, so both are read and counted as the
     * one principal they describe. An unreadable token counts as zero.
     */
    recentFailureCountForFlow(flowToken: string): Promise<number>;
    /**
     * One principal, one bucket. The password step keeps the identifier: the
     * account may not exist, and a bucket depending on that is an oracle. With
     * no account resolved there is no account to charge either, so the typed
     * namespace takes it — never the account one, which nothing typed may reach.
     */
    private lockoutBucket;
    /** Brute-force lockout: failures since the last success within the window. */
    private assertNotLockedOut;
    /** Record one authentication attempt (lockout counting + audit). */
    private recordAttempt;
    private insertAttempt;
    resolveAuthorizePrompt(clientId: string, isBeforeConsentPage: boolean): Promise<{
        prompt: 'login' | 'consent' | 'none';
        client: any;
        idp: string;
        cookieName: string;
    }>;
    /**
     * `redirectUri` is bound into the verification-token row so the eventual
     * /token exchange can require an identical value.
     */
    createAuthorizationCode(userId: string, clientId: string, codeChallenge: string, challengeMethod: string, redirectUri?: string, scopes?: string[], authInfo?: AuthInfo): Promise<string>;
    /**
     * `homeBaseId` names the base the session lives in. The cookie's name carries
     * that base, and the client it also carries is per-base, so both are resolved
     * there rather than on the base the request addressed.
     */
    resolveCookieName(clientId: string, homeBaseId?: string): Promise<string>;
    verifyEmailByToken(identifier: string, token: string): Promise<void>;
    /**
     * Always the canonical `shortName`: `default`, the uuid and the shortName
     * name one client, so a raw argument gave three names for one session.
     */
    private getCookieName;
    /**
     * The SSO cookie shared by every client federating through `idp`, as opposed
     * to a per-client one. /authorize reads it to recognise a signed-in browser.
     */
    private getIdpCookieName;
    /**
     * `null` on any failure (signature/expiry/shape); never throws. For routes
     * needing an alternative to cookie-based session lookup.
     */
    verifyJwt(token: string): JwtPayload | null;
    getPrompt(clientId: string, originalPrompt: 'consent' | 'login' | 'none'): Promise<"consent" | "login" | "none">;
}
