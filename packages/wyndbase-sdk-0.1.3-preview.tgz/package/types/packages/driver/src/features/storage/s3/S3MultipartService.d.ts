import type { ListOptions, MultipartStore, ObjectMetadata, Part, Upload } from '../../../../../storage/src/index';
import type { WynConnectionHandler } from '../../../WynConnectionHandler';
export declare class S3MultipartService implements MultipartStore {
    private base;
    constructor(base: WynConnectionHandler);
    createUpload(bucket: string, key: string, metadata: Partial<ObjectMetadata>): Promise<string>;
    getUpload(bucket: string, uploadId: string): Promise<{
        key: string;
        metadata: Partial<ObjectMetadata>;
    } | null>;
    registerPart(_bucket: string, uploadId: string, partNumber: number, etag: string, size: number): Promise<void>;
    getPart(_bucket: string, uploadId: string, partNumber: number): Promise<{
        etag: string;
        size: number;
    } | null>;
    deleteUpload(_bucket: string, uploadId: string): Promise<void>;
    listParts(bucket: string, key: string, uploadId: string): Promise<Part[]>;
    listUploads(bucket: string, options?: ListOptions): Promise<Upload[]>;
}
