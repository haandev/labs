import type { WynConnectionHandler } from '../../WynConnectionHandler';
export declare class EventService {
    private base;
    constructor(base: WynConnectionHandler);
    /**
     * Resolves even when the write fails: a storage event is bookkeeping behind
     * the caller's own operation, and a share download must not fail because a
     * flow could not be told about it. It is reported rather than swallowed —
     * a silently missing event looks exactly like a flow that never fired.
     */
    logStorageEvent(input: {
        type: 'download' | 'upload';
        bucketId: string;
        key: string;
        metadata?: Record<string, unknown>;
    }): Promise<import("../../../../wql/src/index").WqlRows<Record<any, unknown>, import("../../../../wql/src/index").WQLOptions<boolean, boolean, boolean, import("../../../../wql/src/index").WQLExecutionMode> & {
        raw?: boolean;
        model?: import("../../../../wql/src/index").WynModel | import("../../../../wql/src/index").WynModelTree;
        skipRealtimeInvalidation?: boolean;
        skipPolyDisplay?: boolean;
    }> | null>;
}
