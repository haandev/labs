import type { DeleteResult, ListObjectsResult, ListOptions, ListStore, ListVersionsResult, ObjectMetadata, ObjectStore, TaggingStore, Tags, Version, VersionStore } from '../../../../../storage/src/index';
import type { WynConnectionHandler } from '../../../WynConnectionHandler';
export declare class S3ObjectService implements ObjectStore, ListStore, TaggingStore, VersionStore {
    private base;
    constructor(base: WynConnectionHandler);
    private dateToISOString;
    put(bucket: string, key: string, metadata: ObjectMetadata): Promise<void>;
    get(bucket: string, key: string, versionId?: string): Promise<ObjectMetadata | null>;
    delete(bucket: string, key: string, versionId?: string): Promise<DeleteResult>;
    head(bucket: string, key: string, versionId?: string): Promise<ObjectMetadata | null>;
    listObjects(bucket: string, options?: ListOptions): Promise<ListObjectsResult>;
    listObjectVersions(bucket: string, options: ListOptions): Promise<ListVersionsResult>;
    exists(bucket: string, key: string): Promise<boolean>;
    putTagging(bucket: string, key: string, tags: Tags): Promise<void>;
    getTagging(bucket: string, key: string): Promise<Tags>;
    deleteTagging(bucket: string, key: string): Promise<void>;
    createVersion(_bucket: string, _key: string): Promise<string>;
    listVersions(bucket: string, key: string): Promise<Version[]>;
    deleteVersion(bucket: string, key: string, versionId: string): Promise<void>;
    createDeleteMarker(bucket: string, key: string): Promise<string>;
}
