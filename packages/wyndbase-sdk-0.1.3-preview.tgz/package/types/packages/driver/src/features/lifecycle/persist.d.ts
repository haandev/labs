/**
 * Persists a model tree via raw SQL — WQL's spread skips the implicit `_id`
 * PK that parent-child integrity here depends on.
 */
import type { WynModel } from '../../../../model/src/types';
import type { WynConnectionHandler } from '../../WynConnectionHandler';
/** Persist all model definitions to system.models. */
export declare function persistModelTree(base: WynConnectionHandler, structure?: WynModel): Promise<void>;
