import type { NamedQueryFacts } from './facts';
export type Severity = 'error' | 'warn';
export interface Diagnostic {
    ruleId: string;
    severity: Severity;
    message: string;
}
export interface NamedQueryRule {
    id: string;
    severity: Severity;
    applies(facts: NamedQueryFacts): boolean;
    message(facts: NamedQueryFacts): string;
}
/**
 * Rules are data so that adding one is a row rather than a traversal. Each
 * reads `NamedQueryFacts`; none walks the syntax tree itself.
 */
export declare const NAMED_QUERY_RULES: readonly NamedQueryRule[];
