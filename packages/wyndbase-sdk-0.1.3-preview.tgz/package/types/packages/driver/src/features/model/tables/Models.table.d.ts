/**
 * ## Module: Models Table Initialization
 *
 * This module defines the `models` system table, which is created for every
 * individual database.
 *
 * Purpose:
 *
 * - The `models` table stores metadata definitions for entities (models) within a
 *   specific database.
 * - It enables introspection, dynamic schema generation, and model management per
 *   database.
 *
 * Notes:
 *
 * - One `models` table is created per database.
 */
declare const factory: () => {
    children: ({
        isSystem: boolean;
        metadata: {
            allowFilter?: undefined;
            onDelete?: undefined;
            targetTables?: undefined;
            schema?: undefined;
            notNull: boolean;
            type: string;
            mirrorColumns?: undefined;
        };
        name: string;
        physicalName: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            schema?: undefined;
            notNull?: undefined;
            allowFilter: boolean;
            mirrorColumns: {
                canHaveMultiple: boolean;
                name: string;
                table: string;
            }[];
            onDelete: string;
            targetTables: {
                table: string;
            }[];
            type: string;
        };
        name: string;
        physicalName: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            onDelete?: undefined;
            targetTables?: undefined;
            schema?: undefined;
            mirrorColumns?: undefined;
            allowFilter: boolean;
            notNull: boolean;
            type: string;
        };
        name: string;
        physicalName: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            allowFilter?: undefined;
            onDelete?: undefined;
            targetTables?: undefined;
            schema?: undefined;
            notNull?: undefined;
            mirrorColumns?: undefined;
            type: string;
        };
        name: string;
        physicalName: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            allowFilter?: undefined;
            onDelete?: undefined;
            targetTables?: undefined;
            notNull?: undefined;
            mirrorColumns?: undefined;
            schema: {
                additionalProperties: boolean;
                type: string;
            };
            type: string;
        };
        name: string;
        physicalName: string;
        type: 'column';
    } | {
        isSystem: boolean;
        metadata: {
            onDelete?: undefined;
            targetTables?: undefined;
            schema?: undefined;
            notNull?: undefined;
            mirrorColumns?: undefined;
            allowFilter: boolean;
            type: string;
        };
        name: string;
        physicalName: string;
        type: 'column';
    })[];
    folder: string;
    isSystem: boolean;
    metadata: {
        displayFieldId: string;
    };
    name: string;
    physicalName: string;
    type: 'table';
};
export default factory;
export type ModelsType = {
    _id: string;
    physicalName: string;
    parent: string | null;
    type: string;
    isSystem: boolean;
    isDynamic: boolean | null;
    name: string;
    displayName: string | null;
    description: string | null;
    metadata: Record<string, any> | null;
    folder: string | null;
    ordinal: number | null;
};
