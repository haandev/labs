import type { FederatedRule, ProviderIdentity } from '../../../../../shared/src/auth-factors/index';
import { UnauthenticatedError } from '../../../errors/Unauthenticated';
import type { WynConnectionHandler } from '../../../WynConnectionHandler';
export type PkcePair = {
    challenge: string;
    method: 'S256';
    verifier: string;
};
/**
 * `S256` and never `plain`: a `plain` challenge *is* the verifier, so anyone who
 * saw the authorize request can complete the exchange.
 */
export declare function createPkcePair(): Promise<PkcePair>;
/**
 * An opaque 256-bit token for the `state` reference and the nonce. Both are
 * guessing targets, so nothing derived from a clock, a counter or the person.
 */
export declare function randomToken(): string;
/**
 * No `login_hint`, no email, no flow token: a query string is read by proxies,
 * browser history and referrers. @throws when the endpoint is not https.
 */
export declare function buildAuthorizeUrl(params: {
    authorizeEndpoint: string;
    challenge: string;
    clientId: string;
    nonce: string;
    redirectUri: string;
    scopes: readonly string[];
    state: string;
}): string;
/**
 * A provider row as the sign-in path reads it. It carries the decrypted client
 * secret, so never hand one of these to a client.
 */
export type FederatedProviderRow = {
    _id: string;
    allowAutoLink: boolean;
    clientId: string;
    clientSecret: string | null;
    defaultDecision: string;
    displayName: string;
    isActive: boolean;
    issuer: string | null;
    providerType: string;
    rules: FederatedRule[] | null;
    scopes: string[] | null;
    slug: string;
    sortOrder: number;
};
export type FederatedCallbackResult = {
    clientId: string;
    identity: ProviderIdentity;
    provider: FederatedProviderRow;
    returnTo: string | null;
};
/**
 * One message for every unusable round trip: telling them apart would answer
 * whether a given state token was ever real, and the remedy is the same anyway.
 */
export declare const ROUND_TRIP_DEAD = "This sign-in attempt is no longer valid";
/** For the audit row and nothing else; none of it reaches the person. */
export type RoundTripDeadReason = 'state_unresolved' | 'handoff_expired' | 'redirect_uri_mismatch' | 'provider_inactive' | 'client_mismatch';
/**
 * `reason` is non-enumerable so `JSON.stringify`, a spread into a response body
 * and log helpers cannot carry it back to whoever is knocking.
 */
export declare class RoundTripDeadError extends UnauthenticatedError {
    readonly reason: RoundTripDeadReason;
    readonly providerId: string | null;
    constructor(reason: RoundTripDeadReason, providerId?: string | null);
}
/**
 * The two legs of a federated sign-in, stateful only through the handoff row, so
 * they may be served by different processes. Every failure here throws.
 */
export declare class FederatedService {
    private readonly base;
    constructor(base: WynConnectionHandler);
    /**
     * The order is load-bearing: an unknown or inactive provider and an
     * undiscoverable issuer are both refused before any handoff row exists.
     */
    begin(params: {
        clientId: string;
        redirectUri: string;
        returnTo?: string | null;
        slug: string;
    }): Promise<{
        authorizeUrl: string;
    }>;
    /**
     * The consume is first and unconditional, so every later refusal lands on a
     * round trip already spent — one restart for a person, no oracle for a guesser.
     */
    resolveIdentity(params: {
        code: string;
        redirectUri: string;
        state: string;
    }): Promise<FederatedCallbackResult>;
    /**
     * The `id_token` and nothing else — `userinfo` says only "whoever holds this
     * bearer token", and the nonce is what ties a valid token to *this* sign-in.
     */
    private identityFromOidc;
}
