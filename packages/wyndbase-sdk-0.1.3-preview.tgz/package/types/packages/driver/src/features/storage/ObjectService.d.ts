import type { WynConnectionHandler } from '../../WynConnectionHandler';
import type { TBulkDeleteResult, TBulkDeleteTargets, TStorageListResponse } from './schemas';
export declare class ObjectService {
    private base;
    private static readonly HEAD_CONCURRENCY;
    constructor(base: WynConnectionHandler);
    list(bucketId: string, options?: {
        prefix?: string;
    }): Promise<TStorageListResponse>;
    /** `null` when the object vanished between the listing and the head. */
    private storedContentType;
    presignedPutObject(bucketId: string, key: string): Promise<string>;
    presignedGetObject(bucketId: string, key: string): Promise<string>;
    /**
     * Removes an object unless a live table row still references it — the one
     * guard behind both delete surfaces, checked before the S3 delete is issued.
     */
    delete(bucketId: string, key: string): Promise<import("@aws-sdk/client-s3").DeleteObjectCommandOutput>;
    /**
     * The guard lives here, not in `delete`, because `deleteMany` needs the
     * identical rule — this keeps both callers from re-implementing it.
     */
    private deleteGuarded;
    /**
     * Every key under a prefix, at any depth. Deliberately no `Delimiter` — a
     * folder's `.keep` marker must count. Paginated: a page caps at 1000 keys.
     */
    private listAllKeys;
    /**
     * Emptying a bucket is this call with the empty prefix, not a separate path.
     * A refusal is recorded per key; any other fault rethrows via `BulkDeleteInterruptedError`.
     */
    deleteMany(bucketId: string, targets: TBulkDeleteTargets): Promise<TBulkDeleteResult>;
    createMultipartUpload(bucketId: string, key: string): Promise<{
        uploadId: string;
    }>;
    presignedUploadPart(bucketId: string, key: string, uploadId: string, partNumber: number): Promise<string>;
    completeMultipartUpload(bucketId: string, key: string, uploadId: string, parts: Array<{
        partNumber: number;
        etag: string;
    }>): Promise<void>;
    abortMultipartUpload(bucketId: string, key: string, uploadId: string): Promise<void>;
    /**
     * The object's bytes, for a server-side reader. Every other read hands out a
     * presigned URL, which a browser fetches immediately — no use to a consumer
     * that has to embed the content rather than link to it.
     */
    get(bucketId: string, key: string): Promise<{
        body: Uint8Array;
        contentType: string | null;
    }>;
    headObject(bucketId: string, key: string): Promise<import("@aws-sdk/client-s3").HeadObjectCommandOutput>;
    /**
     * The single place a bucket identifier fails to resolve, so the answer
     * can't drift between routes. A missing device is a broken config, not caller error.
     */
    private getBucketAndClient;
}
