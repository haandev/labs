import type { WynConnectionHandler } from '../../WynConnectionHandler';
/**
 * What a caller does when the token names a base nothing can be opened for.
 * Distinct from a thrown error, which stays an outage.
 */
export declare const BASE_UNRESOLVED: unique symbol;
/** What `withTokenHomeBase` needs to open a base other than the request's own. */
export type BaseOpener = {
    base(baseId: string): Promise<WynConnectionHandler>;
    mainBase(): Promise<WynConnectionHandler>;
};
/**
 * Whether the base a token names is the one the request already holds. The
 * main base answers to two spellings, so an id-only comparison opens a second
 * handler onto the base already in hand.
 */
export declare function tokenNamesRequestBase(requestBase: WynConnectionHandler | undefined, tokenBaseId: string | undefined): boolean;
/**
 * Runs `use` against the base a token names rather than the base the request
 * targets — sessions live per-base, so reading the wrong one always answers
 * "missing". Reuses the caller's handler when it already serves that base, and
 * disposes only a handler it opened itself.
 *
 * @throws anything but "base not found" — an outage must not read as missing.
 */
export declare function withTokenHomeBase<T>(opener: BaseOpener, tokenBaseId: string | undefined, requestBase: WynConnectionHandler | undefined, use: (home: WynConnectionHandler) => Promise<T>): Promise<T | typeof BASE_UNRESOLVED>;
