/**
 * What the queue reports about itself, and how.
 *
 * The driver cannot import a metrics library — `prom-client` is a backend
 * dependency — so this is the same two-way indirection the realtime hub uses:
 * cheap callbacks for what happens as it happens, and a plain-data snapshot
 * for what has to be sampled.
 *
 * Durations cross this boundary in **milliseconds**. The backend divides where
 * it observes, matching the realtime hub, so the unit is the same on both
 * sides of every one of these calls.
 */
/**
 * Why one pass over one queue ended. `empty` is the healthy one — the base was
 * drained. Everything else means rows were left behind, and which one it was
 * says what to change: `budget` and `deadline` are the worker's own caps,
 * `saturated` is the in-flight limit on actions, `stopping` is shutdown,
 * `error` is a pass that threw rather than finished, and `claim-failed` is a
 * claim that could not be issued at all.
 *
 * `claim-failed` exists because the claim answers a failure as an empty queue
 * — deliberately, so a broken base cannot spin — and without it a base failing
 * every claim would report itself drained for ever. That is the one reading a
 * measurement must never get wrong.
 */
export type PassEndReason = 'budget' | 'claim-failed' | 'deadline' | 'empty' | 'error' | 'saturated' | 'stopping';
export interface QueueObserver {
    /**
     * One pass over one of a base's two queues ended. Exactly one of these fires
     * per pass, so the reasons partition the passes and a rate over them is
     * meaningful.
     *
     * Reported rather than logged because the distribution is the number that
     * matters: a base whose passes end on `empty` is keeping up, and one whose
     * passes end on `budget` or `saturated` is being rationed by a constant
     * somebody chose.
     */
    onPassEnded?: (baseId: string, queue: 'events' | 'jobs', reason: PassEndReason) => void;
    /**
     * One drain of one base: how long it took, and how much it moved. Fires
     * whether or not it moved anything, because a base that drains constantly
     * and moves nothing is the shape worth seeing.
     */
    onDrain?: (baseId: string, durationMs: number, jobsRun: number, eventsRun: number) => void;
    /**
     * A job was settled. `latencyMs` is enqueue to execution — the number a
     * person waiting on a webhook actually feels — measured from the row's
     * arrival, not from the claim.
     *
     * `retried` is not terminal, and a job that retries is reported again on
     * every later attempt and once more when it truly ends. That is why the
     * outcome is a label rather than a note: the three distributions are only
     * meaningful apart, and summing them would double-count a retried job.
     */
    onJobSettled?: (baseId: string, outcome: 'completed' | 'failed' | 'retried', latencyMs: number | null) => void;
    /** One flow-event node advanced, with the same enqueue-to-execution reading. */
    onEventAdvanced?: (baseId: string, latencyMs: number | null) => void;
    /**
     * The safety net caught something the wake substrate missed: a sweep found a
     * base with work that nothing had woken it for. This is the number that says
     * whether the wake path is trustworthy, so it is counted rather than logged.
     */
    onSweepRecovery?: (baseId: string) => void;
    /** Leases returned to the queue because their worker never came back. */
    onLeaseReclaimed?: (baseId: string, count: number) => void;
    /**
     * Finished rows retention removed on one sweep. Counted rather than logged
     * because the question it answers — is anything being reclaimed at all — is
     * one an operator asks of a graph, and because a base that is never quiet
     * never reaches this at all.
     */
    onRetention?: (baseId: string, removed: number) => void;
}
/**
 * What one queue table is physically carrying. Dead rows are the cost of the
 * churn — every claim, lease and settle leaves one behind — and the size is
 * what that cost has turned into on disk, indexes and TOAST included.
 */
export interface QueueTableStats {
    bytes: number;
    deadRows: number;
    liveRows: number;
}
/**
 * What is holding vacuum back on a base's database. `0` means nothing is;
 * sessions and prepared transactions are this database's, slots the cluster's.
 */
export interface VacuumHorizon {
    /**
     * Oldest client transaction still holding a snapshot or transaction id,
     * idle-in-transaction included. A transaction with neither holds nothing
     * back and does not count, however long it has been open.
     */
    sessionAgeMs: number;
    /** Oldest prepared transaction on this database. */
    preparedAgeMs: number;
    /** Oldest replication-slot `xmin`, as a transaction-id age; slots have no clock. */
    slotXidAge: number;
}
/**
 * What one base's queues look like right now. Sampled on the sweep rather than
 * on demand: a depth is two database counts, and answering them inside a
 * metrics scrape would put one round trip per base into an endpoint that has
 * no timeout of its own.
 */
export interface QueueDepthSnapshot {
    /** Queued jobs, including those waiting out a backoff. */
    pendingJobs: number;
    /** Jobs the claim would serve right now. */
    runnableJobs: number;
    /** Unfinished flow events, blocked ones included. */
    queuedEvents: number;
    /** Events the claim would serve right now — blocked ones excluded. */
    runnableEvents: number;
    /**
     * How long the oldest thing the worker is *allowed* to run has been waiting,
     * in milliseconds — `null` when there is nothing runnable. Deliberately not
     * the oldest queued row: a job waiting out its backoff and an event parked
     * on an unanswered blocker are both queued and neither is late.
     */
    oldestRunnableAgeMs: number | null;
    /**
     * The two queue tables' physical state, keyed by table name. Absent when the
     * catalogue could not be read — which is not the same as a table carrying
     * nothing, and is reported as absent rather than as zero.
     */
    tables?: Record<string, QueueTableStats>;
    /** Absent when the catalogue could not be read — not the same as nothing held. */
    horizon?: VacuumHorizon;
    /** When this reading was taken, so a stale one can be recognised. */
    sampledAt: Date;
}
