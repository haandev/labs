import type { EmailProviderTypeName } from '../../../../../shared/src/email-providers';
import type { EmailProviderSpec } from './types';
export declare const EMAIL_PROVIDER_TYPES: Readonly<Record<EmailProviderTypeName, EmailProviderSpec>>;
export declare function isEmailProviderTypeName(name: string): name is EmailProviderTypeName;
/** Null for a name this build does not know — a caller mid-send cannot afford
 *  an exception. */
export declare function findEmailProviderType(name: string): EmailProviderSpec | null;
/** For a caller that has already established the name is valid. */
export declare function emailProviderTypeOf(name: string): EmailProviderSpec;
export type { ConfigFieldDescriptor, EmailProviderDescriptor, EmailProviderTypeName, } from '../../../../../shared/src/email-providers';
export type { EmailProviderSpec, OutboundMessage, ProviderSecret, } from './types';
