import type { WynConnectionHandler } from '../../WynConnectionHandler';
import { type AlertWarning, type CreateAlertBody, type UpdateAlertBody } from './schemas/AlertSchema';
type TrackingEntry = {
    tables?: string[];
};
type AlertRow = Record<string, unknown> & {
    _id: string;
    ownerId?: string;
    trackingEntries?: TrackingEntry[];
    warnings?: AlertWarning[];
    description?: string | null;
    lastError?: string | null;
};
/** Names only the one method `AlertService` calls on the alert evaluator. */
export type AlertCacheInvalidator = {
    invalidateCache(baseId: string): Promise<boolean>;
};
/** Runs at driver privilege, but always scopes writes to the caller's `_id`. */
export declare class AlertService {
    private base;
    private readonly alertCache;
    constructor(base: WynConnectionHandler, alertCache: AlertCacheInvalidator);
    private ownerId;
    create(body: CreateAlertBody): Promise<AlertRow | null>;
    update(alertId: string, patch: UpdateAlertBody): Promise<AlertRow | null>;
    /**
     * Reads the row directly rather than widening `system.getAlert`, whose
     * projection reaches the client — tracking entries carry inlined filter values.
     */
    accessWarnings(alertId: string): Promise<AlertWarning[]>;
    delete(alertId: string): Promise<void>;
    pause(alertId: string): Promise<AlertRow | null>;
    /**
     * A stale alert is excluded from `system.listActiveReactiveAlerts`, so
     * flipping `isActive` alone would leave it unarmed — re-derive first.
     */
    resume(alertId: string): Promise<AlertRow | null>;
    /**
     * Intersects in JS because jsonb-array intersection is not expressible in a
     * WQL FILTER. Dev-time model-change hook, not a hot path.
     */
    flagStaleAlertsForTables(changedTables: string[]): Promise<void>;
    /** Re-deriving also resets the alert to `unknown` and clears its error count. */
    private deriveAndReplaceTracking;
    /**
     * `claimAlertFiring` enforces `isActive`, so this is inert on a paused alert:
     * editing a paused alert's query must not notify.
     */
    private recordInitialState;
    private setActive;
    private invalidateAlertCache;
    private applyMetadata;
    private getOwned;
    private emitFired;
    private validateAndDeriveTracking;
    private ownerAccessWarnings;
    private withWarnings;
}
export {};
