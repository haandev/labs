/**
 * ## Module: Storage Objects Table
 *
 * This module defines the `storage_objects` table for S3-compatible storage.
 *
 * Purpose:
 * - Stores S3 object metadata
 * - Tracks object keys, sizes, ETags, and content types
 *
 * Notes:
 * - One `storage_objects` table is created per database
 * - The actual file content is stored on disk/S3, this table only stores metadata
 */
export declare const STORAGE_OBJECTS_TABLE = "storage_objects";
declare const factory: () => {
    children: ({
        displayName: string;
        isSystem: boolean;
        metadata: {
            schema?: undefined;
            defaultValue?: undefined;
            allowFilter: boolean;
            notNull: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        displayName?: undefined;
        isSystem: boolean;
        metadata: {
            schema?: undefined;
            allowFilter?: undefined;
            defaultValue?: undefined;
            notNull: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        displayName?: undefined;
        isSystem: boolean;
        metadata: {
            schema?: undefined;
            allowFilter?: undefined;
            defaultValue: string;
            notNull: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        displayName?: undefined;
        isSystem: boolean;
        metadata: {
            notNull?: undefined;
            allowFilter?: undefined;
            defaultValue?: undefined;
            schema: {
                additionalProperties: boolean;
                type: string;
            };
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        displayName?: undefined;
        isSystem: boolean;
        metadata: {
            notNull?: undefined;
            schema?: undefined;
            allowFilter?: undefined;
            defaultValue?: undefined;
            type: string;
        };
        name: string;
        type: 'column';
    })[];
    displayName: string;
    folder: string;
    isSystem: boolean;
    name: string;
    type: 'table';
};
export default factory;
type Type = {
    _id: string;
    bucket: string;
    key: string;
    size: number;
    etag: string;
    contentType: string;
    lastModified: Date;
    metadata: Record<string, string> | null;
    expiresAt: Date | null;
};
export type StorageObjectsType = Omit<Type, 'metadata' | 'expiresAt' | 'lastModified'> & {
    metadata: Record<string, string> | null;
    expiresAt: Date | null;
    lastModified: Date;
};
