import type { Bucket, BucketMetadata, BucketStore, VersioningBucketStore } from '../../../../../storage/src/index';
import type { WynConnectionHandler } from '../../../WynConnectionHandler';
export declare class S3BucketService implements BucketStore, VersioningBucketStore {
    private base;
    constructor(base: WynConnectionHandler);
    create(name: string): Promise<void>;
    delete(name: string): Promise<void>;
    list(): Promise<Bucket[]>;
    exists(name: string): Promise<boolean>;
    getMetadata(name: string): Promise<BucketMetadata | null>;
    setVersioning(bucket: string, status: 'Enabled' | 'Suspended'): Promise<void>;
    getVersioning(bucket: string): Promise<'Enabled' | 'Suspended' | null>;
}
