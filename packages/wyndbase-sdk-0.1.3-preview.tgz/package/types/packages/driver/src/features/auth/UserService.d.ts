import type { WynConnectionHandler } from '../../WynConnectionHandler';
import { type NotifyOutcome } from './notify';
export declare class UserService {
    private base;
    private userId;
    constructor(base: WynConnectionHandler, userId: string);
    /**
     * Who authenticated, not whose account this is: on a token path nobody did,
     * and naming the owner there asserts something the trail cannot support.
     */
    private get actorUserId();
    getSessions(): Promise<import("../../../../wql/src/index").WqlRows<{
        _id: string;
        revokedAt: (string | null);
        device: (string | null);
        browser: (string | null);
        os: (string | null);
        clientInfo: {
            _id: string;
            name: string;
            shortName: string;
        }[];
    } & Record<any, unknown>, import("../../../../wql/src/index").WQLOptions<boolean, boolean, boolean, import("../../../../wql/src/index").WQLExecutionMode> & {
        raw?: boolean;
        model?: import("../../../../wql/src/index").WynModel | import("../../../../wql/src/index").WynModelTree;
        skipRealtimeInvalidation?: boolean;
        skipPolyDisplay?: boolean;
    }>>;
    getEmails(): Promise<import("../../../../wql/src/index").WqlRows<{
        _id: string;
        email: string;
        verified: (string | null);
        primary: (boolean | null);
    } & Record<any, unknown>, import("../../../../wql/src/index").WQLOptions<boolean, boolean, boolean, import("../../../../wql/src/index").WQLExecutionMode> & {
        raw?: boolean;
        model?: import("../../../../wql/src/index").WynModel | import("../../../../wql/src/index").WynModelTree;
        skipRealtimeInvalidation?: boolean;
        skipPolyDisplay?: boolean;
    }>>;
    /**
     * `system.getMe` runs unpolicied, and `policyContext` derives the identity
     * only for a policied statement — so this call has to resolve it itself or
     * the projected `isPlatformUser` would come back unbound.
     */
    getMe(): Promise<{
        _id: string;
        name: (string | null);
        givenName: (string | null);
        familyName: (string | null);
        username: (string | null);
        picture: string[];
        zoneinfo: (string | null);
        createdAt: string;
        isPlatformUser: unknown;
        emails: {
            _id: string;
            email: string;
            primary: (boolean | null);
            verified: (string | null);
        }[];
    } & Record<any, unknown>>;
    getLastLoginSession(): Promise<{
        _id: string;
        createdAt: string;
        device: (string | null);
        os: (string | null);
        browser: (string | null);
    } & Record<any, unknown>>;
    revokeSession(sessionId: string): Promise<import("../../../../wql/src/index").WqlRows<Record<any, unknown>, import("../../../../wql/src/index").WQLOptions<boolean, boolean, boolean, import("../../../../wql/src/index").WQLExecutionMode> & {
        raw?: boolean;
        model?: import("../../../../wql/src/index").WynModel | import("../../../../wql/src/index").WynModelTree;
        skipRealtimeInvalidation?: boolean;
        skipPolyDisplay?: boolean;
    }>>;
    revokeAllSessions(exceptSessionId?: string): Promise<import("../../../../wql/src/index").WqlRows<Record<any, unknown>, import("../../../../wql/src/index").WQLOptions<boolean, boolean, boolean, import("../../../../wql/src/index").WQLExecutionMode> & {
        raw?: boolean;
        model?: import("../../../../wql/src/index").WynModel | import("../../../../wql/src/index").WynModelTree;
        skipRealtimeInvalidation?: boolean;
        skipPolyDisplay?: boolean;
    }>>;
    /** Session ids are live credentials and stay out of the audit trail. */
    private recordRevocation;
    getSessionCount(): Promise<number>;
    /**
     * An address added here is never primary; promotion goes through
     * `updateEmail`, which only promotes a verified address. An address another
     * account holds is added all the same, so the answer reveals nothing.
     */
    addEmail(email: string, verified?: Date | null): Promise<{
        _id: string;
        email: string;
        verified: (string | null);
        primary: (boolean | null);
        user: (string | null);
        createdAt: string;
        updatedAt: string;
        createdBy: (string | null);
        updatedBy: (string | null);
    } & Record<any, unknown>>;
    sendEmailConfirmationLink(emailId: string): Promise<NotifyOutcome>;
    /**
     * A partial update: a property the caller omits is left alone, not cleared.
     * Dropping the primary flag is `system.unprimaryEmails`.
     */
    updateEmail(emailId: string, updates: {
        verified?: Date;
        primary?: boolean;
    }): Promise<import("../../../../wql/src/index").WqlRows<Record<any, unknown>, import("../../../../wql/src/index").WQLOptions<boolean, boolean, boolean, import("../../../../wql/src/index").WQLExecutionMode> & {
        raw?: boolean;
        model?: import("../../../../wql/src/index").WynModel | import("../../../../wql/src/index").WynModelTree;
        skipRealtimeInvalidation?: boolean;
        skipPolyDisplay?: boolean;
    }>>;
    private releaseAddressElsewhere;
    removeEmail(emailId: string): Promise<import("../../../../wql/src/index").WqlRows<Record<any, unknown>, import("../../../../wql/src/index").WQLOptions<boolean, boolean, boolean, import("../../../../wql/src/index").WQLExecutionMode> & {
        raw?: boolean;
        model?: import("../../../../wql/src/index").WynModel | import("../../../../wql/src/index").WynModelTree;
        skipRealtimeInvalidation?: boolean;
        skipPolyDisplay?: boolean;
    }>>;
    setPrimaryEmail(emailId: string): Promise<import("../../../../wql/src/index").WqlRows<Record<any, unknown>, import("../../../../wql/src/index").WQLOptions<boolean, boolean, boolean, import("../../../../wql/src/index").WQLExecutionMode> & {
        raw?: boolean;
        model?: import("../../../../wql/src/index").WynModel | import("../../../../wql/src/index").WynModelTree;
        skipRealtimeInvalidation?: boolean;
        skipPolyDisplay?: boolean;
    }>>;
    verifyEmail(emailId: string): Promise<import("../../../../wql/src/index").WqlRows<Record<any, unknown>, import("../../../../wql/src/index").WQLOptions<boolean, boolean, boolean, import("../../../../wql/src/index").WQLExecutionMode> & {
        raw?: boolean;
        model?: import("../../../../wql/src/index").WynModel | import("../../../../wql/src/index").WynModelTree;
        skipRealtimeInvalidation?: boolean;
        skipPolyDisplay?: boolean;
    }>>;
    getEmailCount(): Promise<number>;
    changePassword(currentPassword: string, newPassword: string): Promise<{
        status: string;
        factorType: import("../../../../shared/src/auth-factors/index").FactorType;
        replaced?: boolean;
        label?: string | null;
    }>;
    /**
     * Enrolls a password for a user who has none. Changing an existing one must
     * go through `changePassword`, which verifies the current password first.
     */
    setPassword(newPassword: string): Promise<{
        status: string;
        factorType: import("../../../../shared/src/auth-factors/index").FactorType;
        replaced?: boolean;
        label?: string | null;
    }>;
}
