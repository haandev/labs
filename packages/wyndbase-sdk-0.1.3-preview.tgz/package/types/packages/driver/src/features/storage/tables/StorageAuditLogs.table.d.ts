/**
 * ## Module: Storage Audit Logs Table
 *
 * This module defines the `storage_audit_logs` table for S3 storage auditing.
 *
 * Purpose:
 * - Logs all storage operations (uploads, downloads, deletes)
 * - Tracks authentication attempts
 * - Provides audit trail for compliance and debugging
 *
 * Notes:
 * - One `storage_audit_logs` table is created per database
 * - Logs are immutable - no updates or deletes
 */
export declare const STORAGE_AUDIT_LOGS_TABLE = "storage_audit_logs";
declare const factory: () => {
    children: ({
        displayName: string;
        isSystem: boolean;
        metadata: {
            schema?: undefined;
            defaultValue: string;
            notNull: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        displayName: string;
        isSystem: boolean;
        metadata: {
            schema?: undefined;
            defaultValue?: undefined;
            notNull: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        displayName?: undefined;
        isSystem: boolean;
        metadata: {
            notNull?: undefined;
            schema?: undefined;
            defaultValue?: undefined;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        displayName?: undefined;
        isSystem: boolean;
        metadata: {
            schema?: undefined;
            defaultValue?: undefined;
            notNull: boolean;
            type: string;
        };
        name: string;
        type: 'column';
    } | {
        displayName?: undefined;
        isSystem: boolean;
        metadata: {
            notNull?: undefined;
            defaultValue?: undefined;
            schema: {
                additionalProperties: boolean;
                type: string;
            };
            type: string;
        };
        name: string;
        type: 'column';
    })[];
    displayName: string;
    folder: string;
    isSystem: boolean;
    name: string;
    type: 'table';
};
export default factory;
type Type = {
    _id: string;
    timestamp: string;
    action: string;
    bucket: string | null;
    key: string | null;
    accessKey: string | null;
    status: string;
    statusCode: number | null;
    size: number | null;
    ipAddress: string | null;
    userAgent: string | null;
    metadata: Record<string, any> | null;
};
export type StorageAuditLogsType = Omit<Type, 'timestamp'> & {
    timestamp: Date;
};
