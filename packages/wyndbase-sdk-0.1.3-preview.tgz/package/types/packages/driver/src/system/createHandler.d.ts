/**
 * ## Module: Handler Initialization
 *
 * Creates a new WynConnectionHandler with the system space definition attached as a plain object.
 * No class tree construction — SystemSpace() returns a plain SpaceNode.
 *
 * Example:
 *
 * ```typescript
 * const handler = createHandler({ name: 'my-base' })
 * await initializeDatabase(handler)
 * ```
 */
import type { BaseNode } from '../../../model/src/types';
import type { CreationAttributes } from '../schema/ModelSchema';
import { WynConnectionHandler } from '../WynConnectionHandler';
export default _default;
declare function _default(attributes: CreationAttributes<BaseNode>): WynConnectionHandler;
