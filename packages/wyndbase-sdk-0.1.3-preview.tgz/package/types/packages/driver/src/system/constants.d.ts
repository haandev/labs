declare let DATABASE: string;
export { DATABASE };
export declare const SYSTEM_SPACE = "system";
export declare const MODELS_TABLE = "models";
export declare const MODELS_TABLE_FULL_NAME = "system.models";
export { MAINTENANCE_BASE_ID } from '../../../shared/src/main-base';
/**
 * Server-side bound on a runaway statement; applied as a connection startup
 * parameter so it holds on every pool member.
 */
export declare const STATEMENT_TIMEOUT = "30s";
/**
 * Server-side bound on a connection idling inside an open transaction. No
 * engine path leaves one idle for more than seconds; a longer idle is a leak.
 */
export declare const IDLE_IN_TRANSACTION_TIMEOUT = "60s";
export declare const MAINTENANCE_SCAN_CONCURRENCY = 3;
