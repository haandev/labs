export declare const BASES_TABLE = "bases";
declare const factory: () => {
    children: ({
        isSystem: boolean;
        metadata: {
            schema?: undefined;
            defaultValue?: undefined;
            allowFilter: boolean;
            notNull: boolean;
            type: string;
        };
        name: string;
        physicalName: string;
        type: 'column';
    } | {
        isSystem?: undefined;
        metadata: {
            schema?: undefined;
            defaultValue?: undefined;
            allowFilter: boolean;
            notNull: boolean;
            type: string;
        };
        name: string;
        physicalName: string;
        type: 'column';
    } | {
        isSystem?: undefined;
        metadata: {
            allowFilter?: undefined;
            schema?: undefined;
            notNull?: undefined;
            defaultValue: boolean;
            type: string;
        };
        name: string;
        physicalName: string;
        type: 'column';
    } | {
        isSystem?: undefined;
        metadata: {
            allowFilter?: undefined;
            schema?: undefined;
            defaultValue?: undefined;
            notNull?: undefined;
            type: string;
        };
        name: string;
        physicalName: string;
        type: 'column';
    } | {
        isSystem?: undefined;
        metadata: {
            allowFilter?: undefined;
            defaultValue?: undefined;
            notNull?: undefined;
            schema: {
                additionalProperties: boolean;
                type: string;
            };
            type: string;
        };
        name: string;
        physicalName: string;
        type: 'column';
    } | {
        isSystem?: undefined;
        metadata: {
            schema?: undefined;
            defaultValue?: undefined;
            notNull?: undefined;
            allowFilter: boolean;
            type: string;
        };
        name: string;
        physicalName: string;
        type: 'column';
    })[];
    displayName: string;
    isSystem: boolean;
    name: string;
    physicalName: string;
    type: 'table';
};
export default factory;
