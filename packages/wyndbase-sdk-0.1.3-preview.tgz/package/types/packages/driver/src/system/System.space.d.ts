import '../features/cache/CacheService';
import '../features/auth/user/getMeOnHomeBase';
export default _default;
declare function _default(): Record<string, any>;
