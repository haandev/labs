/**
 * ## Module: Maintenance Base Initialization
 *
 * Creates the central maintenance base. Uses EmptyBase which attaches
 * the full system space definition (including bases table) as plain objects.
 */
import type { BaseNode } from '../../../model/src/types';
import type { CreationAttributes } from '../schema/ModelSchema';
/**
 * The platform base as it exists before `system.bases` holds a row for it:
 * `initialize()` builds the base from this and then inserts the row from it.
 *
 * It is a bootstrap answer and nothing more. Every other read of the platform
 * base goes through the row, because the columns an administrator can change —
 * `allowSelfRegistration`, `allowAnonymousAccess`, `displayName` — do not exist
 * here and a handler built from this literal reports them all absent.
 */
export declare const MAIN_BASE_DEFINITION: CreationAttributes<BaseNode>;
export default _default;
declare function _default(): import("../WynConnectionHandler").WynConnectionHandler;
