import type { BaseNode } from '../../../model/src/types';
import type { CreationAttributes } from '../schema/ModelSchema';
import { WynConnectionHandler } from '../WynConnectionHandler';
import type { ConnectionLane } from '../wyndbase';
/**
 * Only place a stored-without-icon base gets this default; duplicating it
 * elsewhere risks a read path silently returning `undefined` instead.
 */
export declare const DEFAULT_BASE_ICON = "server-filled";
export default _default;
declare function _default(attributes: CreationAttributes<BaseNode>, lane?: ConnectionLane): WynConnectionHandler;
