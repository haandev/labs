/**
 * ## Module: Maintenance Handler Initialization
 *
 * Creates the central maintenance handler. Uses createHandler which attaches
 * the full system space definition (including bases table) as plain objects.
 */
export default _default;
declare function _default(): import("../WynConnectionHandler").WynConnectionHandler;
