import type { BaseNode, BaseSchema } from '../../model/src/types';
import { SQL } from 'bun';
import type { ConnectionLane } from './ConnectionSource';
import { AlertEvaluator } from './features/alert/AlertEvaluator';
import { AlertRetracker } from './features/alert/AlertRetracker';
import { type EmailProviderInput } from './features/email';
import { PollingService } from './features/job-queue/PollingService';
import { RealtimeHub } from './features/realtime/RealtimeHub';
import type { LocalS3Dispatch } from './features/storage/localS3Dispatch';
import type { WynConnectionHandler } from './WynConnectionHandler';
/** Whether the cluster holds a finished installation, debris from a dead attempt, or nothing. */
export type InstallationState = 'absent' | 'incomplete' | 'complete';
/** Optional `emailProvider`: an installation with no mail provider is valid. */
export type InstallationParams = {
    owner: {
        email: string;
        name?: string;
        password: string;
        username: string;
    };
    initialDatabase: Omit<BaseNode, '_id' | 'physicalName'>;
    emailProvider?: EmailProviderInput;
};
export type { ConnectionLane };
export declare class WYNDB {
    pollingService: PollingService | undefined;
    /**
     * Answers the local object route in-process, for work that runs before the
     * HTTP server binds. Assigned by the host application before `start()`;
     * the driver never learns where the tenant's files live.
     */
    localS3Dispatch: LocalS3Dispatch | undefined;
    private _startPromise;
    private _initializePromise;
    private _connections;
    private _maintenanceConnections;
    private _mainBase;
    private _realtimeHub;
    private _alertEvaluator;
    alertRetracker: AlertRetracker | undefined;
    get realtimeHub(): RealtimeHub;
    /** Lazily created so the mutation hook and tests can reach it without boot wiring. */
    get alertEvaluator(): AlertEvaluator;
    get poolSizePerDb(): number;
    /**
     * How many connections one base's maintenance lane may hold.
     *
     * Two, because one was measured to be the queue's ceiling: every settle a
     * drain produces is its own short transaction on this lane, so with a single
     * connection the four actions a pass may run settle one after another
     * through it. A drain moved five jobs at one connection and twenty-five at
     * two — and raising the action cap instead made it worse, because more
     * actions only lengthened the same queue.
     *
     * The second connection is not free: it is one more per base, which is the
     * whole reason this lane is narrow, so it stays a number an installation can
     * lower. Below two a base's two queues also stop draining together, because
     * there is no connection for the second to take.
     */
    get maintenancePoolSize(): number;
    /**
     * Whether a base's two queues may drain at the same time. One question, not
     * two: each pass takes its own clone of the base, so together they need a
     * connection each — and on a single-connection lane the second would only
     * wait for the first, which measured at a fifth of running them in turn.
     */
    get drainsQueuesTogether(): boolean;
    /**
     * Not a hard ceiling: admission gives up waiting for room after a second and
     * installs anyway, so concurrent misses on distinct bases overshoot.
     */
    get maxPools(): number;
    get maxMaintenancePools(): number;
    /**
     * Clamped to the maintenance cache's capacity so a scan can never ask for
     * more pools than it holds.
     */
    get maintenanceScanConcurrency(): number;
    private cacheFor;
    /**
     * Never pass `idleTimeout`: Bun destroys connections with work still in
     * flight, abandoning the socket mid-protocol and desyncing the jsonb decoder.
     */
    createConnection(name?: string, lane?: ConnectionLane): SQL;
    /**
     * Negatives expire fast so a new base is reachable without a restart and an
     * unknown ref cannot be replayed into an unbounded stream of lookups.
     * Keyed by the caller's spelling; the value is the resolved `base.id`.
     */
    private _baseRefs;
    private readonly KNOWN_BASE_TTL_MS;
    private readonly UNKNOWN_BASE_TTL_MS;
    /**
     * Blunt on purpose: a ref resolves against three columns, so a targeted
     * delete would have to name every spelling of every base to be correct.
     */
    forgetKnownBases(): void;
    /**
     * Resolve a caller-supplied reference — `_id`, `physicalName` or `name` — to
     * the base's own `_id`. `undefined` when it names nothing live, which is
     * also the answer before initialization. Never throws: an outage must read
     * as unresolvable, not as a crash on an unauthenticated door.
     */
    resolveBaseRef(ref: string): Promise<string | undefined>;
    /**
     * Whether a ref names a live base, so an unauthenticated `/stream` cannot
     * allocate unbounded realtime shards. Never throws.
     */
    isKnownBase(ref: string): Promise<boolean>;
    /**
     * The stored definition a caller's ref names, or `null` when it names
     * nothing. The platform base resolves here like every other base: the
     * frontend addresses it by the `DATABASE` sentinel and an administrator
     * addresses it by its uuid, and a per-base switch — `allowSelfRegistration`,
     * `allowAnonymousAccess` — must not answer differently depending on which
     * spelling a URL carried.
     *
     * `MAIN_BASE_DEFINITION` is reachable only while `system.bases` has no row
     * for the platform base, which is a genuine state: `initialize()` builds the
     * base before inserting its row. It cannot be dropped, because the lookup
     * below is issued through `mainBase()` — a handler built from that same
     * literal, since reading the row otherwise needs a handler on the row.
     */
    private resolveBaseDefinition;
    base(_base: string | BaseNode, lane?: ConnectionLane): Promise<WynConnectionHandler>;
    createBase(input: BaseSchema): Promise<WynConnectionHandler>;
    updateBase(baseId: string, values: Record<string, unknown>): Promise<{
        _id: string;
        physicalName: string;
        name: string;
        immutable: (boolean | null);
        allowAnonymousAccess: (boolean | null);
        displayName: (string | null);
        description: (string | null);
        metadata: ({
            [k: string]: unknown;
        } | null);
        isSystem: (boolean | null);
        deletedAt: (string | null);
        createdAt: string;
        updatedAt: string;
        createdBy: (string | null);
        updatedBy: (string | null);
    } & Record<any, unknown>>;
    /**
     * Rows only, no connections, so listing does not depend on every listed base
     * being reachable — one gone database used to 500 every page load.
     */
    listBaseDefinitions(): Promise<BaseNode[]>;
    /**
     * Live handlers, for callers that do work *on* each base. `lane` cannot be
     * chosen afterwards: this is what opens the pools. Unopenable bases are skipped.
     */
    listBases(lane?: ConnectionLane): Promise<WynConnectionHandler[]>;
    stop(baseId: string): Promise<void>;
    readonly startTime: number;
    static instance: WYNDB | null;
    getMainBase(): WynConnectionHandler;
    private _isReady;
    get isReady(): boolean;
    get isNotReady(): boolean;
    private _isInitialized;
    get isInitialized(): boolean;
    /**
     * The error the last startup attempt died on, when that error did not mean
     * "uninitialized". Non-null makes the system report unavailable (503,
     * retryable) instead of not-initialized (which steers to first launch).
     */
    private _startupFailure;
    get isUnavailable(): boolean;
    get startupFailure(): Error | null;
    shouldBeInitialized(): Promise<void>;
    get isNotInitialized(): boolean;
    shouldNotBeInitialized(): Promise<void>;
    mainBase(): Promise<WynConnectionHandler>;
    prepare(): Promise<void>;
    /** Memoised so only one `startCall` is ever in flight. */
    start(options?: {
        onStarted?: (instance: WYNDB) => void;
    }): Promise<void>;
    private resetInternalState;
    private startCall;
    startPolling(): Promise<void>;
    /**
     * Pre-populates the per-base evaluator cache so existing alerts fire
     * immediately after a restart. Skipped under test.
     */
    startAlerts(): Promise<void>;
    /**
     * Closes a database's pools rather than merely forgetting them — forgetting
     * orphaned every discarded pool's backends for the life of the process.
     */
    resetConnection(databaseId: string): Promise<void>;
    private _pendingConnections;
    conn(databaseId?: string, lane?: ConnectionLane): Promise<Bun.SQL>;
    /**
     * The connection target with credentials stripped: `DATABASE_URL` carries a
     * password that must never reach a log line or an HTTP error body.
     */
    private describeTarget;
    /**
     * A `3D000` for a database `pg_database` lists means the two connections did
     * not reach the same cluster. More than one address here IS the answer.
     */
    private describeCluster;
    private explainMissingDatabase;
    /**
     * The cluster's own account of a `3D000`. Returns the original error
     * untouched when the maintenance connection cannot answer either.
     */
    private describeMissingDatabase;
    closeAllConnections(): Promise<void>;
    closeConn(databaseId: string): Promise<void>;
    resetDatabase(databaseId?: string): Promise<void>;
    /**
     * Full reset for test suites. Pooled connections to user DBs must be released
     * BEFORE DROP DATABASE, else PG rejects with "is being accessed by other users".
     */
    resetForTest(): Promise<void>;
    /**
     * Reads the cluster — not the in-memory flags. Mirrors the three facts
     * `prepare()` reads, so the probe cannot disagree with the boot path.
     */
    private probeInstallation;
    /**
     * Refuse a first launch colliding with an existing database: the rule is that
     * a rollback never drops a database that existed before the attempt began.
     */
    private assertBaseDatabaseIsNew;
    /**
     * For a database this process just created and no row names yet; `FORCE`
     * ends any session a failed initialization left on it.
     */
    private dropCreatedDatabase;
    /**
     * Drops only what the attempt recorded creating, never the maintenance
     * database. Best-effort: a half-failed rollback must still clear the flags.
     */
    private rollbackFailedInitialization;
    initialize(): Promise<WynConnectionHandler>;
    toggleBaseImmutability(baseId: string, immutable: boolean): Promise<void>;
    /**
     * Concurrent callers share one attempt: the gate inside `initialize()` is
     * read-then-act, so two simultaneous requests would both pass it.
     */
    initializeWithOwner(params: InstallationParams): Promise<WynConnectionHandler>;
    /**
     * A dedicated `max: 1` connection, never a pool: a session advisory lock
     * belongs to one backend, and closing that connection is what releases it.
     */
    private acquireInitializationLock;
    /**
     * Never throws: a failed close must not replace the attempt's own error, and
     * the backend going away releases the lock regardless.
     */
    private closeLockConnection;
    /**
     * The lock spans the probe, the creation and any rollback — otherwise the
     * loser of a race could roll back the winner's finished installation.
     */
    private initializeWithOwnerOnce;
    private runFirstLaunch;
    constructor();
}
declare global {
    var __wyndb__: WYNDB | undefined;
}
declare const wyndbase: WYNDB;
export default wyndbase;
