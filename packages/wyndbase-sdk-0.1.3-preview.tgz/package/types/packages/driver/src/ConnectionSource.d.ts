/**
 * `maintenance` gets its own narrow lane — two connections a base by default —
 * because its scans touch every base on a timer, which would evict
 * user-facing pools continuously.
 */
export type ConnectionLane = 'interactive' | 'maintenance';
/** Connection acquisition, as the transaction layer depends on it. */
export type ConnectionSource = {
    conn(databaseId: string, lane: ConnectionLane): Promise<Bun.SQL>;
};
