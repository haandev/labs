import type { AuditEvent, AuditFilter } from '../../types';
/**
 * Interface for audit logging (optional)
 * Logs all operations for debugging and compliance
 */
export interface AuditStore {
    /**
     * Log an audit event
     */
    log(event: AuditEvent): Promise<void>;
    /**
     * Query audit logs with filters
     */
    query(filter: AuditFilter): Promise<AuditEvent[]>;
}
