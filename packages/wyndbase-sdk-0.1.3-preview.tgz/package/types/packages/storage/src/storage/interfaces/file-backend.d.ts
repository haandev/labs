/**
 * Interface for file I/O operations (read/write/delete actual file data)
 * Files are stored by bucket + key path.
 * Versioning is a metadata-only concept handled by the store.
 */
export interface FileBackend {
    /** Write file data, returns size and etag */
    write(bucket: string, key: string, data: ReadableStream<Uint8Array>): Promise<{
        size: number;
        etag: string;
    }>;
    /** Read file data as a stream */
    read(bucket: string, key: string): Promise<ReadableStream<Uint8Array> | null>;
    /** Delete a file */
    delete(bucket: string, key: string): Promise<void>;
    /** Check if a file exists */
    exists(bucket: string, key: string): Promise<boolean>;
    /** Write a part file, returns size and etag */
    writePart(bucket: string, uploadId: string, partNumber: number, data: ReadableStream<Uint8Array>): Promise<{
        size: number;
        etag: string;
    }>;
    /** Read a part file as ArrayBuffer */
    readPart(bucket: string, uploadId: string, partNumber: number): Promise<ArrayBuffer | null>;
    /** Assemble parts into a final object file, returns etag and size */
    assembleParts(bucket: string, key: string, uploadId: string, partNumbers: number[], partETags: string[]): Promise<{
        etag: string;
        size: number;
    }>;
    /** Delete all multipart upload files */
    deleteMultipartUpload(bucket: string, uploadId: string): Promise<void>;
}
