import type { AuditStore } from './audit-store';
import type { BucketStore, VersioningBucketStore } from './bucket-store';
import type { MultipartStore } from './multipart-store';
import type { ListStore, ObjectStore, TaggingStore, VersionStore } from './object-store';
export interface StorageStore {
    audit: AuditStore;
    buckets: BucketStore & VersioningBucketStore;
    objects: ObjectStore & ListStore & TaggingStore & VersionStore;
    multipart: MultipartStore;
}
