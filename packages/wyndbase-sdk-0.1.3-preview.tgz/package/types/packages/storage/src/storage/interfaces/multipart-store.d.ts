import type { ListOptions, ObjectMetadata, Part, Upload } from '../../types';
/**
 * Interface for multipart upload metadata operations (no file I/O)
 * Actual file read/write is handled by FileBackend
 */
export interface MultipartStore {
    /** Initiate a multipart upload, returns upload ID */
    createUpload(bucket: string, key: string, metadata: Partial<ObjectMetadata>): Promise<string>;
    /** Get upload metadata (key, bucket, initiated, etc.) */
    getUpload(bucket: string, uploadId: string): Promise<{
        key: string;
        metadata: Partial<ObjectMetadata>;
    } | null>;
    /** Register a completed part's metadata (etag, size) */
    registerPart(bucket: string, uploadId: string, partNumber: number, etag: string, size: number): Promise<void>;
    /** Get registered part metadata for validation */
    getPart(bucket: string, uploadId: string, partNumber: number): Promise<{
        etag: string;
        size: number;
    } | null>;
    /** Delete upload metadata */
    deleteUpload(bucket: string, uploadId: string): Promise<void>;
    /** List all parts of a specific multipart upload */
    listParts(bucket: string, key: string, uploadId: string): Promise<Part[]>;
    /** List all in-progress multipart uploads in a bucket */
    listUploads(bucket: string, options?: ListOptions): Promise<Upload[]>;
}
