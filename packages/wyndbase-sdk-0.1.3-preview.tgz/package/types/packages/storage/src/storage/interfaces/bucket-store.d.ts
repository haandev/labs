import type { Bucket, BucketMetadata } from '../../types';
/**
 * Interface for bucket management operations
 */
export interface BucketStore {
    /**
     * Create a new bucket
     */
    create(name: string, metadata: BucketMetadata): Promise<void>;
    /**
     * Delete an existing bucket (must be empty)
     */
    delete(name: string): Promise<void>;
    /**
     * List all buckets
     */
    list(): Promise<Bucket[]>;
    /**
     * Check if a bucket exists
     */
    exists(name: string): Promise<boolean>;
    /**
     * Get bucket metadata
     */
    getMetadata(name: string): Promise<BucketMetadata | null>;
}
/**
 * Interface for bucket versioning operations
 */
export interface VersioningBucketStore {
    /**
     * Set versioning status for a bucket
     */
    setVersioning(bucket: string, status: 'Enabled' | 'Suspended'): Promise<void>;
    /**
     * Get versioning status for a bucket
     */
    getVersioning(bucket: string): Promise<'Enabled' | 'Suspended' | null>;
}
