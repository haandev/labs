import type { DeleteResult, ListObjectsResult, ListOptions, ListVersionsResult, ObjectMetadata, Tags, Version } from '../../types';
/**
 * Interface for object metadata operations (no file I/O)
 * Actual file read/write is handled by FileBackend
 */
export interface ObjectStore {
    /** Save object metadata */
    put(bucket: string, key: string, metadata: ObjectMetadata): Promise<void>;
    /** Get object metadata */
    get(bucket: string, key: string, versionId?: string): Promise<ObjectMetadata | null>;
    /** Delete object metadata */
    delete(bucket: string, key: string, versionId?: string): Promise<DeleteResult>;
    /** Get object metadata (alias for get) */
    head(bucket: string, key: string, versionId?: string): Promise<ObjectMetadata | null>;
}
/**
 * Interface for listing objects
 */
export interface ListStore {
    /**
     * List objects in a bucket
     */
    listObjects(bucket: string, options: ListOptions): Promise<ListObjectsResult>;
    /**
     * List all versions of objects in a bucket
     */
    listObjectVersions(bucket: string, options: ListOptions): Promise<ListVersionsResult>;
}
/**
 * Interface for object tagging operations
 */
export interface TaggingStore {
    /**
     * Set tags for an object
     */
    putTagging(bucket: string, key: string, tags: Tags): Promise<void>;
    /**
     * Get tags for an object
     */
    getTagging(bucket: string, key: string): Promise<Tags>;
    /**
     * Delete tags for an object
     */
    deleteTagging(bucket: string, key: string): Promise<void>;
}
/**
 * Interface for object versioning operations
 */
export interface VersionStore {
    /**
     * Create a new version for an object
     * Returns the new version ID
     */
    createVersion(bucket: string, key: string): Promise<string>;
    /**
     * List all versions of a specific object
     */
    listVersions(bucket: string, key: string): Promise<Version[]>;
    /**
     * Delete a specific version
     */
    deleteVersion(bucket: string, key: string, versionId: string): Promise<void>;
    /**
     * Create a delete marker (soft delete for versioned objects)
     * Returns the delete marker version ID
     */
    createDeleteMarker(bucket: string, key: string): Promise<string>;
}
