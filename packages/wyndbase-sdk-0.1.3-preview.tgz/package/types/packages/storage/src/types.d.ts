export * from './storage/interfaces/audit-store';
export * from './storage/interfaces/bucket-store';
export * from './storage/interfaces/file-backend';
export * from './storage/interfaces/multipart-store';
export * from './storage/interfaces/object-store';
export * from './storage/interfaces/storage-store';
export interface BucketMetadata {
    name: string;
    creationDate: string;
    versioning?: 'Enabled' | 'Suspended';
    region: string;
}
export interface Bucket {
    name: string;
    creationDate: string;
}
export interface ObjectMetadata {
    etag: string;
    size: number;
    contentType?: string;
    lastModified: string;
    metadata?: Record<string, string>;
    storageClass?: string;
    versionId?: string;
    isDeleteMarker?: boolean;
}
export interface ObjectData {
    body: ReadableStream<Uint8Array>;
    metadata: ObjectMetadata;
}
export interface PutResult {
    etag: string;
    versionId?: string;
    size?: number;
}
export interface DeleteResult {
    deleteMarker?: boolean;
    versionId?: string;
}
export interface ListOptions {
    prefix?: string;
    delimiter?: string;
    maxKeys?: number;
    continuationToken?: string;
    startAfter?: string;
    keyMarker?: string;
    versionIdMarker?: string;
}
export interface ListObjectsResult {
    objects: ObjectInfo[];
    commonPrefixes: string[];
    isTruncated: boolean;
    nextContinuationToken?: string;
    keyCount: number;
}
export interface ObjectInfo {
    key: string;
    lastModified: string;
    etag: string;
    size: number;
    storageClass: string;
}
export interface Version {
    key: string;
    versionId: string;
    isLatest: boolean;
    lastModified: string;
    etag: string;
    size: number;
    storageClass: string;
    isDeleteMarker: boolean;
}
export interface ListVersionsResult {
    versions: Version[];
    deleteMarkers: Version[];
    commonPrefixes: string[];
    isTruncated: boolean;
    nextKeyMarker?: string;
    nextVersionIdMarker?: string;
    keyCount: number;
}
export interface Tags {
    [key: string]: string;
}
export interface Part {
    partNumber: number;
    etag: string;
    size?: number;
    lastModified?: string;
}
export interface PartResult {
    etag: string;
    size: number;
}
export interface CompleteResult {
    location: string;
    bucket: string;
    key: string;
    etag: string;
    versionId?: string;
}
export interface Upload {
    key: string;
    uploadId: string;
    initiator: string;
    owner: string;
    storageClass: string;
    initiated: string;
}
export interface AuditEvent {
    timestamp: string;
    eventType: string;
    bucket: string;
    key?: string;
    versionId?: string;
    requester: string;
    requestId: string;
    statusCode: number;
    errorCode?: string;
    bytes?: number;
}
export interface AuditFilter {
    bucket?: string;
    key?: string;
    eventType?: string;
    startTime?: string;
    endTime?: string;
    requester?: string;
}
export interface ParsedS3Request {
    bucket?: string;
    key?: string;
    query: Record<string, string>;
    headers: Headers;
    method: string;
}
export interface SignatureV4Components {
    algorithm: string;
    credential: string;
    signedHeaders: string;
    signature: string;
    date: string;
}
export interface CredentialScope {
    accessKeyId: string;
    date: string;
    region: string;
    service: string;
}
export interface Credential {
    accessKeyId: string;
    secretAccessKey: string;
    allowedBuckets?: string[];
}
export declare const S3_OPERATIONS: readonly ['ListBuckets', 'CreateBucket', 'DeleteBucket', 'HeadBucket', 'GetBucketVersioning', 'PutBucketVersioning', 'PutObject', 'GetObject', 'HeadObject', 'DeleteObject', 'ListObjects', 'ListObjectsV2', 'ListObjectVersions', 'CreateMultipartUpload', 'UploadPart', 'CompleteMultipartUpload', 'AbortMultipartUpload', 'ListParts', 'ListMultipartUploads', 'PutObjectTagging', 'GetObjectTagging', 'DeleteObjectTagging', 'Unknown', '*'];
export type S3Operation = (typeof S3_OPERATIONS)[number];
export interface TenantCredential {
    accessKeyId: string;
    secretAccessKey: string;
    permissions?: S3Operation[];
    buckets?: string[];
    expiresAt?: Date;
}
export interface TenantConfig {
    tenantId: string;
    basePath: string;
    credentials: TenantCredential[];
    pathPrefix?: string;
}
export interface S3HandlerConfig {
    tenants: (TenantConfig & {
        metadataStore: import('./storage/interfaces/storage-store').StorageStore;
    })[];
}
export interface S3ServerConfig {
    storage: {
        basePath: string;
    };
    auth: {
        credentials: Credential[];
    };
    aws: {
        region: string;
    };
    server?: {
        port?: number;
        host?: string;
    };
}
