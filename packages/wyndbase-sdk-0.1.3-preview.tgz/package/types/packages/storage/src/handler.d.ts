import type { StorageStore, TenantConfig } from './types';
/** Handles a single S3 request under this tenant's config. */
export declare function handleS3Request(request: Request, tenantConfig: TenantConfig, store: StorageStore): Promise<Response>;
