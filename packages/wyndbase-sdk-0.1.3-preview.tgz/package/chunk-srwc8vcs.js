import {
  throwOnError
} from "./chunk-sr1a5ekk.js";
import {
  ERROR_SILENT_HEADER,
  NOTIFICATION_SILENT_HEADER
} from "./chunk-1vz930gy.js";
import {
  pluginName
} from "./chunk-83vjawdv.js";

// src/plugins/idp.ts
import {
  startAuthentication,
  startRegistration
} from "@simplewebauthn/browser";

// ../shared/src/registration-message.ts
var REGISTRATION_SUBMITTED_MESSAGE = "Check your inbox. If we can create an account for this address, we have sent you a link.";

// src/plugins/idp.ts
var PASSWORD_ENROLLMENT_SENT_MESSAGE = "If the account exists, a set-password link has been sent.";
function toFlowResult(data) {
  const challenge = data;
  if (challenge?.flow_required && challenge.flow_token) {
    return {
      flowRequired: true,
      flowToken: challenge.flow_token,
      next: challenge.next ?? {
        escapes: [],
        factors: [],
        mode: "verify",
        required: true
      }
    };
  }
  return { flowRequired: false };
}

class IDP {
  sdk;
  config;
  static [pluginName] = "idp";
  _settings = {
    allowedFirstFactors: ["password"],
    allowRegister: false,
    externalProviders: [],
    providers: []
  };
  _discovered = false;
  discover;
  constructor(sdk, config) {
    this.sdk = sdk;
    this.config = config;
    this.discover = this.sdk.defineQuery("discover", async () => {
      return this.discoverCall();
    });
  }
  discoverRetries = 0;
  async discoverCall(retryCount = this.discoverRetries) {
    if (this._discovered)
      return this._settings;
    try {
      const data = await this.sdk.tenant.oauth2.discover.get().then(throwOnError).then((data2) => {
        this.config?.onDiscover?.(data2);
        return data2;
      });
      this._settings = data;
      this._discovered = true;
    } catch (error) {
      if (retryCount > 0) {
        if (retryCount === this.discoverRetries)
          console.group("IDP Discovery Error");
        console.error("Failed to fetch IDP Settings. Make sure the OAuth2 server is running.", error);
        console.warn("Retrying discovery...", {
          remainingRetries: retryCount - 1
        });
        await new Promise((res) => setTimeout(res, 100));
        return this.discoverCall(retryCount - 1);
      }
      console.error("Discover IDP Settings failed after multiple retries. Returning empty settings.");
      this.config?.onDiscoverError?.(error);
    }
    if (retryCount < this.discoverRetries)
      console.groupEnd();
    return this._settings;
  }
  shouldBeDiscovered() {
    if (!this._settings)
      throw new Error("IDP settings not discovered, please call or await the async discover() first");
  }
  get settings() {
    this.shouldBeDiscovered();
    if (!this._settings)
      throw new Error("IDP settings not found");
    return this._settings;
  }
  signIn(provider, payload) {
    this.shouldBeDiscovered();
    switch (provider) {
      case "credentials":
        return this.handleCredentialsSignIn(payload);
      default:
        throw new Error(`Unsupported provider: ${provider}`);
    }
  }
  async handleCredentialsSignIn(payload) {
    const req = {
      grant_type: "flow_start",
      identifier: payload.identifier
    };
    const data = await this.sdk.auth?.tokenRequest(req).send();
    return toFlowResult(data);
  }
  async advanceFlow(payload) {
    const req = {
      code: payload.code,
      factor_type: payload.factorType,
      flow_token: payload.flowToken,
      grant_type: "flow"
    };
    const data = await this.sdk.auth?.tokenRequest(req).send();
    return toFlowResult(data);
  }
  async beginEnroll(payload) {
    const res = await this.sdk.http.post(`/${this.sdk.baseRef}/oauth2/flow/enroll`, {
      factor_type: payload.factorType,
      flow_token: payload.flowToken
    });
    return {
      challengeToken: res.data?.challengeToken,
      factorId: res.data?.factor_id,
      label: res.data?.label,
      options: res.data?.options,
      secret: res.data?.secret,
      uri: res.data?.uri
    };
  }
  async confirmFlowEnroll(payload) {
    const res = await this.sdk.http.post(`/${this.sdk.baseRef}/oauth2/flow/enroll/confirm`, {
      challenge_token: payload.challengeToken,
      code: payload.code,
      factor_id: payload.factorId,
      factor_type: payload.factorType,
      flow_token: payload.flowToken,
      label: payload.label,
      response: payload.response
    });
    const data = res.data;
    if (data && "flow_required" in data && data.flow_required) {
      return { ...toFlowResult(data), recoveryCodes: data.recovery_codes };
    }
    if (data)
      this.sdk.auth.applyTokenResponse(data);
    return {
      flowRequired: false,
      recoveryCodes: data?.recovery_codes
    };
  }
  async updateFlowPassword(payload) {
    const res = await this.sdk.http.post(`/${this.sdk.baseRef}/oauth2/flow/password/update`, {
      confirm_password: payload.confirmPassword,
      flow_token: payload.flowToken,
      new_password: payload.newPassword
    });
    const data = res.data;
    if (data && "flow_required" in data && data.flow_required) {
      return toFlowResult(data);
    }
    if (data)
      this.sdk.auth.applyTokenResponse(data);
    return { flowRequired: false };
  }
  async requestPasswordEnrollment(identifier) {
    const res = await this.sdk.http.post(`/${this.sdk.baseRef}/oauth2/password/enroll-request`, { identifier }, { headers: new Headers({ [ERROR_SILENT_HEADER]: "1" }) });
    return { message: res.data?.message ?? PASSWORD_ENROLLMENT_SENT_MESSAGE };
  }
  async register(payload) {
    const res = await this.sdk.http.post(`/${this.sdk.baseRef}/oauth2/register`, payload, { headers: new Headers({ [ERROR_SILENT_HEADER]: "1" }) });
    return { message: res.data?.message ?? REGISTRATION_SUBMITTED_MESSAGE };
  }
  async enrollPasskey(payload) {
    const setup = await this.beginEnroll(payload);
    if (!setup.options || !setup.challengeToken) {
      throw new Error("Failed to begin passkey enrollment");
    }
    const response = await startRegistration({ optionsJSON: setup.options });
    return this.confirmFlowEnroll({
      challengeToken: setup.challengeToken,
      factorType: payload.factorType,
      flowToken: payload.flowToken,
      label: payload.label ?? setup.label,
      response
    });
  }
  async registerPasskey(label) {
    const begin = await this.sdk.http.post(`/${this.sdk.baseRef}/account/factors`, { label, type: "passkey_synced" }, { headers: new Headers({ [NOTIFICATION_SILENT_HEADER]: "1" }) });
    const { challengeToken, options } = begin.data ?? {};
    if (!options || !challengeToken) {
      throw new Error("Failed to begin passkey registration");
    }
    const response = await startRegistration({ optionsJSON: options });
    const confirm = await this.sdk.http.post(`/${this.sdk.baseRef}/account/factors/passkey/confirm`, {
      challengeToken,
      label,
      response
    });
    return {
      recoveryCodes: confirm.data?.recoveryCodes,
      status: confirm.data?.status ?? "ACTIVE"
    };
  }
  async authenticatePasskey(payload) {
    const challenge = await this.sdk.http.post(`/${this.sdk.baseRef}/oauth2/flow/challenge`, {
      factor_type: payload.factorType,
      flow_token: payload.flowToken
    });
    const { challengeToken, options } = challenge.data ?? {};
    if (!options || !challengeToken) {
      throw new Error("Failed to obtain a passkey challenge");
    }
    const response = await startAuthentication({ optionsJSON: options });
    return this.advanceFlow({
      code: JSON.stringify({ challengeToken, response }),
      factorType: payload.factorType,
      flowToken: payload.flowToken
    });
  }
  async discoverableLogin() {
    const begin = await this.sdk.http.post(`/${this.sdk.baseRef}/oauth2/flow/discoverable/begin`, {});
    const { challengeToken, options } = begin.data ?? {};
    if (!options || !challengeToken) {
      throw new Error("Failed to begin discoverable login");
    }
    const response = await startAuthentication({ optionsJSON: options });
    const complete = await this.sdk.http.post(`/${this.sdk.baseRef}/oauth2/flow/discoverable/complete`, {
      challengeToken,
      client_id: this.sdk.auth.clientId,
      response
    });
    const data = complete.data;
    if (data && "flow_required" in data && data.flow_required) {
      return toFlowResult(data);
    }
    if (data)
      this.sdk.auth.applyTokenResponse(data);
    return { flowRequired: false };
  }
  async beginProviderSignIn(providerId, options) {
    this.shouldBeDiscovered();
    const res = await this.sdk.http.post(`/${this.sdk.baseRef}/oauth2/federated/${encodeURIComponent(providerId)}/begin`, options?.returnTo ? { return_to: options.returnTo } : {});
    const authorizeUrl = res.data?.authorize_url;
    if (!authorizeUrl) {
      throw new Error("Provider sign-in could not be started");
    }
    return { authorizeUrl };
  }
  async completeFederatedSession() {
    try {
      const data = await this.sdk.auth.tokenRequest({
        grant_type: "refresh_token"
      }).send();
      return !!data?.access_token;
    } catch {
      return false;
    }
  }
  get getFactors() {
    return this.sdk.defineQuery("getFactors", (context) => this.sdk.tenant.account.factors.get({ fetch: { signal: context.signal } }).then(throwOnError), undefined, undefined, this.sdk.baseRef);
  }
  get deleteFactor() {
    return this.sdk.defineMutation((id) => this.sdk.tenant.account.factors({ id }).delete().then(throwOnError).then(async (data) => {
      await this.getFactors().invalidate();
      return data;
    }));
  }
  get verifyFactor() {
    return this.sdk.defineMutation((id, code) => this.sdk.tenant.account.factors({ id }).verify.post({ code }).then(throwOnError).then(async (data) => {
      await this.getFactors().invalidate();
      return data;
    }));
  }
  get setupTotpFactor() {
    return this.sdk.defineMutation(() => this.sdk.tenant.account.factors.post({ type: "totp" }, { fetch: { headers: { [NOTIFICATION_SILENT_HEADER]: "1" } } }).then(throwOnError).then(async (data) => {
      await this.getFactors().invalidate();
      return data;
    }));
  }
  get resumeTotpFactor() {
    return this.sdk.defineMutation((id) => this.sdk.tenant.account.factors({ id }).enrollment.get().then(throwOnError));
  }
  get regenerateRecoveryCodes() {
    return this.sdk.defineMutation(() => this.sdk.tenant.account["recovery-codes"].post().then(throwOnError).then(async (data) => {
      await this.getFactors().invalidate();
      return { recoveryCodes: data?.codes ?? [] };
    }));
  }
  get getAccountSessions() {
    return this.sdk.defineQuery("getAccountSessions", () => this.sdk.wql("system.listMySessions", undefined, {
      overrideBaseId: this.sdk.baseRef
    }).fetch(), undefined, undefined, this.sdk.baseRef);
  }
  get revokeAccountSession() {
    return this.sdk.defineMutation((sessionId) => this.sdk.tenant.account.settings.sessions({ sessionId }).delete().then(throwOnError).then(async (data) => {
      await this.getAccountSessions().invalidate();
      return data;
    }));
  }
  get revokeAllSessionsMutation() {
    return this.sdk.defineMutation(() => this.sdk.tenant.account.settings.sessions.all.delete().then(throwOnError).then(async (data) => {
      await this.getAccountSessions().invalidate();
      return data;
    }));
  }
  get updateAccountPassword() {
    return this.sdk.defineMutation((currentPassword, newPassword, confirmPassword) => this.sdk.tenant.account.settings.password.change.post({
      confirmPassword,
      currentPassword,
      newPassword
    }).then(throwOnError));
  }
  get setAccountPassword() {
    return this.sdk.defineMutation((newPassword, confirmPassword) => this.sdk.tenant.account.settings.password.set.post({ confirmPassword, newPassword }).then(throwOnError).then(async (data) => {
      await this.getFactors().invalidate();
      return data;
    }));
  }
}

export { PASSWORD_ENROLLMENT_SENT_MESSAGE, IDP };

//# debugId=81D781078FD4E6B964756E2164756E21
