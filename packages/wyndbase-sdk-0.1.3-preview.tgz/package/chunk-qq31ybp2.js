// src/util/parseFormDataJson.ts
function parseFormDataJson(formData) {
  const obj = {};
  formData.forEach((value, key) => {
    if (obj[key] !== undefined) {
      if (!Array.isArray(obj[key])) {
        obj[key] = [obj[key]];
      }
      obj[key].push(value);
    } else {
      obj[key] = value;
    }
  });
  return obj;
}

export { parseFormDataJson };

//# debugId=401F38BA9325980C64756E2164756E21
