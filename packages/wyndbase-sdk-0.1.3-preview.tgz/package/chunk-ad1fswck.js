// src/step-up-challenge.ts
function createStepUpChallenge() {
  let waiters = [];
  let aal = 0;
  const isPending = () => waiters.length > 0;
  const request = (requiredAal) => {
    if (waiters.length === 0)
      aal = requiredAal;
    return new Promise((resolve) => {
      waiters.push({ aal: requiredAal, resolve });
    });
  };
  return {
    isPending,
    join(requiredAal, open) {
      const opening = !isPending();
      const settled = request(requiredAal);
      if (opening)
        open();
      return settled;
    },
    settle(cleared) {
      const pending = waiters;
      const reached = aal;
      waiters = [];
      aal = 0;
      for (const waiter of pending)
        waiter.resolve(cleared && waiter.aal <= reached);
    }
  };
}

export { createStepUpChallenge };

//# debugId=0F92844D55A987AA64756E2164756E21
